/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 10, 2011 6:56:21 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ConfigurationFolderReader {
  /** The Constant XML_PACKAGE. */
  private static final String XML_PACKAGE = "com.st.scc.config";

  /**
   * Instantiates a new configuration folder reader.
   */
  public ConfigurationFolderReader() {

  }

  /**
   * Read XML file.
   * 
   * @param file
   *          the file
   * @return the configuration folder list
   * @throws Exception
   *           the exception
   */
  public List<TConfigurationFolder> read(final File file) throws Exception {
    List<TConfigurationFolder> list = new ArrayList<TConfigurationFolder>();
    InputStream inputStream = null;
    try {
      inputStream = new FileInputStream(file);
      final ClassLoader classLoader = getClass().getClassLoader();
      final URL schemaUrl = classLoader.getResource("scc-config-folder-schema.xsd");
      Schema schema = null;
      if (schemaUrl != null) {
        final SchemaFactory schemaFactory =
            SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        schema = schemaFactory.newSchema(schemaUrl);
      }
      final TConfigurationFolderList folderList = readData(inputStream, schema);
      if (folderList != null) {
        list = folderList.getConfigurationFolder();
      }
    } catch (final Exception e) {
      throw e;
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          throw e;
        }
      }
    }
    return list;
  }

  /**
   * Read data.
   * 
   * @param inputStream
   *          the input stream
   * @param schema
   *          the schema
   * @return the configuration folder list
   * @throws JAXBException
   *           the JAXB exception
   */
  @SuppressWarnings("unchecked")
  private TConfigurationFolderList readData(final InputStream inputStream, final Schema schema)
      throws JAXBException {
    TConfigurationFolderList data = null;
    // Create StreamSource
    final StreamSource streamSource = new StreamSource(inputStream);
    final JAXBContext context = JAXBContext.newInstance(XML_PACKAGE);
    final Unmarshaller unmarshaller = context.createUnmarshaller();
    if (schema != null) {
      unmarshaller.setSchema(schema);
    }
    final Object object = unmarshaller.unmarshal(streamSource);
    if (object instanceof TConfigurationFolder) {
      data = (TConfigurationFolderList) object;
    } else if (object instanceof JAXBElement) {
      data = ((JAXBElement<TConfigurationFolderList>) object).getValue();
    }
    return data;
  }
}
