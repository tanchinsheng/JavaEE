/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 11, 2011 2:38:39 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.config;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileTypeEnum;
import com.st.common.exception.SccException;
import com.st.scc.common.utils.PropertiesUtil;
import com.st.scc.filewatcher.FileWatcherInfo;

/**
 * The Class ConfigLoader.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ConfigLoader {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ConfigLoader.class);

  /** The Constant FOLDERS_KEY. */
  private static final String FOLDERS_KEY = "SCCFolders";

  /** The Constant VERSION_KEY. */
  public static final String VERSION_KEY = "Version";

  /** The Constant SMDB_KEY. */
  public static final String SMDB_KEY = "SMDB";

  /** The Constant SCCDB_KEY. */
  public static final String SCCDB_KEY = "SCCDB";

  /** The Constant SCDB_KEY. */
  public static final String SCDB_KEY = "SCDB";

  /** The Constant APCD_KEY. */
  public static final String APCD_KEY = "APCD";

  /** The Constant WMRDB_KEY. */
  public static final String WMRDB_KEY = "WMRDB";

  /** The Constant INTERVAL_TIME_KEY. */
  public static final String INTERVAL_TIME_KEY = "IntervalTime";

  /** The Constant MAX_SIZE_NOTIFY_KEY. */
  public static final String MAX_SIZE_NOTIFY_KEY = "MaxSizeNotify";

  /** The Constant STDF_FOLDER. */
  public static final String STDF_FOLDER = "STDFFolder";

  /** The Constant STDF_ARCHIVE_FOLDER. */
  public static final String STDF_ARCHIVE_FOLDER = "STDFArchiveFolder";

  /** The Constant STDF_ERROR_FOLDER. */
  public static final String STDF_ERROR_FOLDER = "STDFErrorFolder";

  /** The Constant XML_FOLDER. */
  public static final String XML_FOLDER = "XMLFolder";

  /** The Constant XML_ARCHIVE_FOLDER. */
  public static final String XML_ARCHIVE_FOLDER = "XMLArchiveFolder";

  /** The Constant XML_ERROR_FOLDER. */
  public static final String XML_ERROR_FOLDER = "XMLErrorFolder";

  /** The Constant ANALYSIS_RETRY_TIME. */
  public static final String ANALYSIS_RETRY_TIME = "analysis-retry-time";

  /** The Constant ANALYSIS_DELAY_TIME. */
  public static final String ANALYSIS_DELAY_TIME = "analysis-delay-time";

  /** The Constant DEFAULT_INTERVAL_TIME. */
  private static final int DEFAULT_INTERVAL_TIME = 60;

  /** The Constant INSTANCE. */
  private static final ConfigLoader INSTANCE = new ConfigLoader();

  /**
   * Gets the single instance of ConfigLoader.
   * 
   * @return single instance of ConfigLoader
   */
  public static ConfigLoader getInstance() {
    return INSTANCE;
  }

  /** The extractor config file path. */
  private String extractorConfigFilePath;

  /** The folders file path. */
  private String foldersFilePath;

  /** The config path. */
  private String configPath;

  /** The configuration map. */
  private final Map<String, String> configurationMap;

  /** The configuration folder map. */
  private final Map<String, FolderInfo> folderMap;

  /** The file watcher info. */
  private final FileWatcherInfo fileWatcherInfo;

  /** The extractor config file time. */
  private long extractorConfigFileTime = 0;

  /** The folders file time. */
  private long foldersFileTime = 0;

  /** The interval time. */
  private int intervalTime = DEFAULT_INTERVAL_TIME;

  /** The version. */
  private String version = "";

  /**
   * Instantiates a new config loader.
   */
  private ConfigLoader() {
    configurationMap = new HashMap<String, String>();
    folderMap = new HashMap<String, FolderInfo>();
    fileWatcherInfo = new FileWatcherInfo();
  }

  /**
   * Gets the configuration value.
   * 
   * @param name
   *          the name
   * @return the configuration value
   */
  public String getConfigurationValue(final String name) {
    final String value = configurationMap.get(name);
    return value != null ? value : "";
  }

  /**
   * Gets the file.
   * 
   * @param fileName
   *          the file name
   * @return the file
   */
  public File getFile(final String fileName) {
    final File file = new File(configPath + File.separator + fileName);
    return file;
  }

  /**
   * Gets the file watcher info.
   * 
   * @return the file watcher info
   */
  public FileWatcherInfo getFileWatcherInfo() {
    return fileWatcherInfo;
  }

  /**
   * Gets the configuration folder.
   * 
   * @param name
   *          the name
   * @return the folder
   */
  public FolderInfo getFolder(final String name) {
    return folderMap.get(name);
  }

  /**
   * Gets the interval time.
   * 
   * @return the interval time
   */
  public int getIntervalTime() {
    return intervalTime;
  }

  /**
   * Gets the version.
   * 
   * @return the version
   */
  public String getVersion() {
    return version;
  }

  /**
   * Load configure.
   * 
   * @param file
   *          the file
   * @throws SccException
   *           the SCC exception
   */
  private void loadConfigure(final File file) throws SccException {
    LOG.info("Loading configuration: " + file.getAbsolutePath());
    final ConfigurationReader configurationReader = new ConfigurationReader();
    if (configPath != null) {
      configurationReader.setConfigFolder(configPath);
    }

    try {
      final Map<String, String> map = configurationReader.read(file);
      if (map != null) {
        configurationMap.putAll(map);
      }
    } catch (final Exception e) {
      throw new SccException(e);
    }

    final String tmpConfigFolders = getConfigurationValue(FOLDERS_KEY);
    if (!tmpConfigFolders.equals(foldersFilePath)) {
      foldersFilePath = tmpConfigFolders;
      if (tmpConfigFolders.length() > 0) {
        final File foldersfile = new File(tmpConfigFolders);
        if (file.exists()) {
          loadFolderConfig(foldersfile);
        }
      }
    } else {
      reloadFoldersConfig();
    }

    final String intervalSecond = getConfigurationValue(INTERVAL_TIME_KEY);
    // get interval-second from file *.xml
    if (intervalSecond == null || intervalSecond.length() == 0) {
      // return default value
      intervalTime = DEFAULT_INTERVAL_TIME;
    } else {
      try {
        intervalTime = Integer.parseInt(intervalSecond);
      } catch (final NumberFormatException ex) {
        intervalTime = DEFAULT_INTERVAL_TIME;
      }
    }

    final String pathVersionFile = getConfigurationValue(VERSION_KEY);
    if (pathVersionFile.length() > 0) {
      final File versionFile = new File(pathVersionFile);
      if (versionFile.exists()) {
        version = readVersion(versionFile);
      } else {
        LOG.warn("File {} doesn't exist", versionFile.getAbsolutePath());
      }
    }

    extractorConfigFileTime = file.lastModified();
  }

  /**
   * Load folder config.
   * 
   * @param file
   *          the file
   * @throws SccException
   *           the SCC exception
   */
  private void loadFolderConfig(final File file) throws SccException {
    LOG.info("Loading folders configuration: " + file.getAbsolutePath());
    try {
      final ConfigurationFolderReader configFolderReader = new ConfigurationFolderReader();
      final List<TConfigurationFolder> list = configFolderReader.read(file);
      updateFolders(list);
    } catch (final Exception e) {
      throw new SccException(e);
    }
    foldersFileTime = file.lastModified();
  }

  /**
   * Read version.
   * 
   * @param file
   *          the file
   * @return the string
   */
  private String readVersion(final File file) {
    final Properties properties = new Properties();
    PropertiesUtil.load(properties, file);
    final String retVal = properties.getProperty("version", "");
    return retVal;
  }

  /**
   * Reload config.
   * 
   * @return true, if successful
   * @throws SccException
   *           the SCC exception
   */
  public synchronized boolean reload() throws SccException {
    boolean refresh = false;
    if (extractorConfigFilePath == null) {
      throw new SccException(
          "Not found config file. Must set config file before calling this function.");
    }

    final File file = new File(extractorConfigFilePath);
    if (!file.exists()) {
      throw new SccException("Configuration file doesn't not exist. File: "
          + file.getAbsolutePath());
    }
    if (file.lastModified() != extractorConfigFileTime) {
      loadConfigure(file);
      refresh = true;
    }
    return refresh;
  }

  /**
   * Reload folders config.
   * 
   * @return true, if successful
   * @throws SccException
   *           the SCC exception
   */
  public synchronized boolean reloadFoldersConfig() throws SccException {
    boolean refresh = false;
    if (foldersFilePath == null) {
      throw new SccException(
          "Not found config file. Must set config file before calling this function.");
    }

    final File file = new File(foldersFilePath);
    if (!file.exists()) {
      throw new SccException("Folders configuration file doesn't not exist. File: "
          + file.getAbsolutePath());
    }
    if (file.lastModified() != foldersFileTime) {
      loadFolderConfig(file);
      refresh = true;
    }
    return refresh;
  }

  /**
   * Sets the config path.
   * 
   * @param configPath
   *          the new config path
   */
  public void setConfigPath(final String configPath) {
    this.configPath = configPath;
  }

  /**
   * Sets the extractor config file path.
   * 
   * @param extractorConfigFilePath
   *          the new extractor config file path
   */
  public void setExtractorConfigFilePath(final String extractorConfigFilePath) {
    this.extractorConfigFilePath = extractorConfigFilePath;
  }

  /**
   * Sets the folders file path.
   * 
   * @param foldersFilePath
   *          the new folders file path
   */
  public void setFoldersFilePath(final String foldersFilePath) {
    this.foldersFilePath = foldersFilePath;
  }

  /**
   * To folder info.
   * 
   * @param cf
   *          the configuration folder
   * @return the folder info
   */
  private FolderInfo toFolderInfo(final TConfigurationFolder cf) {
    final FolderInfo folderInfo = new FolderInfo();
    if (cf.getFolderType() != null && cf.getFolderType().getValue() != null) {
      folderInfo.setFolderType(FileTypeEnum.fromValue(cf.getFolderType().getValue().name()));
    }
    if (cf.getFolder() != null) {
      folderInfo.setFolder(cf.getFolder().getValue());
    }
    if (cf.getFileType() != null) {
      folderInfo.setFileType(cf.getFileType().getValue());
    }
    if (cf.getDepthFolder() != null) {
      folderInfo.setDepthFolder(cf.getDepthFolder().getValue());
    }
    final FileTypeEnum folderType = folderInfo.getFolderType();
    if (folderType != null && folderType != FileTypeEnum.NFS) {
      if (cf.getFileServer() != null) {
        folderInfo.setFileServer(cf.getFileServer().getValue());
      }
      if (cf.getUserName() != null) {
        folderInfo.setUserName(cf.getUserName().getValue());
      }
      if (cf.getPassword() != null) {
        folderInfo.setPassword(cf.getPassword().getValue());
      }
      if (cf.getPort() != null) {
        folderInfo.setPort(cf.getPort().getValue());
      }
    }
    return folderInfo;
  }

  /**
   * Update folders.
   * 
   * @param list
   *          the configuration folder list
   * @throws SccException
   *           the SCC exception
   */
  private void updateFolders(final List<TConfigurationFolder> list) throws SccException {
    folderMap.clear();
    for (final TConfigurationFolder configurationFolder : list) {
      final String name = configurationFolder.getName();
      folderMap.put(name, toFolderInfo(configurationFolder));
      if (name.equals(fileWatcherInfo.getFolderName())) {
        fileWatcherInfo.loadConfigureWatcher(configurationFolder,
            getConfigurationValue(MAX_SIZE_NOTIFY_KEY));
      }
    }
  }
}
