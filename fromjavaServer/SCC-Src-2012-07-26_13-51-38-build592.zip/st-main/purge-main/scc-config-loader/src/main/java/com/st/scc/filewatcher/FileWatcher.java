/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 3, 2011 2:01:50 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.scc.filewatcher;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.fileaccess.FileScanner;
import com.st.common.fileaccess.FileScannerFactory;
import com.st.common.mail.EmailNotification;
import com.st.common.mail.EmailNotification.ErrorMailEnum;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class FileWatcher {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileWatcher.class);

  /** The file watcher info. */
  private FileWatcherInfo fileWatcherInfo;

  /**
   * Instantiates a new file watcher.
   * 
   * @param fileWatcherInfo
   *          the file watcher info
   */
  public FileWatcher(final FileWatcherInfo fileWatcherInfo) {
    this.fileWatcherInfo = fileWatcherInfo;
  }

  /**
   * Notify new file.
   *
   * @return the files in monitor folder
   */
  public List<FileInfo> getFilesInMonitorFolder() {
    final FileTypeEnum monitorType = fileWatcherInfo.getMonitorType();
    final String monitorFolder = fileWatcherInfo.getMonitorFolder();

    if (monitorType == null) {
      LOG.error("Started notify new file is failed because monitor_type is undefined");
      return null;
    }
    if (monitorFolder == null) {
      LOG.error("Started notify new file is failed because monitor_folder is undefined");
      return null;
    }

    List<FileInfo> list = null;
    final EmailNotification emailNotification = EmailNotification.getInstance();
    final FileScanner fileScanner =
        FileScannerFactory.create(monitorType, fileWatcherInfo.getHost(),
            fileWatcherInfo.getUserName(), fileWatcherInfo.getPassword(),
            fileWatcherInfo.getPort());
    if (fileScanner != null) {
      fileScanner.setFilePatternList(fileWatcherInfo.getListFileType());
      fileScanner.setMonitorFolder(fileWatcherInfo.getMonitorFolder());

      list =
          fileScanner.scan(monitorFolder, fileWatcherInfo.getDepthFolder(),
              fileWatcherInfo.getMaxSizeFile());
      if (list != null) {
        emailNotification.resetOTM(ErrorMailEnum.FILE_ACCESS_ERROR);
      } else {
        final String message =
            "Could not access monitor folder " + monitorFolder + " on " + monitorType;
        LOG.error(message);
        emailNotification.sendOTM(ErrorMailEnum.FILE_ACCESS_ERROR, message);
      }
      fileScanner.disconnect();
      emailNotification.resetOTM(ErrorMailEnum.FILE_ACCESS_CONNECTION_ERROR);
    } else {
      final String message =
          "Could not create connection to access monitor folder " + monitorFolder + " on "
              + monitorType;
      LOG.error(message);
      emailNotification.sendOTM(ErrorMailEnum.FILE_ACCESS_CONNECTION_ERROR, message);
    }
    return list;
  }

  /**
   * Gets the file watcher info.
   * 
   * @return the file watcher info
   */
  public FileWatcherInfo getFileWatcherInfo() {
    return fileWatcherInfo;
  }

  /**
   * Sets the file watcher info.
   * 
   * @param fileWatcherInfo
   *          the new file watcher info
   */
  public void setFileWatcherInfo(final FileWatcherInfo fileWatcherInfo) {
    this.fileWatcherInfo = fileWatcherInfo;
  }

}
