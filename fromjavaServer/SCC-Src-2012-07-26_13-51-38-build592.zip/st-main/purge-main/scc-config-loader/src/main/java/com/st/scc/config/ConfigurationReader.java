/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 10, 2011 6:20:26 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

/**
 * The Class ConfigurationReader.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ConfigurationReader {

  /** The Constant SHARE_CONFIG_FOLDER. */
  public static final String SHARE_CONFIG_FOLDER = "ConfigFolder";

  /** The Constant XML_PACKAGE. */
  private static final String XML_PACKAGE = "com.st.scc.config";

  /** The config folder. */
  private String configFolder;

  /**
   * Instantiates a new configuration reader.
   */
  public ConfigurationReader() {

  }

  /**
   * Gets the config folder.
   * 
   * @return the config folder
   */
  public String getConfigFolder() {
    return configFolder;
  }

  /**
   * Put configuration.
   * 
   * @param configuration
   *          the configuration
   * @param map
   *          the map
   */
  private void putConfiguration(final TConfiguration configuration,
      final Map<String, String> map) {
    if (configuration != null) {
      final String separator = File.separator;
      if (configFolder == null) {
        configFolder = "conf" + separator;
      }
      if (!configFolder.endsWith(separator)) {
        configFolder += separator;
      }

      final List<TParameter> parameters = configuration.getParameter();
      String shareConfigFolder = null;
      for (final TParameter parameter : parameters) {
        if (SHARE_CONFIG_FOLDER.equals(parameter.getName())) {
          shareConfigFolder = parameter.getValue();
          break;
        }
      }

      if (shareConfigFolder == null) {
        shareConfigFolder = configFolder;
      }
      if (!shareConfigFolder.endsWith(separator)) {
        shareConfigFolder += separator;
      }

      for (final TParameter parameter : parameters) {
        final String key = parameter.getName();
        String value = parameter.getValue();
        final TType type = parameter.getType();
        if (type == TType.SHARED_FILE) {
          value = shareConfigFolder + value;
        } else if (type == TType.LOCAL_FILE) {
          value = configFolder + value;
        }
        map.put(key, value);
      }
    }
  }

  /**
   * Read XML configuration file.
   * 
   * @param file
   *          the file
   * @return the map
   * @throws Exception
   *           the exception
   */
  public Map<String, String> read(final File file) throws Exception {
    final Map<String, String> map = new LinkedHashMap<String, String>();
    InputStream inputStream = null;
    try {
      final ClassLoader classLoader = getClass().getClassLoader();
      final URL schemaUrl = classLoader.getResource("scc-config-schema.xsd");
      Schema schema = null;
      if (schemaUrl != null) {
        final SchemaFactory schemaFactory =
            SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        schema = schemaFactory.newSchema(schemaUrl);
      }
      inputStream = new FileInputStream(file);
      final TConfiguration configuration = readData(inputStream, schema);
      putConfiguration(configuration, map);
    } catch (final Exception e) {
      throw e;
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          throw e;
        }
      }
    }
    return map;
  }

  /**
   * Read data.
   * 
   * @param inputStream
   *          the input stream
   * @param schema
   *          the schema
   * @return the configuration
   * @throws JAXBException
   *           the JAXB exception
   */
  @SuppressWarnings("unchecked")
  private TConfiguration readData(final InputStream inputStream, final Schema schema)
      throws JAXBException {
    TConfiguration data = null;
    // Create StreamSource
    final StreamSource streamSource = new StreamSource(inputStream);
    final JAXBContext context = JAXBContext.newInstance(XML_PACKAGE);
    final Unmarshaller unmarshaller = context.createUnmarshaller();
    if (schema != null) {
      unmarshaller.setSchema(schema);
    }
    final Object object = unmarshaller.unmarshal(streamSource);
    if (object instanceof TConfiguration) {
      data = (TConfiguration) object;
    } else if (object instanceof JAXBElement) {
      data = ((JAXBElement<TConfiguration>) object).getValue();
    }
    return data;
  }

  /**
   * Sets the config folder.
   * 
   * @param configFolder
   *          the new config folder
   */
  public void setConfigFolder(final String configFolder) {
    this.configFolder = configFolder;
  }

}
