/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 10, 2011 4:59:18 PM - duytv - Initialize version
/********************************************************************************/
package com.st.scc.purge;

import java.sql.Timestamp;

import com.st.persistence.SQLExecutor;
import com.st.persistence.service.actionlog.ActionLog;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ActionLogService {

  /** Purge author. */
  private static final String PURGE_AUTHOR = "purge";
  /** Purge db. */
  private static final String PURGE_DB = "Purge DB";


  /**
   * Tracking purge table.
   * 
   * @param exe
   *          executor.
   * @param tableName
   *          table name.
   * @param deletedRecords
   *          record is deleted.
   * @param elapsedTime
   *          elapsed time.
   * @param when
   *          is time for writing log.
   */
  public void trackingPurgeTable(final SQLExecutor exe, final String tableName,
      final int deletedRecords, final long elapsedTime, final Timestamp when) {
    if (deletedRecords > 0) {
      ActionLog.getInstance().insertTracking(null, exe, PURGE_AUTHOR, PURGE_DB, elapsedTime,
          tableName + ": " + deletedRecords + " records deleted" + "; when: " + when);
    }
  }

  /**
   * Tracking xml file deleted.
   * 
   * @param exe
   *          is executor.
   * @param deletedFileCount
   *          count all files deleted.
   * @param elapsedTime
   *          elapsed time.
   * @param when
   *          is time for writing log.
   * @param dbname is name of db.
   * 
   */

  public void trackingPurgeAction(final SQLExecutor exe, final int deletedFileCount,
      final long elapsedTime, final Timestamp when, final String dbname) {
    if (deletedFileCount > 0) {
      ActionLog.getInstance().insertTracking(dbname, exe, PURGE_AUTHOR, dbname,
          elapsedTime,
          deletedFileCount + " " + dbname + " file deleted" + "; when: " + when);
    }
  }
}
