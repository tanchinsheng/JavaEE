/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 10:40:53 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.purge.file;

import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Session;
import com.st.common.beans.FileTypeEnum;
import com.st.common.config.FolderInfo;
import com.st.scc.common.utils.FTPUtil;
import com.st.scc.common.utils.SFTPUtils;
import com.st.scc.purge.file.impl.FileDeletionFTP;
import com.st.scc.purge.file.impl.FileDeletionNFS;
import com.st.scc.purge.file.impl.FileDeletionSFTP;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public final class FileDeletionFactory {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileDeletionFactory.class);

  /**
   * Creates the file deletion object.
   * 
   * @param folderInfo
   *          the folder info
   * @return the file deletion
   */
  public static FileDeletion create(final FolderInfo folderInfo) {
    final FileTypeEnum fileType = folderInfo.getFolderType();
    final String host = folderInfo.getFileServer();
    final String userName = folderInfo.getUserName();
    final String password = folderInfo.getPassword();
    final int port = folderInfo.getPort();

    FileDeletion fileDeletion = null;
    if (fileType != null) {
      switch (fileType) {
      case NFS:
        final FileDeletionNFS nfs = new FileDeletionNFS();
        nfs.setFolderInfo(folderInfo);
        fileDeletion = nfs;
        break;

      case FTP:
        final FileDeletionFTP ftp = new FileDeletionFTP();
        final FTPClient ftpClient = FTPUtil.connectFTP(host, userName, password, port);
        if (ftpClient != null && ftpClient.isConnected()) {
          ftp.setFtp(ftpClient);
          ftp.setFolderInfo(folderInfo);
          fileDeletion = ftp;
        }
        break;

      case SFTP:
        final FileDeletionSFTP sftp = new FileDeletionSFTP();
        final Session session = SFTPUtils.createSession(host, userName, password, port);
        if (session != null && session.isConnected()) {
          sftp.setSession(session);
          sftp.setFolderInfo(folderInfo);
          fileDeletion = sftp;
        }
        break;

      default:
        LOG.warn("Un-support file type [{}]", fileType);
        break;
      }
    } else {
      LOG.warn("FileType is null");
    }
    return fileDeletion;
  }

  /**
   * Instantiates a new file deletion factory.
   */
  private FileDeletionFactory() {

  }
}
