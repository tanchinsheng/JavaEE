/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 29, 2011 2:09:01 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.purge;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.purge.config.TPurge;
import com.st.purge.config.TTimeUnit;
import com.st.scc.utils.PurgeUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public abstract class AbsPurge implements Runnable, IPurge {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(AbsPurge.class);

  /** Second to millisecond. */
  protected static final long SECOND_TO_MILLISECOND = 1000;

  /**
   * get tag purge from xml.
   */
  protected TPurge tpurge;

  /** scheduler of purge DB. */
  protected ScheduledExecutorService scheduler = null;

  protected long intervalTime;

  protected AbsPurge(final TPurge tpurge) {
    this.tpurge = tpurge;

    startScheduler(true);
  }

  private void startScheduler(boolean isFirstStart) {
    LOG.info("Start purge " + tpurge.getName());

    PurgeUtils purgeUtil = PurgeUtils.getInstance();
    final Date startTime = purgeUtil.getStartTime();
    intervalTime = purgeUtil.getIntervalTime() * 60;
    if (intervalTime == 0) {
      LOG.error("Can't load intervaltime of purge");
      return;
    }
    scheduler = Executors.newScheduledThreadPool(1);
    TTimeUnit time = null;
    time = time == null ? TTimeUnit.DAYS : time;
    if (time == TTimeUnit.DAYS) {
      long delay = 0;
      if (isFirstStart) {
        delay = (startTime.getTime() - System.currentTimeMillis()) / SECOND_TO_MILLISECOND;
      }
      scheduler.scheduleWithFixedDelay(this, delay, intervalTime, TimeUnit.SECONDS);
    } else {
      scheduler.scheduleWithFixedDelay(this, 0, intervalTime, TimeUnit.SECONDS);
    }
    Runtime.getRuntime().addShutdownHook(new PurgeShutdown(scheduler, tpurge.getName()));
  }

  private void shutdownScheduler() {
    new PurgeShutdown(scheduler, tpurge.getName()).run();
  }

  private void restartScheduler() {
    if (scheduler != null) {
      shutdownScheduler();
    }
    LOG.info("Restart purge " + tpurge.getName());
    startScheduler(false);
  }

  private boolean checkIntervalTimeToRestart() {
    //Reload all config of purge.
    PurgeUtils.getInstance().reload();
    final long newIntervalTime = PurgeUtils.getInstance().getIntervalTime() * 60;
    if (newIntervalTime != intervalTime) {
      restartScheduler();
      return true;
    }
    return false;
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.lang.Runnable#run()
   */
  public void run() {
    if (checkIntervalTimeToRestart()) {
      return;
    }
    executor();
  }

  /**
   * subtract days.
   * 
   * @param time
   *          is time.
   * @param days
   *          is year for subtracting.
   * @return timestamp.
   */
  public Timestamp addDays(final Timestamp time, final int days) {
    Calendar cal = getCalendar(time);
    cal.add(Calendar.DAY_OF_YEAR, getNegative(days));
    return getTimestamp(cal);
  }

  /**
   * Convert timestamp to calendar.
   * 
   * @param time
   *          is timestamp.
   * @return calendar.
   */
  private Calendar getCalendar(final Timestamp time) {
    Calendar cal = Calendar.getInstance();
    if (time == null) {
      return cal;
    }
    cal.setTimeInMillis(time.getTime());
    return cal;
  }

  /**
   * Convert cal to timestamp.
   * 
   * @param cal
   *          is calendar.
   * @return timestamp.
   */
  private Timestamp getTimestamp(final Calendar cal) {
    Timestamp time = null;
    if (cal == null) {
      time = new Timestamp(System.currentTimeMillis());
    } else {
      time = new Timestamp(cal.getTimeInMillis());
    }
    return time;
  }

  /**
   * get negative.
   * 
   * @param n
   *          is number
   * @return negative of n.
   */
  private int getNegative(final int n) {
    return (-n);
  }

}
