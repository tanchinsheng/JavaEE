/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 10:38:16 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.purge.file;

import java.util.List;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public interface FileDeletion {
  /**
   * Delete files.
   * 
   * @param folder
   *          the folder
   * @param depth
   *          the depth
   * @param lastModified
   *          the last modified time
   * @return true, if successful
   */
  boolean deleteFiles(final String folder, final int depth, final long lastModified);

  /**
   * Delete folders.
   * 
   * @param folder
   *          the folder
   * @param depth
   *          the depth
   * @param lastModified
   *          the last modified time
   * @return true, if successful
   */
  boolean deleteFolders(final String folder, final int depth, final long lastModified);

  /**
   * Disconnect and release resources.
   */
  void disconnect();

  /**
   * Gets the number of file deleted.
   * 
   * @return the number of file deleted
   */
  int getNumOfFileDelete();

  /**
   * Checks if is first write.
   * 
   * @return true, if is first write
   */
  boolean isFirstWrite();

  /**
   * Sets the CVS name.
   * 
   * @param cvsName
   *          the new CVS name
   */
  void setCvsName(String cvsName);

  /**
   * Sets the file type list.
   * 
   * @param fileTypeList
   *          the new file type list
   */
  void setFileTypeList(final List<String> fileTypeList);

  /**
   * Sets the purge name.
   * 
   * @param purgeName
   *          the new purge name
   */
  void setPurgeName(String purgeName);
}
