/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 9, 2011 2:33:45 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.utils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ConstantPurge {
	/**
	 * Constructor default.
	 */
	private ConstantPurge() {
	}

	/** Path to folder current. */
	public static final String DIR = System.getProperty("user.dir").replaceAll(
			"\\\\", "/");
	/** Path to folder configure. */
	public static final String PATH_CONFIGURE = DIR + "/conf";
	/** Convert an hour to minutes. */
	public static final int HOUR_TO_MINUTES = 60;
	/** Convert an hour to seconds. */
	public static final int HOUR_TO_SECONDS = 3600;
	/** Convert a minute to seconds. */
	public static final int MINUTE_TO_SECOND = 60;
	/** Convert a day to hours. */
	public static final int DAY_TO_HOURS = 24;
	/** Convert a month to days. */
	public static final int MONTH_TO_DAYS = 30;
	/** Convert a year to months. */
	public static final int YEAR_TO_MONTHS = 12;
	/** Convert a year to days. */
	public static final int YEAR_TO_DAYS = 365;
	/** Convert a week to days. */
	public static final int WEEK_TO_DAYS = 7;
	/** Default port FTP. */
	public static final int PORT_FTP = 21;
	/** Default port SFTP. */
	public static final int PORT_SFTP = 22;
	/** Default START_TIME is HHmmss is 00:00:00. */
	public static final String START_TIME = "00:00:00";

	/** Default INTERVAL_TIME is 1 and unit is hour. */
	public static final int INTERVAL_TIME = 1;

	/** Convert a second to milliseconds. */
	public static final long SECOND_TO_MILLISECONDS = 1000L;
	/** Default Zero is 0. */
	public static final int ZERO = 0;
	
  /** The Constant DISTANCE_TIME_SEND. */
  public static final long DISTANCE_TIME_SEND = 30 * 60 * 1000;

}
