/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 11:01:29 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.purge.file.impl;

import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.common.utils.SFTPUtils;
import com.st.scc.utils.ConstantPurge;

/**
 * The Class FileDeletionSFTP.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class FileDeletionSFTP extends AbsFileDeletion {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileDeletionSFTP.class);

  /** The session. */
  private Session session;

  /**
   * cd to folder.
   * 
   * @param channel
   *          channel.
   * @param sub
   *          is string path sub folder.
   * @return boolean.
   */
  private boolean cd(final ChannelSftp channel, final String sub) {
    boolean result = false;
    if (channel != null && sub != null) {
      try {
        channel.cd(sub);
        result = true;
      } catch (final SftpException e) {
        final StringBuilder str = getNamePurge();
        str.append("error occurred when changing direction to monitor folder = ");
        str.append(sub);
        LOG.error(str.toString(), e);
      }
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#deleteFiles(java.lang.String, int,
   *      long)
   */
  public boolean deleteFiles(final String folder, final int depth, final long lastModified) {
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (!cd(channel, folder)) {
      final StringBuilder sb = getNamePurge();
      sb.append("On SFTP: Could not access monitor folder [");
      sb.append(folder);
      sb.append("] path of monitor folder does not exist or no permission");
      LOG.error(sb.toString());
      sendMail(sb.toString());
      return false;
    }
    deleteRecursiveSFTP(channel, depth, folder, lastModified);
    return true;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#deleteFolders(java.lang.String,
   *      int, long)
   */
  public boolean deleteFolders(final String folder, final int depth, final long lastModified) {
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (!cd(channel, folder)) {
      final StringBuilder sb = getNamePurge();
      sb.append("On SFTP: Could not access monitor folder [");
      sb.append(folder);
      sb.append("] path of monitor folder does not exist or no permission");
      LOG.error(sb.toString());
      sendMail(sb.toString());
      return false;
    }
    // If depth=0, it mean that delete the root folder.
    // But we cannot delete the root folder.
    if (depth > 0) {
      deleteRecursiveFolder(channel, depth, folder, lastModified);
    }
    return true;
  }

  /**
   * Delete recursive folder.
   * 
   * @param channel
   *          the channel
   * @param depth
   *          the depth
   * @param path
   *          the path
   * @param lastModified
   *          the last modified
   * @return the number of file in the directory
   */
  @SuppressWarnings("unchecked")
  private int deleteRecursiveFolder(final ChannelSftp channel, final int depth,
      final String path, final long lastModified) {
    int numOfFile = -1;
    if (depth < 0) {
      return numOfFile;
    }
    try {
      final List<LsEntry> vector = SFTPUtils.listFiles(channel, path); // channel.ls(path);
      if (vector == null) {
        LOG.error("Can't get list path " + path);
        return numOfFile;
      }

      if (vector.size() > 0) {
        for (final LsEntry entry : vector) {
          final String fileName = entry.getFilename();
          final SftpATTRS attrs = entry.getAttrs();
          final StringBuilder sb = new StringBuilder();
          if (path.endsWith("/")) {
            sb.append(path).append(fileName);
          } else {
            sb.append(path).append("/").append(fileName);
          }
          final String pathFileName = sb.toString();

          if (attrs.isDir()) {
            final int tmpDepth = depth - 1;
            if (tmpDepth > 0) {
              if (deleteRecursiveFolder(channel, tmpDepth, pathFileName, lastModified) == 0) {
                SFTPUtils.deleteFolder(channel, pathFileName);
              }
            } else {
              final long lastModifileFile =
                  attrs.getMTime() * ConstantPurge.SECOND_TO_MILLISECONDS;
              if (lastModifileFile < lastModified) {
                SFTPUtils.deleteFolder(channel, pathFileName);
                writecsv(pathFileName);
                increaseNumOfFileDelete();
              }
            }
          }
        }
        // after scan this folder, check whether this folder is empty
        // If it is empty, delete this folder
        final List<LsEntry> vector2 = SFTPUtils.listFiles(channel, path); // channel.ls(path);
        if (vector2 == null) {
          LOG.error("Can't get list path " + path);
          return numOfFile;
        }
        // check empty
        if (vector2.size() == 0) {
          numOfFile = 0;
        }
      } else {
        numOfFile = 0;
      }
    } catch (final Exception e) {
      final StringBuilder sb = getNamePurge();
      sb.append(e.getMessage());
      LOG.error(sb.toString(), e);
    }
    return numOfFile;
  }

  /**
   * Delete recursive on SFTP.
   * 
   * @param channel
   *          the channel
   * @param depth
   *          the depth
   * @param path
   *          the path
   * @param lastModified
   *          the last modified
   * @return the number of file in the directory
   */
  @SuppressWarnings("unchecked")
  private int deleteRecursiveSFTP(final ChannelSftp channel, final int depth,
      final String path, final long lastModified) {
    int numOfFile = -1;
    if (depth < 0) {
      return numOfFile;
    }
    final List<String> extensionFile = getFileTypeList();
    if (extensionFile == null) {
      return numOfFile;
    }
    try {
      final List<LsEntry> vector =SFTPUtils.listFiles(channel, path); //channel.ls(path);
      if (vector == null) {
        LOG.error("Can't get list path " + path);
        return numOfFile;
      }

      if (vector.size() > 0) {
        for (final LsEntry entry : vector) {
          final String fileName = entry.getFilename();
          final SftpATTRS attrs = entry.getAttrs();
          StringBuilder sb = new StringBuilder();
          if (path.endsWith("/")) {
            sb.append(path).append(fileName);
          } else {
            sb.append(path).append("/").append(fileName);
          }
          final String pathFileName = sb.toString();

          if (!attrs.isDir()) {
            final long lastModifileFile =
                attrs.getMTime() * ConstantPurge.SECOND_TO_MILLISECONDS;
            if (lastModifileFile < lastModified) {
              for (final String entension : extensionFile) {
                if (Pattern.matches(entension.toString(), FileUtils.getTailFileName(fileName))) {
                  sb = getNamePurge();
                  try {
                    if (SFTPUtils.deleteFile(channel, pathFileName, false)) {
                      writecsv(pathFileName);
                      increaseNumOfFileDelete();
                      if (LOG.isDebugEnabled()) {
                        sb.append("deleted file ");
                        sb.append(pathFileName);
                        sb.append(" successfully");
                        LOG.debug(sb.toString());
                      }
                    } else {
                      sb.append("file ");
                      sb.append(pathFileName);
                      sb.append(" is using or it is not permission delete");
                      LOG.error(sb.toString());
                    }
                    break;
                  } catch (final Exception e) {
                    final StringBuilder sbLog = getNamePurge();
                    sbLog.append("delete file=");
                    sbLog.append(pathFileName);
                    sbLog.append(" fail");
                    sbLog.append(e.getMessage());
                    LOG.error(sbLog.toString(), e);
                  }
                }
              }
            }
          } else {
            if (deleteRecursiveSFTP(channel, depth - 1, pathFileName, lastModified) == 0) {
              SFTPUtils.deleteFolder(channel, pathFileName);
            }
          }
        }
        // after scan this folder, check whether this folder is empty
        // If it is empty, delete this folder
        final List<LsEntry> vector2 = SFTPUtils.listFiles(channel, path); // channel.ls(path);
        if (vector2 == null) {
          LOG.error("Can't get list path " + path);
          return numOfFile;
        }
        // check empty
        if (vector2.size() == 0) {
          numOfFile = 0;
        }
      } else {
        numOfFile = 0;
      }
    } catch (final Exception e) {
      final StringBuilder sb = getNamePurge();
      sb.append(e.getMessage());
      LOG.error(sb.toString(), e);
    }
    return numOfFile;
  }
  
  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#disconnect()
   */
  public void disconnect() {
    close();
    SFTPUtils.disconnect(session);
  }

  /**
   * Gets the session.
   * 
   * @return the session
   */
  public Session getSession() {
    return session;
  }

  /**
   * Sets the session.
   * 
   * @param session
   *          the new session
   */
  public void setSession(final Session session) {
    this.session = session;
  }

}
