/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 28, 2011 4:59:18 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.purge;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.mail.EmailNotification;
import com.st.persistence.SQLExecutor;
import com.st.purge.config.TDataInfo;
import com.st.purge.config.TDataQuery;
import com.st.purge.config.TPurge;
import com.st.purge.config.TTable;
import com.st.purge.config.TTables;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.utils.ConstantPurge;
import com.st.scc.utils.InfoNextPurgeDB;
import com.st.scc.utils.PurgeServiceFactory;
import com.st.scc.utils.PurgeUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class PurgeDB extends AbsPurge {

  /**
   * implements interface Comparator.
   * 
   * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
   *         rights reserved.
   */
  private class Sort implements Comparator<TTable> {
    /**
     * Compare table. {@inheritDoc}
     * 
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(final TTable t1, final TTable t2) {
      if (t1 != null && t2 != null) {
        if (t1.getOrder() > t2.getOrder()) {
          return 1;
        } else {
          if (t1.getOrder() < t2.getOrder()) {
            return -1;
          }
        }
      }
      return 0;
    }
  }

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(PurgeDB.class);

  /*** Time for deleting db. */
  private Timestamp date;

  /**
   * list Table of purge.
   */
  private List<TTable> listTable;

  /** write csv. */
  private FileWriter writer;

  /**
   * Constructor.
   * 
   * @param tpurge
   *          of tage purge.
   */
  public PurgeDB(final TPurge tpurge) {
    super(tpurge);
  }

  /** Path CSV file. */
  private String pathcsv;
  /** SELECT MAX RECORDS. */
  private static final int SELECT_MAX_RECORDS = 50000;
  /** DELETE MAX RECORDS Each delete is 50 max rows. */
  private static final int DELETE_MAX_RECORDS = 100;
  /** RECORD IS DELETE, IT MUST > ONE. */
  private static final int ONE = 1;

  /**
   * Count the number of instances of substring within a string.
   * 
   * @param string
   *          String to look for substring in.
   * @param substring
   *          Sub-string to look for.
   * @return Count of substrings in string.
   */
  public static int count(final String string, final String substring) {
    int count = 0;
    int idx = 0;
    while ((idx = string.indexOf(substring, idx)) != -1) {
      idx++;
      count++;
    }
    return count;
  }

  /**
   * get column from sql.
   * 
   * @param query
   *          is query.
   * @return list column.
   */
  private static List<String> getColumn(final String query) {
    String sql = query;
    final List<String> list = new ArrayList<String>();
    if (sql != null) {
      sql = sql.toUpperCase();
      final int from = sql.indexOf("FROM");
      final String sub = sql.substring(0, from);
      final Pattern pa1 = Pattern.compile("\\,");
      final String[] st = pa1.split(sub);
      String result = "";
      for (final String string : st) {
        final String temp = string.trim();
        int last = temp.lastIndexOf(".") + 1;
        if (last > 0) {
          result = temp.substring(last);
        } else {
          last = temp.lastIndexOf(" ") + 1;
          if (last > 0) {
            result = temp.substring(last).trim();
          }
        }
        list.add(result);
      }
    }
    return list;
  }

  /**
   * cut query for getting from->end.
   * 
   * @param sqlQuery
   *          is query.
   * @return string.
   */
  private static String getFromToEnd(final String sqlQuery) {
    String sqlTemp = sqlQuery;
    String result = "";
    if (sqlTemp != null) {
      sqlTemp = sqlTemp.trim();
      final String sql = sqlTemp.toUpperCase();
      final int from = sql.indexOf("FROM");
      result = from > -1 ? sqlTemp.substring(from) : "";
      result = result.trim();
    }
    return result;
  }

  /**
   * count how much parameter and get parameter in list.
   * 
   * @param sqlQuery
   *          is query.
   * @return list string.
   */
  private static List<String> getParamList(final String sqlQuery) {
    final List<String> list = new ArrayList<String>();
    String sql = sqlQuery;
    if (sql == null) {
      return list;
    }
    int from = 1;
    while (from > 0) {
      from = sql.indexOf(":") + 1;
      String temp = from > 0 ? sql.substring(from) : "";
      sql = temp;
      temp = temp.trim();
      from = getTag(temp);
      temp = from > -1 ? temp.substring(0, from) : temp;
      if (temp.length() > 0) {
        list.add(temp);
      }
    }
    return list;
  }

  /**
   * get index of \t or \n .
   * 
   * @param str
   *          is string.
   * @return position first index of char \t or \n or space or '(' or ')'.
   */
  private static int getTag(final String str) {
    int result = -1;
    if (str == null) {
      return result;
    }
    final int t = str.indexOf("\t");
    final int n = str.indexOf("\n");
    final int o = str.indexOf("(");
    final int c = str.indexOf(")");
    final int s = str.indexOf(" ");
    if (t > -1) {
      result = t;
    }
    if (n > -1) {
      if (n < result) {
        result = n;
      } else {
        if (result == -1) {
          result = n;
        }
      }
    }
    if (o > -1) {
      if (o < result) {
        result = o;
      } else {
        if (result == -1) {
          result = o;
        }
      }
    }
    if (c > -1) {
      if (c < result) {
        result = c;
      } else {
        if (result == -1) {
          result = c;
        }
      }
    }
    if (s > -1) {
      if (s < result) {
        result = s;
      } else {
        if (result == -1) {
          result = s;
        }
      }
    }
    return result;
  }

  /**
   * check null table and column.
   * 
   * @param table
   *          is table of configure.
   * @return true or false.
   */
  private boolean checkNullTable(final TTable table) {
    final StringBuilder str = getNamePurge();
    boolean result = true;
    if (table != null && table.getName() != null && table.getQueryDelete() != null) {
      result = false;
    } else {
      str.append("have table is null");
    }
    return result;
  }

  /**
   * close writer.
   */
  private void close() {
    if (writer != null) {
      try {
        writer.close();
      } catch (final IOException e) {
        final StringBuilder sb = getNamePurge();
        sb.append("close is fail");
        LOG.warn(sb.toString());
      }
    }
  }

  /**
   * @param exec
   *          is executor.
   * @param sql
   *          is query.
   * @param params
   *          array object.
   * @return number rows were deleted.
   */
  private int executerSQL(final SQLExecutor exec, final String sql, final Object[] params) {
    String command =
        PurgeUtils.createDeleteScript(exec.getDatabaseType(), sql, DELETE_MAX_RECORDS);
    String newSql = sql.toUpperCase();
    newSql = newSql.replaceFirst("DELETE ", " SELECT COUNT(*) ");
    BigDecimal rowsAffected = exec.getNumberValue(newSql, params);
    int result = 0;
    try {
      if (LOG.isDebugEnabled()) {
        StringBuilder sb = getNamePurge();
        sb.append(command).append(" param=[");
        if (params != null && params.length > 0) {
          sb.append(params[0]);
        }
        sb.append("]");
        LOG.debug(sb.toString());
      }
      while (true) {
        result = exec.executeSQL(command, params);
        if (result < ONE) {
          break;
        }
      }

    } catch (Exception e) {
      StringBuilder sb = getNamePurge();
      sb.append("query error sql=" + command);
      if (params != null && params.length > 0) {
        sb.append(" ").append(params[0]);
      }
      sb.append(e.getMessage());
      LOG.error(sb.toString(), e);
    }

    if (rowsAffected != null) {
      return rowsAffected.intValue();
    }

    return 0;
  }

  /**
   * get name of purge.
   * 
   * @return is a string builder.
   */
  private StringBuilder getNamePurge() {
    final StringBuilder sb = new StringBuilder();
    sb.append("Purge ");
    sb.append(tpurge.getName());
    sb.append(" database, configured key=").append(tpurge.getKey()).append(" : ");
    return sb;
  }

  /**
   * get path file.
   * 
   * @param name
   *          is name file.
   * @param time
   *          is time stapm
   * @return path.
   */
  private String getPathFile(final String name, final Timestamp time) {
    String dir = ConstantPurge.DIR;
    dir = dir + "/info";
    final StringBuilder path = new StringBuilder(dir);
    path.append("/");
    path.append(name);
    path.append("_");
    path.append(PurgeUtils.getInstance().format(time));
    path.append(".csv");
    final String filePath = path.toString();
    File file = new File(filePath);
    try {
      FileUtils.createParentPath(file);
    } catch (IOException e) {
      LOG.error(e.getMessage(), e);
    }
    return filePath;
  }

  /**
   * send mail information for next purge.
   * 
   * @param exec
   *          is executor.
   * @param time
   *          is time stamp.
   * @return true or false.
   */
  private boolean infoNextPurge(final SQLExecutor exec, final Timestamp time) {
    boolean result = false;
    if (exec == null) {
      LOG.warn("SQL param exec is null");
      return result;
    }
    final TDataInfo data = tpurge.getDataInfo();
    Timestamp timestamp = time;
    if (timestamp == null) {
      StringBuilder sb = getNamePurge();
      sb.append("Can't get sysdate of database");
      LOG.error(sb.toString());
      return false;
    }
    if (timestamp != null) {
      final List<TDataQuery> listDataQuery = data.getDataQuery();
      if (listDataQuery == null) {
        return true;
      }
      String sql;
      InfoNextPurgeDB info = InfoNextPurgeDB.getInstance();
      final StringBuilder mailContent = getNamePurge();
      mailContent.append("Purge will delete expired data after ");
      mailContent.append(PurgeUtils.getInstance().getIntervalTime());
      mailContent.append(" minute(s).").append("\nExpired time = ").append(timestamp);
      mailContent.append(" \nDetail of data to be deleted is stored at following:\n");
      int delete = 0;
      boolean first = true;
      String keyDB;
      for (final TDataQuery tData : listDataQuery) {
        keyDB = getKey(tData.getGroupId());
        if (tData.getValue() == null) {
          continue;
        }
        sql = tData.getValue() == null ? "" : tData.getValue();
        final Map<String, Object> param = new HashMap<String, Object>();
        final List<String> listKey = getParamList(sql);
        for (final String key : listKey) {
          param.put(key, timestamp);
        }
        try {
          final String path = getPathFile(keyDB, timestamp);
          pathcsv = path;
          delete += processQuery(exec, sql, param);
          if (delete == 0) {
            pathcsv = null;
          } else {
            if (first) {
              first = false;
            } else {
              mailContent.append("\n");
            }
            mailContent.append(tpurge.getName()).append(":[");
            mailContent.append(pathcsv).append("]");
          }
          info.getMapFile().put(keyDB, pathcsv);

        } catch (final Throwable e) {
          final StringBuilder th = getNamePurge();
          th.append(e.getMessage());
          LOG.error(th.toString(), e);
        }
      }
      if (delete > 0) {
        sendMailInfo(mailContent.toString());
        LOG.info(mailContent.toString());
        result = true;
      }
    }
    return result;
  }

  /**
   * install value.
   * 
   * @return true|false.
   */
  private boolean init() {
    boolean result = false;
    if (tpurge != null) {
      final TTables table = tpurge.getTables();
      if (table != null) {
        this.listTable = table.getTable();
        result = true;
      } else {
        final StringBuilder sb = getNamePurge();
        sb.append(" has table = null");
        LOG.error(sb.toString());
      }

      final SQLExecutor exec = getExecutor();
      if (exec != null) {
        final Timestamp timePurge =
            PurgeUtils.getInstance().getTimestamp(tpurge, getNamePurge(),
                getCurrecntDate(exec));
        if (timePurge != null) {
          result = true;
        } else {
          result = false;
          LOG.error(getNamePurge() + "Expire time is missing.");
        }
      }
    } else {
      LOG.error("purge is null");
    }
    return result;
  }

  /**
   * @param exec
   *          is SQLExcutor.
   * @param sql
   *          is query
   * @param param
   *          is map.
   * @return number query.
   */
  private int processQuery(final SQLExecutor exec, final String sql,
      final Map<String, Object> param) {
    int result = 0;
    final List<Object[]> listQuery = null;
    final List<String> listColumn = getColumn(sql);
    if (exec == null || sql == null) {
      return result;
    }
    final String sqlFromToEnd = getFromToEnd(sql);
    final StringBuilder sb = new StringBuilder();
    sb.append("SELECT COUNT(*) ");
    sb.append(sqlFromToEnd);
    final BigDecimal big = exec.getNumberValue2(sb.toString(), param);
    LOG.debug("Number record to write csv: " + big);
    if (big == null) {
      return result;
    }
    final int n = big.intValue();
    result = n;
    if (n == 0) {
      return result;
    }
    final File file = new File(pathcsv);
    if (file.getParentFile() != null && !file.exists()) {
      file.getParentFile().mkdirs();
    }
    if (LOG.isDebugEnabled()) {
      StringBuilder sbTemp = getNamePurge();
      sbTemp.append("start writing csv file ");
      sbTemp.append(pathcsv);
      LOG.debug(sbTemp.toString());
    }
    try {
      writer = new FileWriter(file);
    } catch (IOException e) {
      StringBuilder sbTemp = getNamePurge();
      sbTemp.append(e.getMessage());
      LOG.error(sbTemp.toString(), e);
    }
    writeFile(listColumn, listQuery);
    String[] arrayColumn = listColumn.toArray(new String[listColumn.size()]);
    if (n <= SELECT_MAX_RECORDS) {
      final List<Object[]> data = exec.query(sql, param, arrayColumn);
      writeFile(data);
    } else {
      // final List<String> column = getColumn(sql);
      // final String queryEntryEnd = getEntryToEnd(sql);
      int start = 0;
      int end = 0;
      final int i =
          n % SELECT_MAX_RECORDS == 0 ? n / SELECT_MAX_RECORDS + 1 : n / SELECT_MAX_RECORDS
              + 2;
      for (int count = 1; count < i; count++) {
        start = end;
        end = count * SELECT_MAX_RECORDS;
        // final String query = getQuery(queryEntryEnd, start, end, column);
        final List<Object[]> data = exec.query(sql, param, arrayColumn, start, end - start);
        writeFile(data);
      }
    }
    if (LOG.isDebugEnabled()) {
      StringBuilder sbTemp = getNamePurge();
      sbTemp.append("write csv successfully");
      LOG.debug(sbTemp.toString());
    }
    close();
    return result;
  }

  /**
   * get current date of db or system.
   * 
   * @param exec
   *          is executor.
   * @return time stamp.
   */
  private Timestamp getCurrecntDate(final SQLExecutor exec) {
    Timestamp result = null;
    if (exec != null) {
      result = exec.getSysDate();
      if (result == null) {
        final StringBuilder sb = getNamePurge();
        sb.append("Cannot connect to server for getting system date "
            + "of server so it is gotten current time");
        LOG.warn(sb.toString());
        result = new Timestamp(System.currentTimeMillis());
      }
    } else {
      result = new Timestamp(System.currentTimeMillis());
    }
    return result;
  }

  /**
   * get key from group.
   * 
   * @param group
   *          is group_id or notify-group.
   * @return key.
   */
  private String getKey(final int group) {
    String namePurge = tpurge.getName() + "." + tpurge.getKey();
    String result = namePurge + group;
    return result;
  }

  private String getKeyOfMap() {
    String namePurge = tpurge.getName() + "." + tpurge.getKey();
    return namePurge;
  }

  /**
   * @return SQL executor.
   */
  private SQLExecutor getExecutor() {
    SQLExecutor result = null;
    EntityManagerFactory entity =
        PurgeUtils.getInstance().getEntity(tpurge.getName(), tpurge.getType());
    if (entity != null) {
      result = PurgeServiceFactory.getSQLExecutor(entity);
    }
    return result;
  }

  /**
   * delete all field in database if last modifile < lastTime.
   */
  private void purge() {
    final SQLExecutor exec = getExecutor();
    if (exec != null) {
      executorAndPurge(exec);
    }
  }

  /**
   * @param exec
   *          is sql executor.
   */
  private void executorAndPurge(final SQLExecutor exec) {
    int sumRecords = 0;
    // get current time in milisecond
    date = getCurrecntDate(exec);
    // get expired time in second
    listTable = sortListOrder(listTable);

    // Check first times.
    Timestamp lastTimeForPurging = null;
    InfoNextPurgeDB info = InfoNextPurgeDB.getInstance();
    StringBuilder sb = getNamePurge();
    final Timestamp timePurge = PurgeUtils.getInstance().getTimestamp(tpurge, sb, date);
    String pathOldFile = null;
    if (!info.contentMap(getKeyOfMap())) {
      // first time purge.
      if (tpurge.getDataInfo() != null) {
        infoNextPurge(exec, timePurge);
        info.getMapDB().put(getKeyOfMap(), timePurge);
        sb = getNamePurge().append("Expired time = ").append(timePurge);
        sb = getNamePurge();
        sb = getNamePurge().append("first time, just check data which will be deleted.");
        LOG.info(sb.toString());
        return;
      }
      lastTimeForPurging = timePurge;

    } else {
      lastTimeForPurging = info.getMapDB().get(getKeyOfMap());
    }

    // To check which data to delete, do following steps:
    // 1. Divide into 2 groups: => just need to do one time only when
    // loading configuration file
    // 1.1 group tables that must be notified before deleting
    // 1.2 group tables that just do delete without notifying
    // 2. In case of notified-group-tables:
    // 2.1 check whether these tables is notified or not by checking
    // existence of CSV file
    // 2.2 if exist CSV file then do deleting else lookup new expired
    // data to notify
    // 3. In case of no-notified-group-tables:
    // 3.1 delete expired data if any 4. Send mail if any data is
    // deleted.

    // Step1. detect group

    // Step2. delete data which had been notified
    /**
     * if it doesn't found CSV file, it will not be deleted.
     */
    sb = getNamePurge();
    sb.append("Data which is older than ").append(lastTimeForPurging);
    sb.append(" will be deleted.");
    LOG.info(sb.toString());
    // final StringBuilder tempLog = getNamePurge();
    // for tables: check null
    final StringBuilder deletedTableName = new StringBuilder();
    final Set<String> listFileNotified = new HashSet<String>();
    for (final TTable table : listTable) {
      if (checkNullTable(table)) {
        continue;
      }

      sb = getNamePurge();

      String key = "";
      if (table.getNotifyGroup() != null) {
        key = getKey(table.getNotifyGroup());
      } else {
        key = getKey(-1);
      }
      // check key is contains in map.
      if (info.getMapFile().containsKey(key)) {
        // check whether data in notified-group-tables is notified
        // or not
        // just do delete if data had been notified by checking csv
        // file.
        pathOldFile = info.getMapFile().get(key);
        if (pathOldFile == null) {
          continue;
        } else {
          // if old path file is not exist is continue.
          if (!(new File(pathOldFile)).exists()) {
            continue;
          }
        }
      }

      // delete data if:
      // tables in notified-group-tables which had been notified, or
      // tables in no-notified-group-tables
      final String sql = table.getQueryDelete();
      Object[] params = new Object[]{lastTimeForPurging };
      int recordDeleted = 0;
      try {
        // execute query.
        try {
          long beginTime = System.currentTimeMillis();
          if (LOG.isDebugEnabled()) {
            StringBuilder sbLog = getNamePurge();
            sbLog.append(sql).append(" param=[");
            sbLog.append(params[0]);
            sbLog.append("]");
            LOG.debug(sbLog.toString());
          }
          recordDeleted = executerSQL(exec, sql, params);
          long endTime = System.currentTimeMillis();
          ActionLogService actionLogService = new ActionLogService();
          actionLogService.trackingPurgeTable(exec, table.getName(), recordDeleted, endTime
              - beginTime, new Timestamp(System.currentTimeMillis()));

        } catch (final Exception e) {
          final StringBuilder sqlError = getNamePurge();
          sqlError.append("execute sql error sql = " + sql);
          sqlError.append(e.getMessage());
          LOG.error(sqlError.toString(), e);
        }
        final StringBuilder sbtemp = new StringBuilder();
        final StringBuilder sbLog = getNamePurge();
        sbtemp.append("Deleted from ");
        sbtemp.append(table.getName());
        sbtemp.append(": ");
        sbtemp.append(recordDeleted);
        sbtemp.append(" record(s)");
        sbLog.append(sbtemp.toString());
        LOG.info(sbLog.toString());
        if (recordDeleted > 0) {
          if (sumRecords > 0) {
            deletedTableName.append(".\n");
          }
          deletedTableName.append(sbtemp.toString());
          if (pathOldFile != null) {
            listFileNotified.add(pathOldFile);
          }
        }
        sumRecords += recordDeleted;
      } catch (final Exception e) {
        final StringBuilder sbTemp = getNamePurge();
        sbTemp.append("Error delete database SQL = ");
        sbTemp.append(sql);
        LOG.error(sbTemp.toString(), e);
        sendMailIntervalTime(sbTemp);
      } catch (final Throwable e) {
        final StringBuilder sbTemp = getNamePurge();
        sbTemp.append("Error delete database SQL = ");
        LOG.error(sbTemp.toString(), e);
        sendMailIntervalTime(sbTemp);
      }
    }
    StringBuilder strMail = getNamePurge();
    if (sumRecords > 0) {
      strMail.append("all expired data were deleted successfully.\n");
      strMail.append(deletedTableName);
      strMail.append("\nExpired time = ");
      strMail.append(lastTimeForPurging);
      boolean first = true;
      for (String str : listFileNotified) {
        if (first) {
          strMail.append("\nDetail of deleted data: [");
          strMail.append(str);
          first = false;
        } else {
          strMail.append(",");
          strMail.append(str);
        }
      }
      strMail.append("]");
      sendMailInfo(strMail.toString());
    } else {
      StringBuilder sbLog = getNamePurge();
      sbLog.append("Expired time = ").append(lastTimeForPurging);
      LOG.info(sbLog.toString());
    }

    // Get data will be deleted for next time.
    if (tpurge.getDataInfo() != null) {
      infoNextPurge(exec, timePurge);
      info.getMapDB().put(getKeyOfMap(), timePurge);
    }

  }

  /**
   * @param s
   *          is string for sending.
   */
  private void sendMailInfo(final String s) {
    if (s == null) {
      return;
    }
    StringBuilder sb;
    String name = "";
    if (LOG.isDebugEnabled()) {
      sb = getNamePurge();
      name = EmailNotification.getInstance().getAdminEmail();
      sb.append("start notify mail to ");
      sb.append(name);
      sb.append(". Content:[");
      sb.append(s.trim());
      sb.append("]");
      LOG.debug(sb.toString());
    }
    EmailNotification.getInstance().sendMail(s);
    if (LOG.isDebugEnabled()) {
      sb = getNamePurge();
      sb.append("finish notify mail to ");
      sb.append(name);
      LOG.debug(sb.toString());
    }

  }

  /**
   * @param sb
   *          is writing log.
   */
  private void sendMailIntervalTime(final StringBuilder sb) {
    EmailNotification.getInstance().sendOneMessageMail(sb.toString(),
        ConstantPurge.DISTANCE_TIME_SEND);
  }

  /**
   * sort list table order by is table.getOrder().
   * 
   * @param listTable
   *          is array list.
   * @return list<TTable>.
   */
  private List<TTable> sortListOrder(final List<TTable> listTable) {
    if (listTable == null || listTable.size() == 0) {
      return listTable;
    }
    final Comparator<TTable> sort = new Sort();
    Collections.sort(listTable, sort);
    return listTable;
  }

  /**
   * write csv.
   * 
   * @param data
   *          is data for writing file.
   * @return true or false.
   */
  private boolean writeFile(final List<Object[]> data) {
    boolean result = false;
    try {
      if (writer == null) {
        return result;
      }
      if (data != null && data.size() > 0) {
        String str;
        for (final Object[] objects : data) {
          final StringBuilder sb = new StringBuilder();
          for (final Object object : objects) {
            str = object.toString();
            str = str == null ? "" : str.trim();
            sb.append("\"");
            sb.append(str);
            sb.append("\",");
          }
          sb.append("\n");
          writer.append(sb.toString());
        }
        result = true;
      }
    } catch (final IOException e) {
      final StringBuilder sb = getNamePurge();
      sb.append("can't write csv");
      LOG.error(sb.toString());
    }
    return result;

  }

  /**
   * write csv.
   * 
   * @param head
   *          is header.
   * @param data
   *          is data.
   * @return true or false.
   */
  private boolean writeFile(final List<String> head, final List<Object[]> data) {
    boolean result = false;
    try {
      if (writer == null) {
        return result;
      }
      if (head != null && head.size() > 0) {
        for (final String str : head) {
          writer.append("\"" + str + "\",");
        }
        writer.append("\n");
        result = true;
      }

      if (data != null && data.size() > 0) {
        for (final Object[] objects : data) {
          for (final Object object : objects) {
            writer.append("\"" + object + "\",");
          }
          writer.append("\n");
        }
        result = true;
      }
    } catch (final IOException e) {
      final StringBuilder sb = getNamePurge();
      sb.append("can't write csv");
      LOG.error(sb.toString());
    }
    return result;
  }

  /**
   * executor purge.
   */
  public void executor() {
    boolean isShutdown = false;
    try {
      StringBuilder sbStart = new StringBuilder();
      String namePurge = tpurge.getName() == null ? "" : tpurge.getName().trim();
      sbStart.append("Start purging ").append(namePurge).append(" database, configured key=")
          .append(tpurge.getKey());
      LOG.info(sbStart.toString());
      if (init()) {
        purge();
        StringBuilder sb = new StringBuilder();
        sb.append("Finish purging ").append(namePurge).append(" database");
        LOG.info(sb.toString());
      } else {
        isShutdown = true;
        final StringBuilder sb = getNamePurge();
        sb.append("init is fail");
        LOG.error(sb.toString());
      }
    } catch (final Throwable e) {
      isShutdown = true;
      final StringBuilder sb = getNamePurge();
      sb.append(e.getMessage());
      LOG.error(sb.toString(), e);
    }
    if (isShutdown && scheduler != null) {
      StringBuilder sb = getNamePurge().append("is shutdown ");
      LOG.info(sb.toString());
      scheduler.shutdown();
    }

  }

}
