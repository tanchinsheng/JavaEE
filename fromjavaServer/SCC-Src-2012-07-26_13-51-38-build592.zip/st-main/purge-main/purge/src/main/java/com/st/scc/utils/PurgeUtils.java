/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 28, 2011 3:17:12 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import javax.persistence.EntityManagerFactory;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.ConfigLoader;
import com.st.persistence.DatabaseType;
import com.st.persistence.entity.SettingEntity;
import com.st.persistence.service.SettingService;
import com.st.purge.config.TActionLog;
import com.st.purge.config.TExpiredTime;
import com.st.purge.config.TIntervalTime;
import com.st.purge.config.TLocation;
import com.st.purge.config.TPurge;
import com.st.purge.config.TPurgeConfigure;
import com.st.purge.config.TPurgeSchedule;
import com.st.purge.config.TPurgeType;
import com.st.purge.config.TSetting;
import com.st.purge.config.TTimeUnit;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class PurgeUtils {

  /** Map include all entity. */
  private Map<String, EntityManagerFactory> mapEntity =
      new HashMap<String, EntityManagerFactory>();

  /** LOG for writting log. */
  private static final Logger LOG = LoggerFactory.getLogger(PurgeUtils.class);
  /** Path configure to folder. */
  private static final String PATH = System.getProperty("user.dir") + File.separator + "conf"
      + File.separator;
  /** The Constant INSTANCE. */
  private static final PurgeUtils INSTANCE = new PurgeUtils();
  /** Package configure. */
  private static final String XML_PACKAGE = "com.st.purge.config";
  /** Path file is gotten from argument of PurgeMain. */
  private String pathPurgeFile = "";
  /** Time start. */
  private Date startTime;
  /** Interval time has until that is minutes. */
  private volatile Integer intervalTime;
  /** Last modifile time. */
  private volatile long lastModifileTime;

  /** TPurge configure. */
  private TPurgeConfigure tPurgeConfigure;
  /** first purge. */
  private boolean firstTimesPurge;
  /** Tab Setting in configure. */
  private TSetting tSetting;
  /** Tab config-folder in configure. */
  private TActionLog tActionLog;

  /** Path of configure. */
  private String pathConfiguration;

  /** Configure db file of entity manager factory. */
  private EntityManagerFactory entityConfigureFile = null;
  /** Configure db action log of entity manager factory. */
  private EntityManagerFactory entityActionLog = null;

  /**
   * get file purge.properties in folder conf.
   */
  private PurgeUtils() {
    this.firstTimesPurge = true;
  }

  /**
   * get instance of PurgeUtils.
   * 
   * @return PurgeUtils.
   */
  public static PurgeUtils getInstance() {
    return INSTANCE;
  }

  /**
   * set start time from string start.
   * 
   * @param startTimeString
   *          is "HH:mm:ss".
   * @param unit
   *          is unit of start time.
   * @throws ParseException
   *           is exception of purse.
   */
  private void setStartTime(final String startTimeString, final TTimeUnit unit)
      throws ParseException {
    DateFormat dateformat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    Calendar ca = Calendar.getInstance();
    int years = ca.get(Calendar.YEAR);
    int months = ca.get(Calendar.MONTH) + 1;
    int days = ca.get(Calendar.DAY_OF_MONTH);
    if (unit == null || startTimeString == null) {
      startTime = new Date();
      LOG.warn("Format is error so start time is gotten default " + ConstantPurge.START_TIME);
    } else {
      final String start = startTimeString.replaceAll("\\\\", "/").trim();
      StringBuilder sb = new StringBuilder();
      switch (unit) {
      case MINUTES:
      case HOURS:
        startTime = new Date();
        break;
      case MONTHS:
      case YEARS:
        sb.append(years).append("/").append(months).append("/").append(days).append(" ");
        sb.append(start);
        startTime = dateformat.parse(sb.toString());
        break;
      case DAYS:
        sb.append(years).append("/").append(months).append("/").append(days).append(" ");
        sb.append(start);
        startTime = dateformat.parse(sb.toString());
        // if time < time current add 1 day.
        if (startTime.getTime() < System.currentTimeMillis()) {
          Calendar calenda = getCalendar(new Timestamp(startTime.getTime()));
          calenda.add(Calendar.DAY_OF_MONTH, 1);
          startTime = new Date(calenda.getTimeInMillis());
        }
        break;

      default:
        break;
      }
    }
  }

  /**
   * Convert timestamp to calendar.
   * 
   * @param time
   *          is timestamp.
   * @return calendar.
   */
  private Calendar getCalendar(final Timestamp time) {
    Calendar cal = Calendar.getInstance();
    if (time == null) {
      return cal;
    }
    cal.setTimeInMillis(time.getTime());
    return cal;
  }

  /**
   * Convert cal to timestamp.
   * 
   * @param cal
   *          is calendar.
   * @return timestamp.
   */
  private Timestamp getTimestamp(final Calendar cal) {
    Timestamp time = null;
    if (cal == null) {
      time = new Timestamp(System.currentTimeMillis());
    } else {
      time = new Timestamp(cal.getTimeInMillis());
    }
    return time;
  }

  /**
   * subtract year.
   * 
   * @param time
   *          is time.
   * @param years
   *          is year for subtracting.
   * @return timestamp.
   */
  private Timestamp years(final Timestamp time, final int years) {
    Calendar cal = getCalendar(time);
    cal.add(Calendar.YEAR, getNegative(years));
    return getTimestamp(cal);
  }

  /**
   * get negative.
   * 
   * @param n
   *          is number
   * @return negative of n.
   */
  private int getNegative(final int n) {
    return (-n);
  }

  /**
   * subtract months.
   * 
   * @param time
   *          is time.
   * @param months
   *          is year for subtracting.
   * @return timestamp.
   */
  private Timestamp months(final Timestamp time, final int months) {
    Calendar cal = getCalendar(time);
    cal.add(Calendar.MONTH, getNegative(months));
    return getTimestamp(cal);
  }

  /**
   * subtract days.
   * 
   * @param time
   *          is time.
   * @param days
   *          is year for subtracting.
   * @return timestamp.
   */
  public Timestamp days(final Timestamp time, final int days) {
    Calendar cal = getCalendar(time);
    cal.add(Calendar.DAY_OF_YEAR, getNegative(days));
    return getTimestamp(cal);
  }

  /**
   * subtract hours.
   * 
   * @param time
   *          is time.
   * @param hours
   *          is year for subtracting.
   * @return timestamp.
   */
  private Timestamp hours(final Timestamp time, final int hours) {
    Calendar cal = getCalendar(time);
    cal.add(Calendar.HOUR, getNegative(hours));
    return getTimestamp(cal);
  }

  /**
   * subtract minutes.
   * 
   * @param time
   *          is time.
   * @param minutes
   *          is year for subtracting.
   * @return timestamp.
   */
  private Timestamp minutes(final Timestamp time, final int minutes) {
    Calendar cal = getCalendar(time);
    cal.add(Calendar.MINUTE, getNegative(minutes));
    return getTimestamp(cal);
  }

  /**
   * @param tpurge
   *          is tag purge of configure file.
   * @param sBuilder
   *          is string builder.
   * @param current
   *          is current time.
   * @return time stamp.
   */
  public Timestamp getTimestamp(final TPurge tpurge, final StringBuilder sBuilder,
      final Timestamp current) {
    Timestamp currentTime = current;
    if (currentTime == null) {
      currentTime = new Timestamp(System.currentTimeMillis());
    }
    StringBuilder sb = sBuilder;
    if (sb == null) {
      sb = new StringBuilder();
    }
    Timestamp result = null;
    if (this.tSetting.getLocation() == TLocation.DATABASE) {
      String name = tpurge.getName();
      Pattern con = Pattern.compile("\\.");
      String[] token = con.split(name);
      EntityManagerFactory entity = null;
      String keyExpiredTime = "";
      if (token.length > 0) {
        entity = getEntity(token[0], tpurge.getType());
        if (tpurge.getKey() != null) {
          keyExpiredTime = "PURGE_" + tpurge.getKey().toUpperCase() + ".EXPIRED_TIME";
        } else {
          keyExpiredTime = "PURGE_" + token[0].toUpperCase() + ".EXPIRED_TIME";
        }
      }
      int value = ConstantPurge.WEEK_TO_DAYS;
      if (keyExpiredTime.length() > 0 && entity != null) {
        SettingService setting = new SettingService();
        // PurgeServiceFactory.getScEntityManagerFactory(path);
        setting.setEntityManagerFactory(entity);
        SettingEntity expiredTime = setting.find(keyExpiredTime);
        if (expiredTime != null) {
          String expired = expiredTime.getParaValue();
          try {
            value = Integer.parseInt(expired);
          } catch (Exception e) {
            if (LOG.isDebugEnabled()) {
              LOG.debug(e.getMessage(), e);
            }
          }
          tpurge.setExpiredTime(value);
        } else {
          return null;
        }
      }

      sb.append("expired-time is ");
      sb.append(value);
      result = days(currentTime, value);
      sb.append(" day(s)");
      LOG.info(sb.toString());
    } else {
      int days = ConstantPurge.WEEK_TO_DAYS;
      if (tpurge == null || tpurge.getExpiredTime() == null) {
        result = days(currentTime, days);
        sb.append("expired-time is gotten default is ");
        sb.append(days);
        sb.append(" day(s)");
        LOG.warn(sb.toString());
      } else {
        int expiredTime = tpurge.getExpiredTime() != null ? tpurge.getExpiredTime() : 0;
        sb.append("expired-time is ");
        sb.append(expiredTime);
        result = days(currentTime, expiredTime);
        sb.append(" day(s)");
        LOG.info(sb.toString());
      }
    }
    LOG.info("Data is before '" + result.toString() + "' will be purged.");
    return result;
  }

  /**
   * @param name
   *          is name of purge.
   * @param type
   *          is FILE or DATABASE.
   * @return EntityManagerFactory.
   */
  public EntityManagerFactory getEntity(final String name, final TPurgeType type) {
    if (type == TPurgeType.FILE) {
      return getEntityActionLog();
    }
    EntityManagerFactory entity = mapEntity.get(name);
    if (entity == null) {
      String path = PATH + name + ".xml";
      entity = PurgeServiceFactory.getEntityManagerFactory(path, name);
    }
    return entity;
  }

  /**
   * @param expired
   *          is tag expired of configure file.
   * @param sbuilder
   *          is string builder.
   * @param current
   *          is current time.
   * @return time stamp.
   */
  public Timestamp getTimestamp(final TExpiredTime expired, final StringBuilder sbuilder,
      final Timestamp current) {
    Timestamp currentTime = current;
    StringBuilder sb = sbuilder;
    if (currentTime == null) {
      currentTime = new Timestamp(System.currentTimeMillis());
    }
    if (sb == null) {
      sb = new StringBuilder();
    }
    Timestamp result = null;
    int days = ConstantPurge.WEEK_TO_DAYS;
    if (expired == null || expired.getUnit() == null) {
      result = days(currentTime, days);
      sb.append("expired-time is gotten default is ");
      sb.append(days);
      sb.append(" day(s)");
      LOG.warn(sb.toString());
    } else {
      int expiredTime = expired.getValue();
      TTimeUnit tTime = expired.getUnit();
      switch (tTime) {
      case YEARS:
        result = years(currentTime, expiredTime);
        sb.append(" year(s)");
        LOG.info(sb.toString());
        break;
      case MONTHS:
        result = months(currentTime, expiredTime);
        sb.append(" month(s)");
        LOG.info(sb.toString());
        break;
      case DAYS:
        result = days(currentTime, expiredTime);
        sb.append(" day(s)");
        LOG.info(sb.toString());
        break;
      case HOURS:
        result = hours(currentTime, expiredTime);
        sb.append(" hour(s)");
        LOG.info(sb.toString());
        break;
      case MINUTES:
        result = minutes(currentTime, expiredTime);
        sb.append(" minute(s)");
        LOG.info(sb.toString());
        break;
      default:
        LOG.warn(sb.toString() + "unit of expired-time is not support");
        result = days(currentTime, days);
      }
    }
    return result;
  }

  /**
   * @param interval
   *          is interval time.
   * @return minutes.
   */
  public Integer getMinutes(final TIntervalTime interval) {
    Integer result = null;
    if (interval != null && interval.getUnit() != null) {
      int intervalTime = interval.getValue();
      TTimeUnit tTime = interval.getUnit();
      switch (tTime) {
      case YEARS:
        result =
            intervalTime * ConstantPurge.YEAR_TO_MONTHS * ConstantPurge.MONTH_TO_DAYS
                * ConstantPurge.DAY_TO_HOURS * ConstantPurge.HOUR_TO_MINUTES;
        break;
      case MONTHS:
        result =
            intervalTime * ConstantPurge.MONTH_TO_DAYS * ConstantPurge.DAY_TO_HOURS
                * ConstantPurge.HOUR_TO_MINUTES;
        break;
      case DAYS:
        result = intervalTime * ConstantPurge.DAY_TO_HOURS * ConstantPurge.HOUR_TO_MINUTES;
        break;
      case HOURS:
        result = intervalTime * ConstantPurge.HOUR_TO_MINUTES;
        break;
      case MINUTES:
        result = intervalTime;
        break;
      default:
        LOG.info("Unit of interval-time is not support");
        TIntervalTime temp = null;
        result = getMinutes(temp);
        break;
      }
      LOG.info("interval-time is " + result + " minute(s)");
    }
    return result;
  }

  /**
   * @return the mapEntity
   */
  public Map<String, EntityManagerFactory> getMapEntity() {
    return mapEntity;
  }

  /**
   * Reload.
   * 
   * @return true, if successful
   */
  public boolean reload() {
    boolean refresh = false;
    final String path = System.getProperty("user.dir");
    StringBuilder strBuilder = new StringBuilder();
    if (path != null) {
      strBuilder.append(path.replaceAll("\\\\", "/"));
      strBuilder.append("/conf/");
    }
    strBuilder.append(this.pathPurgeFile);
    final String temp = strBuilder.toString();

    File file = new File(this.pathPurgeFile);
    if (file.isDirectory() || !file.exists()) {
      file = new File(temp);
      if (file.isDirectory() || !file.exists()) {
        LOG.error("File is not exist path=[" + temp + "]");
        return false;
      }
    }
    if (file.lastModified() != this.lastModifileTime) {
      try {
        configureUtils(file);
        refresh = true;
      } catch (Exception e) {
        LOG.error(e.getMessage(), e);
      }
    } else {
      //if file does not changed, but if setting in DB, we must reload setting from DB.
      if (tSetting.getLocation() == TLocation.DATABASE) {
        try {
          loadSettingFromDB();
          refresh = true;
        } catch (ParseException e) {
          LOG.error("Error parsing the start time.", e);
        }
      }
    }

    return refresh;
  }

  /**
   * load entity.
   */
  private void loadEntity() {
    this.entityActionLog = entityActionLog();
    if (this.tSetting.getLocation() == TLocation.DATABASE) {
      this.entityConfigureFile = entityConfigureFileDB();
    }
  }

  /**
   * @return EntityManagerFactory.
   */
  private EntityManagerFactory entityConfigureFileDB() {
    String temp = tSetting.getConfigurationFile();
    String conf = temp == null ? "" : temp;
    if (conf.length() > 0) {
      String path = PATH + conf + ".xml";
      return PurgeServiceFactory.getEntityManagerFactory(path, temp);
    }
    return null;
  }

  /**
   * @return EntityManagerFactory.
   */
  private EntityManagerFactory entityActionLog() {
    String temp = tActionLog != null ? tActionLog.getActionlogDb() : "";
    String actionLog = temp == null ? "" : temp;
    if (actionLog.length() > 0) {
      String path = PATH + actionLog + ".xml";
      return PurgeServiceFactory.getEntityManagerFactory(path, temp);
    }
    return null;
  }

  /**
   * get tab TSetting of file configure.
   * 
   * @param tPurge
   *          is tag purge-configure.
   * @return TSetting.
   */
  private TSetting getSetting(final TPurgeConfigure tPurge) {
    return tPurge.getSettingInformation().getSetting();
  }

  /**
   * load configure.
   * 
   * @param file
   *          is file of configure.
   */
  private void configureUtils(final File file) {
    InputStream inputStream = null;
    try {
      ClassLoader classLoader = getClass().getClassLoader();
      URL schemaUrl = classLoader.getResource("purge.xsd");
      inputStream = new FileInputStream(file);
      SchemaFactory schemaFactory =
          SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
      tPurgeConfigure = readDataFromXMLFile(inputStream, schemaFactory.newSchema(schemaUrl));
      if (tPurgeConfigure != null) {
        this.tSetting = getSetting(tPurgeConfigure);
        this.tActionLog = tPurgeConfigure.getSettingInformation().getActionlog();
        loadEntity();
        if (tSetting.getLocation() == TLocation.DATABASE) {
         loadSettingFromDB();
        } else {
          TPurgeSchedule schedule = tPurgeConfigure.getPurgeSchedule();
          if (schedule == null) {
            LOG.error("Can't get tag purge from configure file");
            return;
          }
          TTimeUnit unit = TTimeUnit.DAYS;
          if (schedule.getIntervalTime() == null
              || schedule.getIntervalTime().getUnit() == null) {
            LOG.info("Unit of interval-time is getten default days, no support " + unit.name());
            unit = TTimeUnit.DAYS;
          } else {
            unit = schedule.getIntervalTime().getUnit();
            if (unit == TTimeUnit.MONTHS || unit == TTimeUnit.YEARS) {
              LOG.info("Unit of interval-time is getten default days, no support "
                  + unit.name());
              unit = TTimeUnit.DAYS;
            }
          }
          String start = schedule.getStartTime();
          setStartTime(start, unit);
          LOG.info("start-time is " + schedule.getStartTime());
          intervalTime = getMinutes(schedule.getIntervalTime());
        }
        lastModifileTime = file.lastModified();
      } else {
        LOG.error("error read data from xml file");
      }
    } catch (JAXBException e) {
      LOG.error("Error configure purge.xml is not correct schema.", e);
    } catch (IOException e) {
      LOG.error(e.getMessage(), e);
    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
    }
  }
  
  private void loadSettingFromDB() throws ParseException {
    SettingService setting = new SettingService();
    EntityManagerFactory entityManagerFactory = getEntityConfigureFile();
    // PurgeServiceFactory.getScEntityManagerFactory(path);
    setting.setEntityManagerFactory(entityManagerFactory);
    SettingEntity settingStart = setting.find(ConfigLoader.PURGE_START_TIME);
    SettingEntity settingInterval = setting.find(ConfigLoader.PURGE_INTERVAL_TIME);
    SettingEntity settingUnit = setting.find(ConfigLoader.PURGE_INTERVAL_UNIT);
    TIntervalTime interval = null;

    String start = null;
    TTimeUnit unit = TTimeUnit.DAYS;
    if (settingStart != null) {
      start = settingStart.getParaValue();
    }
    if (settingUnit != null && settingInterval != null) {
      String temp = settingUnit.getParaValue();
      if (temp != null) {
        unit = TTimeUnit.fromValue(temp.toLowerCase());
      }
      int value = 0;
      temp = settingInterval.getParaValue();
      if (temp != null) {
        try {
          value = Integer.parseInt(temp);
          interval = new TIntervalTime();
          interval.setValue(value);
          interval.setUnit(unit);
        } catch (Exception e) {
          LOG.error("PURGE_INTERVAL_TIME is not a number");
        }

      }
    }
    setStartTime(start, unit);
    intervalTime = getMinutes(interval);
  }

  /**
   * @param inputStream
   *          is file input stream.
   * @param schema
   *          is schema.
   * @return TPurgeConfigure.
   * @throws JAXBException
   *           exception.
   */
  @SuppressWarnings("unchecked")
  private TPurgeConfigure readDataFromXMLFile(final InputStream inputStream,
      final Schema schema) throws JAXBException {
    TPurgeConfigure data = null;
    // Create StreamSource
    final StreamSource streamSource = new StreamSource(inputStream);
    final JAXBContext context = JAXBContext.newInstance(XML_PACKAGE);
    final Unmarshaller unmarshaller = context.createUnmarshaller();
    if (schema != null) {
      unmarshaller.setSchema(schema);
    }
    final Object object = unmarshaller.unmarshal(streamSource);
    if (object instanceof TPurgeConfigure) {
      data = (TPurgeConfigure) object;
    } else if (object instanceof JAXBElement) {
      data = ((JAXBElement<TPurgeConfigure>) object).getValue();
    }
    return data;
  }

  /**
   * get absolute path configure.
   * 
   * @param nameFile
   *          is name file.
   * @return path.
   */
  public String getAbsolutePathConfigure(final String nameFile) {
    File file = new File(nameFile);
    if (file.exists()) {
      return nameFile;
    }
    final String path = System.getProperty("user.dir").replaceAll("\\\\", "/");
    StringBuilder sb = new StringBuilder();
    if (path != null) {
      sb.append(path);
      sb.append("/");
    }
    sb.append("conf/");
    sb.append(nameFile);
    return sb.toString();
  }

  /**
   * @return startTime.
   */
  public Date getStartTime() {
    return startTime;
  }

  /**
   * get interval time unit is minutes.
   * 
   * @return intervalTime.
   */
  public Integer getIntervalTime() {
    return intervalTime;
  }

  /**
   * @return the purge
   */
  public TPurgeConfigure getTpurgeConfigure() {
    return tPurgeConfigure;
  }

  /**
   * @return the firstTimesPurge
   */
  public boolean isFirstTimesPurge() {
    return firstTimesPurge;
  }

  /**
   * @param firstTimesPurge
   *          the firstTimesPurge to set
   */
  public void setFirstTimesPurge(final boolean firstTimesPurge) {
    this.firstTimesPurge = firstTimesPurge;
  }

  /**
   * @return the entityConfigureFile
   */
  public EntityManagerFactory getEntityConfigureFile() {
    return entityConfigureFile;
  }

  /**
   * @return the entityActionLog
   */
  public EntityManagerFactory getEntityActionLog() {
    return entityActionLog;
  }

  /**
   * @return the pathConfigure
   */
  public String getPathPurgeFile() {
    return pathPurgeFile;
  }

  /**
   * @param pathConfigure
   *          the pathConfigure to set
   */
  public void setPathPurgeFile(final String pathConfigure) {
    this.pathPurgeFile = pathConfigure;
  }

  /**
   * @return the tSetting
   */
  public TSetting gettSetting() {
    return tSetting;
  }

  /**
   * @return the tConfigFolder
   */
  public TActionLog gettActionLog() {
    return tActionLog;
  }

  /**
   * format with yyyyMMdd_HHmmss.
   * 
   * @param time
   *          is time input.
   * @return string.
   */
  public String format(final Timestamp time) {
    String result = "";
    if (time != null) {
      DateFormat date = new SimpleDateFormat("yyyyMMdd_HHmmss");
      result = date.format(time);
      return result;
    }
    return result;
  }

  /**
   * @param databaseType
   * @param deleteCommand
   *          is command for deleting.
   * @param batchNumber
   *          is batch number.
   * @return string.
   */
  public static String createDeleteScript(DatabaseType databaseType,
      final String deleteCommand, final int batchNumber) {
    StringBuilder sql = new StringBuilder();
    sql.append(deleteCommand);
    if (databaseType == DatabaseType.MYSQL) {
      sql.append(" LIMIT ");
    } else {
      sql.append(" AND ROWNUM <= ");
    }
    sql.append(batchNumber);
    return sql.toString();
  }

  /**
   * @return path string.
   */
  public String getPathConfiguration() {
    if (this.pathConfiguration == null) {
      String name = tSetting.getConfigurationFile();
      String path =
          System.getProperty("user.dir") + File.separator + "conf" + File.separator + name;
      File file = new File(path);
      String temp =
          tSetting.getConfigurationPath() != null ? tSetting.getConfigurationPath() : "";
      if (!file.exists() || file.isDirectory()) {
        path = temp + File.separator + name;
        file = new File(path);
        if (!file.exists() || file.isDirectory()) {
          return null;
        }
      }
      this.pathConfiguration = path;

    }
    return this.pathConfiguration;
  }

}
