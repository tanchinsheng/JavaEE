/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 14, 2011 11:50:03 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.utils;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 * 
 */
public final class InfoNextPurgeDB {
	/** Map of purge database. */
	private Map<String, Timestamp> mapDB;
	/** Map of path file csv of purge. */
	private Map<String, String> mapFile;
	/** INSTANCE of InfoNextPurgeDB.. */
	private static final InfoNextPurgeDB INSTANCE = new InfoNextPurgeDB();

	/**
	 * constructor.
	 */
	private InfoNextPurgeDB() {
		mapDB = new HashMap<String, Timestamp>();
		mapFile = new HashMap<String, String>();
	}

	/**
	 * 
	 * @param key is key of map data base.
	 * @return true or false.
	 */
	public boolean contentMap(final String key) {
		if (key == null) {
			return false;
		}
		return mapDB.containsKey(key);
	}

	/**
	 * 
	 * @param key is key of map data base.
	 * @return time stamp.
	 */
	public Timestamp getTimestampFromMap(final String key) {
		if (key == null) {
			return null;
		}
		return mapDB.get(key);
	}

	/**
	 * @return the instance
	 */
	public static InfoNextPurgeDB getInstance() {
		return INSTANCE;
	}

	/**
	 * @return the mapDB
	 */
	public Map<String, Timestamp> getMapDB() {
		return mapDB;
	}

	/**
	 * @return the mapFile
	 */
	public Map<String, String> getMapFile() {
		return mapFile;
	}
}
