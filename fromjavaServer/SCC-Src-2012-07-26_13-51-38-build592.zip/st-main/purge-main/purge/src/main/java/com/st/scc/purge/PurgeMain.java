/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 28, 2011 11:41:38 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.purge;

import java.io.File;
import java.util.List;

import org.apache.log4j.xml.DOMConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.ConfigLoader;
import com.st.common.exception.SccException;
import com.st.purge.config.TPurge;
import com.st.purge.config.TPurgeConfigure;
import com.st.purge.config.TPurgeType;
import com.st.scc.utils.PurgeUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class PurgeMain {

  /**
   * if parameter has then call function constructor FilePurgeMain has
   * parameter. else call function constructor default. then call function run
   * for run application
   * 
   * @param args
   *          the arguments
   */

  static {
    final String pro = System.getProperty("user.dir");
    final StringBuilder sb = new StringBuilder();
    if (pro != null) {
      sb.append(pro.replaceAll("\\\\", "/"));
      sb.append("/");
    }
    sb.append("conf/log4j.xml");
    final File file = new File(sb.toString());
    if (file.exists()) {
      DOMConfigurator.configure(sb.toString());
    } else {
      System.out.println("File configure " + sb.toString() + " is not found");
    }

  }

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(PurgeMain.class);

  /** The version. */
  private static String version = "";

  /**
   * @param args
   *          is parameter.
   */
  public static void main(final String[] args) {
    boolean printVersion = false;
    if (args != null && args.length > 0) {
      if ("-v".equalsIgnoreCase(args[0])) {
        printVersion = true;
      } else {
        // set path or name file from argument.
        final PurgeUtils pur = PurgeUtils.getInstance();
        pur.setPathPurgeFile(args[0]);
      }
    }
    try {
      PurgeMain.run(printVersion);
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    }
  }

  /**
   * Prints the purge version.
   * 
   * @param purgeConfigure
   *          is tab purge configure.
   */
  private static void printPurgeVersion(final TPurgeConfigure purgeConfigure) {
    final String version = readVersion(purgeConfigure);
    if (version != null && version.length() > 0) {
      final String message = "Purge " + version;
      LOG.info(message);
      System.out.println(message);
    }
  }

  /**
   * Read version.
   * 
   * @param purgeConfigure
   *          the purge configure
   * @return the string
   */
  private static String readVersion(final TPurgeConfigure purgeConfigure) {
    final ConfigLoader conf = ConfigLoader.getInstance();
    String version = "";
    try {
      conf.load();
      version = conf.getVersion();
    } catch (final SccException e) {
      LOG.error(e.getMessage(), e);
    }
    return version;
  }

  /**
   * run purge.
   * 
   * @param printVersion
   *          is version.
   */
  public static void run(final boolean printVersion) {
    final PurgeUtils purgeUtil = PurgeUtils.getInstance();
    purgeUtil.reload();
    final TPurgeConfigure tpurgeConf = purgeUtil.getTpurgeConfigure();
    if (printVersion) {
      printPurgeVersion(tpurgeConf);
      return;
    }
    if (tpurgeConf == null) {
      LOG.error("Can't load configure");
      LOG.info("Stopped Purge successfully");
      return;
    } else {
      version = readVersion(tpurgeConf);
      LOG.info("Start purging");
      PurgeUtils.getInstance().reload();
      final List<TPurge> tPurges = tpurgeConf.getPurge();
      if (tPurges == null || tPurges.size() == 0) {
        LOG.error("Configure purge is null, there are not have to purge");
        LOG.info("Stopped Purge successfully");
        return;
      }
      final Integer intervalTime = PurgeUtils.getInstance().getIntervalTime();
      if (intervalTime == null) {
        LOG.error("Purge interval is null");
        LOG.info("Stopped Purge successfully");
        return;
      }

      for (final TPurge tpurge : tPurges) {
        if (tpurge != null && tpurge.getType() != null) {
          final TPurgeType type = tpurge.getType();
          switch (type) {
          case DATABASE:
            new PurgeDB(tpurge);
            break;

          case FILE:
            new PurgeFile(tpurge);
            break;

          case FOLDER:
            new PurgeFile(tpurge, true);
            break;

          default:
            LOG.error("Type of tag purge is not support, type=" + type.value());
            break;
          }
        }
      }
      LOG.info("Started Purge {} sucessfully", version);
    }
  }

  /**
   * Constructor default.
   */
  private PurgeMain() {

  }

}
