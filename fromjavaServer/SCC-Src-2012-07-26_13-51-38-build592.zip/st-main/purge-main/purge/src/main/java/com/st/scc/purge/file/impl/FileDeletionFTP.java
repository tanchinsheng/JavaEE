/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 11:01:29 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.purge.file.impl;

import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.scc.common.utils.FTPUtil;
import com.st.scc.common.utils.FileUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class FileDeletionFTP extends AbsFileDeletion {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileDeletionFTP.class);

  /** The FTP client. */
  private FTPClient ftp;

  /**
   * Chang working directory.
   * 
   * @param ftp
   *          the ftp
   * @param sub
   *          the sub
   * @return true, if successful
   */
  private boolean changWorkingDirectory(final FTPClient ftp, final String sub) {
    boolean result = false;
    try {
      result = ftp.changeWorkingDirectory(sub);
    } catch (final IOException e) {
      final StringBuilder str = getNamePurge();
      str.append("error occurred when changing direction to monitor folder = ");
      str.append(sub);
      LOG.error(str.toString(), e);
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#deleteFiles(java.lang.String, int,
   *      long)
   */
  public boolean deleteFiles(final String folder, final int depth, final long lastModified) {
    if (!changWorkingDirectory(ftp, folder)) {
      final StringBuilder str = getNamePurge();
      str.append("On FTP: Could not access monitor folder [");
      str.append(folder);
      str.append("] path of monitor folder does not exist or no permission");
      LOG.error(str.toString());
      sendMail(str.toString());
      return false;
    }
    deleteRecursiveFTP(ftp, depth, lastModified, folder);
    return true;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#deleteFolders(java.lang.String,
   *      int, long)
   */
  public boolean deleteFolders(final String folder, final int depth, final long lastModified) {
    if (!changWorkingDirectory(ftp, folder)) {
      final StringBuilder str = getNamePurge();
      str.append("On FTP: Could not access monitor folder [");
      str.append(folder);
      str.append("] path of monitor folder does not exist or no permission");
      LOG.error(str.toString());
      sendMail(str.toString());
      return false;
    }
    // If depth=0, it mean that delete the root folder.
    // But we cannot delete the root folder.
    if (depth > 0) {
      deleteRecursiveFolder(ftp, depth, lastModified, folder);
    }
    return true;
  }

  /**
   * Delete recursive folder.
   * 
   * @param ftp
   *          the FTP client
   * @param depth
   *          the depth folder
   * @param lastModified
   *          the last modified
   * @param path
   *          the path
   * @return the number of files in the directory
   */
  private int deleteRecursiveFolder(final FTPClient ftp, final int depth,
      final long lastModified, final String path) {
    if (depth < 0) {
      return -1;
    }
    int numOfFile = -1;
    try {
      if (changWorkingDirectory(ftp, path)) {
        final FTPFile[] ftpFile = FTPUtil.listFiles(ftp); // ftp.listFiles(path);
        if (ftpFile != null && ftpFile.length > 0) {
          for (final FTPFile ftpfi : ftpFile) {
            final StringBuffer str = new StringBuffer();
            str.append(path);
            if (!path.endsWith("/")) {
              str.append("/");
            }
            str.append(ftpfi.getName());
            // if ftpFile[i] is directory then browse sub directory.
            final String filePath = str.toString();
            if (ftpfi.isDirectory()) {
              final int tmpDepth = depth - 1;
              if (tmpDepth > 0) {
                if (deleteRecursiveFolder(ftp, tmpDepth, lastModified, filePath) == 0) {
                  FTPUtil.deleteFolder(ftp, filePath);
                }
              } else {
                if (ftpfi.getTimestamp().getTimeInMillis() < lastModified) {
                  FTPUtil.deleteFolder(ftp, filePath);
                  writecsv(filePath);
                  increaseNumOfFileDelete();
                }
              }
            }
          }
          // after scan in this folder, check it whether is empty, if empty then
          // delete this folder
          FTPFile[] ftpFile2 = ftp.listFiles(path);
          if (ftpFile2 == null || ftpFile2.length == 0) {
            numOfFile = 0;
          }
        } else {
          numOfFile = 0;
        }
      }
    } catch (final Exception e) {
      final StringBuilder sb = getNamePurge();
      sb.append(e.getMessage());
      LOG.error(sb.toString(), e);
    }
    return numOfFile;
  }

  /**
   * Delete recursive FTP.
   * 
   * @param ftp
   *          the FTP client
   * @param depth
   *          the depth
   * @param lastModified
   *          the last modified time
   * @param path
   *          the path
   * @return the number of files in the directory
   */
  private int deleteRecursiveFTP(final FTPClient ftp, final int depth,
      final long lastModified, final String path) {
    if (depth < 0) {
      return -1;
    }
    int numOfFile = -1;
    try {
      if (changWorkingDirectory(ftp, path)) {
        final FTPFile[] ftpFile = FTPUtil.listFiles(ftp); // ftp.listFiles(path);
        if (ftpFile != null && ftpFile.length > 0) {
          for (final FTPFile ftpfi : ftpFile) {
            final StringBuffer str = new StringBuffer();
            str.append(path);
            if (!path.endsWith("/")) {
              str.append("/");
            }
            str.append(ftpfi.getName());
            // if ftpFile[i] is directory then browse sub directory.
            final String filePath = str.toString();
            if (ftpfi.isDirectory()) {
              if (deleteRecursiveFTP(ftp, depth - 1, lastModified, filePath) == 0) {
                FTPUtil.deleteFolder(ftp, ftpfi.getName());
              }
            } else {
              final List<String> listFileType = getFileTypeList();
              if (listFileType != null
                  && ftpfi.getTimestamp().getTimeInMillis() < lastModified) {
                for (final String string : listFileType) {
                  if (Pattern.matches(string, FileUtils.getTailFileName(ftpfi.getName()))) {
                    final StringBuilder sb = getNamePurge();
                    try {
                      if (FTPUtil.deleteFileFTP(ftp, filePath, false)) {
                        writecsv(filePath);
                        increaseNumOfFileDelete();
                        if (LOG.isDebugEnabled()) {
                          sb.append("deleted file ");
                          sb.append(filePath);
                          sb.append(" successfully");
                          LOG.debug(sb.toString());
                        }
                      } else {
                        sb.append("file ");
                        sb.append(filePath);
                        sb.append(" is using or it is not permission delete");
                        LOG.error(sb.toString());
                      }
                    } catch (final Exception e) {
                      sb.append("file ");
                      sb.append(filePath);
                      sb.append(" can't be deleted ");
                      sb.append(e.getMessage());
                      LOG.error(sb.toString(), e);
                    }
                    break;
                  }
                }
              }
            }
          }
          // after scan in this folder, check it whether is empty, if empty then
          // delete this folder
          FTPFile[] ftpFile2 = ftp.listFiles(path);
          if (ftpFile2 == null || ftpFile2.length == 0) {
            numOfFile = 0;
          }
        } else {
          numOfFile = 0;
        }
      }
    } catch (final Exception e) {
      final StringBuilder sb = getNamePurge();
      sb.append(e.getMessage());
      LOG.error(sb.toString(), e);
    }
    return numOfFile;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#disconnect()
   */
  public void disconnect() {
    close();
    FTPUtil.disconnectFTP(ftp);
  }

  /**
   * Gets the FTP client.
   * 
   * @return the FTP client
   */
  public FTPClient getFtp() {
    return ftp;
  }

  /**
   * Sets the FTP client.
   * 
   * @param ftp
   *          the new FTP client
   */
  public void setFtp(final FTPClient ftp) {
    this.ftp = ftp;
  }

}
