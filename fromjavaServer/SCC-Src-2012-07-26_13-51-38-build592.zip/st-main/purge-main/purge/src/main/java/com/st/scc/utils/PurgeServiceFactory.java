/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 30, 2011 1:23:54 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.utils;

import java.io.File;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.persistence.SQLExecutor;
import com.st.persistence.SQLExecutorJpaImpl;
import com.st.persistence.util.EntityManagerUtils;
import com.st.scc.common.utils.PropertiesUtil;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class PurgeServiceFactory {
  /** Convert minutes to seconds. */
  private static final Logger LOG = LoggerFactory.getLogger(PurgeServiceFactory.class);

  /**
   * Gets the entity manager factory.
   * 
   * @param pathConfDB
   *          is path of configure db.
   * @param nameDB
   *          is name of database. Ex SCDB.
   * @return the entity manager factory
   */
  public static EntityManagerFactory getEntityManagerFactory(final String pathConfDB,
      final String nameDB) {
    EntityManagerFactory entity = null;
    File file = new File(pathConfDB);
    if (!file.exists()) {
      LOG.error("Path file of {} does not exist ", pathConfDB);
      return null;
    }
    synchronized (PurgeServiceFactory.class) {
      final Map<String, String> properties = PropertiesUtil.loadFromXML(file);
      entity = EntityManagerUtils.getEntityManagerFactory(nameDB, properties);
    }

    return entity;
  }

  /**
   * @param entity
   *          is entity manager factory.
   * @return SQL executor.
   */
  public static SQLExecutor getSQLExecutor(final EntityManagerFactory entity) {
    SQLExecutor executor = null;
    synchronized (PurgeServiceFactory.class) {
      executor = new SQLExecutorJpaImpl(entity);
    }
    return executor;
  }

  /**
   * Instantiates a new SC service utility.
   */
  private PurgeServiceFactory() {
  }

}
