/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 11:01:29 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.purge.file.impl;

import java.io.File;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.scc.common.utils.FileUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class FileDeletionNFS extends AbsFileDeletion {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileDeletionNFS.class);

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#deleteFiles(java.lang.String, int,
   *      long)
   */
  public boolean deleteFiles(final String folder, final int depth, final long lastModified) {
    // If path is not exist then return PATHNOTEXIST.
    final File directory = new File(folder);
    if (!directory.exists()) {
      final StringBuilder str = getNamePurge();
      str.append("On NFS: Could not access monitor folder [");
      str.append(folder);
      str.append("] path of monitor folder does not exist or no permission");
      LOG.error(str.toString());
      sendMail(str.toString());
      return false;
    }
    if (directory.isFile()) {
      final StringBuilder sb = getNamePurge();
      sb.append("path monitor folder must be directory ");
      sb.append(folder);
      LOG.error(sb.toString());
      sendMail(sb.toString());
      return false;
    } else {
      final String[] list = directory.list();
      if (list != null && list.length > 0) {
        deleteRecursiveNFS(folder, depth, lastModified, true);
      }
    }
    return true;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#deleteFolders(java.lang.String,
   *      int, long)
   */
  public boolean deleteFolders(final String folder, final int depth, final long lastModified) {
    // If path is not exist then return PATHNOTEXIST.
    final File directory = new File(folder);
    if (!directory.exists()) {
      final StringBuilder str = getNamePurge();
      str.append("On NFS: Could not access monitor folder [");
      str.append(folder);
      str.append("] path of monitor folder does not exist or no permission");
      LOG.error(str.toString());
      sendMail(str.toString());
      return false;
    }
    if (directory.isFile()) {
      final StringBuilder sb = getNamePurge();
      sb.append("path monitor folder must be directory ");
      sb.append(folder);
      LOG.error(sb.toString());
      sendMail(sb.toString());
      return false;
    }
    deleteRecursiveFolder(folder, depth, lastModified, true);
    return true;
  }

  /**
   * delete recursive for NFS delete all files have subpath is sub path of path
   * and type files have in listFileType.
   * 
   * @param path
   *          is monitor folder.
   * @param depth
   *          is depth of folder
   * @param lastModified
   *          is date modified
   */
  private void deleteRecursiveNFS(final String path, final int depth, final long lastModified,
      final boolean isRootFolder) {
    // If depth of file exceed the limit DEPTHMINIMUM then return
    // DEPTHMINIMUM.
    if (depth < -1) {
      return;
    }
    final File directory = new File(path);
    String[] arrayChildrenPath;
    StringBuilder childrenPath = null;
    final List<String> listFileType = getFileTypeList();

    // select all files have modified > max modified in data base.
    if (directory.isFile()) {
      if (directory.lastModified() < lastModified) {
        if (listFileType != null) {
          // if type of directory has in listFileType then add this
          // file
          // into list.
          for (final String string : listFileType) {
            if (Pattern.matches(string, FileUtils.getTailFileName(directory.getName()))) {
              final StringBuilder sb = getNamePurge();
              if (directory.delete()) {
                writecsv(directory.getAbsolutePath());
                increaseNumOfFileDelete();
                if (LOG.isDebugEnabled()) {
                  sb.append("deleted file ");
                  sb.append(directory.getAbsolutePath());
                  sb.append(" successfully");
                  LOG.debug(sb.toString());
                }
              } else {
                sb.append("file ");
                sb.append(directory.getAbsolutePath());
                sb.append(" is using or it is not permission delete");
                LOG.error(sb.toString());
              }
              break;
            }
          }
        }
      }
    } else {
      // arrayChilrdenPath is path to folder children.
      arrayChildrenPath = directory.list();
      if (arrayChildrenPath != null && arrayChildrenPath.length > 0) {
        final int depTemp = depth - 1;
        for (final String str : arrayChildrenPath) {
          childrenPath = new StringBuilder();
          childrenPath.append(path);
          childrenPath.append(File.separator);
          childrenPath.append(str);
          deleteRecursiveNFS(childrenPath.toString(), depTemp, lastModified, false);
        }
        // check folder is empty, if it is empty after deleted files, delete
        // this folder.
        if (!isRootFolder) {
          arrayChildrenPath = directory.list();
          if (arrayChildrenPath == null || arrayChildrenPath.length == 0) {
            directory.delete();
          }
        }
      } else {
        if (!isRootFolder) {
          directory.delete();
        }
      }
    }
  }

  /**
   * Delete recursive folder.
   * 
   * @param path
   *          the path
   * @param depth
   *          the depth
   * @param lastModified
   *          the last modified
   */
  private void deleteRecursiveFolder(final String path, final int depth,
      final long lastModified, boolean isRootFolder) {
    // If depth of file exceed the limit DEPTHMINIMUM then return
    // DEPTHMINIMUM.
    if (depth < 0) {
      return;
    }
    final File directory = new File(path);
    StringBuilder childrenPath = null;
    // select all files have modified > max modified in data base.
    if (directory.isDirectory()) {
      if (depth > 0) {
        // arrayChilrdenPath is path to folder children.
        String[] arrayChildrenPath = directory.list();
        if (arrayChildrenPath != null && arrayChildrenPath.length > 0) {
          final int depTemp = depth - 1;
          for (final String str : arrayChildrenPath) {
            childrenPath = new StringBuilder();
            childrenPath.append(path);
            childrenPath.append(File.separator);
            childrenPath.append(str);
            deleteRecursiveFolder(childrenPath.toString(), depTemp, lastModified, false);
          }
          // after scan this folder, check whether folder is empty to be
          // deleted.
          if (!isRootFolder) {
            arrayChildrenPath = directory.list();
            if (arrayChildrenPath == null || arrayChildrenPath.length == 0) {
              // delete empty folder
              directory.delete();
            }
          }
        } else {
          if (!isRootFolder) {
            // delete empty folder
            directory.delete();
          }
        }
      } else {
        if (!isRootFolder) {
          if (directory.lastModified() < lastModified) {
            org.apache.commons.io.FileUtils.deleteQuietly(directory);
            writecsv(directory.getAbsolutePath());
            increaseNumOfFileDelete();
          }
        }
      }
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#disconnect()
   */
  public void disconnect() {
    close();
  }

}
