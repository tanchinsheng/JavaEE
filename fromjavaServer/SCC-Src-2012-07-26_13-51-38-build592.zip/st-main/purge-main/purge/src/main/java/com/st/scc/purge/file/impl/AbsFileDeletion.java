/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 11:06:44 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.purge.file.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.FolderInfo;
import com.st.common.mail.EmailNotification;
import com.st.scc.purge.file.FileDeletion;
import com.st.scc.utils.ConstantPurge;

/**
 * The Class AbsFileDeletion.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public abstract class AbsFileDeletion implements FileDeletion {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(AbsFileDeletion.class);

  /** The file type list. */
  private List<String> fileTypeList;

  /** The folder info. */
  private FolderInfo folderInfo;

  /** The number of file delete. */
  private int numOfFileDelete = 0;

  /** The purge name. */
  private String purgeName;

  /**
   * check is first write.
   */
  private boolean firstWrite;
  /**
   * write csv.
   */
  private FileWriter writer;
  /**
   * start write csv.
   */
  private boolean startcsv = true;

  /** The cvs name. */
  private String cvsName;

  /**
   * close writer.
   */
  protected void close() {
    try {
      if (writer != null) {
        writer.close();
      }
    } catch (final IOException e) {
      final StringBuilder sb = getNamePurge();
      sb.append("close write csv is fail");
      LOG.warn(sb.toString(), e);
    }
  }

  /**
   * Gets the CVS name.
   * 
   * @return the CVS name
   */
  public String getCvsName() {
    return cvsName;
  }

  /**
   * Gets the file type list.
   * 
   * @return the file type list
   */
  public List<String> getFileTypeList() {
    return fileTypeList;
  }

  /**
   * Gets the folder info.
   * 
   * @return the folder info
   */
  public FolderInfo getFolderInfo() {
    return folderInfo;
  }

  /**
   * Get name of purge.
   * 
   * @return the string builder contains name purge
   */
  protected StringBuilder getNamePurge() {
    final StringBuilder sb = new StringBuilder();
    sb.append("Purge ").append(purgeName).append(" file: ");
    return sb;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#getNumOfFileDelete()
   */
  public int getNumOfFileDelete() {
    return numOfFileDelete;
  }

  /**
   * Gets the purge name.
   * 
   * @return the purge name
   */
  public String getPurgeName() {
    return purgeName;
  }

  /**
   * Increase number of files deleted.
   */
  public void increaseNumOfFileDelete() {
    numOfFileDelete++;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#isFirstWrite()
   */
  public boolean isFirstWrite() {
    return firstWrite;
  }

  /**
   * Send mail.
   * 
   * @param message
   *          the message
   */
  protected void sendMail(final String message) {
    EmailNotification.getInstance().sendOneMessageMail(message,
        ConstantPurge.DISTANCE_TIME_SEND);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#setCvsName(java.lang.String)
   */
  public void setCvsName(final String cvsName) {
    this.cvsName = cvsName;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#setFileTypeList(java.util.List)
   */
  public void setFileTypeList(final List<String> fileTypeList) {
    this.fileTypeList = fileTypeList;
  }

  /**
   * Sets the folder info.
   * 
   * @param folderInfo
   *          the new folder info
   */
  public void setFolderInfo(final FolderInfo folderInfo) {
    this.folderInfo = folderInfo;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.file.FileDeletion#setPurgeName(java.lang.String)
   */
  public void setPurgeName(final String purgeName) {
    this.purgeName = purgeName;
  }

  /**
   * @param file
   *          is path file for writing CSV.
   */
  private void writecsv(final File file) {
    if (startcsv && file != null) {
      try {
        if (LOG.isDebugEnabled()) {
          final StringBuilder sb = getNamePurge();
          sb.append("start writing CSV file ");
          sb.append(file.getAbsolutePath());
          LOG.debug(sb.toString());
        }
        writer = new FileWriter(file);
        //writer.append("\"" + "All STDF file was deleted" + "\"\n");
        startcsv = false;
      } catch (final IOException e) {
        final StringBuilder sb = getNamePurge();
        sb.append("write file=");
        sb.append(file.getAbsolutePath());
        sb.append(" fail");
        sb.append(e.getMessage());
        LOG.error(sb.toString(), e);
      }
    }
  }

  /**
   * write CSV for path STDF.
   * 
   * @param strPathSTDF
   *          is path STDF file.
   */
  protected void writecsv(final String strPathSTDF) {
    if (getCvsName() == null) {
      return;
    }
    if (!firstWrite) {
      final File file = new File(getCvsName());
      writecsv(file);
      firstWrite = true;
    }
    if (writer != null && !startcsv) {
      try {
        writer.append("\"" + strPathSTDF + "\"\n");
      } catch (final IOException e) {
        final StringBuilder sb = getNamePurge();
        sb.append("write CSV ");
        sb.append(" fail path=");
        sb.append(getCvsName());
        sb.append(" ");
        sb.append(e.getMessage());
        LOG.error(sb.toString(), e);
      }
    }
  }
}
