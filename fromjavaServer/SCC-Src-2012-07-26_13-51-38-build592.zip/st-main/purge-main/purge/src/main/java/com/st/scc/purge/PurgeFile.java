/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 28, 2011 4:59:18 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.purge;

import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileTypeEnum;
import com.st.common.config.ConfigLoader;
import com.st.common.config.FolderInfo;
import com.st.common.exception.SccException;
import com.st.common.mail.EmailNotification;
import com.st.persistence.SQLExecutor;
import com.st.persistence.entity.SettingEntity;
import com.st.persistence.service.SettingService;
import com.st.purge.config.TLocation;
import com.st.purge.config.TPurge;
import com.st.scc.purge.file.FileDeletion;
import com.st.scc.purge.file.FileDeletionFactory;
import com.st.scc.utils.ConstantPurge;
import com.st.scc.utils.PurgeServiceFactory;
import com.st.scc.utils.PurgeUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class PurgeFile extends AbsPurge {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(PurgeFile.class);

  /** The Constant CONF_EXPIRED_TIME. */
  private static final String EXPIRED_TIME = ".EXPIRED_TIME";
  /** List file type. */
  private List<String> listFileType;
  /** Expired time is delete file. */
  private Timestamp expiredTime;

  /** Count file deleted. */
  private int hasFileDelete;
  /** file name scv. */
  private String fileNameCSV;
  /** Expried time get DB. */
  private int expiredTimeDB;

  /** Modified of file. */
  private long modified = 0;

  /** The folder info. */
  private FolderInfo folderInfo;

  /** The delete folder. */
  private boolean deleteFolder;

  /**
   * Constructor.
   * 
   * @param tpurge
   *          is tag purge.
   */
  public PurgeFile(final TPurge tpurge) {
    this(tpurge, false);
  }

  /**
   * Instantiates a new purge file.
   * 
   * @param tpurge
   *          the tpurge
   * @param deleleFolder
   *          the delete folder
   */
  public PurgeFile(final TPurge tpurge, final boolean deleleFolder) {
    super(tpurge);
    deleteFolder = deleleFolder;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.purge.IPurge#executor()
   */
  public void executor() {
    boolean isShutdown = false;
    try {
      final StringBuilder sbStart = new StringBuilder();
      final String namePurge = tpurge.getName() == null ? "" : tpurge.getName().trim();
      sbStart.append("Start purging ").append(namePurge).append(" file...");
      LOG.info(sbStart.toString());
      if (init()) {
        purgeFile();
        final StringBuilder sb = new StringBuilder();
        sb.append("Finish purging ").append(namePurge)
            .append(" file. Number of purged files:[");
        sb.append(hasFileDelete).append("].");
        if (hasFileDelete > 0) {
          if (tpurge.isWriteCsv()) {
            sb.append(" Detail of data to be deleted is stored at following:[").append(
                fileNameCSV);
          }
        }
        LOG.info(sb.toString());
      } else {
        isShutdown = true;
        final StringBuilder sb = getNamePurge();
        sb.append("init is fail");
        LOG.error(sb.toString());
      }
    } catch (final Throwable e) {
      isShutdown = true;
      final StringBuilder sb = getNamePurge();
      sb.append(e.getMessage());
      LOG.error(sb.toString(), e);
    }
    if (isShutdown && scheduler != null) {
      final StringBuilder sb = getNamePurge().append("is shutdown ");
      LOG.info(sb.toString());
      scheduler.shutdown();
    }
  }

  /**
   * get name of purge.
   * 
   * @return StringBuilder.
   */
  private StringBuilder getNamePurge() {
    final StringBuilder sb = new StringBuilder();
    sb.append("Purge ");
    sb.append(tpurge.getName());
    sb.append(" file: ");
    return sb;
  }

  /**
   * @param timeStamp
   *          is time stamp.
   * @return path file.
   */
  private String getPathFile(final Timestamp timeStamp) {
    final String name = tpurge.getName() == null ? "" : tpurge.getName().trim().toUpperCase();
    Timestamp time = timeStamp;
    if (time == null) {
      time = new Timestamp(System.currentTimeMillis());
    }
    String dir = ConstantPurge.DIR;
    dir = dir + "/info";
    final File file = new File(dir);
    if (!file.exists()) {
      file.mkdirs();
    }
    final StringBuilder path = new StringBuilder(dir);
    path.append("/");
    path.append(name);
    path.append("_");
    path.append(PurgeUtils.getInstance().format(time));
    path.append(".csv");
    return path.toString();
  }

  /**
   * @return true|false.
   */
  private boolean init() {
    boolean result = false;
    if (tpurge != null) {
      final PurgeUtils purgeUtils = PurgeUtils.getInstance();
      // Get configuration from file
      if (purgeUtils.gettSetting().getLocation() == TLocation.FILE) {
        final String pathShare = purgeUtils.getPathConfiguration();
        if (pathShare != null) {
          result = initFile(pathShare, tpurge.getName());
        } else {
          result = false;
        }
      } else {
        // Get configuration from database
        try {
          final EntityManagerFactory entity = purgeUtils.getEntityConfigureFile();
          if (entity == null) {
            final StringBuilder sb = getNamePurge();
            sb.append("db-configuration can't create EntityManagerFactory");
            LOG.error(sb.toString());
            return false;
          }
          result = loadConfFromDB(entity, tpurge.getName());
          // //////////////////////////
          // ///////// TO DO //////////
          // //////////////////////////
        } catch (final Exception e) {
          LOG.error("Can't connection to database ", e);
          result = false;
        }
      }

    } else {
      LOG.error("Purge is null");
    }
    return result;
  }

  /**
   * @param pathConfigure
   *          is TConfiguration folder.
   * @param namePurge
   *          is name of configure tag.
   * @return true or false.
   */
  private boolean initFile(final String pathConfigure, final String namePurge) {
    final File file = new File(pathConfigure);
    if (file.lastModified() != modified) {
      final com.st.scc.config.ConfigLoader configLoader =
          com.st.scc.config.ConfigLoader.getInstance();
      configLoader.setFoldersFilePath(pathConfigure);
      try {
        configLoader.reloadFoldersConfig();
      } catch (final SccException e) {
        final StringBuilder sb = getNamePurge();
        sb.append(e.getMessage());
        LOG.error(sb.toString(), e);
        return false;
      }
      final com.st.scc.config.FolderInfo folder = configLoader.getFolder(namePurge);
      if (folder == null) {
        final StringBuilder sb = getNamePurge();
        sb.append(namePurge).append(" can't lookup in file=[");
        sb.append(pathConfigure).append("]");
        return false;
      }

      // get folder-type from purge.xml file
      final FileTypeEnum folderType = folder.getFolderType();
      StringBuilder sb = null;
      if (folderType == null) {
        sb = getNamePurge();
        sb.append("doesn't exist tag folder-type or has but it is null");
        LOG.error(sb.toString());
        return false;
      } else {
        sb = getNamePurge();
        sb.append("folder-type is ");
        sb.append(folderType.name());
        LOG.info(sb.toString());
      }
      // get folder-path from purge.xml file
      final String pathFolder = folder.getFolder();
      if (pathFolder == null || pathFolder.length() == 0) {
        sb = getNamePurge();
        sb.append("doesn't exist tag folder-path or has but it is null");
        LOG.error(sb.toString());
        return false;
      } else {
        sb = getNamePurge();
        sb.append("folder-path is ");
        sb.append(pathFolder);
        LOG.info(sb.toString());
      }

      // get file-extension from purge.xml file
      String fileExtension = folder.getFileType();
      if (fileExtension == null || fileExtension.length() == 0) {
        sb = getNamePurge();
        sb.append("doesn't exist tag file-extension or has but it is null");
        LOG.error(sb.toString());
        return false;
      } else {
        fileExtension = fileExtension.replaceAll(",", ";");
        sb = getNamePurge();
        sb.append("file-extension is ");
        sb.append(fileExtension);
        LOG.info(sb.toString());
      }
      listFileType = new ArrayList<String>();
      final Pattern p = Pattern.compile(";");
      final String[] tokens = p.split(fileExtension);
      String temp = "";
      for (final String token : tokens) {
        if (".Z".equals(token.toString())) {
          temp = token.toString();
        } else {
          temp = token.toString().toLowerCase().replaceAll("\\*", "[_a-zA-Z0-9]*");
        }
        listFileType.add(temp);
      }

      folderInfo = new FolderInfo(folderType, pathFolder);
      if (folderType != FileTypeEnum.NFS) {
        // get host from purge.xml file
        final String host = folder.getFileServer();
        if (host == null || host.length() == 0) {
          sb = getNamePurge();
          sb.append("doesn't have tag host or has but it is null");
          LOG.error(sb.toString());
          return false;
        } else {
          final StringBuilder sbHost = getNamePurge();
          sbHost.append("host is ");
          sbHost.append(host);
          LOG.info(sbHost.toString());
        }
        folderInfo.setFileServer(host);

        // get username from purge.xml file
        final String userName = folder.getUserName();
        if (userName == null || userName.length() == 0) {
          sb = getNamePurge();
          sb.append("doesn't have tag username or has but it is null");
          LOG.error(sb.toString());
          return false;
        } else {
          final StringBuilder sbTemp = getNamePurge();
          sbTemp.append("username is ");
          sbTemp.append(userName);
          LOG.info(sbTemp.toString());
        }
        folderInfo.setUserName(userName);

        // get password from purge.xml file
        final String password = folder.getPassword();
        if (password == null || password.length() == 0) {
          sb = getNamePurge();
          sb.append("doesn't have tag password or has but it is null");
          LOG.error(sb.toString());
          return false;
        }
        folderInfo.setPassword(password);

        // get port from purge.xml file
        int port = folder.getPort();
        if (port < 1) {
          sb = getNamePurge();
          sb.append("doesn't exist tag tag port or has but port less than one");
          LOG.warn(sb.toString());
          switch (folderType) {
          case FTP:
            port = ConstantPurge.PORT_FTP;
            break;
          case SFTP:
            port = ConstantPurge.PORT_SFTP;
            break;
          default:
            break;
          }
          sb = getNamePurge();
          sb.append("port will get default ");
          sb.append(port);
          LOG.warn(sb.toString());
        } else {
          sb = getNamePurge();
          sb.append("port is ");
          sb.append(port);
          LOG.info(sb.toString());
        }
        folderInfo.setPort(port);
      }
      // get depth-folder from purge.xml file
      int depthFolder = folder.getDepthFolder();
      sb = getNamePurge();
      if (depthFolder < 0) {
        depthFolder = 2;
        sb.append("depth-folder must be number greater than or equal zero ");
        sb.append("so it is gotten default ");
        sb.append(depthFolder);
        LOG.warn(sb.toString());
      } else {
        sb.append("depth-folder is ");
        sb.append(depthFolder);
        LOG.info(sb.toString());
      }
      folderInfo.setDepthFolder(depthFolder);
      modified = file.lastModified();
    }
    // update expriedTime from purge.xml file
    StringBuilder sb = getNamePurge();
    final Timestamp time = new Timestamp(System.currentTimeMillis());
    expiredTime = PurgeUtils.getInstance().getTimestamp(tpurge, sb, time);

    return true;
  }

  /**
   * insert database.
   * 
   * @param startTime
   *          is time start.
   */
  private void insertDB(final long startTime) {
    final long elapsedTime = System.currentTimeMillis() - startTime;

    boolean actionLog = false;
    if (PurgeUtils.getInstance().gettActionLog() != null) {
      final Boolean temp = PurgeUtils.getInstance().gettActionLog().isLog();
      actionLog = temp != null ? temp : false;
    }
    if (actionLog) {
      final EntityManagerFactory entity = PurgeUtils.getInstance().getEntityActionLog();
      if (entity == null) {
        final StringBuilder sb = getNamePurge().append("get entity of action is null ");
        LOG.error(sb.toString());
      } else {
        final SQLExecutor exec = PurgeServiceFactory.getSQLExecutor(entity);
        final ActionLogService actionLogService = new ActionLogService();
        actionLogService.trackingPurgeAction(exec, hasFileDelete, elapsedTime, new Timestamp(
            System.currentTimeMillis()), tpurge.getName());
      }

    }

  }

  /**
   * init value from database.
   * 
   * @param entity
   *          is entity manager factory.
   * @param name
   *          is name of purge.
   * @return true or false.
   */
  private boolean loadConfFromDB(final EntityManagerFactory entity, final String name) {
    final SettingService settingService = new SettingService();
    settingService.setEntityManagerFactory(entity);
    final Map<String, Object> mapSetting = settingService.loadAll();
    final ConfigLoader configLoader = ConfigLoader.getInstance();
    try {
      configLoader.reload(mapSetting, null);
    } catch (final SccException e) {
      LOG.error(e.getMessage(), e);
      return false;
    }
    final FolderInfo conf = configLoader.getFolder(name);
    if (conf == null) {
      final StringBuilder sb = getNamePurge().append("Load configure get loader is null");
      LOG.error(sb.toString());
      return false;
    }
    StringBuilder sb = null;
    final FileTypeEnum folderType = conf.getFolderType();
    if (folderType == null) {
      sb = getNamePurge().append(name);
      sb.append(" folder-type has only support NFS or FTP or SFTP");
      LOG.error(sb.toString());
      return false;
    }
    sb = getNamePurge().append(name);
    sb.append(" folder-type is ");
    sb.append(folderType.name());
    LOG.info(sb.toString());

    final String pathFolder = conf.getFolder();
    if (pathFolder == null) {
      sb = getNamePurge().append(name);
      sb.append(" path foleder is null");
      return false;
    }
    sb = getNamePurge().append(name);
    sb.append(" path foleder is ");
    sb.append(pathFolder);
    LOG.info(sb.toString());

    final String fileExtension = conf.getFileType();

    sb = getNamePurge().append(name);
    sb.append(" file type is ");
    sb.append(fileExtension);
    LOG.info(sb.toString());

    listFileType = new ArrayList<String>();
    final Pattern p = Pattern.compile(";");
    final String[] tokens = p.split(fileExtension);
    String temp = "";
    for (final String token : tokens) {
      if (".Z".equals(token.toString())) {
        temp = token.toString();
      } else {
        temp = token.toString().toLowerCase().replaceAll("\\*", "[_a-zA-Z0-9]*");
      }
      listFileType.add(temp);
    }
    folderInfo = new FolderInfo(folderType, pathFolder);

    if (folderType != FileTypeEnum.NFS) {
      final String host = conf.getFileServer();
      if (host == null) {
        sb = getNamePurge().append(name);
        sb.append(" Host is null");
        return false;
      }
      final StringBuilder sbHost = getNamePurge().append(name);
      sbHost.append(" file server is ");
      sbHost.append(host);
      LOG.info(sbHost.toString());
      folderInfo.setFileServer(host);

      final String userName = conf.getUserName();
      if (userName == null) {
        sb = getNamePurge().append(name);
        sb.append(" User name is null");
        return false;
      }
      final StringBuilder sbUserName = getNamePurge().append(name);
      sbUserName.append(" username is ");
      sbUserName.append(userName);
      LOG.info(sbUserName.toString());
      folderInfo.setUserName(userName);

      final String password = conf.getPassword();
      if (password == null) {
        sb = getNamePurge().append(name);
        sb.append(" Password is null");
        return false;
      }
      folderInfo.setPassword(password);

      final int port = conf.getPort();
      final StringBuilder sbPort = getNamePurge().append(name);
      sbPort.append(" port is ");
      sbPort.append(port);
      LOG.info(sbPort.toString());
      folderInfo.setPort(port);

    }

    final String key = name + EXPIRED_TIME;
    final SettingEntity value = settingService.find(key);
    if (value == null || value.getParaValue() == null) {
      sb = getNamePurge().append(key);
      sb.append(" doesn't have in database or has but it is null");
      LOG.error(sb.toString());
      return false;
    } else {
      final String expiredTimeDB = value.getParaValue();
      try {
        this.expiredTimeDB = Integer.parseInt(expiredTimeDB);
        final StringBuilder sbTemp = getNamePurge().append(key);
        sbTemp.append(" is ");
        sbTemp.append(this.expiredTimeDB);
        LOG.info(sbTemp.toString());
      } catch (final Exception e) {
        sb = getNamePurge().append(key);
        sb.append(" must be number integer");
        LOG.error(sb.toString());
        return false;
      }
    }

    try {
      final int depthFolder = conf.getDepthFolder();
      final StringBuilder sbTemp = getNamePurge().append(name);
      sbTemp.append(" depfolder is ");
      sbTemp.append(depthFolder);
      LOG.info(sbTemp.toString());
      folderInfo.setDepthFolder(depthFolder);
    } catch (final Exception e) {
      sb = getNamePurge().append(name);
      sb.append(" depfolder must be number integer");
      LOG.error(sb.toString());
      return false;
    }

    final Timestamp time = new Timestamp(System.currentTimeMillis());
    expiredTime = addDays(time, expiredTimeDB);
    return true;
  }

  /**
   * purge file is test and purge.
   */
  private void purgeFile() {
    if (folderInfo != null && expiredTime != null) {
      final long dateModified = expiredTime.getTime();
      StringBuilder sb = getNamePurge();
      sb.append("Data which is older than ").append(expiredTime);
      sb.append(" will be deleted.");
      LOG.info(sb.toString());
      boolean hasPurged = false;

      final long startTime = System.currentTimeMillis();

      fileNameCSV = null;
      if (tpurge.isWriteCsv()) {
        fileNameCSV = getPathFile(expiredTime);
      }
      final FileDeletion fd = FileDeletionFactory.create(folderInfo);
      if (fd != null) {
        fd.setPurgeName(tpurge.getName());
        //If set fileNameCSV = null, it will not write CSV file.
        fd.setCvsName(fileNameCSV);
        if (deleteFolder) {
          hasPurged =
              fd.deleteFolders(folderInfo.getFolder(), folderInfo.getDepthFolder(),
                  dateModified);
        } else {
          fd.setFileTypeList(listFileType);
          hasPurged =
              fd.deleteFiles(folderInfo.getFolder(), folderInfo.getDepthFolder(), dateModified);
        }
        fd.disconnect();
        hasFileDelete = fd.getNumOfFileDelete();
      } else {
        sb = getNamePurge();
        sb.append("Connect ").append(folderInfo.getFolderType().name());
        sb.append(" host:").append(folderInfo.getFileServer());
        sb.append(" port:").append(folderInfo.getPort());
        sb.append(" userName:").append(folderInfo.getUserName());
        sb.append(" is failed");
        LOG.error(sb.toString());
        EmailNotification.getInstance().sendOneMessageMail(sb.toString(),
            ConstantPurge.DISTANCE_TIME_SEND);
      }
      if (hasPurged) {
        final StringBuilder sbMail = getNamePurge();
        sbMail.append("Deleted from folder:[");
        sbMail.append(folderInfo.getFolder());
        sbMail.append("]:");
        sbMail.append(hasFileDelete);
        sbMail.append(" file(s).");
        LOG.info(sbMail.toString());
        
        sbMail.append("\nExpired time = ");
        sbMail.append(expiredTime);
        if (hasFileDelete > 0) {
          insertDB(startTime);
          if (tpurge.isWriteCsv()) {
            sbMail.append("\nPlease check in log file or [");
            sbMail.append(fileNameCSV);
            sbMail.append("] file for more detail.");
          }
          sendMainInfo(sbMail.toString());
        } else {
          sb = getNamePurge();
          sb.append("There is no file ");
          sb.append(listFileType);
          sb.append(" which is purged in ");
          sb.append(folderInfo.getFolder());
          LOG.info(sb.toString());
        }
      }
    }
  }

  /**
   * Send email to admin.
   * 
   * @param s
   *          is string.
   */
  private void sendMainInfo(final String s) {
    StringBuilder sb;
    String name = "";
    if (LOG.isDebugEnabled()) {
      sb = getNamePurge();
      name = EmailNotification.getInstance().getAdminEmail();
      sb.append("start notify mail to ");
      sb.append(name);
      sb.append(", Content:[").append(s).append("]");
      LOG.debug(sb.toString());
    }
    EmailNotification.getInstance().sendMail(s);
    if (LOG.isDebugEnabled()) {
      sb = getNamePurge();
      sb.append("finish notify mail to ");
      sb.append(name);
      LOG.debug(sb.toString());
    }
  }
}
