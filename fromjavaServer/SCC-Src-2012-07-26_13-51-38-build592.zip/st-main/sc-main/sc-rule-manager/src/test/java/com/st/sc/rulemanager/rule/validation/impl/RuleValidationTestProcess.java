/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 30, 2012 4:57:17 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import static junit.framework.Assert.assertEquals;

import java.util.List;

import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.Record;

/**
 * The Class RuleValidationTestProcess.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class RuleValidationTestProcess {

  /** The rule validation. */
  private RuleValidation ruleValidation;

  /** The expected point. */
  private double expectedPoint;

  /** The records. */
  private List<Record> records;

  /**
   * Execute.
   */
  public void execute() {
    final ContextData contextData = new ContextData();
    ruleValidation.setContextData(contextData);

    for (final Record record : records) {
      contextData.updateData(record);
      if (ruleValidation.isCrossRule() && ruleValidation.canValidate(record)) {
        ruleValidation.validate(record);
      }
    }

    if (!ruleValidation.isCrossRule()) {
      ruleValidation.validate(null);
    }

    ruleValidation.postValidate();
    double obtainedPoint = 0;
    if (ruleValidation.getNumOfRecords() != 0) {
      obtainedPoint =
          ruleValidation.getPoint() * ruleValidation.getNumOfPassedRecords()
              / ruleValidation.getNumOfRecords();
    }

    assertEquals("Obtained point", expectedPoint, obtainedPoint);
  }

  /**
   * Gets the expected point.
   * 
   * @return the expected point
   */
  public double getExpectedPoint() {
    return expectedPoint;
  }

  /**
   * Gets the records.
   * 
   * @return the records
   */
  public List<Record> getRecords() {
    return records;
  }

  /**
   * Gets the rule validation.
   * 
   * @return the rule validation
   */
  public RuleValidation getRuleValidation() {
    return ruleValidation;
  }

  /**
   * Sets the expected point.
   * 
   * @param expectedPoint
   *          the new expected point
   */
  public void setExpectedPoint(final double expectedPoint) {
    this.expectedPoint = expectedPoint;
  }

  /**
   * Sets the records.
   * 
   * @param records
   *          the new records
   */
  public void setRecords(final List<Record> records) {
    this.records = records;
  }

  /**
   * Sets the rule validation.
   * 
   * @param ruleValidation
   *          the new rule validation
   */
  public void setRuleValidation(final RuleValidation ruleValidation) {
    this.ruleValidation = ruleValidation;
  }

}
