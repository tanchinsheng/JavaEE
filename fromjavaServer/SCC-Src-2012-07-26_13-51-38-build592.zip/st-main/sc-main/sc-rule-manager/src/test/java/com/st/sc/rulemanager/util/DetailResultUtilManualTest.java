/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 7, 2012 10:08:17 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.util;

import java.io.File;
import java.util.Map;

import junit.framework.TestCase;

import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.rulemanager.data.FailedValueData;
import com.st.sc.rulemanager.serialization.FailedDetailReportData;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class DetailResultUtilManualTest extends TestCase {

  /** The fail value path. */
  private String failValuePath = "";

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#setUp()
   */
  @Override
  protected void setUp() throws Exception {
    super.setUp();
    failValuePath = "d:/var/scc/fail/20120207/12/0000000000000516/";
  }

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#tearDown()
   */
  @Override
  protected void tearDown() throws Exception {
    super.tearDown();
  }

  /**
   * Test read header.
   */
  public void testReadHeader() {
    final Map<Integer, String[]> headerData =
        DetailResultUtil.getHeaderData(new File(failValuePath
            + FailedValueData.HEADER_FILE_NAME));
    assertNotNull("Object not null", headerData);
    assertTrue("Not empty", !headerData.isEmpty());
  }

  /**
   * Test read record data.
   */
  public void testReadRecordData() {
    final Map<Integer, String[]> headerData =
        DetailResultUtil.getHeaderData(new File(failValuePath
            + FailedValueData.HEADER_FILE_NAME));
    final FailedDetailReportData reportData =
        DetailResultUtil.getFailedReportData(failValuePath, "0000000000000166",
            RecordEnum.PTR, RuleTypeEnum.VALIDATE_BIT7, headerData);
    assertNotNull("Object not null", reportData);
    assertNotNull("Object data not null", reportData.getData());
    assertNotNull("Object header not null", reportData.getHeaders());
    assertTrue("Data not empty", reportData.getData().length > 0);
  }

  /**
   * Test read special.
   */
  public void testReadSpecial() {
    final Object[][] specialData =
        DetailResultUtil.getSpecialData(new File(failValuePath
            + FailedValueData.SPECIAL_DATA_FILE_NAME), FailedValueData.INDEX_KEY_SOFTBIN);
    assertNotNull("Object not null", specialData);
    assertTrue("Not empty", specialData.length > 0);
  }
}
