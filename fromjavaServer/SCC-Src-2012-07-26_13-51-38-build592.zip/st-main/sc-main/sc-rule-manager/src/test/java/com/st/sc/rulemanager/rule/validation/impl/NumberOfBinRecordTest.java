/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 14, 2012 11:37:24 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Header;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class NumberOfBinRecordTest extends TestCase {

  /**
   * Creates the HBR record.
   * 
   * @param headNum
   *          the head num
   * @param siteNum
   *          the site num
   * @param binNum
   *          the bin num
   * @return the record
   */
  private Record createHBR(final int headNum, final int siteNum, final int binNum) {
    final Record record = new Record(new Header(RecordEnum.HBR));
    record.setFieldValue(FieldEnum.HEAD_NUM, (short) headNum);
    record.setFieldValue(FieldEnum.SITE_NUM, (short) siteNum);
    record.setFieldValue(FieldEnum.HBIN_NUM, binNum);
    return record;
  }

  /**
   * Creates the PRR record.
   * 
   * @param headNum
   *          the head num
   * @param siteNum
   *          the site num
   * @param hardBin
   *          the hard bin
   * @param softBin
   *          the soft bin
   * @return the record
   */
  private Record createPRR(final int headNum, final int siteNum, final int hardBin,
      final int softBin) {
    final Record record = new Record(new Header(RecordEnum.PRR));
    record.setFieldValue(FieldEnum.HEAD_NUM, (short) headNum);
    record.setFieldValue(FieldEnum.SITE_NUM, (short) siteNum);
    record.setFieldValue(FieldEnum.HARD_BIN, hardBin);
    record.setFieldValue(FieldEnum.SOFT_BIN, softBin);
    return record;
  }

  /**
   * Creates the SBR record.
   * 
   * @param headNum
   *          the head num
   * @param siteNum
   *          the site num
   * @param binNum
   *          the bin num
   * @return the record
   */
  private Record createSBR(final int headNum, final int siteNum, final int binNum) {
    final Record record = new Record(new Header(RecordEnum.SBR));
    record.setFieldValue(FieldEnum.HEAD_NUM, (short) headNum);
    record.setFieldValue(FieldEnum.SITE_NUM, (short) siteNum);
    record.setFieldValue(FieldEnum.SBIN_NUM, binNum);
    return record;
  }

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#setUp()
   */
  @Override
  protected void setUp() throws Exception {
    super.setUp();
  }

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#tearDown()
   */
  @Override
  protected void tearDown() throws Exception {
    super.tearDown();
  }

  /**
   * Test validation HBR.
   */
  public void testValidationHBR() {
    final RuleValidationTestProcess process = new RuleValidationTestProcess();
    final double expectedPoint = 10;
    process.setExpectedPoint(expectedPoint);
    final List<Record> records = new ArrayList<Record>();
    records.add(new Record(new Header(RecordEnum.FAR)));
    records.add(new Record(new Header(RecordEnum.MIR)));
    records.add(new Record(new Header(RecordEnum.WCR)));
    records.add(new Record(new Header(RecordEnum.WIR)));
    records.add(new Record(new Header(RecordEnum.PIR)));
    Record record = createPRR(1, 0, 1, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 2, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 3, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 1, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 3, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 1, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 1, 2, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(2, 0, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(2, 1, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.WRR)));
    record = createHBR(1, 1, 0);
    records.add(record);
    record = createHBR(2, 0, 0);
    records.add(record);
    record = createHBR(2, 1, 0);
    records.add(record);
    record = createHBR(255, 255, 0);
    records.add(record);
    record = createHBR(1, 0, 1);
    records.add(record);
    record = createHBR(255, 255, 1);
    records.add(record);
    record = createHBR(1, 0, 2);
    records.add(record);
    record = createHBR(1, 1, 2);
    records.add(record);
    record = createHBR(255, 255, 2);
    records.add(record);
    record = createHBR(1, 0, 3);
    records.add(record);
    record = createHBR(255, 255, 3);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.MRR)));
    process.setRecords(records);
    final RuleValidation ruleValidation = new NumberOfBinRecord(true);
    ruleValidation.setRecordType(RecordEnum.HBR);
    process.setRuleValidation(ruleValidation);
    ruleValidation.setPoint(10);
    process.execute();
  }

  /**
   * Test validation missing HBR.
   */
  public void testValidationMissingHBR() {
    validationMissing(true, RecordEnum.HBR);
  }

  /**
   * Test validation missing SBR.
   */
  public void testValidationMissingSBR() {
    validationMissing(false, RecordEnum.SBR);
  }

  /**
   * Test validation SBR.
   */
  public void testValidationSBR() {
    final RuleValidationTestProcess process = new RuleValidationTestProcess();
    final double expectedPoint = 10;
    process.setExpectedPoint(expectedPoint);
    final List<Record> records = new ArrayList<Record>();
    records.add(new Record(new Header(RecordEnum.FAR)));
    records.add(new Record(new Header(RecordEnum.MIR)));
    records.add(new Record(new Header(RecordEnum.WCR)));
    records.add(new Record(new Header(RecordEnum.WIR)));
    records.add(new Record(new Header(RecordEnum.PIR)));
    Record record = createPRR(1, 0, 0, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0, 2);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 0, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 0, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 0, 3);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.WRR)));
    record = createSBR(1, 0, 0);
    records.add(record);
    record = createSBR(1, 2, 0);
    records.add(record);
    record = createSBR(255, 255, 0);
    records.add(record);
    record = createSBR(1, 0, 1);
    records.add(record);
    record = createSBR(1, 2, 1);
    records.add(record);
    record = createSBR(255, 255, 1);
    records.add(record);
    record = createSBR(1, 0, 2);
    records.add(record);
    record = createSBR(255, 255, 2);
    records.add(record);
    record = createSBR(1, 2, 3);
    records.add(record);
    record = createSBR(255, 255, 3);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.MRR)));
    process.setRecords(records);
    final RuleValidation ruleValidation = new NumberOfBinRecord(false);
    ruleValidation.setRecordType(RecordEnum.SBR);
    process.setRuleValidation(ruleValidation);
    ruleValidation.setPoint(10);
    process.execute();
  }

  /**
   * Test validation missing.
   * 
   * @param hardBin
   *          the hard bin
   * @param recordType
   *          the record type
   */
  private void validationMissing(final boolean hardBin, final RecordEnum recordType) {
    final RuleValidationTestProcess process = new RuleValidationTestProcess();
    final double expectedPoint = 0;
    process.setExpectedPoint(expectedPoint);
    final List<Record> records = new ArrayList<Record>();
    records.add(new Record(new Header(RecordEnum.FAR)));
    records.add(new Record(new Header(RecordEnum.MIR)));
    records.add(new Record(new Header(RecordEnum.WCR)));
    records.add(new Record(new Header(RecordEnum.WIR)));
    records.add(new Record(new Header(RecordEnum.PIR)));
    records.add(new Record(new Header(RecordEnum.PRR)));
    records.add(new Record(new Header(RecordEnum.PIR)));
    records.add(new Record(new Header(RecordEnum.PRR)));
    records.add(new Record(new Header(RecordEnum.WRR)));
    records.add(new Record(new Header(RecordEnum.MRR)));
    process.setRecords(records);
    final RuleValidation ruleValidation = new NumberOfBinRecord(hardBin);
    ruleValidation.setRecordType(recordType);
    process.setRuleValidation(ruleValidation);
    ruleValidation.setPoint(10);
    process.execute();
  }
}
