/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 16, 2012 10:46:40 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.mvel2.ParserContext;
import org.mvel2.compiler.CompiledExpression;

import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.rule.validation.expression.exception.CompileException;
import com.st.sc.rulemanager.rule.validation.expression.exception.EvaluateException;
import com.st.sc.rulemanager.rule.validation.expression.stdf.SDR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.StdfContext;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.SDR_HC;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.STGDR;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class ExpressionProcessorTest extends TestCase {

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#setUp()
   */
  @Override
  protected void setUp() throws Exception {
    super.setUp();
  }

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#tearDown()
   */
  @Override
  protected void tearDown() throws Exception {
    super.tearDown();
  }

  /**
   * Test method for
   * {@link ExpressionProcessor#compile(String, org.mvel2.ParserContext)} .
   */
  public void testCompileSTGDR() {
    final String expresion = "GDR.SDR_HC.HEAD_NUM == SDR.HEAD_NUM && GDR.FLD_CNT";
    final ParserContext parserContext = ExpressionUtil.newContext();
    CompiledExpression compiledExpression = null;
    try {
      compiledExpression = ExpressionProcessor.compile(expresion, parserContext);
    } catch (final CompileException e) {
      e.printStackTrace();
      fail("Complilation error");
    }
    assertNotNull("Object is not null", compiledExpression);
  }

  /**
   * Test method for
   * {@link ExpressionProcessor#eval(Object, Object, java.util.Map)} .
   */
  public void testEval() {
    final String expresion = "GDR.SDR_HC.HEAD_NUM == SDR.HEAD_NUM && GDR.FLD_CNT > 0";
    final ParserContext parserContext = ExpressionUtil.newContext();
    CompiledExpression compiledExpression = null;
    try {
      compiledExpression = ExpressionProcessor.compile(expresion, parserContext);
    } catch (final CompileException e) {
      e.printStackTrace();
      fail("Complilation error");
    }
    assertNotNull("Object is not null", compiledExpression);

    final Map<String, Object> vars = new HashMap<String, Object>();
    final ContextData contextData = new ContextData();
    final StdfContext stdfContext = new StdfContext(contextData);
    final STGDR gdr = new STGDR();
    final Map<String, Object> map = new HashMap<String, Object>();
    map.put("HEAD_NUM", Integer.valueOf(1));
    final SDR_HC SDR_HC = new SDR_HC(map);
    gdr.setSDR_HC(SDR_HC);
    gdr.setFLD_CNT(Integer.valueOf(2));
    vars.put("GDR", gdr);
    final SDR sdr = new SDR(map);
    vars.put("SDR", sdr);

    Object value = null;
    try {
      value = ExpressionProcessor.eval(compiledExpression, stdfContext, vars);
    } catch (final EvaluateException e) {
      e.printStackTrace();
      fail("Eval error");
    }
    final Object expectedVal = Boolean.TRUE;
    assertEquals("Eval value", expectedVal, value);
  }

}
