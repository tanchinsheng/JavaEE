/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 14, 2012 11:12:07 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Header;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class NumberOfPCRTest extends TestCase {

  /**
   * Creates the PCR record.
   * 
   * @param headNum
   *          the head num
   * @param siteNum
   *          the site num
   * @return the record
   */
  private Record createPCR(final int headNum, final int siteNum) {
    final Record record = new Record(new Header(RecordEnum.PCR));
    record.setFieldValue(FieldEnum.HEAD_NUM, (short) headNum);
    record.setFieldValue(FieldEnum.SITE_NUM, (short) siteNum);
    return record;
  }

  /**
   * Creates the PRR record.
   * 
   * @param headNum
   *          the head num
   * @param siteNum
   *          the site num
   * @param hardBin
   *          the hard bin
   * @return the record
   */
  private Record createPRR(final int headNum, final int siteNum, final int hardBin) {
    final Record record = new Record(new Header(RecordEnum.PRR));
    record.setFieldValue(FieldEnum.HEAD_NUM, (short) headNum);
    record.setFieldValue(FieldEnum.SITE_NUM, (short) siteNum);
    record.setFieldValue(FieldEnum.HARD_BIN, hardBin);
    return record;
  }

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#setUp()
   */
  @Override
  protected void setUp() throws Exception {
    super.setUp();
  }

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#tearDown()
   */
  @Override
  protected void tearDown() throws Exception {
    super.tearDown();
  }

  /**
   * Test validation.
   */
  public void testValidation() {
    final RuleValidationTestProcess process = new RuleValidationTestProcess();
    final double expectedPoint = 10;
    process.setExpectedPoint(expectedPoint);
    final List<Record> records = new ArrayList<Record>();
    records.add(new Record(new Header(RecordEnum.FAR)));
    records.add(new Record(new Header(RecordEnum.MIR)));
    records.add(new Record(new Header(RecordEnum.WCR)));
    records.add(new Record(new Header(RecordEnum.WIR)));
    records.add(new Record(new Header(RecordEnum.PIR)));
    Record record = createPRR(1, 0, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 2, 0);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(1, 0, 2);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(2, 2, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.PIR)));
    record = createPRR(2, 2, 1);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.WRR)));
    record = createPCR(1, 0);
    records.add(record);
    record = createPCR(1, 2);
    records.add(record);
    record = createPCR(2, 2);
    records.add(record);
    record = createPCR(255, 255);
    records.add(record);
    records.add(new Record(new Header(RecordEnum.MRR)));
    process.setRecords(records);
    final RuleValidation ruleValidation = new NumberOfPCR();
    ruleValidation.setRecordType(RecordEnum.PCR);
    process.setRuleValidation(ruleValidation);
    ruleValidation.setPoint(10);
    process.execute();
  }

  /**
   * Test validation missing.
   */
  public void testValidationMissing() {
    final RuleValidationTestProcess process = new RuleValidationTestProcess();
    final double expectedPoint = 0;
    process.setExpectedPoint(expectedPoint);
    final List<Record> records = new ArrayList<Record>();
    records.add(new Record(new Header(RecordEnum.FAR)));
    records.add(new Record(new Header(RecordEnum.MIR)));
    records.add(new Record(new Header(RecordEnum.WCR)));
    records.add(new Record(new Header(RecordEnum.WIR)));
    records.add(new Record(new Header(RecordEnum.PIR)));
    records.add(new Record(new Header(RecordEnum.PRR)));
    records.add(new Record(new Header(RecordEnum.PIR)));
    records.add(new Record(new Header(RecordEnum.PRR)));
    records.add(new Record(new Header(RecordEnum.WRR)));
    records.add(new Record(new Header(RecordEnum.MRR)));
    process.setRecords(records);
    final RuleValidation ruleValidation = new NumberOfPCR();
    ruleValidation.setRecordType(RecordEnum.PCR);
    process.setRuleValidation(ruleValidation);
    ruleValidation.setPoint(10);
    process.execute();
  }
}
