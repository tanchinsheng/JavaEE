/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 11, 2012 11:19:29 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.st.common.exception.SccException;
import com.st.sc.entity.CompliancyResult;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleValue;
import com.st.sc.entity.RuleValuePK;
import com.st.sc.entity.RuleVersion;
import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.entity.enums.RuleValueKeyEnum;
import com.st.sc.rulemanager.rule.validation.enums.OperatorEnum;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class FileValidationManualTest extends TestCase {

  /**
   * Creates the rule validations.
   * 
   * @return the list
   */
  private List<RuleVersion> createRuleValidations() {
    final List<RuleVersion> list = new ArrayList<RuleVersion>();
    RuleVersion ruleVersion = new RuleVersion();
    ruleVersion.setPoint(20);
    ruleVersion.setRuleVersionId(1L);
    ruleVersion.setVersion(1);
    ruleVersion.setRuleType(RuleTypeEnum.REQUIRED_RECORD);
    Rule rule = new Rule();
    rule.setRecordType(RecordEnum.MIR.getText());
    ruleVersion.setRule(rule);
    list.add(ruleVersion);

    ruleVersion = new RuleVersion();
    ruleVersion.setPoint(20);
    ruleVersion.setVersion(1);
    ruleVersion.setRuleVersionId(2L);
    ruleVersion.setRuleType(RuleTypeEnum.CHECK_LENGTH_FIELD);
    rule = new Rule();
    rule.setRecordType(RecordEnum.HBR.getText());
    ruleVersion.setRule(rule);
    RuleValue ruleValue = new RuleValue();
    RuleValuePK ruleValuePK = new RuleValuePK();
    ruleValuePK.setRuleValueKey(RuleValueKeyEnum.FIELD_LENGTH_OPERATOR);
    ruleValue.setId(ruleValuePK);
    ruleValue.setParamValue(OperatorEnum.GT.getValue());
    ruleVersion.getRuleValueList().add(ruleValue);
    ruleValue = new RuleValue();
    ruleValuePK = new RuleValuePK();
    ruleValuePK.setRuleValueKey(RuleValueKeyEnum.FIELD_LENGTH_VALUE);
    ruleValue.setId(ruleValuePK);
    ruleValue.setParamValue("0");
    ruleVersion.getRuleValueList().add(ruleValue);
    ruleValue = new RuleValue();
    ruleValuePK = new RuleValuePK();
    ruleValuePK.setRuleValueKey(RuleValueKeyEnum.FIELD_NAME);
    ruleValue.setId(ruleValuePK);
    ruleValue.setParamValue(FieldEnum.HBIN_NAM.getText());
    ruleVersion.getRuleValueList().add(ruleValue);
    list.add(ruleVersion);

    ruleVersion = new RuleVersion();
    ruleVersion.setPoint(10);
    ruleVersion.setRuleVersionId(3L);
    ruleVersion.setVersion(1);
    ruleVersion.setRuleType(RuleTypeEnum.REQUIRED_RECORD);
    rule = new Rule();
    rule.setRecordType(RecordEnum.GDR_REF_DIE_XY.getText());
    ruleVersion.setRule(rule);
    list.add(ruleVersion);

    ruleVersion = new RuleVersion();
    ruleVersion.setPoint(20);
    ruleVersion.setRuleVersionId(3L);
    ruleVersion.setVersion(1);
    ruleVersion.setRuleType(RuleTypeEnum.EXPRESSION);
    rule = new Rule();
    rule.setRecordType(RecordEnum.MIR.getText());
    ruleVersion.setRule(rule);
    ruleValue = new RuleValue();
    ruleValuePK = new RuleValuePK();
    ruleValuePK.setRuleValueKey(RuleValueKeyEnum.EXPRESSION);
    ruleValue.setId(ruleValuePK);
    final String expression = "GDR.REF_DIE_XY.XREF > 0 && GDR.GEN_DATA != null";
    ruleValue.setParamValue(expression);
    ruleVersion.getRuleValueList().add(ruleValue);
    list.add(ruleVersion);

    return list;
  }

  /**
   * Test method for
   * {@link FileValidation#validate(String, String, Integer, java.util.List)} .
   */
  public void testValidate() {
    final String filePath =
        "d:/var/scc/tmp/1111_fuh69bd1-1_1107bjt-02d3_uh69ea01_p_ews1_ewttl016_20110613-014259.std";
    final String sessionId = "sessionId";
    final String rootPath = "d:/var/scc/fail/";
    final String ruleSetName = "ABC";
    final Integer ruleSetVersion = Integer.valueOf(50);

    final File file = new File(filePath);
    final FileValidation fileValidation = new FileValidation();
    fileValidation.setSessionId(sessionId);
    fileValidation.setFile(file);

    final List<RuleVersion> ruleVersions = createRuleValidations();

    try {
      fileValidation.validate(rootPath, ruleSetName, ruleSetVersion, ruleVersions);
    } catch (final SccException e) {
      fail("Failed to validate file");
      e.printStackTrace();
    }

    final RuleValidationDetail[] details = fileValidation.getDetails();
    final CompliancyResult result = fileValidation.getResult();
    assertNotNull("Result is not null", result);
    assertNotNull("Result Detail is not null", details);

    final double score = 75.0;
    assertEquals("Score", score, result.getCompliancyScore());
    assertEquals("Detail size", ruleVersions.size(), details.length);
  }

}
