/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 6:29:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;
import java.util.Map;

public class NMR implements RecordType {
  private Object CONT_FLG;
  private Object NMR_INDX;
  private Object TOTM_CNT;
  private Object LOCM_CNT;
  private Object PMR_INDX;
  private Object ATPG_NAM;
  public NMR(Map<String, Object> map) {
    initialize(map);
  }
  private void initialize(Map<String, Object> map) {
    this.CONT_FLG = map.get("CONT_FLG");
    this.NMR_INDX = map.get("NMR_INDX");
    this.TOTM_CNT = map.get("TOTM_CNT");
    this.LOCM_CNT = map.get("LOCM_CNT");
    this.PMR_INDX = map.get("PMR_INDX");
    this.ATPG_NAM = map.get("ATPG_NAM");
  }
  public Object getCONT_FLG() {
    return this.CONT_FLG;
  }
  public Object getNMR_INDX() {
    return this.NMR_INDX;
  }
  public Object getTOTM_CNT() {
    return this.TOTM_CNT;
  }
  public Object getLOCM_CNT() {
    return this.LOCM_CNT;
  }
  public Object getPMR_INDX() {
    return this.PMR_INDX;
  }
  public Object getATPG_NAM() {
    return this.ATPG_NAM;
  }
  public String getType() {
    return "NMR";
  }
}
