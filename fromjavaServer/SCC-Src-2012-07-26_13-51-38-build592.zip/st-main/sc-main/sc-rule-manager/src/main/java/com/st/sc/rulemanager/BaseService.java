/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 7:46:51 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.persistence.SQLExecutor;
import com.st.persistence.SQLExecutorJpaImpl;
import com.st.persistence.util.EntityManagerUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class BaseService {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(BaseService.class);

  /**
   * The entity manager factory
   */
  private EntityManagerFactory factory;

  public BaseService(EntityManagerFactory factory) {
    this.factory = factory;
  }

  /**
   * Get the entity manager factory of BaseService.
   * 
   * @return EntityManagerFactory.
   */
  public EntityManagerFactory getEntityManagerFactory() {
    return factory;
  }

  /**
   * Get current time in database.
   * 
   * @return the current time.
   */
  public Timestamp getCurrentTime() {
    SQLExecutor exe = new SQLExecutorJpaImpl(this.factory);
    return exe.getSysDate();
  }

  /**
   * Get next value of sequence
   * 
   * @param sequenceName
   *          sequence name.
   * @return the next value.
   */
  public Long getNextValueSequence(String sequenceName) {
    SQLExecutor exe = new SQLExecutorJpaImpl(this.factory);
    return exe.getSequence(sequenceName);
  }

  /**
   * Insert entity
   * 
   * @param entity
   * @throws Exception
   */
  public void insertEntity(Object entity) throws Exception {
    SQLExecutor exe = new SQLExecutorJpaImpl(this.factory);
    exe.addEntities(entity);
  }

  /**
   * Delete entity by using its primary key of it.
   * 
   * @param cls
   *          Class of deleted entity.
   * @param primaryKey
   *          the primary key of deleted data.
   * @throws Exception
   */
  public void deleteEntity(Class cls, Object primaryKey) throws Exception {
    EntityManager entityManager = EntityManagerUtils.createEntityManager(factory);
    EntityTransaction trans = entityManager.getTransaction();
    trans.begin();
    try {
      new EntityExecutor(cls, primaryKey).delete(entityManager);
      trans.commit();
    } catch (Exception e) {
      trans.rollback();
      throw e;
    }
    closeEntityManager(entityManager);
  }

  /**
   * Delete entity when entity is in managed state in entity manager.
   * 
   * @param entityManager
   * @param entity
   * @throws Exception
   */
  public void deleteEntity(EntityManager entityManager, Object entity) throws Exception {
    EntityTransaction trans = entityManager.getTransaction();
    trans.begin();
    try {
      entityManager.remove(entity);
      trans.commit();
    } catch (Exception e) {
      trans.rollback();
      throw e;
    }
  }

  /**
   * Update entity if entity already exist and insert if entity does not exist.
   * 
   * @param entity
   * @throws Exception
   */
  public void mergeEntity(Object entity) throws Exception {
    SQLExecutor exe = new SQLExecutorJpaImpl(this.factory);
    exe.mergeEntities(entity);
  }

  /**
   * Execute update or delete with named query.
   * 
   * @param namedQueryName
   *          the name of named query
   * @param parameters
   *          map contains name and value of parameters.
   * @throws Exception
   */
  public boolean updateDeleteNamedQuery(String namedQueryName, Map<String, Object> parameters)
      throws Exception {
    return updateDelete(namedQueryName, parameters, QueryExecutor.NAMED_QUERY);
  }

  /**
   * Execute the update or delete by using SQL string.
   * 
   * @param sqlString
   *          the SQL string
   * @param parameters
   * @throws Exception
   */
  public boolean updateDeleteNativeSQL(String sqlString, Map<String, Object> parameters)
      throws Exception {
    return updateDelete(sqlString, parameters, QueryExecutor.SQL_QUERY);
  }

  /**
   * Execute the update or delete by using JPQL string.
   * 
   * @param jpqlString
   *          the JPQL string.
   * @param parameters
   *          parameters for querying.
   * @throws Exception
   */
  public boolean updateDeleteUseJPQL(String jpqlString, Map<String, Object> parameters)
      throws Exception {
    return updateDelete(jpqlString, parameters, QueryExecutor.JPQL_QUERY);
  }

  /**
   * Execute the update or delete in one transaction.
   * 
   * @param queryString
   *          if queryType = NAMED_QUERY, queryString is the name of named
   *          query. If queryType = SQL_QUERY, queryString is the sql string. If
   *          queryType = JPQL_QUERY, queryString is the jpql string.
   * @param parameters
   *          the parameters of query.
   * @param queryType
   *          SQL_QUERY, JPQL_QUERY, NAMED_QUERY.
   * @return true if executing successfully.
   * @throws Exception
   */
  private boolean updateDelete(String queryString, Map<String, Object> parameters,
      int queryType) throws Exception {
    EntityManager entityManager = EntityManagerUtils.createEntityManager(factory);
    EntityTransaction trans = entityManager.getTransaction();
    trans.begin();
    try {
      QueryStringExecutor q = new QueryStringExecutor(queryType, queryString, parameters);
      boolean result = q.execute(entityManager);
      trans.commit();
      return result;
    } catch (Exception e) {
      trans.rollback();
      throw e;
    } finally {
      closeEntityManager(entityManager);
    }
  }

  /**
   * Insert/Update/delete multiple query.
   * 
   * @param listQuery
   * @throws Exception
   */
  public void executeMultipleQuery(List<QueryExecutor> listQuery) throws Exception {
    if (listQuery != null) {
      EntityManager entityManager = EntityManagerUtils.createEntityManager(factory);
      EntityTransaction trans = entityManager.getTransaction();
      try {
        trans.begin();
        for (QueryExecutor queryEntity : listQuery) {
          queryEntity.execute(entityManager);
        }
        trans.commit();
      } catch (Exception ex) {
        // trans.rollback();
        throw ex;
      } finally {
        closeEntityManager(entityManager);
      }
    }
  }

  /**
   * Query using primary key and class.
   * 
   * @param cls
   *          the class of the entity needed to queried.
   * @param primaryKey
   *          the primary key of entity needed to queried
   * @return entity entity which have primary key.
   */
  public <E> E queryByPrimaryKey(Class<E> cls, Object primaryKey) {
    SQLExecutor exe = new SQLExecutorJpaImpl(this.factory);
    try {
      return exe.findEntity(cls, primaryKey);
    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
      return null;
    }
  }

  /**
   * Query using primary key, class and entityManager. entityManager should be
   * closed explicitly after using the queried result.
   * 
   * @param entityManager
   *          the entity manager.
   * @param cls
   *          class of entity.
   * @param primaryKey
   *          primary key of entity needed to query.
   * @return entity which have primary key.
   */
  public <E> E queryByPrimaryKey(EntityManager entityManager, Class<E> cls, Object primaryKey) {
    E rs = entityManager.find(cls, primaryKey);
    return rs;
  }

  /**
   * Query list entities using named query. You can handle query by your
   * entityManager.
   * 
   * @param entityManager
   *          the entity manager. After used, you should close this entity
   *          manager.
   * @param namedQueryName
   *          the name of named query.
   * @param parameters
   *          parameters for this query
   * @param cls
   *          Class of entity.
   * @return list of queried entities.
   */
  public <E> List<E> queryListUseNamedQuery(EntityManager entityManager,
      String namedQueryName, Map<String, Object> parameters, Class<E> cls) {
    return queryList(entityManager, namedQueryName, parameters, cls, QueryExecutor.NAMED_QUERY);
  }

  /**
   * Query list entities use named query. You cannot handle entity manager,
   * after executing this query, the entity manager is closed.
   * 
   * @param namedQueryName
   * @param parameters
   * @param cls
   * @return
   */
  public <E> List<E> queryListUseNamedQuery(String namedQueryName,
      Map<String, Object> parameters, Class<E> cls) {
    EntityManager entityManager = EntityManagerUtils.createEntityManager(factory);
    List<E> ls =
        queryList(entityManager, namedQueryName, parameters, cls, QueryExecutor.NAMED_QUERY);
    closeEntityManager(entityManager);
    return ls;
  }

  /**
   * Query list entities using SQL query.
   * 
   * @param entityManager
   *          an entity manager to query.
   * @param sqlString
   *          the sql string.
   * @param parameters
   *          parameters for this query
   * @param cls
   *          Class of entity.
   * @return list of queried entities.
   */
  public <E> List<E> queryListUseNativeSQL(EntityManager entityManager, String sqlString,
      Map<String, Object> parameters, Class<E> cls) {
    return queryList(entityManager, sqlString, parameters, cls, QueryExecutor.SQL_QUERY);
  }

  /**
   * Query list entities using JPQL query.
   * 
   * @param entityManager
   *          an entity manager to query.
   * @param jpqlString
   *          the JPQL string.
   * @param parameters
   *          parameters for this query
   * @param cls
   *          Class of entity.
   * @return list of queried entities.
   */
  public <E> List<E> queryListUseJPQL(EntityManager entityManager, String jpqlString,
      Map<String, Object> parameters, Class<E> cls) {
    return queryList(entityManager, jpqlString, parameters, cls, QueryExecutor.JPQL_QUERY);
  }

  /**
   * Query entities using query string and query type.
   * 
   * @param entityManager
   *          an entity manager to query.
   * @param queryString
   *          if queryType = NAMED_QUERY, queryString is the name of named
   *          query. If queryType = SQL_QUERY, queryString is the sql string. If
   *          queryType = JPQL_QUERY, queryString is the jpql string.
   * @param parameters
   *          parameters for this query
   * @param cls
   *          Class of entity.
   * @param queryType
   *          : SQL_QUERY, JPQL_QUERY, NAMED_QUERY
   * @return list of entities.
   */
  private <E> List<E> queryList(EntityManager entityManager, String queryString,
      Map<String, Object> parameters, Class<E> cls, int queryType) {
    Query q = createQuery(entityManager, queryString, parameters, cls, queryType);
    if (q == null) {
      return null;
    }
    return q.getResultList();
  }

  /**
   * Create Query object and set parameters for it.
   * 
   * @param entityManager
   * @param queryString
   * @param parameters
   * @param cls
   * @param queryType
   * @return
   */
  private Query createQuery(EntityManager entityManager, String queryString,
      Map<String, Object> parameters, Class cls, int queryType) {
    Query q = null;
    switch (queryType) {
    case QueryExecutor.SQL_QUERY:
      if (cls != null) {
        q = entityManager.createNativeQuery(queryString, cls);
      } else {
        q = entityManager.createNativeQuery(queryString);
      }
      break;
    case QueryExecutor.JPQL_QUERY:
      if (cls != null) {
        q = entityManager.createQuery(queryString, cls);
      } else {
        q = entityManager.createQuery(queryString);
      }
      break;
    case QueryExecutor.NAMED_QUERY:
      if (cls != null) {
        q = entityManager.createNamedQuery(queryString, cls);
      } else {
        q = entityManager.createNamedQuery(queryString);
      }
      break;
    }
    if (q == null) {
      return null;
    }
    if (parameters != null) {
      Set<String> keys = parameters.keySet();
      for (String name : keys) {
        Object value = parameters.get(name);
        q.setParameter(name, value);
      }
    }
    return q;
  }

  /**
   * Query a single value using named query.
   * 
   * @param namedQuery
   *          name of named query.
   * @param parameters
   *          parameters for the query.
   * @return value
   */
  public Object querySingleValueUseNamedQuery(String namedQuery, Map<String, Object> parameters) {
    EntityManager entityManager = EntityManagerUtils.createEntityManager(factory);
    Query query =
        createQuery(entityManager, namedQuery, parameters, null, QueryExecutor.NAMED_QUERY);
    Object rs = query.getSingleResult();
    closeEntityManager(entityManager);
    return rs;
  }

  /**
   * Query a single value using JPQL query.
   * 
   * @param jpqlString
   *          JPQL string.
   * @param parameters
   *          parameters for the query.
   * @return value
   */
  public Object querySingleValueUseJPQL(String jpqlString, Map<String, Object> parameters) {
    EntityManager entityManager = EntityManagerUtils.createEntityManager(factory);
    Query query =
        createQuery(entityManager, jpqlString, parameters, null, QueryExecutor.JPQL_QUERY);
    Object rs = query.getSingleResult();
    closeEntityManager(entityManager);
    return rs;
  }

  /**
   * Query a single value using SQL query.
   * 
   * @param nativeSql
   *          SQL query .
   * @param parameters
   *          parameters for the query.
   * @return value
   */
  public Object querySingleValueUseNativeQuery(String nativeSql, Map<String, Object> parameters) {
    SQLExecutor exe = new SQLExecutorJpaImpl(this.factory);
    return exe.getScalarValue2(nativeSql, parameters);
  }

  /**
   * Close the entity manager.
   * 
   * @param entityManager
   */
  public void closeEntityManager(EntityManager entityManager) {
    entityManager.clear();
    entityManager.close();
  }
}
