/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 24, 2011 2:23:07 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.rule.validation.RuleValidationHelper;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class CorrespondentBetweenRecords.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class CorrespondentBetweenRecords extends RuleValidation {

  /** The target record type. */
  private final RecordEnum targetRecordType;

  /** The source field set. */
  private final Set<FieldEnum> sourceFieldSet;

  /** The target field set. */
  private final Set<FieldEnum> targetFieldSet;

  /** The helper. */
  private RuleValidationHelper helper;

  /** The fields. */
  private FieldEnum[] fields;

  /** The rule key. */
  private String ruleKey;

  /** The target keys. */
  private Set<String> targetKeys;

  /** The source set. */
  private Map<Integer, Object[]> sourceData;

  /**
   * Instantiates a new correspondent between records.
   * 
   * @param recordType
   *          the record type
   * @param targetRecordType
   *          the target record type
   * @param sourceFieldSet
   *          the source field set
   * @param targetFieldSet
   *          the target field set
   */
  public CorrespondentBetweenRecords(final RecordEnum recordType,
      final RecordEnum targetRecordType, final Set<FieldEnum> sourceFieldSet,
      final Set<FieldEnum> targetFieldSet) {
    super();
    this.targetRecordType = targetRecordType;
    this.sourceFieldSet = sourceFieldSet;
    this.targetFieldSet = targetFieldSet;
    initialize(recordType);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    final RecordEnum recordType = record.getType();
    return recordType == getRecordType() || recordType == targetRecordType;
  }

  /**
   * Creates the key.
   * 
   * @param array
   *          the array
   * @return the string
   */
  private String createKey(final Object[] array) {
    String key = null;
    final StringBuilder sb = new StringBuilder();
    for (final Object value : array) {
      if (value != null) {
        sb.append("_").append(value.toString());
      }
    }
    if (sb.length() > 0) {
      key = sb.toString();
    }
    return key;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#getHelper()
   */
  @Override
  public RuleValidationHelper getHelper() {
    return helper;
  }

  /**
   * Gets the source data.
   * 
   * @return the source data
   */
  @SuppressWarnings("unchecked")
  public Map<Integer, Object[]> getSourceData() {
    if (sourceData == null) {
      final String key = ruleKey + "sourceData";
      sourceData = (Map<Integer, Object[]>) getContextData().getDataMap().get(key);
      if (sourceData == null) {
        sourceData = new HashMap<Integer, Object[]>();
        getContextData().getDataMap().put(key, sourceData);
      }
    }
    return sourceData;
  }

  /**
   * Gets the target keys.
   * 
   * @return the target keys
   */
  @SuppressWarnings("unchecked")
  public Set<String> getTargetKeys() {
    if (targetKeys == null) {
      final String key = ruleKey + "targetKeys";
      targetKeys = (Set<String>) getContextData().getDataMap().get(key);
      if (targetKeys == null) {
        targetKeys = new HashSet<String>();
        getContextData().getDataMap().put(key, targetKeys);
      }
    }
    return targetKeys;
  }

  /**
   * Initialize.
   * 
   * @param recordType
   *          the record type
   */
  private void initialize(final RecordEnum recordType) {
    fields = new FieldEnum[sourceFieldSet.size()];
    fields = sourceFieldSet.toArray(fields);
    helper = new RuleValidationHelper();
    helper.setReportFields(fields);

    final StringBuilder sb = new StringBuilder(128);
    sb.append(RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS.getValue());
    sb.append(recordType.getText());
    sb.append(targetRecordType.getText());
    sb.append(sourceFieldSet.toString());
    sb.append(targetFieldSet.toString());
    ruleKey = sb.toString();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    final int count = getContextData().getCount(getRecordType());
    if (count == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
      return;
    }
    setNumOfRecords(count);

    final Set<String> tSet = getTargetKeys();
    final Map<Integer, Object[]> src = getSourceData();
    for (final Entry<Integer, Object[]> entry : src.entrySet()) {
      final Object[] value = entry.getValue();
      final String key = createKey(value);
      if (tSet.contains(key)) {
        if (tSet.contains(key)) {
          increaseNumOfPassedRecords();
        }
      } else {
        getContextData().getFailedData().addFailedValues(getRecordType(),
            helper.getReportFields(), value, entry.getKey(), helper);
      }
    }

    sourceFieldSet.clear();
    targetFieldSet.clear();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final RecordEnum recordType = record.getType();
    final Set<String> tSet = getTargetKeys();
    if (recordType == getRecordType()) {
      final String dataKey = getKey(record, sourceFieldSet);
      if (dataKey != null) {
        if (tSet.contains(dataKey)) {
          increaseNumOfPassedRecords();
        } else {
          getSourceData().put(Integer.valueOf(record.getIndex()),
              DetailResultUtil.ripData(record, helper.getReportFields()));
        }
      } else {
        getContextData().getFailedData().addFailedRecord(record, helper);
      }
    } else if (recordType == targetRecordType) {
      final String key = getKey(record, targetFieldSet);
      if (key != null && !tSet.contains(key)) {
        tSet.add(key);
      }
    }
  }
}
