/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 3:38:36 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation;

import java.util.Set;

import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.rulemanager.data.ContextData;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class RuleValidation.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public abstract class RuleValidation implements BaseRule {

  /** The num of records. */
  private int numOfRecords;

  /** The num of passed records. */
  private int numOfPassedRecords;

  /** The rule name. */
  private String ruleName;

  /** The rule version. */
  private int ruleVersion;

  /** The point. */
  private double point;

  /** The record type. */
  private RecordEnum recordType;

  /** The context data. */
  private ContextData contextData;

  /** The cross rule. */
  private boolean crossRule = true;

  /** The failed message. */
  private String failedMessage;

  /** The rule version id. */
  private Long ruleVersionId;

  /** The log id. */
  private Integer logId;

  /** The rule type. */
  private RuleTypeEnum ruleType;

  /**
   * Instantiates a new rule validation.
   */
  public RuleValidation() {
  }

  /**
   * Gets the context data.
   * 
   * @return the context data
   */
  public ContextData getContextData() {
    return contextData;
  }

  /**
   * Gets the failed message.
   * 
   * @return the failed message
   */
  public String getFailedMessage() {
    return failedMessage;
  }

  /**
   * Gets the helper.
   * 
   * @return the helper
   */
  public RuleValidationHelper getHelper() {
    return null;
  }

  /**
   * Gets the key.
   * 
   * @param record
   *          the record
   * @param fieldSet
   *          the field set
   * @return the key
   */
  protected String getKey(final Record record, final Set<FieldEnum> fieldSet) {
    String key = null;
    final StringBuilder sb = new StringBuilder();
    for (final FieldEnum fieldEnum : fieldSet) {
      final Object value = record.getFieldValue(fieldEnum);
      if (value != null) {
        sb.append("_").append(value.toString());
      }
    }
    if (sb.length() > 0) {
      key = sb.toString();
    }
    return key;
  }

  /**
   * Gets the log id.
   * 
   * @return the log id
   */
  public Integer getLogId() {
    return logId;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#getNumOfPassedRecords()
   */
  public int getNumOfPassedRecords() {
    return numOfPassedRecords;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#getNumOfRecords()
   */
  public int getNumOfRecords() {
    return numOfRecords;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#getPoint()
   */
  public double getPoint() {
    return point;
  }

  /**
   * Gets the record type.
   * 
   * @return the record type
   */
  public RecordEnum getRecordType() {
    return recordType;
  }

  /**
   * Gets the rule name.
   * 
   * @return the rule name
   */
  public String getRuleName() {
    return ruleName;
  }

  /**
   * Gets the rule type.
   * 
   * @return the rule type
   */
  public RuleTypeEnum getRuleType() {
    return ruleType;
  }

  /**
   * Gets the rule version.
   * 
   * @return the rule version
   */
  public int getRuleVersion() {
    return ruleVersion;
  }

  /**
   * Gets the rule version id.
   * 
   * @return the rule version id
   */
  public Long getRuleVersionId() {
    return ruleVersionId;
  }

  /**
   * Increase num of passed records.
   */
  protected void increaseNumOfPassedRecords() {
    numOfPassedRecords++;
  }

  /**
   * Increase num of records.
   */
  protected void increaseNumOfRecords() {
    numOfRecords++;
  }

  /**
   * Checks if is cross rule.
   * 
   * @return true, if is cross rule
   */
  public boolean isCrossRule() {
    return crossRule;
  }

  /**
   * Post validate.
   */
  public void postValidate() {
    // do nothing
  }

  /**
   * Sets the context data.
   * 
   * @param contextData
   *          the new context data
   */
  public void setContextData(final ContextData contextData) {
    this.contextData = contextData;
  }

  /**
   * Sets the cross rule.
   * 
   * @param crossRule
   *          the new cross rule
   */
  public void setCrossRule(final boolean crossRule) {
    this.crossRule = crossRule;
  }

  /**
   * Sets the failed message.
   * 
   * @param failedMessage
   *          the new failed message
   */
  public void setFailedMessage(final String failedMessage) {
    this.failedMessage = failedMessage;
  }

  /**
   * Sets the failed message for value.
   * 
   * @param failedMessage
   *          the new failed message for value
   */
  public void setFailedMessageForValue(final String failedMessage) {
    if (" ".equals(failedMessage)) {
      this.failedMessage = "space";
    } else if (failedMessage.length() == 0) {
      this.failedMessage = "empty";
    } else {
      this.failedMessage = failedMessage;
    }
  }

  /**
   * Sets the log id.
   * 
   * @param logId
   *          the new log id
   */
  public void setLogId(final Integer logId) {
    this.logId = logId;
  }

  /**
   * Sets the num of passed records.
   * 
   * @param numOfPassedRecords
   *          the new num of passed records
   */
  public void setNumOfPassedRecords(final int numOfPassedRecords) {
    this.numOfPassedRecords = numOfPassedRecords;
  }

  /**
   * Sets the num of records.
   * 
   * @param numOfRecords
   *          the new num of records
   */
  public void setNumOfRecords(final int numOfRecords) {
    this.numOfRecords = numOfRecords;
  }

  /**
   * Sets the point.
   * 
   * @param point
   *          the new point
   */
  public void setPoint(final double point) {
    this.point = point;
  }

  /**
   * Sets the record type.
   * 
   * @param recordType
   *          the new record type
   */
  public void setRecordType(final RecordEnum recordType) {
    this.recordType = recordType;
  }

  /**
   * Sets the rule name.
   * 
   * @param ruleName
   *          the new rule name
   */
  public void setRuleName(final String ruleName) {
    this.ruleName = ruleName;
  }

  /**
   * Sets the rule type.
   * 
   * @param ruleType
   *          the new rule type
   */
  public void setRuleType(final RuleTypeEnum ruleType) {
    this.ruleType = ruleType;
  }

  /**
   * Sets the rule version.
   * 
   * @param ruleVersion
   *          the new rule version
   */
  public void setRuleVersion(final int ruleVersion) {
    this.ruleVersion = ruleVersion;
  }

  /**
   * Sets the rule version id.
   * 
   * @param ruleVersionId
   *          the new rule version id
   */
  public void setRuleVersionId(final Long ruleVersionId) {
    this.ruleVersionId = ruleVersionId;
  }
}
