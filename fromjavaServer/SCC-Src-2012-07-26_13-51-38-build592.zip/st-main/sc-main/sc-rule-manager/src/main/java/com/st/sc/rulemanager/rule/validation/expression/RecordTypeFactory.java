/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 6:29:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression;

import java.util.Map;

import com.st.sc.rulemanager.rule.validation.expression.stdf.ATR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.BPS;
import com.st.sc.rulemanager.rule.validation.expression.stdf.CDR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.CNR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.DTR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.EPS;
import com.st.sc.rulemanager.rule.validation.expression.stdf.FAR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.FTR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.HBR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.MIR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.MPR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.MRR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.NMR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PCR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PGR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PIR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PLR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PMR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PRR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PSR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PTR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.RDR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.RecordType;
import com.st.sc.rulemanager.rule.validation.expression.stdf.SBR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.SDR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.SSR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.STR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.TSR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.VUR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.WCR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.WIR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.WRR;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;
import com.st.stdfparser.stdf.util.RecordUtil;

/**
 * A factory for creating RecordType objects.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class RecordTypeFactory {

  /**
   * Create a new record type object for expression from record.
   * 
   * @param record
   *          the record
   * @return the record type
   */
  public static RecordType newRecordType(final Record record) {
    if (record == null || record.getType() == null) {
      return null;
    }

    RecordType recordType = null;
    final RecordEnum recordEnum = record.getType();
    final Map<String, Object> map = RecordUtil.toMapObject(record.getFields());
    switch (recordEnum) {
    case ATR:
      recordType = new ATR(map);
      break;

    case BPS:
      recordType = new BPS(map);
      break;

    case DTR:
      recordType = new DTR(map);
      break;

    case EPS:
      recordType = new EPS();
      break;

    case FAR:
      recordType = new FAR(map);
      break;

    case FTR:
      recordType = new FTR(map);
      break;

    case HBR:
      recordType = new HBR(map);
      break;

    case MIR:
      recordType = new MIR(map);
      break;

    case MPR:
      recordType = new MPR(map);
      break;

    case MRR:
      recordType = new MRR(map);
      break;

    case PCR:
      recordType = new PCR(map);
      break;

    case PGR:
      recordType = new PGR(map);
      break;

    case PIR:
      recordType = new PIR(map);
      break;

    case PLR:
      recordType = new PLR(map);
      break;

    case PMR:
      recordType = new PMR(map);
      break;

    case PRR:
      recordType = new PRR(map);
      break;

    case PTR:
      recordType = new PTR(map);
      break;

    case RDR:
      recordType = new RDR(map);
      break;

    case SBR:
      recordType = new SBR(map);
      break;

    case SDR:
      recordType = new SDR(map);
      break;

    case TSR:
      recordType = new TSR(map);
      break;

    case WCR:
      recordType = new WCR(map);
      break;

    case WIR:
      recordType = new WIR(map);
      break;
      
    case WRR:
      recordType = new WRR(map);
      break;

    case CDR:
      recordType = new CDR(map);
      break;

    case CNR:
      recordType = new CNR(map);
      break;

    case NMR:
      recordType = new NMR(map);
      break;

    case PSR:
      recordType = new PSR(map);
      break;

    case SSR:
      recordType = new SSR(map);
      break;

    case STR:
      recordType = new STR(map);
      break;

    case VUR:
      recordType = new VUR(map);
      break;

    default:
      break;
    }

    return recordType;
  }

  /**
   * Instantiates a new record type factory.
   */
  private RecordTypeFactory() {

  }
}
