/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 6:43:02 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression;

import java.util.Map;

import org.mvel2.MVEL;
import org.mvel2.ParserContext;
import org.mvel2.compiler.CompiledExpression;
import org.mvel2.integration.impl.MapVariableResolverFactory;

import com.st.sc.rulemanager.rule.validation.expression.exception.CompileException;
import com.st.sc.rulemanager.rule.validation.expression.exception.EvaluateException;

/**
 * The Class ExpressionProcessor.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ExpressionProcessor {

  /**
   * Compile the expression.
   * 
   * @param expression
   *          the expression
   * @param context
   *          the context
   * @return the object
   * @throws CompileException
   *           the compile exception
   */
  public static CompiledExpression compile(final String expression, final ParserContext context)
      throws CompileException {
    CompiledExpression compileExpression = null;
    try {
      compileExpression = (CompiledExpression) MVEL.compileExpression(expression, context);
    } catch (final Exception e) {
      throw new CompileException(e);
    }
    return compileExpression;
  }

  /**
   * Evaluate the compiled expression.
   * 
   * @param compiledExpression
   *          the compiled expression
   * @param object
   *          the object
   * @param vars
   *          the variables
   * @return the object
   * @throws EvaluateException
   *           the evaluate exception
   */
  public static Object eval(final Object compiledExpression, final Object object,
      final Map<String, Object> vars) throws EvaluateException {
    final MapVariableResolverFactory factory = new MapVariableResolverFactory(vars);
    Object result = null;
    try {
      result = MVEL.executeExpression(compiledExpression, object, factory);
    } catch (final Exception e) {
      throw new EvaluateException(e);
    }
    return result;
  }

  /**
   * Instantiates a new expression processor.
   */
  private ExpressionProcessor() {

  }
}
