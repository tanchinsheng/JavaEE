/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 16, 2011 11:37:25 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esotericsoftware.kryo.ObjectBuffer;
import com.st.sc.entity.CompliancyResult;
import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.data.FailedValueData;
import com.st.sc.rulemanager.data.RuleEngine;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.rule.validation.RuleValidationHelper;
import com.st.sc.rulemanager.serialization.FailedDetailReportData;
import com.st.sc.rulemanager.serialization.KryoHelper;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.scc.common.utils.ByteUtil;
import com.st.scc.common.utils.DateUtils;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.common.utils.StringUtil;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class DetailResultUtil.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class DetailResultUtil {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(DetailResultUtil.class);

  /** The Constant TEXT_FAILED. */
  private static final String TEXT_FAILED = "Failed";

  /**
   * Calculate result.
   * 
   * @param ruleEngine
   *          the rule engine
   * @param detailResultList
   *          the detail result list
   * @return the compliancy result
   */
  public static CompliancyResult calculateResult(final RuleEngine ruleEngine,
      final List<RuleValidationDetail> detailResultList) {
    double totalPoint = 0;
    double totalObtainedPoint = 0;
    final List<RuleValidation> ruleValidations = ruleEngine.getRuleValidations();

    final List<RuleValidationHelper> helpers = new ArrayList<RuleValidationHelper>();
    for (final RuleValidation rv : ruleValidations) {
      if (!rv.isCrossRule()) {
        rv.validate(null);
      }
      rv.postValidate();
      if (rv.getHelper() != null) {
        helpers.add(rv.getHelper());
      }

      totalPoint += rv.getPoint();
      double obtainedPoint = 0;
      if (rv.getNumOfRecords() != 0) {
        obtainedPoint = rv.getPoint() * rv.getNumOfPassedRecords() / rv.getNumOfRecords();
        totalObtainedPoint += obtainedPoint;
      }
      final RuleValidationDetail detail = DetailResultUtil.toDetail(rv, obtainedPoint);
      if (detail != null) {
        detailResultList.add(detail);
        if (TEXT_FAILED.equals(detail.getResultStr())) {
          ruleEngine.getLogIdList().add(rv.getLogId());
        }
      }
    }
    final ContextData contextData = ruleEngine.getContextData();
    contextData.getFailedData().flushFailedValues(helpers);
    contextData.clear();

    double compliancyScore = 0;
    if (totalPoint != 0) {
      compliancyScore = totalObtainedPoint / totalPoint * 100;
    }
    final CompliancyResult result =
        createCompliancyResult(ruleEngine, new Timestamp(contextData.getCheckingTime()));
    result.setCompliancyScore(Double.valueOf(compliancyScore));
    final Record mirRecord = contextData.getMirRecord();
    if (mirRecord != null) {
      final Long startT = (Long) mirRecord.getFieldValue(FieldEnum.START_T);
      if (startT != null) {
        final Date gmtDate = DateUtils.getGMTDate(new Date(startT.longValue() * 1000));
        result.setMirStartT(new Timestamp(gmtDate.getTime()));
      }
      result.setMirCmodCod((String) mirRecord.getFieldValue(FieldEnum.CMOD_COD));
      result.setMirDsgnRev((String) mirRecord.getFieldValue(FieldEnum.DSGN_REV));
      result.setMirExecTyp((String) mirRecord.getFieldValue(FieldEnum.EXEC_TYP));
      result.setMirExecVer((String) mirRecord.getFieldValue(FieldEnum.EXEC_VER));
      result.setMirFlowId((String) mirRecord.getFieldValue(FieldEnum.FLOW_ID));
      result.setMirJobNam((String) mirRecord.getFieldValue(FieldEnum.JOB_NAM));
      result.setMirJobRev((String) mirRecord.getFieldValue(FieldEnum.JOB_REV));
      result.setMirModeCod((String) mirRecord.getFieldValue(FieldEnum.MODE_COD));
      result.setMirOperFrq((String) mirRecord.getFieldValue(FieldEnum.OPER_FRQ));
      result.setMirPartTyp((String) mirRecord.getFieldValue(FieldEnum.PART_TYP));
      result.setMirProcId((String) mirRecord.getFieldValue(FieldEnum.PROC_ID));
      result.setMirSpecNam((String) mirRecord.getFieldValue(FieldEnum.SPEC_NAM));
      result.setMirSpecVer((String) mirRecord.getFieldValue(FieldEnum.SPEC_VER));
      result.setMirSuprNam((String) mirRecord.getFieldValue(FieldEnum.SUPR_NAM));
      result.setMirTstrTyp((String) mirRecord.getFieldValue(FieldEnum.TSTR_TYP));
    }
    final Record mrrRecord = contextData.getMrrRecord();
    if (mrrRecord != null) {
      final Long finishT = (Long) mrrRecord.getFieldValue(FieldEnum.FINISH_T);
      if (finishT != null) {
        final Date gmtDate = DateUtils.getGMTDate(new Date(finishT.longValue() * 1000));
        result.setMrrFinishT(new Timestamp(gmtDate.getTime()));
      }
    }

    return result;
  }

  /**
   * Creates the compliancy result.
   * 
   * @param ruleEngine
   *          the rule engine
   * @param checkingTime
   *          the checking time
   * @return the compliancy result
   */
  private static CompliancyResult createCompliancyResult(final RuleEngine ruleEngine,
      final Timestamp checkingTime) {
    final CompliancyResult result = new CompliancyResult();
    result.setCheckingTime(checkingTime);
    result.setFileName(ruleEngine.getFileName());
    result.setRuleSetName(ruleEngine.getRuleSetName());
    result.setRuleSetVer(ruleEngine.getRuleSetVersion());
    return result;
  }

  /**
   * Flush headers of data to file.
   * 
   * @param file
   *          the file
   * @param headerMap
   *          the header map
   * @return true, if successful
   */
  public static boolean flushHeaders(final File file, final Map<Integer, String[]> headerMap) {
    boolean retVal = false;

    OutputStream fos = null;
    ObjectBuffer objectBuffer = null;
    try {
      objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
      final ByteArrayOutputStream baos = new ByteArrayOutputStream(8192);

      synchronized (objectBuffer) {
        final Set<Entry<Integer, String[]>> entrySet = headerMap.entrySet();
        for (final Entry<Integer, String[]> entry : entrySet) {
          final Integer key = entry.getKey();
          final byte[] bytes = objectBuffer.writeClassAndObject(entry.getValue());
          baos.write(ByteUtil.fromInt(key.intValue()));
          baos.write(ByteUtil.fromInt(bytes.length));
          baos.write(bytes);
        }
      }
      final byte[] byteArray = baos.toByteArray();

      FileUtils.createParentPath(file);
      if (!file.exists()) {
        file.createNewFile();
      }
      fos = new BufferedOutputStream(new FileOutputStream(file, true));
      fos.write(byteArray);
      fos.flush();
      retVal = true;
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().invalidateObject(objectBuffer);
        } catch (final Exception ex) {
          LOG.error(e.getMessage(), e);
        } finally {
          objectBuffer = null;
        }
      }
    } finally {
      if (fos != null) {
        try {
          fos.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().returnObject(objectBuffer);
        } catch (final Exception e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Flush record data to file.
   * 
   * @param file
   *          the file
   * @param map
   *          the data map
   * @param indexList
   *          the written index list
   * @return true, if successful
   */
  public static boolean flushRecordData(final File file, final Map<Integer, Object[]> map,
      final Collection<Integer> indexList) {
    boolean retVal = false;

    OutputStream fos = null;
    ObjectBuffer objectBuffer = null;
    try {
      FileUtils.createParentPath(file);
      if (!file.exists()) {
        file.createNewFile();
      }
      objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
      fos = new BufferedOutputStream(new FileOutputStream(file, true));

      final Set<Entry<Integer, Object[]>> entrySet = map.entrySet();
      synchronized (objectBuffer) {
        for (final Entry<Integer, Object[]> entry : entrySet) {
          final int index = entry.getKey().intValue();
          final Object[] array = entry.getValue();
          final byte[] bytes = objectBuffer.writeClassAndObject(array);
          fos.write(ByteUtil.fromInt(index));
          fos.write(ByteUtil.fromInt(bytes.length));
          fos.write(bytes);
          if (indexList != null) {
            indexList.add(index);
          }
        }
      }

      fos.flush();
      retVal = true;
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().invalidateObject(objectBuffer);
        } catch (final Exception ex) {
          LOG.error(e.getMessage(), e);
        } finally {
          objectBuffer = null;
        }
      }
      if (indexList != null) {
        indexList.clear();
      }
    } finally {
      if (fos != null) {
        try {
          fos.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().returnObject(objectBuffer);
        } catch (final Exception e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Flush rule index data.
   * 
   * @param file
   *          the file
   * @param list
   *          the list
   * @return true, if successful
   */
  public static boolean flushRuleIndexData(final File file, final List<Integer> list) {
    boolean retVal = false;

    OutputStream fos = null;
    ObjectBuffer objectBuffer = null;
    try {
      FileUtils.createParentPath(file);
      if (!file.exists()) {
        file.createNewFile();
      }
      objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
      fos = new BufferedOutputStream(new FileOutputStream(file, true));

      synchronized (objectBuffer) {
        fos.write(ByteUtil.fromInt(list.size()));
        for (final Integer integer : list) {
          final int index = integer.intValue();
          fos.write(ByteUtil.fromInt(index));
        }
      }

      fos.flush();
      retVal = true;
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().invalidateObject(objectBuffer);
        } catch (final Exception ex) {
          LOG.error(e.getMessage(), e);
        } finally {
          objectBuffer = null;
        }
      }
    } finally {
      if (fos != null) {
        try {
          fos.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().returnObject(objectBuffer);
        } catch (final Exception e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Flush special data.
   * 
   * @param file
   *          the file
   * @param map
   *          the special data map
   * @return true, if successful
   */
  public static boolean flushSpecialData(final File file,
      final Map<Integer, List<Object[]>> map) {
    boolean retVal = false;

    OutputStream fos = null;
    ObjectBuffer objectBuffer = null;
    try {
      FileUtils.createParentPath(file);
      if (!file.exists()) {
        file.createNewFile();
      }
      objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
      fos = new BufferedOutputStream(new FileOutputStream(file, true));

      final Set<Entry<Integer, List<Object[]>>> entrySet = map.entrySet();
      synchronized (objectBuffer) {
        for (final Entry<Integer, List<Object[]>> entry : entrySet) {
          final int index = entry.getKey().intValue();
          final List<Object[]> list = entry.getValue();
          fos.write(ByteUtil.fromInt(index));
          fos.write(ByteUtil.fromInt(list.size()));
          for (final Object[] array : list) {
            final byte[] bytes = objectBuffer.writeClassAndObject(array);
            fos.write(ByteUtil.fromInt(bytes.length));
            fos.write(bytes);
          }
        }
      }

      fos.flush();
      retVal = true;
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().invalidateObject(objectBuffer);
        } catch (final Exception ex) {
          LOG.error(e.getMessage(), e);
        } finally {
          objectBuffer = null;
        }
      }
    } finally {
      if (fos != null) {
        try {
          fos.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().returnObject(objectBuffer);
        } catch (final Exception e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the failed report data.
   * 
   * @param failedValuePath
   *          the failed value path
   * @param detail
   *          the detail
   * @param headerMap
   *          the header map
   * @return the failed report data
   */
  public static FailedDetailReportData getFailedReportData(final String failedValuePath,
      final RuleValidationDetail detail, final Map<Integer, String[]> headerMap) {
    final RecordEnum recordType = RecordEnum.fromValue(detail.getRecordType());
    final RuleTypeEnum ruleType = RuleTypeEnum.fromValue(detail.getRuleType());
    return getFailedReportData(failedValuePath,
        getResultDetailFileName(detail.getRuleVersionId()), recordType, ruleType, headerMap);
  }

  /**
   * Gets the failed report data.
   * 
   * @param failedValuePath
   *          the failed value path
   * @param detailFileName
   *          the detail file name
   * @param recordType
   *          the record type
   * @param ruleType
   *          the rule type
   * @param headerMap
   *          the header map
   * @return the failed report data
   */
  public static FailedDetailReportData getFailedReportData(final String failedValuePath,
      final String detailFileName, final RecordEnum recordType, final RuleTypeEnum ruleType,
      final Map<Integer, String[]> headerMap) {
    FailedDetailReportData reportData = null;
    final int headerIndexKey = getHeaderIndexKey(recordType, ruleType);
    String[] headers = null;
    Object[][] dataList = null;
    switch (headerIndexKey) {
    case FailedValueData.INDEX_KEY_HARDBIN:
    case FailedValueData.INDEX_KEY_SOFTBIN:
    case FailedValueData.INDEX_KEY_SDR:
      headers = headerMap.get(Integer.valueOf(headerIndexKey));
      dataList =
          getSpecialData(new File(failedValuePath + FailedValueData.SPECIAL_DATA_FILE_NAME),
              headerIndexKey);
      break;

    default:
      headers = headerMap.get(recordType.getId());
      final int[] indexList = getIndexData(new File(failedValuePath + detailFileName));
      dataList =
          getRecordData(new File(failedValuePath + recordType.getText().toLowerCase()),
              indexList);
      break;
    }

    if (headers != null && dataList != null) {
      reportData = new FailedDetailReportData();
      reportData.setHeaders(headers);
      reportData.setData(dataList);
    }
    return reportData;
  }

  /**
   * Gets the file path.
   * 
   * @param checkingTime
   *          the checking time
   * @param fileId
   *          the file id
   * @return the file path
   */
  public static String getFilePath(final Date checkingTime, final long fileId) {
    final String separator = File.separator;
    final StringBuilder sb = new StringBuilder();
    if (checkingTime != null) {
      final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd" + separator + "HH");
      final String dateStr = dateFormat.format(checkingTime);
      sb.append(dateStr).append(separator);
    }
    final NumberFormat numberFormat = new DecimalFormat("0000000000000000");
    sb.append(numberFormat.format(fileId)).append(separator);
    return sb.toString();
  }

  /**
   * Gets the file path.
   * 
   * @param sessionId
   *          the session id
   * @param checkingTime
   *          the checking time
   * @param uuid
   *          the UUID
   * @return the file path
   */
  public static String getFilePath(final String sessionId, final Timestamp checkingTime,
      final String uuid) {
    final String separator = File.separator;
    final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd" + separator + "HH");
    final String dateStr = dateFormat.format(checkingTime);
    final StringBuilder sb = new StringBuilder();
    sb.append(sessionId).append(separator);
    sb.append(dateStr).append(separator);
    sb.append(uuid).append(separator);
    return sb.toString();
  }

  /**
   * Gets the header data.
   * 
   * @param headerFile
   *          the header file
   * @return the header data
   */
  public static Map<Integer, String[]> getHeaderData(final File headerFile) {
    Map<Integer, String[]> map = null;
    ObjectBuffer objectBuffer = null;
    RandomAccessFile fis = null;
    final byte[] buffer = new byte[8192];
    final byte[] int2Buffer = new byte[8];
    final byte[] intBuffer = new byte[4];
    try {
      objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
      final ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
      map = new HashMap<Integer, String[]>();
      fis = new RandomAccessFile(headerFile, "r");
      String[] array = null;

      synchronized (objectBuffer) {
        while (fis.read(int2Buffer) != -1) {
          intBuffer[0] = int2Buffer[0];
          intBuffer[1] = int2Buffer[1];
          intBuffer[2] = int2Buffer[2];
          intBuffer[3] = int2Buffer[3];
          final int index = ByteUtil.toInt(intBuffer);

          intBuffer[0] = int2Buffer[4];
          intBuffer[1] = int2Buffer[5];
          intBuffer[2] = int2Buffer[6];
          intBuffer[3] = int2Buffer[7];
          int length = ByteUtil.toInt(intBuffer);
          while (length > 0) {
            final int len = buffer.length < length ? buffer.length : length;
            fis.read(buffer, 0, len);
            byteStream.write(buffer, 0, len);
            length -= len;
          }
          array = (String[]) objectBuffer.readClassAndObject(byteStream.toByteArray());
          byteStream.reset();
          if (array != null) {
            map.put(index, array);
          }
        }
      }
    } catch (final Exception e) {
      map = null;
      LOG.error(e.getMessage(), e);
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().invalidateObject(objectBuffer);
        } catch (final Exception ex) {
          LOG.error(e.getMessage(), e);
        } finally {
          objectBuffer = null;
        }
      }
    } finally {
      if (fis != null) {
        try {
          fis.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().returnObject(objectBuffer);
        } catch (final Exception e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }

    return map;
  }

  /**
   * Gets the header index key.
   * 
   * @param recordType
   *          the record type
   * @param ruleType
   *          the rule type
   * @return the header index key
   */
  public static int getHeaderIndexKey(final RecordEnum recordType, final RuleTypeEnum ruleType) {
    int key = 0;
    if (ruleType != null) {
      switch (ruleType) {
      case NUMBER_OF_BIN_RECORD_OP2:
        if (recordType == RecordEnum.HBR) {
          key = FailedValueData.INDEX_KEY_HARDBIN;
        } else if (recordType == RecordEnum.SBR) {
          key = FailedValueData.INDEX_KEY_SOFTBIN;
        }
        break;

      case NUMBER_OF_SDR:
        key = FailedValueData.INDEX_KEY_SDR;
        break;

      default:
        if (recordType != null) {
          key = (short) recordType.ordinal();
        }
        break;
      }
    }
    return key;
  }

  /**
   * Gets the index data.
   * 
   * @param indexFile
   *          the index file
   * @return the index data
   */
  public static int[] getIndexData(final File indexFile) {
    int[] list = null;
    ObjectBuffer objectBuffer = null;
    RandomAccessFile fis = null;
    final byte[] buf = new byte[8192];
    final byte[] intBuffer = new byte[4];
    try {
      objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
      fis = new RandomAccessFile(indexFile, "r");

      synchronized (objectBuffer) {
        fis.read(intBuffer);
        final int length = ByteUtil.toInt(intBuffer);
        list = new int[length];
        int len = 0;
        int count = 0;
        while ((len = fis.read(buf)) != -1) {
          for (int i = 0; i < len; i += 4) {
            intBuffer[0] = buf[i];
            intBuffer[1] = buf[i + 1];
            intBuffer[2] = buf[i + 2];
            intBuffer[3] = buf[i + 3];
            final int index = ByteUtil.toInt(intBuffer);
            list[count++] = index;
          }
        }
      }
    } catch (final Exception e) {
      list = null;
      LOG.error(e.getMessage(), e);
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().invalidateObject(objectBuffer);
        } catch (final Exception ex) {
          LOG.error(e.getMessage(), e);
        } finally {
          objectBuffer = null;
        }
      }
    } finally {
      if (fis != null) {
        try {
          fis.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().returnObject(objectBuffer);
        } catch (final Exception e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }

    return list;
  }

  /**
   * Gets the record data.
   * 
   * @param recordFile
   *          the record file
   * @param indexList
   *          the index list
   * @return the record data
   */
  public static Object[][] getRecordData(final File recordFile, final int[] indexList) {
    Object[][] list = null;
    if (indexList != null) {
      ObjectBuffer objectBuffer = null;
      RandomAccessFile fis = null;
      final byte[] buffer = new byte[8192];
      final byte[] int2Buffer = new byte[8];
      final byte[] intBuffer = new byte[4];

      final Set<Integer> set = new HashSet<Integer>();
      for (final int index : indexList) {
        set.add(Integer.valueOf(index));
      }
      try {
        objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
        final ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        fis = new RandomAccessFile(recordFile, "r");
        list = new Object[indexList.length][];
        Object[] array = null;
        int count = 0;

        synchronized (objectBuffer) {
          while (fis.read(int2Buffer) != -1) {
            intBuffer[0] = int2Buffer[0];
            intBuffer[1] = int2Buffer[1];
            intBuffer[2] = int2Buffer[2];
            intBuffer[3] = int2Buffer[3];
            final Integer index = Integer.valueOf(ByteUtil.toInt(intBuffer));

            intBuffer[0] = int2Buffer[4];
            intBuffer[1] = int2Buffer[5];
            intBuffer[2] = int2Buffer[6];
            intBuffer[3] = int2Buffer[7];
            int length = ByteUtil.toInt(intBuffer);
            if (set.contains(index)) {
              while (length > 0) {
                final int len = buffer.length < length ? buffer.length : length;
                fis.read(buffer, 0, len);
                byteStream.write(buffer, 0, len);
                length -= len;
              }
              array = (Object[]) objectBuffer.readClassAndObject(byteStream.toByteArray());
              byteStream.reset();
              if (array != null) {
                set.remove(index);
                list[count++] = array;
                if (set.isEmpty()) {
                  break;
                }
              }
            } else {
              fis.skipBytes(length);
            }
          }
        }
      } catch (final Exception e) {
        list = null;
        LOG.error(e.getMessage(), e);
        if (objectBuffer != null) {
          try {
            KryoHelper.getObjectPool().invalidateObject(objectBuffer);
          } catch (final Exception ex) {
            LOG.error(e.getMessage(), e);
          } finally {
            objectBuffer = null;
          }
        }
      } finally {
        if (fis != null) {
          try {
            fis.close();
          } catch (final IOException e) {
            LOG.error("Failed to close stream", e);
          }
        }
        if (objectBuffer != null) {
          try {
            KryoHelper.getObjectPool().returnObject(objectBuffer);
          } catch (final Exception e) {
            LOG.error(e.getMessage(), e);
          }
        }
      }
    }

    return list;
  }

  /**
   * Gets the result detail file name.
   * 
   * @param ruleVersionId
   *          the rule version id
   * @return the result detail file name
   */
  public static String getResultDetailFileName(final long ruleVersionId) {
    final NumberFormat numberFormat = new DecimalFormat("0000000000000000");
    return numberFormat.format(ruleVersionId);
  }

  /**
   * Gets the special data.
   * 
   * @param specialFile
   *          the special file
   * @param indexData
   *          the index data
   * @return the special data
   */
  public static Object[][] getSpecialData(final File specialFile, final int indexData) {
    Object[][] retVal = null;
    ObjectBuffer objectBuffer = null;
    RandomAccessFile fis = null;
    final byte[] buffer = new byte[8192];
    final byte[] intBuffer = new byte[4];
    try {
      objectBuffer = (ObjectBuffer) KryoHelper.getObjectPool().borrowObject();
      final ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
      fis = new RandomAccessFile(specialFile, "r");
      Object[] array = null;

      synchronized (objectBuffer) {
        while (fis.read(intBuffer) != -1) {
          final int index = ByteUtil.toInt(intBuffer);
          fis.read(intBuffer);
          final int size = ByteUtil.toInt(intBuffer);
          int length = 0;

          if (index != indexData) {
            for (int i = 0; i < size; i++) {
              fis.read(intBuffer);
              length = ByteUtil.toInt(intBuffer);
              fis.skipBytes(length);
            }
          } else {
            final List<Object[]> list = new ArrayList<Object[]>();
            for (int i = 0; i < size; i++) {
              fis.read(intBuffer);
              length = ByteUtil.toInt(intBuffer);
              while (length > 0) {
                final int len = buffer.length < length ? buffer.length : length;
                fis.read(buffer, 0, len);
                byteStream.write(buffer, 0, len);
                length -= len;
              }
              array = (Object[]) objectBuffer.readClassAndObject(byteStream.toByteArray());
              byteStream.reset();
              if (array != null) {
                list.add(array);
              }
            }
            retVal = new Object[list.size()][];
            int i = 0;
            for (final Object[] objects : list) {
              retVal[i++] = objects;
            }
            break;
          }
        }
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().invalidateObject(objectBuffer);
        } catch (final Exception ex) {
          LOG.error(e.getMessage(), e);
        } finally {
          objectBuffer = null;
        }
      }
    } finally {
      if (fis != null) {
        try {
          fis.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
      if (objectBuffer != null) {
        try {
          KryoHelper.getObjectPool().returnObject(objectBuffer);
        } catch (final Exception e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }

    return retVal;
  }

  /**
   * Rip data from record with given fields.
   * 
   * @param record
   *          the record
   * @param fields
   *          the fields
   * @return the array of objects
   */
  public static Object[] ripData(final Record record, final FieldEnum[] fields) {
    Object[] array = null;
    if (fields != null) {
      array = new Object[fields.length];
      for (int i = 0; i < fields.length; i++) {
        final FieldEnum field = fields[i];
        final Object value = record.getFieldValue(field);
        if (value != null) {
          if (value instanceof List< ? >) {
            array[i] = String.valueOf(value);
          } else {
            switch (field.getType()) {
            case BX:
              array[i] = StringUtil.byteToBinaryString(((Number) value).shortValue());
              break;

            case Bn:
            case Dn:
            case N1:
              array[i] = Arrays.toString((byte[]) value);
              break;

            default:
              array[i] = value;
              break;
            }
          }
        }
      }
    }
    return array;
  }

  /**
   * To bytes.
   * 
   * @param data
   *          the data
   * @return the byte[]
   */
  public static byte[] toBytes(final RuleValidationDetail[] data) {
    byte[] bytes = null;
    if (data != null) {
      bytes = ByteUtil.toByteArray(data);
    } else {
      bytes = ByteUtil.toByteArray(new RuleValidationDetail[0]);
    }

    return bytes;
  }

  /**
   * To detail.
   * 
   * @param bytes
   *          the bytes
   * @return the failed detail report data
   */
  public static RuleValidationDetail[] toDetail(final byte[] bytes) {
    RuleValidationDetail[] data = null;
    if (bytes != null && bytes.length > 0) {
      data = (RuleValidationDetail[]) ByteUtil.toObject(bytes);
    } else {
      data = new RuleValidationDetail[0];
    }
    return data;
  }

  /**
   * To detail.
   * 
   * @param rv
   *          the rule validation
   * @param obtainedPoint
   *          the obtained point
   * @return the rule validation detail
   */
  public static RuleValidationDetail toDetail(final RuleValidation rv,
      final double obtainedPoint) {
    RuleValidationDetail detail = null;
    if (rv != null) {
      detail = new RuleValidationDetail();
      detail.setRuleName(rv.getRuleName());
      detail.setPoint((int) rv.getPoint());
      final int numOfRecords = rv.getNumOfRecords();
      detail.setNumOfRecords(numOfRecords);
      final int numOfPassedRecords = rv.getNumOfPassedRecords();
      detail.setNumOfPassedRecords(numOfPassedRecords);
      detail.setObtainedPoint(obtainedPoint);
      final Long ruleVersionId = rv.getRuleVersionId();
      if (ruleVersionId != null) {
        detail.setRuleVersionId(ruleVersionId.longValue());
      }
      boolean failed = false;
      if (numOfRecords == numOfPassedRecords && numOfRecords > 0) {
        detail.setResultStr("Passed");
      } else {
        detail.setResultStr(TEXT_FAILED);
        failed = true;
      }
      detail.setRecordType(rv.getRecordType().getText());
      detail.setRuleVersion(rv.getRuleVersion());
      if (failed) {
        final String message = rv.getFailedMessage();
        if (message != null) {
          detail.setFailedValue(message);
        }
      }
      final RuleTypeEnum ruleType = rv.getRuleType();
      if (ruleType != null) {
        detail.setRuleType(ruleType.getValue());
      }
    }
    return detail;
  }

  /**
   * Instantiates a new detail result utility.
   */
  private DetailResultUtil() {

  }
}
