/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf.gdr;
import java.util.Map;

import com.st.sc.rulemanager.rule.validation.expression.stdf.RecordType;
import com.st.stdfparser.stdf.RecordEnum;

public class REF_DIE implements RecordType {
  private Object FLD_CNT;
  private Object XREF;
  private Object YREF;
  private Object X_COORD;
  private Object Y_COORD;
  
  public REF_DIE(Map<String, Object> map) {
    initialize(map);
  }
  
  private void initialize(Map<String, Object> map) {
    this.FLD_CNT = map.get("FLD_CNT");
    this.XREF = map.get("XREF");
    this.YREF = map.get("YREF");
    this.X_COORD = map.get("X_COORD");
    this.Y_COORD = map.get("Y_COORD");
  }
  public Object getFLD_CNT() {
    return this.FLD_CNT;
  }
  public Object getXREF() {
    return this.XREF;
  }
  public Object getYREF() {
    return this.YREF;
  }
  public Object getX_COORD() {
    return this.X_COORD;
  }
  public Object getY_COORD() {
    return this.Y_COORD;
  }
  public String getType() {
    return RecordEnum.GDR_REF_DIE.getText();
  }
}
