/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 5, 2011 1:29:59 AM - Trung - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl.order;

import java.util.LinkedHashSet;
import java.util.Set;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class WIROrder.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class WIROrder extends RuleValidation {

  /** The open HEAD_NUM set. */
  private final Set<Short> openHeadNumSet = new LinkedHashSet<Short>();

  /** The number of invalid WIR. */
  private int numOfInvalidWIR;

  /**
   * Instantiates a new WIR order.
   */
  public WIROrder() {
    super();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    final RecordEnum recordType = record.getType();
    return recordType == RecordEnum.WIR || recordType == RecordEnum.WRR;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    final int count = getContextData().getCount(getRecordType());
    if (count == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
      return;
    }

    setNumOfPassedRecords(getNumOfRecords() - numOfInvalidWIR);

    if (getNumOfRecords() > getNumOfPassedRecords()) {
      setFailedMessage("WIR cannot occur if there is an open WIR with same HEAD_NUM");
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final RecordEnum recordType = record.getType();
    final Short headNum = (Short) record.getFieldValue(FieldEnum.HEAD_NUM);
    switch (recordType) {
    case WIR:
      if (openHeadNumSet.contains(headNum)) {
        numOfInvalidWIR++;
      } else {
        openHeadNumSet.add(headNum);
      }
      increaseNumOfRecords();
      break;

    case WRR:
      openHeadNumSet.remove(headNum);
      break;

    default:
      break;
    }
  }

}
