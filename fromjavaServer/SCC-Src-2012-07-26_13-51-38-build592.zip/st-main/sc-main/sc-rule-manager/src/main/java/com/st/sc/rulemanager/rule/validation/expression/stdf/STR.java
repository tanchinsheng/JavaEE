/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 6:29:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;
import java.util.Map;

public class STR implements RecordType {
  private Object CONT_FLG;
  private Object TEST_NUM;
  private Object HEAD_NUM;
  private Object SITE_NUM;
  private Object PSR_REF;
  private Object TEST_FLG;
  private Object LOG_TYP;
  private Object TEST_TXT;
  private Object ALARM_ID;
  private Object PROG_TXT;
  private Object RSLT_TXT;
  private Object Z_VAL;
  private Object FMU_FLG;
  private Object MASK_MAP;
  private Object FAL_MAP;
  private Object CYC_CNT;
  private Object TOTF_CNT;
  private Object TOTL_CNT;
  private Object CYC_BASE;
  private Object BIT_BASE;
  private Object COND_CNT;
  private Object LIM_CNT;
  private Object CYC_SIZE;
  private Object PMR_SIZE;
  private Object CHN_SIZE;
  private Object PAT_SIZE;
  private Object BIT_SIZE;
  private Object U1_SIZE;
  private Object U2_SIZE;
  private Object U3_SIZE;
  private Object UTX_SIZE;
  private Object CAP_BGN;
  private Object LIM_INDX;
  private Object LIM_SPEC;
  private Object COND_LST;
  private Object CYCO_CNT;
  private Object CYC_OFST;
  private Object PMR_CNT;
  private Object PMR_INDX;
  private Object CHN_CNT;
  private Object CHN_NUM;
  private Object EXP_CNT;
  private Object EXP_DATA;
  private Object CAP_CNT;
  private Object CAP_DATA;
  private Object NEW_CNT;
  private Object NEW_DATA;
  private Object PAT_CNT;
  private Object PAT_NUM;
  private Object BPOS_CNT;
  private Object BIT_POS;
  private Object USR1_CNT;
  private Object USR1;
  private Object USR2_CNT;
  private Object USR2;
  private Object USR3_CNT;
  private Object USR3;
  private Object TXT_CNT;
  private Object USER_TXT;
  public STR(Map<String, Object> map) {
    initialize(map);
  }
  private void initialize(Map<String, Object> map) {
    this.CONT_FLG = map.get("CONT_FLG");
    this.TEST_NUM = map.get("TEST_NUM");
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_NUM = map.get("SITE_NUM");
    this.PSR_REF = map.get("PSR_REF");
    this.TEST_FLG = map.get("TEST_FLG");
    this.LOG_TYP = map.get("LOG_TYP");
    this.TEST_TXT = map.get("TEST_TXT");
    this.ALARM_ID = map.get("ALARM_ID");
    this.PROG_TXT = map.get("PROG_TXT");
    this.RSLT_TXT = map.get("RSLT_TXT");
    this.Z_VAL = map.get("Z_VAL");
    this.FMU_FLG = map.get("FMU_FLG");
    this.MASK_MAP = map.get("MASK_MAP");
    this.FAL_MAP = map.get("FAL_MAP");
    this.CYC_CNT = map.get("CYC_CNT");
    this.TOTF_CNT = map.get("TOTF_CNT");
    this.TOTL_CNT = map.get("TOTL_CNT");
    this.CYC_BASE = map.get("CYC_BASE");
    this.BIT_BASE = map.get("BIT_BASE");
    this.COND_CNT = map.get("COND_CNT");
    this.LIM_CNT = map.get("LIM_CNT");
    this.CYC_SIZE = map.get("CYC_SIZE");
    this.PMR_SIZE = map.get("PMR_SIZE");
    this.CHN_SIZE = map.get("CHN_SIZE");
    this.PAT_SIZE = map.get("PAT_SIZE");
    this.BIT_SIZE = map.get("BIT_SIZE");
    this.U1_SIZE = map.get("U1_SIZE");
    this.U2_SIZE = map.get("U2_SIZE");
    this.U3_SIZE = map.get("U3_SIZE");
    this.UTX_SIZE = map.get("UTX_SIZE");
    this.CAP_BGN = map.get("CAP_BGN");
    this.LIM_INDX = map.get("LIM_INDX");
    this.LIM_SPEC = map.get("LIM_SPEC");
    this.COND_LST = map.get("COND_LST");
    this.CYCO_CNT = map.get("CYCO_CNT");
    this.CYC_OFST = map.get("CYC_OFST");
    this.PMR_CNT = map.get("PMR_CNT");
    this.PMR_INDX = map.get("PMR_INDX");
    this.CHN_CNT = map.get("CHN_CNT");
    this.CHN_NUM = map.get("CHN_NUM");
    this.EXP_CNT = map.get("EXP_CNT");
    this.EXP_DATA = map.get("EXP_DATA");
    this.CAP_CNT = map.get("CAP_CNT");
    this.CAP_DATA = map.get("CAP_DATA");
    this.NEW_CNT = map.get("NEW_CNT");
    this.NEW_DATA = map.get("NEW_DATA");
    this.PAT_CNT = map.get("PAT_CNT");
    this.PAT_NUM = map.get("PAT_NUM");
    this.BPOS_CNT = map.get("BPOS_CNT");
    this.BIT_POS = map.get("BIT_POS");
    this.USR1_CNT = map.get("USR1_CNT");
    this.USR1 = map.get("USR1");
    this.USR2_CNT = map.get("USR2_CNT");
    this.USR2 = map.get("USR2");
    this.USR3_CNT = map.get("USR3_CNT");
    this.USR3 = map.get("USR3");
    this.TXT_CNT = map.get("TXT_CNT");
    this.USER_TXT = map.get("USER_TXT");
  }
  public Object getCONT_FLG() {
    return this.CONT_FLG;
  }
  public Object getTEST_NUM() {
    return this.TEST_NUM;
  }
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  public Object getSITE_NUM() {
    return this.SITE_NUM;
  }
  public Object getPSR_REF() {
    return this.PSR_REF;
  }
  public Object getTEST_FLG() {
    return this.TEST_FLG;
  }
  public Object getLOG_TYP() {
    return this.LOG_TYP;
  }
  public Object getTEST_TXT() {
    return this.TEST_TXT;
  }
  public Object getALARM_ID() {
    return this.ALARM_ID;
  }
  public Object getPROG_TXT() {
    return this.PROG_TXT;
  }
  public Object getRSLT_TXT() {
    return this.RSLT_TXT;
  }
  public Object getZ_VAL() {
    return this.Z_VAL;
  }
  public Object getFMU_FLG() {
    return this.FMU_FLG;
  }
  public Object getMASK_MAP() {
    return this.MASK_MAP;
  }
  public Object getFAL_MAP() {
    return this.FAL_MAP;
  }
  public Object getCYC_CNT() {
    return this.CYC_CNT;
  }
  public Object getTOTF_CNT() {
    return this.TOTF_CNT;
  }
  public Object getTOTL_CNT() {
    return this.TOTL_CNT;
  }
  public Object getCYC_BASE() {
    return this.CYC_BASE;
  }
  public Object getBIT_BASE() {
    return this.BIT_BASE;
  }
  public Object getCOND_CNT() {
    return this.COND_CNT;
  }
  public Object getLIM_CNT() {
    return this.LIM_CNT;
  }
  public Object getCYC_SIZE() {
    return this.CYC_SIZE;
  }
  public Object getPMR_SIZE() {
    return this.PMR_SIZE;
  }
  public Object getCHN_SIZE() {
    return this.CHN_SIZE;
  }
  public Object getPAT_SIZE() {
    return this.PAT_SIZE;
  }
  public Object getBIT_SIZE() {
    return this.BIT_SIZE;
  }
  public Object getU1_SIZE() {
    return this.U1_SIZE;
  }
  public Object getU2_SIZE() {
    return this.U2_SIZE;
  }
  public Object getU3_SIZE() {
    return this.U3_SIZE;
  }
  public Object getUTX_SIZE() {
    return this.UTX_SIZE;
  }
  public Object getCAP_BGN() {
    return this.CAP_BGN;
  }
  public Object getLIM_INDX() {
    return this.LIM_INDX;
  }
  public Object getLIM_SPEC() {
    return this.LIM_SPEC;
  }
  public Object getCOND_LST() {
    return this.COND_LST;
  }
  public Object getCYCO_CNT() {
    return this.CYCO_CNT;
  }
  public Object getCYC_OFST() {
    return this.CYC_OFST;
  }
  public Object getPMR_CNT() {
    return this.PMR_CNT;
  }
  public Object getPMR_INDX() {
    return this.PMR_INDX;
  }
  public Object getCHN_CNT() {
    return this.CHN_CNT;
  }
  public Object getCHN_NUM() {
    return this.CHN_NUM;
  }
  public Object getEXP_CNT() {
    return this.EXP_CNT;
  }
  public Object getEXP_DATA() {
    return this.EXP_DATA;
  }
  public Object getCAP_CNT() {
    return this.CAP_CNT;
  }
  public Object getCAP_DATA() {
    return this.CAP_DATA;
  }
  public Object getNEW_CNT() {
    return this.NEW_CNT;
  }
  public Object getNEW_DATA() {
    return this.NEW_DATA;
  }
  public Object getPAT_CNT() {
    return this.PAT_CNT;
  }
  public Object getPAT_NUM() {
    return this.PAT_NUM;
  }
  public Object getBPOS_CNT() {
    return this.BPOS_CNT;
  }
  public Object getBIT_POS() {
    return this.BIT_POS;
  }
  public Object getUSR1_CNT() {
    return this.USR1_CNT;
  }
  public Object getUSR1() {
    return this.USR1;
  }
  public Object getUSR2_CNT() {
    return this.USR2_CNT;
  }
  public Object getUSR2() {
    return this.USR2;
  }
  public Object getUSR3_CNT() {
    return this.USR3_CNT;
  }
  public Object getUSR3() {
    return this.USR3;
  }
  public Object getTXT_CNT() {
    return this.TXT_CNT;
  }
  public Object getUSER_TXT() {
    return this.USER_TXT;
  }
  public String getType() {
    return "STR";
  }
}
