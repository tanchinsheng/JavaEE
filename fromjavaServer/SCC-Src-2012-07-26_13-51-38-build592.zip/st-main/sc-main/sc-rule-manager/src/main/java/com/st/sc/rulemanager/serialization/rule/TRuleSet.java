/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.serialization.rule;

import java.io.Serializable;

/**
 * The Class TRuleSet.
 */
public class TRuleSet implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 5610862831403427482L;

  /** The created by. */
  private String createdBy;

  /** The name. */
  private String name;

  /** The origin. */
  private String origin;

  /** The owners. */
  private String[] owners;

  /** The rule set versions. */
  private TRuleSetVersion[] ruleSetVersions;

  /**
   * Instantiates a new t rule set.
   */
  public TRuleSet() {
  }

  /**
   * Gets the created by.
   * 
   * @return the created by
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * Gets the name.
   * 
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets the origin.
   * 
   * @return the origin
   */
  public String getOrigin() {
    return origin;
  }

  /**
   * Gets the owners.
   * 
   * @return the owners
   */
  public String[] getOwners() {
    return owners;
  }

  /**
   * Gets the rule set versions.
   * 
   * @return the rule set versions
   */
  public TRuleSetVersion[] getRuleSetVersions() {
    return ruleSetVersions;
  }

  /**
   * Sets the created by.
   * 
   * @param createdBy
   *          the new created by
   */
  public void setCreatedBy(final String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * Sets the name.
   * 
   * @param name
   *          the new name
   */
  public void setName(final String name) {
    this.name = name;
  }

  /**
   * Sets the origin.
   * 
   * @param origin
   *          the new origin
   */
  public void setOrigin(final String origin) {
    this.origin = origin;
  }

  /**
   * Sets the owners.
   * 
   * @param owners
   *          the new owners
   */
  public void setOwners(final String[] owners) {
    this.owners = owners;
  }

  /**
   * Sets the rule set versions.
   * 
   * @param ruleSetVersions
   *          the new rule set versions
   */
  public void setRuleSetVersions(final TRuleSetVersion[] ruleSetVersions) {
    this.ruleSetVersions = ruleSetVersions;
  }
}
