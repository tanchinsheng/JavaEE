/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class PMR implements RecordType {

  /**
   * 
   * @param map
   *          the map
   */
  public PMR(final Map<String, Object> map) {
    initialize(map);
  }
  private Object PMR_INDX;
  private Object CHAN_TYP;
  private Object CHAN_NAM;
  private Object PHY_NAM;
  private Object LOG_NAM;
  private Object HEAD_NUM;
  private Object SITE_NUM;
  private void initialize(Map<String, Object> map) {
    this.PMR_INDX = map.get("PMR_INDX");
    this.CHAN_TYP = map.get("CHAN_TYP");
    this.CHAN_NAM = map.get("CHAN_NAM");
    this.PHY_NAM = map.get("PHY_NAM");
    this.LOG_NAM = map.get("LOG_NAM");
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_NUM = map.get("SITE_NUM");
  }
  public Object getPMR_INDX() {
    return this.PMR_INDX;
  }
  public Object getCHAN_TYP() {
    return this.CHAN_TYP;
  }
  public Object getCHAN_NAM() {
    return this.CHAN_NAM;
  }
  public Object getPHY_NAM() {
    return this.PHY_NAM;
  }
  public Object getLOG_NAM() {
    return this.LOG_NAM;
  }
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  public Object getSITE_NUM() {
    return this.SITE_NUM;
  }
  public String getType() {
    return "PMR";
  }
}
