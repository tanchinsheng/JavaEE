/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class MIR  implements RecordType {

  /**
   * 
   * @param map
   *          the map
   */
  public MIR(final Map<String, Object> map) {
    initialize(map);
  }
  private Long SETUP_T;
  private Long START_T;
  private Object STAT_NUM;
  private Object MODE_COD;
  private Object RTST_COD;
  private Object PROT_COD;
  private Object BURN_TIM;
  private Object CMOD_COD;
  private Object LOT_ID;
  private Object PART_TYP;
  private Object NODE_NAM;
  private Object TSTR_TYP;
  private Object JOB_NAM;
  private Object JOB_REV;
  private Object SBLOT_ID;
  private Object OPER_NAM;
  private Object EXEC_TYP;
  private Object EXEC_VER;
  private Object TEST_COD;
  private Object TST_TEMP;
  private Object USER_TXT;
  private Object AUX_FILE;
  private Object PKG_TYP;
  private Object FAMLY_ID;
  private Object DATE_COD;
  private Object FACIL_ID;
  private Object FLOOR_ID;
  private Object PROC_ID;
  private Object OPER_FRQ;
  private Object SPEC_NAM;
  private Object SPEC_VER;
  private Object FLOW_ID;
  private Object SETUP_ID;
  private Object DSGN_REV;
  private Object ENG_ID;
  private Object ROM_COD;
  private Object SERL_NUM;
  private Object SUPR_NAM;
  private void initialize(Map<String, Object> map) {
    this.SETUP_T = (Long) map.get("SETUP_T");
    this.START_T = (Long) map.get("START_T");
    this.STAT_NUM = map.get("STAT_NUM");
    this.MODE_COD = map.get("MODE_COD");
    this.RTST_COD = map.get("RTST_COD");
    this.PROT_COD = map.get("PROT_COD");
    this.BURN_TIM = map.get("BURN_TIM");
    this.CMOD_COD = map.get("CMOD_COD");
    this.LOT_ID = map.get("LOT_ID");
    this.PART_TYP = map.get("PART_TYP");
    this.NODE_NAM = map.get("NODE_NAM");
    this.TSTR_TYP = map.get("TSTR_TYP");
    this.JOB_NAM = map.get("JOB_NAM");
    this.JOB_REV = map.get("JOB_REV");
    this.SBLOT_ID = map.get("SBLOT_ID");
    this.OPER_NAM = map.get("OPER_NAM");
    this.EXEC_TYP = map.get("EXEC_TYP");
    this.EXEC_VER = map.get("EXEC_VER");
    this.TEST_COD = map.get("TEST_COD");
    this.TST_TEMP = map.get("TST_TEMP");
    this.USER_TXT = map.get("USER_TXT");
    this.AUX_FILE = map.get("AUX_FILE");
    this.PKG_TYP = map.get("PKG_TYP");
    this.FAMLY_ID = map.get("FAMLY_ID");
    this.DATE_COD = map.get("DATE_COD");
    this.FACIL_ID = map.get("FACIL_ID");
    this.FLOOR_ID = map.get("FLOOR_ID");
    this.PROC_ID = map.get("PROC_ID");
    this.OPER_FRQ = map.get("OPER_FRQ");
    this.SPEC_NAM = map.get("SPEC_NAM");
    this.SPEC_VER = map.get("SPEC_VER");
    this.FLOW_ID = map.get("FLOW_ID");
    this.SETUP_ID = map.get("SETUP_ID");
    this.DSGN_REV = map.get("DSGN_REV");
    this.ENG_ID = map.get("ENG_ID");
    this.ROM_COD = map.get("ROM_COD");
    this.SERL_NUM = map.get("SERL_NUM");
    this.SUPR_NAM = map.get("SUPR_NAM");
  }
  public Long getSETUP_T() {
    return this.SETUP_T;
  }
  public Long getSTART_T() {
    return this.START_T;
  }
  public Object getSTAT_NUM() {
    return this.STAT_NUM;
  }
  public Object getMODE_COD() {
    return this.MODE_COD;
  }
  public Object getRTST_COD() {
    return this.RTST_COD;
  }
  public Object getPROT_COD() {
    return this.PROT_COD;
  }
  public Object getBURN_TIM() {
    return this.BURN_TIM;
  }
  public Object getCMOD_COD() {
    return this.CMOD_COD;
  }
  public Object getLOT_ID() {
    return this.LOT_ID;
  }
  public Object getPART_TYP() {
    return this.PART_TYP;
  }
  public Object getNODE_NAM() {
    return this.NODE_NAM;
  }
  public Object getTSTR_TYP() {
    return this.TSTR_TYP;
  }
  public Object getJOB_NAM() {
    return this.JOB_NAM;
  }
  public Object getJOB_REV() {
    return this.JOB_REV;
  }
  public Object getSBLOT_ID() {
    return this.SBLOT_ID;
  }
  public Object getOPER_NAM() {
    return this.OPER_NAM;
  }
  public Object getEXEC_TYP() {
    return this.EXEC_TYP;
  }
  public Object getEXEC_VER() {
    return this.EXEC_VER;
  }
  public Object getTEST_COD() {
    return this.TEST_COD;
  }
  public Object getTST_TEMP() {
    return this.TST_TEMP;
  }
  public Object getUSER_TXT() {
    return this.USER_TXT;
  }
  public Object getAUX_FILE() {
    return this.AUX_FILE;
  }
  public Object getPKG_TYP() {
    return this.PKG_TYP;
  }
  public Object getFAMLY_ID() {
    return this.FAMLY_ID;
  }
  public Object getDATE_COD() {
    return this.DATE_COD;
  }
  public Object getFACIL_ID() {
    return this.FACIL_ID;
  }
  public Object getFLOOR_ID() {
    return this.FLOOR_ID;
  }
  public Object getPROC_ID() {
    return this.PROC_ID;
  }
  public Object getOPER_FRQ() {
    return this.OPER_FRQ;
  }
  public Object getSPEC_NAM() {
    return this.SPEC_NAM;
  }
  public Object getSPEC_VER() {
    return this.SPEC_VER;
  }
  public Object getFLOW_ID() {
    return this.FLOW_ID;
  }
  public Object getSETUP_ID() {
    return this.SETUP_ID;
  }
  public Object getDSGN_REV() {
    return this.DSGN_REV;
  }
  public Object getENG_ID() {
    return this.ENG_ID;
  }
  public Object getROM_COD() {
    return this.ROM_COD;
  }
  public Object getSERL_NUM() {
    return this.SERL_NUM;
  }
  public Object getSUPR_NAM() {
    return this.SUPR_NAM;
  }
  public String getType() {
    return "MIR";
  }
}
