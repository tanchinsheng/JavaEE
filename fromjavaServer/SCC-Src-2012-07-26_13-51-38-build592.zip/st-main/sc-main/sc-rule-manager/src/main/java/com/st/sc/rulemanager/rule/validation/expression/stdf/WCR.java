/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class WCR implements RecordType {

  /**
   * 
   * @param map
   *          the map
   */
  public WCR(final Map<String, Object> map) {
    initialize(map);
  }
  private Object WAFR_SIZ;
  private Object DIE_HT;
  private Object DIE_WID;
  private Object WF_UNITS;
  private Object WF_FLAT;
  private Object CENTER_X;
  private Object CENTER_Y;
  private Object POS_X;
  private Object POS_Y;
  private void initialize(Map<String, Object> map) {
    this.WAFR_SIZ = map.get("WAFR_SIZ");
    this.DIE_HT = map.get("DIE_HT");
    this.DIE_WID = map.get("DIE_WID");
    this.WF_UNITS = map.get("WF_UNITS");
    this.WF_FLAT = map.get("WF_FLAT");
    this.CENTER_X = map.get("CENTER_X");
    this.CENTER_Y = map.get("CENTER_Y");
    this.POS_X = map.get("POS_X");
    this.POS_Y = map.get("POS_Y");
  }
  public Object getWAFR_SIZ() {
    return this.WAFR_SIZ;
  }
  public Object getDIE_HT() {
    return this.DIE_HT;
  }
  public Object getDIE_WID() {
    return this.DIE_WID;
  }
  public Object getWF_UNITS() {
    return this.WF_UNITS;
  }
  public Object getWF_FLAT() {
    return this.WF_FLAT;
  }
  public Object getCENTER_X() {
    return this.CENTER_X;
  }
  public Object getCENTER_Y() {
    return this.CENTER_Y;
  }
  public Object getPOS_X() {
    return this.POS_X;
  }
  public Object getPOS_Y() {
    return this.POS_Y;
  }
  public String getType() {
    return "WCR";
  }
}
