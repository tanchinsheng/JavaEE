/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 16, 2011 10:15:15 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.serialization;

import java.io.Serializable;

/**
 * The Class RuleValidationDetail.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleValidationDetail implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -6429647635412859463L;

  /** The failed value. */
  private String failedValue;

  /** The number of passed records. */
  private int numOfPassedRecords;

  /** The number of records. */
  private int numOfRecords;

  /** The obtained point. */
  private double obtainedPoint;

  /** The point. */
  private int point;

  /** The record type. */
  private String recordType;

  /** The result string. */
  private String resultStr;

  /** The rule name. */
  private String ruleName;

  /** The rule version. */
  private int ruleVersion;

  /** The rule version id. */
  private long ruleVersionId;

  /** The rule type. */
  private int ruleType;

  /**
   * Instantiates a new rule validation detail.
   */
  public RuleValidationDetail() {

  }

  /**
   * Gets the failed value.
   * 
   * @return the failed value
   */
  public String getFailedValue() {
    return failedValue;
  }

  /**
   * Gets the number of passed records.
   * 
   * @return the number of passed records
   */
  public int getNumOfPassedRecords() {
    return numOfPassedRecords;
  }

  /**
   * Gets the number of records.
   * 
   * @return the number of records
   */
  public int getNumOfRecords() {
    return numOfRecords;
  }

  /**
   * Gets the obtained point.
   * 
   * @return the obtained point
   */
  public double getObtainedPoint() {
    return obtainedPoint;
  }

  /**
   * Gets the point.
   * 
   * @return the point
   */
  public int getPoint() {
    return point;
  }

  /**
   * Gets the record type.
   * 
   * @return the record type
   */
  public String getRecordType() {
    return recordType;
  }

  /**
   * Gets the result string.
   * 
   * @return the result string
   */
  public String getResultStr() {
    return resultStr;
  }

  /**
   * Gets the rule name.
   * 
   * @return the rule name
   */
  public String getRuleName() {
    return ruleName;
  }

  /**
   * Gets the rule type.
   * 
   * @return the rule type
   */
  public int getRuleType() {
    return ruleType;
  }

  /**
   * Gets the rule version.
   * 
   * @return the rule version
   */
  public int getRuleVersion() {
    return ruleVersion;
  }

  /**
   * Gets the rule version id.
   * 
   * @return the rule version id
   */
  public long getRuleVersionId() {
    return ruleVersionId;
  }

  /**
   * Sets the failed value.
   * 
   * @param failedValue
   *          the failed value
   */
  public void setFailedValue(final String failedValue) {
    this.failedValue = failedValue;
  }

  /**
   * Sets the number of passed records.
   * 
   * @param numOfPassedRecords
   *          the number of passed records
   */
  public void setNumOfPassedRecords(final int numOfPassedRecords) {
    this.numOfPassedRecords = numOfPassedRecords;
  }

  /**
   * Sets the number of records.
   * 
   * @param numOfRecords
   *          the number of records
   */
  public void setNumOfRecords(final int numOfRecords) {
    this.numOfRecords = numOfRecords;
  }

  /**
   * Sets the obtained point.
   * 
   * @param obtainedPoint
   *          the obtained point
   */
  public void setObtainedPoint(final double obtainedPoint) {
    this.obtainedPoint = obtainedPoint;
  }

  /**
   * Sets the point.
   * 
   * @param point
   *          the point
   */
  public void setPoint(final int point) {
    this.point = point;
  }

  /**
   * Sets the record type.
   * 
   * @param recordType
   *          the record type
   */
  public void setRecordType(final String recordType) {
    this.recordType = recordType;
  }

  /**
   * Sets the result string.
   * 
   * @param resultStr
   *          the result string
   */
  public void setResultStr(final String resultStr) {
    this.resultStr = resultStr;
  }

  /**
   * Sets the rule name.
   * 
   * @param ruleName
   *          the rule name
   */
  public void setRuleName(final String ruleName) {
    this.ruleName = ruleName;
  }

  /**
   * Sets the rule type.
   * 
   * @param ruleType
   *          the new rule type
   */
  public void setRuleType(final int ruleType) {
    this.ruleType = ruleType;
  }

  /**
   * Sets the rule version.
   * 
   * @param ruleVersion
   *          the rule version
   */
  public void setRuleVersion(final int ruleVersion) {
    this.ruleVersion = ruleVersion;
  }

  /**
   * Sets the rule version id.
   * 
   * @param ruleVersionId
   *          the new rule version id
   */
  public void setRuleVersionId(final long ruleVersionId) {
    this.ruleVersionId = ruleVersionId;
  }

}
