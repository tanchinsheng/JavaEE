/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 14, 2011 3:35:05 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.mvel2.ParserContext;
import org.mvel2.compiler.CompiledExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.sc.entity.RuleValue;
import com.st.sc.entity.RuleVersion;
import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.entity.enums.RuleValueKeyEnum;
import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.rule.validation.enums.OperatorEnum;
import com.st.sc.rulemanager.rule.validation.expression.ExpressionProcessor;
import com.st.sc.rulemanager.rule.validation.expression.ExpressionUtil;
import com.st.sc.rulemanager.rule.validation.expression.exception.CompileException;
import com.st.sc.rulemanager.rule.validation.impl.CheckLengthField;
import com.st.sc.rulemanager.rule.validation.impl.CheckUniqueness;
import com.st.sc.rulemanager.rule.validation.impl.CorrespondentBetweenRecords;
import com.st.sc.rulemanager.rule.validation.impl.ErrorRuleValidation;
import com.st.sc.rulemanager.rule.validation.impl.Expression;
import com.st.sc.rulemanager.rule.validation.impl.MustInGroup;
import com.st.sc.rulemanager.rule.validation.impl.NumberOfBinRecord;
import com.st.sc.rulemanager.rule.validation.impl.NumberOfBinRecordPerBin;
import com.st.sc.rulemanager.rule.validation.impl.NumberOfPCR;
import com.st.sc.rulemanager.rule.validation.impl.NumberOfSDR;
import com.st.sc.rulemanager.rule.validation.impl.NumberOfTestRecord;
import com.st.sc.rulemanager.rule.validation.impl.OccurrenceRecord;
import com.st.sc.rulemanager.rule.validation.impl.OccurrenceTwoRecords;
import com.st.sc.rulemanager.rule.validation.impl.RequiredField;
import com.st.sc.rulemanager.rule.validation.impl.RequiredRecord;
import com.st.sc.rulemanager.rule.validation.impl.ValidateBit7;
import com.st.sc.rulemanager.rule.validation.impl.ValueFieldInList;
import com.st.sc.rulemanager.rule.validation.impl.ValueInRange;
import com.st.sc.rulemanager.rule.validation.impl.order.ATROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.AfterInitialSequenceOrder;
import com.st.sc.rulemanager.rule.validation.impl.order.FAROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.MIROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.MRROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.PIROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.PRROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.RDROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.SDROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.TestOrder;
import com.st.sc.rulemanager.rule.validation.impl.order.VUROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.WIROrder;
import com.st.sc.rulemanager.rule.validation.impl.order.WRROrder;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.scc.common.utils.ConvertUtils;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.RecordEnum;
import com.st.stdfparser.stdf.util.RecordUtil;

/**
 * A factory for creating RuleValidation objects.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class RuleValidationFactory {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(RuleValidationFactory.class);

  /** The Constant COMMA. */
  private static final String COMMA = ",";

  /**
   * Convert to map.
   * 
   * @param ruleValueList
   *          the rule value list
   * @return the map
   */
  private static Map<RuleValueKeyEnum, String> convertToMap(final List<RuleValue> ruleValueList) {
    final Map<RuleValueKeyEnum, String> map = new HashMap<RuleValueKeyEnum, String>();
    if (ruleValueList != null) {
      for (final RuleValue ruleValue : ruleValueList) {
        map.put(ruleValue.getId().getRuleValueKey(), ruleValue.getParamValue());
      }
    }
    return map;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createCheckLength(final RecordEnum recordType,
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    final FieldEnum field = getField(recordType, ruleValueMap);
    Integer length = null;
    OperatorEnum operator = null;
    if (field != null) {
      String value = ruleValueMap.get(RuleValueKeyEnum.FIELD_LENGTH_VALUE);
      if (value != null && value.length() > 0) {
        length = ConvertUtils.getInteger(value);
      }
      value = ruleValueMap.get(RuleValueKeyEnum.FIELD_LENGTH_OPERATOR);
      if (value != null && value.length() > 0) {
        operator = OperatorEnum.fromValue(value);
      }

      if (operator != null && length != null) {
        ruleValidation = new CheckLengthField(field, operator, length.intValue(), recordType);
      } else {
        ruleValidation = new ErrorRuleValidation();
      }
    } else {
      ruleValidation =
          new ErrorRuleValidation(recordType + "."
              + ruleValueMap.get(RuleValueKeyEnum.FIELD_NAME) + " is invalid");
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createCheckUniqueness(final RecordEnum recordType,
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    final String value = ruleValueMap.get(RuleValueKeyEnum.FIELD_UNIQUE);
    final Set<FieldEnum> fieldSet = new LinkedHashSet<FieldEnum>();
    if (value != null && value.length() > 0) {
      updateFieldSet(recordType, value, fieldSet);
      if (fieldSet.size() > 0) {
        ruleValidation = new CheckUniqueness(fieldSet, recordType);
      } else {
        ruleValidation = new ErrorRuleValidation("Invalid Field(s)");
      }
    } else {
      ruleValidation = new ErrorRuleValidation();
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createCorrespondentBetweenRecords(final RecordEnum recordType,
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    String value = ruleValueMap.get(RuleValueKeyEnum.FIELD_MATCHING_TARGET_RECORD);
    RecordEnum targetRecordType = null;
    final Set<FieldEnum> sourceFieldSet = new LinkedHashSet<FieldEnum>();
    final Set<FieldEnum> targetFieldSet = new LinkedHashSet<FieldEnum>();
    if (value != null && value.length() > 0) {
      targetRecordType = RecordEnum.fromValue(value);
    }
    value = ruleValueMap.get(RuleValueKeyEnum.FIELD_MATCHING_SRC_FIELD);
    if (value != null && value.length() > 0) {
      updateFieldSet(recordType, value, sourceFieldSet);
    }
    value = ruleValueMap.get(RuleValueKeyEnum.FIELD_MATCHING_TARGET_FIELD);
    if (value != null && value.length() > 0) {
      updateFieldSet(targetRecordType, value, targetFieldSet);
    }
    if (targetRecordType != null && sourceFieldSet.size() > 0
        && sourceFieldSet.size() == targetFieldSet.size()) {
      ruleValidation =
          new CorrespondentBetweenRecords(recordType, targetRecordType, sourceFieldSet,
              targetFieldSet);
    } else {
      ruleValidation = new ErrorRuleValidation();
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createExpression(
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    final String value = ruleValueMap.get(RuleValueKeyEnum.EXPRESSION);
    if (value != null && value.length() > 0) {
      final ParserContext context = ExpressionUtil.newContext();
      try {
        final CompiledExpression compiledExpression =
            ExpressionProcessor.compile(value, context);
        if (compiledExpression != null) {
          ruleValidation = new Expression(value, compiledExpression);
        }
      } catch (final CompileException e) {
        ruleValidation = new ErrorRuleValidation("Expression is error");
        LOG.error(e.getMessage());
      }
    } else {
      ruleValidation = new ErrorRuleValidation("Expression is missing");
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createMustInGroup(
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    final String value = ruleValueMap.get(RuleValueKeyEnum.EXIST_IN_GROUP);
    final Set<RecordEnum> set = new HashSet<RecordEnum>();
    if (value != null && value.length() > 0) {
      final String[] strings = value.split(COMMA);
      for (final String string : strings) {
        final RecordEnum enumValue = RecordEnum.fromValue(string);
        if (enumValue != null && !set.contains(enumValue)) {
          set.add(enumValue);
        }
      }
    }
    if (set.size() > 0) {
      ruleValidation = new MustInGroup(set);
    } else {
      ruleValidation = new ErrorRuleValidation("Invalid Record(s)");
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createOccurrenceRecord(
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    Integer recordCount = null;
    OperatorEnum operator = null;
    String value = ruleValueMap.get(RuleValueKeyEnum.OCCURRENCE_RECORD_OPERATOR);
    if (value != null && value.length() > 0) {
      operator = OperatorEnum.fromValue(value);
    }
    value = ruleValueMap.get(RuleValueKeyEnum.OCCURRENCE_RECORD_COUNT);
    if (value != null && value.length() > 0) {
      recordCount = ConvertUtils.getInteger(value);
    }
    if (recordCount != null && operator != null) {
      ruleValidation = new OccurrenceRecord(operator, recordCount.intValue());
    } else {
      ruleValidation = new ErrorRuleValidation();
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createOccurrenceTwoRecord(
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    OperatorEnum operator = null;
    RecordEnum secondRecordType = null;
    String value = ruleValueMap.get(RuleValueKeyEnum.OCCURRENCE_2_RECORD_OPERATOR);
    if (value != null && value.length() > 0) {
      operator = OperatorEnum.fromValue(value);
    }
    value = ruleValueMap.get(RuleValueKeyEnum.OCCURRENCE_2_RECORD_TYPE);
    if (value != null && value.length() > 0) {
      secondRecordType = RecordEnum.fromValue(value);
    }
    if (operator != null && secondRecordType != null) {
      ruleValidation = new OccurrenceTwoRecords(operator, secondRecordType);
    } else {
      ruleValidation = new ErrorRuleValidation();
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @return the rule validation
   */
  private static RuleValidation createOrderRule(final RecordEnum recordType) {
    RuleValidation ruleValidation = null;
    switch (recordType) {
    case FAR:
      ruleValidation = new FAROrder();
      break;

    case VUR:
      ruleValidation = new VUROrder();
      break;

    case ATR:
      ruleValidation = new ATROrder();
      break;

    case MIR:
      ruleValidation = new MIROrder();
      break;

    case RDR:
      ruleValidation = new RDROrder();
      break;

    case SDR:
      ruleValidation = new SDROrder();
      break;

    case MRR:
      ruleValidation = new MRROrder();
      break;

    case WIR:
      ruleValidation = new WIROrder();
      break;

    case PIR:
      ruleValidation = new PIROrder();
      break;

    case PTR:
    case MPR:
    case FTR:
      ruleValidation = new TestOrder();
      break;

    case PRR:
      ruleValidation = new PRROrder();
      break;

    case WRR:
      ruleValidation = new WRROrder();
      break;

    default:
      ruleValidation = new AfterInitialSequenceOrder();
      break;
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createRequiredField(final RecordEnum recordType,
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    final FieldEnum field = getField(recordType, ruleValueMap);
    if (field != null) {
      ruleValidation = new RequiredField(field);
    } else {
      ruleValidation =
          new ErrorRuleValidation(recordType + "."
              + ruleValueMap.get(RuleValueKeyEnum.FIELD_NAME) + " is invalid");
    }
    return ruleValidation;

  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @param ruleType
   *          the rule type
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createRuleValidation(final RecordEnum recordType,
      final RuleTypeEnum ruleType, final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    if (ruleType != null) {
      switch (ruleType) {
      case REQUIRED_RECORD:
        ruleValidation = new RequiredRecord();
        break;

      case OCCURRENCE_RECORD:
        ruleValidation = createOccurrenceRecord(ruleValueMap);
        break;

      case OCCURRENCE_TWO_RECORDS:
        ruleValidation = createOccurrenceTwoRecord(ruleValueMap);
        break;

      case NUMBER_OF_PCR:
        ruleValidation = new NumberOfPCR();
        break;

      case NUMBER_OF_BIN_RECORD_OP1:
        if (recordType == RecordEnum.HBR) {
          ruleValidation = new NumberOfBinRecord(true);
        } else if (recordType == RecordEnum.SBR) {
          ruleValidation = new NumberOfBinRecord(false);
        }
        break;

      case NUMBER_OF_BIN_RECORD_OP2:
        if (recordType == RecordEnum.HBR) {
          ruleValidation = new NumberOfBinRecordPerBin(true);
        } else if (recordType == RecordEnum.SBR) {
          ruleValidation = new NumberOfBinRecordPerBin(false);
        }
        break;

      case NUMBER_OF_TEST_RECORD:
        ruleValidation = new NumberOfTestRecord();
        break;

      case MUST_IN_GROUP:
        ruleValidation = createMustInGroup(ruleValueMap);
        break;

      case ORDER_TERADYNE:
        ruleValidation = createOrderRule(recordType);
        break;

      case REQUIRED_FIELD:
        ruleValidation = createRequiredField(recordType, ruleValueMap);
        break;

      case NUMBER_OF_SDR:
        if (recordType == RecordEnum.SDR) {
          ruleValidation = new NumberOfSDR();
        }
        break;

      case VALUE_FIELD_IN_LIST:
        ruleValidation = createValueFieldInList(recordType, ruleValueMap, true);
        break;

      case VALUE_FIELD_NOT_IN_LIST:
        ruleValidation = createValueFieldInList(recordType, ruleValueMap, false);
        break;

      case VALUE_IN_RANGE:
        ruleValidation = createValueInRange(recordType, ruleValueMap);
        break;

      case CHECK_LENGTH_FIELD:
        ruleValidation = createCheckLength(recordType, ruleValueMap);
        break;

      case VALIDATE_BIT7:
        ruleValidation = new ValidateBit7(recordType);
        break;

      case CHECK_UNIQUENESS:
        ruleValidation = createCheckUniqueness(recordType, ruleValueMap);
        break;

      case CORRESPONDENT_BETWEEN_RECORDS:
        ruleValidation = createCorrespondentBetweenRecords(recordType, ruleValueMap);
        break;

      case EXPRESSION:
        ruleValidation = createExpression(ruleValueMap);
        break;

      default:
        break;
      }
    }
    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param ruleVersions
   *          the rule versions
   * @param contextData
   *          the context data
   * @param detailPath
   *          the detail path
   * @return the list
   */
  public static List<RuleValidation> createRuleValidations(
      final List<RuleVersion> ruleVersions, final ContextData contextData,
      final String detailPath) {
    final String failedValuePath = contextData.getRootPath() + File.separator + detailPath;
    contextData.getFailedData().setFailedValuePath(failedValuePath);

    final List<RuleValidation> list = new ArrayList<RuleValidation>(ruleVersions.size());
    final Map<RecordEnum, Set<FieldEnum>> reportFieldMap =
        new HashMap<RecordEnum, Set<FieldEnum>>();
    for (final RuleVersion ruleVersion : ruleVersions) {
      final RuleTypeEnum ruleType = ruleVersion.getRuleType();
      final List<RuleValue> ruleValueList = ruleVersion.getRuleValueList();
      final Map<RuleValueKeyEnum, String> ruleValueMap = convertToMap(ruleValueList);
      final String recordTypeStr = ruleVersion.getRule().getRecordType();
      final RecordEnum recordType = RecordEnum.fromValue(recordTypeStr);
      if (recordType != null) {
        final RuleValidation ruleValidation =
            createRuleValidation(recordType, ruleType, ruleValueMap);
        if (ruleValidation != null) {
          ruleValidation.setContextData(contextData);
          ruleValidation.setRecordType(recordType);
          ruleValidation.setRuleName(ruleVersion.getRule().getName());
          ruleValidation.setPoint(ruleVersion.getPoint().doubleValue());
          ruleValidation.setRuleVersion(ruleVersion.getVersion().intValue());
          ruleValidation.setLogId(ruleVersion.getLogId());
          ruleValidation.setRecordType(recordType);
          ruleValidation.setRuleVersionId(ruleVersion.getRuleVersionId());
          ruleValidation.setRuleType(ruleType);
          list.add(ruleValidation);

          final RuleValidationHelper helper = ruleValidation.getHelper();
          if (helper != null) {
            final String filePath =
                failedValuePath
                    + DetailResultUtil.getResultDetailFileName(ruleVersion.getRuleVersionId()
                        .longValue());
            helper.setFilePath(filePath);

            Set<FieldEnum> reportFieldSet = reportFieldMap.get(recordType);
            if (reportFieldSet == null) {
              reportFieldSet = new LinkedHashSet<FieldEnum>();
              reportFieldMap.put(recordType, reportFieldSet);
            }
            for (final FieldEnum fieldEnum : helper.getReportFields()) {
              reportFieldSet.add(fieldEnum);
            }
          }
        }
      }
    }
    if (reportFieldMap.size() > 0) {
      final Map<RecordEnum, FieldEnum[]> map = contextData.getFailedData().getReportFieldMap();
      for (final Entry<RecordEnum, Set<FieldEnum>> entry : reportFieldMap.entrySet()) {
        final Set<FieldEnum> set = entry.getValue();
        final FieldEnum[] fields = new FieldEnum[set.size()];
        map.put(entry.getKey(), set.toArray(fields));
      }
    }
    return list;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @param ruleValueMap
   *          the rule value map
   * @param inList
   *          the in list
   * @return the rule validation
   */
  private static RuleValidation createValueFieldInList(final RecordEnum recordType,
      final Map<RuleValueKeyEnum, String> ruleValueMap, final boolean inList) {
    RuleValidation ruleValidation = null;
    final FieldEnum field = getField(recordType, ruleValueMap);
    String value;
    if (field != null) {
      final List<Object> list = new ArrayList<Object>();
      final RuleValueKeyEnum ruleConstant =
          inList ? RuleValueKeyEnum.FIELD_NAME_IN_LIST
              : RuleValueKeyEnum.FIELD_NAME_NOT_IN_LIST;
      value = ruleValueMap.get(ruleConstant);
      if (value != null && value.length() > 0) {
        final String[] strings = value.split(COMMA);
        for (final String string : strings) {
          final Object fieldValue = RecordUtil.convertFieldValue(field.getType(), string);
          if (fieldValue != null) {
            list.add(fieldValue);
          }
        }

        ruleValidation = new ValueFieldInList(field, list, inList, recordType);
      } else {
        ruleValidation = new ErrorRuleValidation();
      }
    } else {
      ruleValidation =
          new ErrorRuleValidation(recordType + "."
              + ruleValueMap.get(RuleValueKeyEnum.FIELD_NAME) + " is invalid");
    }

    return ruleValidation;
  }

  /**
   * Creates a new RuleValidation object.
   * 
   * @param recordType
   *          the record type
   * @param ruleValueMap
   *          the rule value map
   * @return the rule validation
   */
  private static RuleValidation createValueInRange(final RecordEnum recordType,
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    RuleValidation ruleValidation = null;
    final FieldEnum field = getField(recordType, ruleValueMap);
    Number fromValue = null;
    Number toValue = null;
    if (field != null) {
      String value = ruleValueMap.get(RuleValueKeyEnum.FIELD_IN_RANGE_FROM);
      if (value != null && value.length() > 0) {
        final Object obj = RecordUtil.convertFieldValue(field.getType(), value);
        if (obj instanceof Number) {
          fromValue = (Number) obj;
        }
      }
      value = ruleValueMap.get(RuleValueKeyEnum.FIELD_IN_RANGE_TO);
      if (value != null && value.length() > 0) {
        final Object obj = RecordUtil.convertFieldValue(field.getType(), value);
        if (obj instanceof Number) {
          toValue = (Number) obj;
        }
      }

      if (fromValue != null || toValue != null) {
        ruleValidation = new ValueInRange(field, fromValue, toValue, recordType);
      } else {
        ruleValidation = new ErrorRuleValidation();
      }
    } else {
      ruleValidation =
          new ErrorRuleValidation(recordType + "."
              + ruleValueMap.get(RuleValueKeyEnum.FIELD_NAME) + " is invalid");
    }
    return ruleValidation;
  }

  /**
   * Gets the field.
   * 
   * @param recordType
   *          the record type
   * @param ruleValueMap
   *          the rule value map
   * @return the field
   */
  private static FieldEnum getField(final RecordEnum recordType,
      final Map<RuleValueKeyEnum, String> ruleValueMap) {
    FieldEnum field = null;

    final String value = ruleValueMap.get(RuleValueKeyEnum.FIELD_NAME);
    if (value != null && value.length() > 0) {
      field = RecordUtil.findFieldEnum(recordType, value.trim());
    } else {
      if (LOG.isDebugEnabled()) {
        LOG.debug(recordType + "." + value + " is invalid");
      }
    }
    return field;
  }

  /**
   * Update field set.
   * 
   * @param recordType
   *          the record type
   * @param value
   *          the value
   * @param fieldSet
   *          the field set
   */
  private static void updateFieldSet(final RecordEnum recordType, final String value,
      final Set<FieldEnum> fieldSet) {
    final String[] strings = value.split(COMMA);
    for (final String string : strings) {
      if (string != null) {
        final FieldEnum field = RecordUtil.findFieldEnum(recordType, string.trim());
        if (field != null && !fieldSet.contains(field)) {
          fieldSet.add(field);
        }
      }
    }
  }

  /**
   * Instantiates a new rule validation factory.
   */
  private RuleValidationFactory() {

  }
}
