/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.serialization.rule;

import java.io.Serializable;

/**
 * The Class TRuleSetVersion.
 */
public class TRuleSetVersion implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -1068637228740571647L;

  /** The alarm threshold. */
  private Double alarmThreshold;

  /** The description. */
  private String description;

  /** The status. */
  private boolean status;

  /** The version. */
  private Integer version;

  /** The mir criteria. */
  private TMirCriteria mirCriteria;

  /** The rules. */
  private TRule[] rules;

  /**
   * Instantiates a new t rule set version.
   */
  public TRuleSetVersion() {
  }

  /**
   * Gets the alarm threshold.
   * 
   * @return the alarm threshold
   */
  public Double getAlarmThreshold() {
    return alarmThreshold;
  }

  /**
   * Gets the description.
   * 
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets the mir criteria.
   * 
   * @return the mir criteria
   */
  public TMirCriteria getMirCriteria() {
    return mirCriteria;
  }

  /**
   * Gets the rules.
   * 
   * @return the rules
   */
  public TRule[] getRules() {
    return rules;
  }

  /**
   * Gets the version.
   * 
   * @return the version
   */
  public Integer getVersion() {
    return version;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public boolean getStatus() {
    return status;
  }

  /**
   * Sets the alarm threshold.
   * 
   * @param alarmThreshold
   *          the new alarm threshold
   */
  public void setAlarmThreshold(final Double alarmThreshold) {
    this.alarmThreshold = alarmThreshold;
  }

  /**
   * Sets the description.
   * 
   * @param description
   *          the new description
   */
  public void setDescription(final String description) {
    this.description = description;
  }

  /**
   * Sets the mir criteria.
   * 
   * @param mirCriteria
   *          the new mir criteria
   */
  public void setMirCriteria(final TMirCriteria mirCriteria) {
    this.mirCriteria = mirCriteria;
  }

  /**
   * Sets the rules.
   * 
   * @param rules
   *          the new rules
   */
  public void setRules(final TRule[] rules) {
    this.rules = rules;
  }

  /**
   * Sets the status.
   * 
   * @param status
   *          the new status
   */
  public void setStatus(final boolean status) {
    this.status = status;
  }

  /**
   * Sets the version.
   * 
   * @param version
   *          the new version
   */
  public void setVersion(final Integer version) {
    this.version = version;
  }
}
