/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.serialization.rule;

import java.io.Serializable;

/**
 * The persistent class for the MIR_CRITERIA database table.
 */
public class TMirCriteria implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -3166087985394559204L;

  /** The cmod cod. */
  private String cmodCod;

  /** The dsgn rev. */
  private String dsgnRev;

  /** The exec typ. */
  private String execTyp;

  /** The exec ver. */
  private String execVer;

  /** The flow id. */
  private String flowId;

  /** The job nam. */
  private String jobNam;

  /** The job rev. */
  private String jobRev;

  /** The mode cod. */
  private String modeCod;

  /** The oper frq. */
  private String operFrq;

  /** The part typ. */
  private String partTyp;

  /** The proc id. */
  private String procId;

  /** The spec nam. */
  private String specNam;

  /** The spec ver. */
  private String specVer;

  /** The supr nam. */
  private String suprNam;

  /** The tstr typ. */
  private String tstrTyp;

  /**
   * Instantiates a new t mir criteria.
   */
  public TMirCriteria() {
  }

  /**
   * Gets the cmod cod.
   * 
   * @return the cmod cod
   */
  public String getCmodCod() {
    return cmodCod;
  }

  /**
   * Gets the dsgn rev.
   * 
   * @return the dsgn rev
   */
  public String getDsgnRev() {
    return dsgnRev;
  }

  /**
   * Gets the exec typ.
   * 
   * @return the exec typ
   */
  public String getExecTyp() {
    return execTyp;
  }

  /**
   * Gets the exec ver.
   * 
   * @return the exec ver
   */
  public String getExecVer() {
    return execVer;
  }

  /**
   * Gets the flow id.
   * 
   * @return the flow id
   */
  public String getFlowId() {
    return flowId;
  }

  /**
   * Gets the job nam.
   * 
   * @return the job nam
   */
  public String getJobNam() {
    return jobNam;
  }

  /**
   * Gets the job rev.
   * 
   * @return the job rev
   */
  public String getJobRev() {
    return jobRev;
  }

  /**
   * Gets the mode cod.
   * 
   * @return the mode cod
   */
  public String getModeCod() {
    return modeCod;
  }

  /**
   * Gets the oper frq.
   * 
   * @return the oper frq
   */
  public String getOperFrq() {
    return operFrq;
  }

  /**
   * Gets the part typ.
   * 
   * @return the part typ
   */
  public String getPartTyp() {
    return partTyp;
  }

  /**
   * Gets the proc id.
   * 
   * @return the proc id
   */
  public String getProcId() {
    return procId;
  }

  /**
   * Gets the spec nam.
   * 
   * @return the spec nam
   */
  public String getSpecNam() {
    return specNam;
  }

  /**
   * Gets the spec ver.
   * 
   * @return the spec ver
   */
  public String getSpecVer() {
    return specVer;
  }

  /**
   * Gets the supr nam.
   * 
   * @return the supr nam
   */
  public String getSuprNam() {
    return suprNam;
  }

  /**
   * Gets the tstr typ.
   * 
   * @return the tstr typ
   */
  public String getTstrTyp() {
    return tstrTyp;
  }

  /**
   * Sets the cmod cod.
   * 
   * @param cmodCod
   *          the new cmod cod
   */
  public void setCmodCod(final String cmodCod) {
    this.cmodCod = cmodCod;
  }

  /**
   * Sets the dsgn rev.
   * 
   * @param dsgnRev
   *          the new dsgn rev
   */
  public void setDsgnRev(final String dsgnRev) {
    this.dsgnRev = dsgnRev;
  }

  /**
   * Sets the exec typ.
   * 
   * @param execTyp
   *          the new exec typ
   */
  public void setExecTyp(final String execTyp) {
    this.execTyp = execTyp;
  }

  /**
   * Sets the exec ver.
   * 
   * @param execVer
   *          the new exec ver
   */
  public void setExecVer(final String execVer) {
    this.execVer = execVer;
  }

  /**
   * Sets the flow id.
   * 
   * @param flowId
   *          the new flow id
   */
  public void setFlowId(final String flowId) {
    this.flowId = flowId;
  }

  /**
   * Sets the job nam.
   * 
   * @param jobNam
   *          the new job nam
   */
  public void setJobNam(final String jobNam) {
    this.jobNam = jobNam;
  }

  /**
   * Sets the job rev.
   * 
   * @param jobRev
   *          the new job rev
   */
  public void setJobRev(final String jobRev) {
    this.jobRev = jobRev;
  }

  /**
   * Sets the mode cod.
   * 
   * @param modeCod
   *          the new mode cod
   */
  public void setModeCod(final String modeCod) {
    this.modeCod = modeCod;
  }

  /**
   * Sets the oper frq.
   * 
   * @param operFrq
   *          the new oper frq
   */
  public void setOperFrq(final String operFrq) {
    this.operFrq = operFrq;
  }

  /**
   * Sets the part typ.
   * 
   * @param partTyp
   *          the new part typ
   */
  public void setPartTyp(final String partTyp) {
    this.partTyp = partTyp;
  }

  /**
   * Sets the proc id.
   * 
   * @param procId
   *          the new proc id
   */
  public void setProcId(final String procId) {
    this.procId = procId;
  }

  /**
   * Sets the spec nam.
   * 
   * @param specNam
   *          the new spec nam
   */
  public void setSpecNam(final String specNam) {
    this.specNam = specNam;
  }

  /**
   * Sets the spec ver.
   * 
   * @param specVer
   *          the new spec ver
   */
  public void setSpecVer(final String specVer) {
    this.specVer = specVer;
  }

  /**
   * Sets the supr nam.
   * 
   * @param suprNam
   *          the new supr nam
   */
  public void setSuprNam(final String suprNam) {
    this.suprNam = suprNam;
  }

  /**
   * Sets the tstr typ.
   * 
   * @param tstrTyp
   *          the new tstr typ
   */
  public void setTstrTyp(final String tstrTyp) {
    this.tstrTyp = tstrTyp;
  }

}
