/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 23, 2011 4:36:02 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.data.FailedValueData;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class NumberOfSDR.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class NumberOfSDR extends RuleValidation {

  /** The Constant SDR_HEAD_NUM. */
  private static final String SDR_HEAD_NUM = "SDR.HEAD_NUM";

  /** The Constant SDR_SITE_CNT. */
  private static final String SDR_SITE_CNT = "SDR.SITE_CNT";

  /** The Constant NO_SITE_PRR. */
  private static final String NO_SITE_PRR = "No. of site from PRR";

  /**
   * Instantiates a new number of SDR.
   */
  public NumberOfSDR() {
    super();
    setCrossRule(false);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    return false;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final ContextData context = getContextData();
    final int countPCR = context.getCount(RecordEnum.SDR);
    if (countPCR == 0) {
      setFailedMessage(RecordEnum.SDR.getText() + " is missing");
      return;
    }

    final List<Object[]> failedValues = new ArrayList<Object[]>();
    final Set<Short> headNumSet = context.getHeadNumSetPRR();
    final Map<Short, Set<Short>> sitePerHeadMap = context.getSitePerHeadMap();
    for (final Short head : headNumSet) {
      final Set<Short> siteSet = sitePerHeadMap.get(head);
      final int siteSize = siteSet != null ? siteSet.size() : 0;
      final Short siteCnt = context.getSiteCntPerHeadMap().get(head);
      short siteCntVal = 0;
      if (siteCnt != null) {
        siteCntVal = siteCnt.shortValue();
      }
      if (siteCntVal == siteSize) {
        increaseNumOfPassedRecords();
      } else {
        final Object[] array = {head, siteCntVal, siteSet != null ? siteSet.size() : 0 };
        failedValues.add(array);
      }
      increaseNumOfRecords();
    }

    if (failedValues.size() > 0) {
      if (failedValues.size() == 1) {
        if (getNumOfRecords() == 1) {
          final Object[] array = failedValues.get(0);
          final StringBuilder sb = new StringBuilder();
          sb.append(SDR_HEAD_NUM).append(": ").append(array[0]);
          sb.append(", ").append(SDR_SITE_CNT).append(": ").append(array[1]);
          sb.append(", ").append(NO_SITE_PRR).append(": ").append(array[2]);
          setFailedMessage(sb.toString());
        }
      } else {
        final String[] headers = {SDR_HEAD_NUM, SDR_SITE_CNT, NO_SITE_PRR };
        final int key = DetailResultUtil.getHeaderIndexKey(getRecordType(), getRuleType());
        final FailedValueData failedData = context.getFailedData();
        failedData.getHeaderMap().put(key, headers);
        failedData.getSpecialMap().put(key, failedValues);
      }
    }
  }
}
