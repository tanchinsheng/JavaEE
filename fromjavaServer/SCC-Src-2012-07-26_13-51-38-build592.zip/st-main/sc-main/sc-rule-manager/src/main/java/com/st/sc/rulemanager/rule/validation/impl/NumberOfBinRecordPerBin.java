/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 23, 2011 11:20:38 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.st.sc.rulemanager.data.BinData;
import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.data.FailedValueData;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class NumberOfBinRecordPerBin.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class NumberOfBinRecordPerBin extends RuleValidation {

  /** The Constant NO_OF_HEAD_SITE. */
  private static final String NO_OF_HEAD_SITE = "No. of head/site combination";

  /** The Constant NO_OF_RECORD. */
  private static final String NO_OF_RECORD = "No. of ";

  /** The is hard bin. */
  private final boolean isHardBin;

  /** The bin field. */
  private FieldEnum binField;

  /** The bin record type. */
  private RecordEnum binRecordType;

  /**
   * Instantiates a new number of bin record per bin.
   * 
   * @param isHardBin
   *          the is hard bin
   */
  public NumberOfBinRecordPerBin(final boolean isHardBin) {
    super();
    this.isHardBin = isHardBin;
    setCrossRule(false);
    initialize();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    return false;
  }

  /**
   * Gets the text no record.
   * 
   * @return the text no record
   */
  private String getTextNoRecord() {
    return NO_OF_RECORD + binRecordType.getText();
  }

  /**
   * Initialize.
   */
  private void initialize() {
    if (isHardBin) {
      binField = FieldEnum.HARD_BIN;
      binRecordType = RecordEnum.HBR;
    } else {
      binField = FieldEnum.SOFT_BIN;
      binRecordType = RecordEnum.SBR;
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final ContextData context = getContextData();
    int countBin = 0;
    BinData binData = null;
    if (isHardBin) {
      countBin = context.getCount(RecordEnum.HBR);
      binData = context.getHardBinData();
    } else {
      countBin = context.getCount(RecordEnum.SBR);
      binData = context.getSoftBinData();
    }
    if (countBin == 0) {
      setFailedMessage(getRecordType() + " is missing");
      return;
    }

    final List<Object[]> failedValues = new ArrayList<Object[]>();
    final Set<Integer> binSet = binData.getBinNumSet();
    final Map<Integer, Integer> binNumCountMap = binData.getBinNumCountMap();
    final Map<Integer, Set<String>> headSitePerBinMap = binData.getHeadSitePerBinMap();
    for (final Integer integer : binSet) {
      final Integer numBinRecordPerBin = binNumCountMap.get(integer);
      int numBinRecordPerBinVal = 0;
      if (numBinRecordPerBin != null) {
        numBinRecordPerBinVal = numBinRecordPerBin.intValue();
      }
      final Set<String> set = headSitePerBinMap.get(integer);
      final int setSize = set != null ? set.size() : 0;
      if (numBinRecordPerBinVal == setSize + 1) {
        increaseNumOfPassedRecords();
      } else {
        final Object[] array = {integer, numBinRecordPerBinVal, setSize };
        failedValues.add(array);
      }
      increaseNumOfRecords();
    }

    if (failedValues.size() > 0) {
      if (failedValues.size() == 1) {
        if (getNumOfRecords() == 1) {
          final StringBuilder sb = new StringBuilder();
          final Object[] array = failedValues.get(0);
          sb.append(binField.getText()).append(": ").append(array[0]);
          sb.append(", ").append(getTextNoRecord()).append(": ").append(array[1]);
          sb.append(", ").append(NO_OF_HEAD_SITE).append(": ").append(array[2]);
          setFailedMessage(sb.toString());
        }
      } else {
        final String[] headers = {binField.getText(), getTextNoRecord(), NO_OF_HEAD_SITE };
        final int key = DetailResultUtil.getHeaderIndexKey(getRecordType(), getRuleType());
        final FailedValueData failedData = context.getFailedData();
        failedData.getHeaderMap().put(key, headers);
        failedData.getSpecialMap().put(key, failedValues);
      }
    }
  }

}
