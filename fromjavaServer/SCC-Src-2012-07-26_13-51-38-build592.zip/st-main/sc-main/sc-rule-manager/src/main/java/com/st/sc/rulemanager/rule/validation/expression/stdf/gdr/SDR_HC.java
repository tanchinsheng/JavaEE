/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf.gdr;
import java.util.Map;

import com.st.sc.rulemanager.rule.validation.expression.stdf.RecordType;
import com.st.stdfparser.stdf.RecordEnum;

public class SDR_HC implements RecordType {
  private Object FLD_CNT;
  private Object HEAD_NUM;
  private Object SITE_GRP;
  private Object SITE_CNT;
  private Object SITE_NUM;
  private Object HAND_TYP;
  private Object HAND_ID;
  private Object CARD_TYP;
  private Object CARD_ID;
  private Object LOAD_TYP;
  private Object LOAD_ID;
  private Object DIB_TYP;
  private Object DIB_ID;
  private Object CABL_TYP;
  private Object CABL_ID;
  private Object CONT_TYP;
  private Object CONT_ID;
  private Object LASR_TYP;
  private Object LASR_ID;
  private Object EXTR_TYP;
  private Object EXTR_ID;
  
  public SDR_HC(Map<String, Object> map) {
    initialize(map);
  }
  
  private void initialize(Map<String, Object> map) {
    this.FLD_CNT = map.get("FLD_CNT");
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_GRP = map.get("SITE_GRP");
    this.SITE_CNT = map.get("SITE_CNT");
    this.SITE_NUM = map.get("SITE_NUM");
    this.HAND_TYP = map.get("HAND_TYP");
    this.HAND_ID = map.get("HAND_ID");
    this.CARD_TYP = map.get("CARD_TYP");
    this.CARD_ID = map.get("CARD_ID");
    this.LOAD_TYP = map.get("LOAD_TYP");
    this.LOAD_ID = map.get("LOAD_ID");
    this.DIB_TYP = map.get("DIB_TYP");
    this.DIB_ID = map.get("DIB_ID");
    this.CABL_TYP = map.get("CABL_TYP");
    this.CABL_ID = map.get("CABL_ID");
    this.CONT_TYP = map.get("CONT_TYP");
    this.CONT_ID = map.get("CONT_ID");
    this.LASR_TYP = map.get("LASR_TYP");
    this.LASR_ID = map.get("LASR_ID");
    this.EXTR_TYP = map.get("EXTR_TYP");
    this.EXTR_ID = map.get("EXTR_ID");
  }
  public Object getFLD_CNT() {
    return this.FLD_CNT;
  }
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  public Object getSITE_GRP() {
    return this.SITE_GRP;
  }
  public Object getSITE_CNT() {
    return this.SITE_CNT;
  }
  public Object getSITE_NUM() {
    return this.SITE_NUM;
  }
  public Object getHAND_TYP() {
    return this.HAND_TYP;
  }
  public Object getHAND_ID() {
    return this.HAND_ID;
  }
  public Object getCARD_TYP() {
    return this.CARD_TYP;
  }
  public Object getCARD_ID() {
    return this.CARD_ID;
  }
  public Object getLOAD_TYP() {
    return this.LOAD_TYP;
  }
  public Object getLOAD_ID() {
    return this.LOAD_ID;
  }
  public Object getDIB_TYP() {
    return this.DIB_TYP;
  }
  public Object getDIB_ID() {
    return this.DIB_ID;
  }
  public Object getCABL_TYP() {
    return this.CABL_TYP;
  }
  public Object getCABL_ID() {
    return this.CABL_ID;
  }
  public Object getCONT_TYP() {
    return this.CONT_TYP;
  }
  public Object getCONT_ID() {
    return this.CONT_ID;
  }
  public Object getLASR_TYP() {
    return this.LASR_TYP;
  }
  public Object getLASR_ID() {
    return this.LASR_ID;
  }
  public Object getEXTR_TYP() {
    return this.EXTR_TYP;
  }
  public Object getEXTR_ID() {
    return this.EXTR_ID;
  }
  public String getType() {
    return RecordEnum.GDR_SDR_HC.getText();
  }
}
