/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 30, 2011 1:33:24 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.data;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * The Class BinData.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class BinData {

  /** The bin num count map. */
  private Map<Integer, Integer> binNumCountMap;

  /** The site per bin map. */
  private Map<Integer, Set<String>> headSitePerBinMap;

  /** The bin num set. */
  private Set<Integer> binNumSet;

  /**
   * Instantiates a new bin data.
   */
  public BinData() {
    binNumCountMap = new HashMap<Integer, Integer>();
    headSitePerBinMap = new HashMap<Integer, Set<String>>();

    binNumSet = new HashSet<Integer>();
  }

  /**
   * Adds the bin num.
   * 
   * @param binNum
   *          the bin num
   */
  public void add(final Integer binNum) {
    if (binNum != null) {
      Integer integer = binNumCountMap.get(binNum);
      if (integer != null) {
        integer = Integer.valueOf(integer.intValue() + 1);
      } else {
        integer = Integer.valueOf(1);
      }
      binNumCountMap.put(binNum, integer);
    }
  }

  /**
   * Adds the head/site/bin combination.
   * 
   * @param headNum
   *          the head num
   * @param siteNum
   *          the site num
   * @param binNum
   *          the bin num
   */
  public void add(final Short headNum, final Short siteNum, final Integer binNum) {
    Set<String> set = headSitePerBinMap.get(binNum);
    if (set == null) {
      set = new HashSet<String>();
      headSitePerBinMap.put(binNum, set);
    }
    final String key = headNum + "::" + siteNum;
    if (!set.contains(key)) {
      set.add(key);
    }
  }

  /**
   * Clear all data.
   */
  public void clear() {
    if (binNumCountMap != null) {
      binNumCountMap.clear();
      binNumCountMap = null;
    }
    if (headSitePerBinMap != null) {
      headSitePerBinMap.clear();
      headSitePerBinMap = null;
    }

    if (binNumSet != null) {
      binNumSet.clear();
      binNumSet = null;
    }
  }

  /**
   * Gets the bin num count map.
   * 
   * @return the bin num count map
   */
  public Map<Integer, Integer> getBinNumCountMap() {
    return binNumCountMap;
  }

  /**
   * Gets the bin num set.
   * 
   * @return the bin num set
   */
  public Set<Integer> getBinNumSet() {
    return binNumSet;
  }

  /**
   * Gets the head site bin size.
   * 
   * @return the head site bin size
   */
  public int getHeadSiteBinSize() {
    int retVal = 0;
    final Collection<Set<String>> values = headSitePerBinMap.values();
    for (final Set<String> set : values) {
      retVal += set.size();
    }
    return retVal;
  }

  /**
   * Gets the head site per bin map.
   * 
   * @return the head site per bin map
   */
  public Map<Integer, Set<String>> getHeadSitePerBinMap() {
    return headSitePerBinMap;
  }

}
