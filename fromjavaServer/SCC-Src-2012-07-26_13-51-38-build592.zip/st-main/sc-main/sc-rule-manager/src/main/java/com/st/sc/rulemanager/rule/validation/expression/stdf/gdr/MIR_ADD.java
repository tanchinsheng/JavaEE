/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf.gdr;
import java.util.Map;

import com.st.sc.rulemanager.rule.validation.expression.stdf.RecordType;
import com.st.stdfparser.stdf.RecordEnum;

public class MIR_ADD implements RecordType {
  private Object FLD_CNT;
  private Object GUI_NAM;
  private Object GUI_REV;
  private Object CONV_NAM;
  private Object CONV_REV;
  private Object TGT_TEMP;
  private Object TEMP_UNT;
  private Object OVER_TRV;
  private Object DRV_NAM;
  private Object DRV_REV;
  private Object STDF_IN;
  private Object STDF_FRM;
  
  public MIR_ADD(Map<String, Object> map) {
    initialize(map);
  }

  private void initialize(Map<String, Object> map) {
    this.FLD_CNT = map.get("FLD_CNT");
    this.GUI_NAM = map.get("GUI_NAM");
    this.GUI_REV = map.get("GUI_REV");
    this.CONV_NAM = map.get("CONV_NAM");
    this.CONV_REV = map.get("CONV_REV");
    this.TGT_TEMP = map.get("TGT_TEMP");
    this.TEMP_UNT = map.get("TEMP_UNT");
    this.OVER_TRV = map.get("OVER_TRV");
    this.DRV_NAM = map.get("DRV_NAM");
    this.DRV_REV = map.get("DRV_REV");
    this.STDF_IN = map.get("STDF_IN");
    this.STDF_FRM = map.get("STDF_FRM");
  }
  public Object getFLD_CNT() {
    return this.FLD_CNT;
  }
  public Object getGUI_NAM() {
    return this.GUI_NAM;
  }
  public Object getGUI_REV() {
    return this.GUI_REV;
  }
  public Object getCONV_NAM() {
    return this.CONV_NAM;
  }
  public Object getCONV_REV() {
    return this.CONV_REV;
  }
  public Object getTGT_TEMP() {
    return this.TGT_TEMP;
  }
  public Object getTEMP_UNT() {
    return this.TEMP_UNT;
  }
  public Object getOVER_TRV() {
    return this.OVER_TRV;
  }
  public Object getDRV_NAM() {
    return this.DRV_NAM;
  }
  public Object getDRV_REV() {
    return this.DRV_REV;
  }
  public Object getSTDF_IN() {
    return this.STDF_IN;
  }
  public Object getSTDF_FRM() {
    return this.STDF_FRM;
  }
  public String getType() {
    return RecordEnum.GDR_MIR_ADD.getText();
  }
}
