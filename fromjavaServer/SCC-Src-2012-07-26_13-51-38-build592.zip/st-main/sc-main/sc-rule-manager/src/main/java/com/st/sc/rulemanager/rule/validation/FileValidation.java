/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 9, 2012 2:47:11 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation;

import java.io.File;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.compress.Compressors;
import com.st.common.config.ConfigLoader;
import com.st.common.exception.SccException;
import com.st.common.executor.CompletionExecutor;
import com.st.sc.entity.CompliancyResult;
import com.st.sc.entity.RuleVersion;
import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.data.RuleEngine;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.common.utils.UUIDGenerator;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;
import com.st.stdfparser.stdf.StdfInputStream;
import com.st.stdfparser.stdf.StdfInputStreamFactory;
import com.st.stdfparser.stdf.util.GDRConverter;

/**
 * The Class FileValidation.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class FileValidation {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileValidation.class);

  /** The Constant MAX_RECORD_PER_LIST. */
  private static final int MAX_RECORD_PER_LIST = 10000;

  /** The Constant MAX_NUM_OF_TASKS. */
  private static final int MAX_NUM_OF_TASKS = 3;

  /** The details. */
  private RuleValidationDetail[] details;

  /** The result. */
  private CompliancyResult result;

  /** The file. */
  private File file;

  /** The session id. */
  private String sessionId;

  /** The file UUID. */
  private String fileUUID;

  /** The limit fail value. */
  private Integer limitFailValue;

  /**
   * Instantiates a new file validation.
   */
  public FileValidation() {
  }

  /**
   * Creates the record types.
   * 
   * @return the set
   */
  private Set<RecordEnum> createRecordTypes() {
    final Set<RecordEnum> set = new HashSet<RecordEnum>();
    set.add(RecordEnum.ATR);
    set.add(RecordEnum.BPS);
    set.add(RecordEnum.CDR);
    set.add(RecordEnum.CNR);
    set.add(RecordEnum.DTR);
    set.add(RecordEnum.EPS);
    set.add(RecordEnum.FAR);
    set.add(RecordEnum.FTR);
    set.add(RecordEnum.GDR);
    set.add(RecordEnum.HBR);
    set.add(RecordEnum.MIR);
    set.add(RecordEnum.MPR);
    set.add(RecordEnum.MRR);
    set.add(RecordEnum.NMR);
    set.add(RecordEnum.PCR);
    set.add(RecordEnum.PGR);
    set.add(RecordEnum.PIR);
    set.add(RecordEnum.PLR);
    set.add(RecordEnum.PMR);
    set.add(RecordEnum.PRR);
    set.add(RecordEnum.PSR);
    set.add(RecordEnum.PTR);
    set.add(RecordEnum.RDR);
    set.add(RecordEnum.SBR);
    set.add(RecordEnum.SDR);
    set.add(RecordEnum.SSR);
    set.add(RecordEnum.STR);
    set.add(RecordEnum.TSR);
    set.add(RecordEnum.VUR);
    set.add(RecordEnum.WCR);
    set.add(RecordEnum.WIR);
    set.add(RecordEnum.WRR);
    return set;
  }

  /**
   * Gets the details.
   * 
   * @return the details
   */
  public RuleValidationDetail[] getDetails() {
    return details;
  }

  /**
   * Gets the file.
   * 
   * @return the file
   */
  public File getFile() {
    return file;
  }

  /**
   * Gets the file UUID.
   * 
   * @return the file UUID
   */
  public String getFileUUID() {
    return fileUUID;
  }

  /**
   * Gets the limit fail value.
   * 
   * @return the limit fail value
   */
  public Integer getLimitFailValue() {
    return limitFailValue;
  }

  /**
   * Gets the result.
   * 
   * @return the result
   */
  public CompliancyResult getResult() {
    return result;
  }

  /**
   * Gets the session id.
   * 
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Process records.
   * 
   * @param completionExecutor
   *          the completion executor
   * @param ruleEngine
   *          the rule engine
   * @param records
   *          the records
   */
  private void processRecords(final CompletionExecutor completionExecutor,
      final RuleEngine ruleEngine, final List<Record> records) {
    completionExecutor.execute(new Runnable() {

      public void run() {
        try {
          final ContextData contextData = ruleEngine.getContextData();
          for (Record record : records) {
            final RecordEnum recordType = record.getType();
            Record specialGDR = null;
            // If record is GDR, we will convert to a special GDR record.
            if (recordType == RecordEnum.GDR) {
              specialGDR = GDRConverter.convert(record);
              // After converting, it is not a special GDR.
              if (specialGDR.getType() == RecordEnum.GDR) {
                specialGDR = null;
              }
            }
            // Because when validating a Rule on a general GDR record,
            // we must include special GDR records.
            // Thus, after converting to a special GDR, we also validate Rules
            // on general GDR.
            List<Record> tmpList = new ArrayList<Record>();
            tmpList.add(record);
            if (specialGDR != null) {
              tmpList.add(specialGDR);
            }
            for (Record record2 : tmpList) {
              contextData.updateData(record2);

              final List<RuleValidation> crossRules = ruleEngine.getCrossRules();
              for (final RuleValidation ruleValidation : crossRules) {
                if (ruleValidation.canValidate(record2)) {
                  ruleValidation.validate(record2);
                }
                contextData.getFailedData().flushFailedValues(ruleValidation.getRecordType(),
                    false);
              }
            }
          }
        } catch (final Throwable e) {
          LOG.error(e.getMessage(), e);
        } finally {
          records.clear();
        }
      }
    });
  }

  /**
   * Sets the file.
   * 
   * @param file
   *          the new file
   */
  public void setFile(final File file) {
    this.file = file;
  }

  /**
   * Sets the file UUID.
   * 
   * @param fileUUID
   *          the new file UUID
   */
  public void setFileUUID(final String fileUUID) {
    this.fileUUID = fileUUID;
  }

  /**
   * Sets the limit fail value.
   * 
   * @param limitFailValue
   *          the new limit fail value
   */
  public void setLimitFailValue(final Integer limitFailValue) {
    this.limitFailValue = limitFailValue;
  }

  /**
   * Sets the session id.
   * 
   * @param sessionId
   *          the new session id
   */
  public void setSessionId(final String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Extract input Z file.
   * 
   * @param input
   *          the input
   * @param outputPath
   *          the output path
   * @return the string
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  private String unZ(final String input, final String outputPath) throws IOException {
    final String output = Compressors.uncompress(input, outputPath, false, true);
    return output;
  }

  /**
   * Validate rule set.
   * 
   * @param rootPath
   *          the root path
   * @param ruleSetName
   *          the rule set name
   * @param ruleSetVersion
   *          the rule set version
   * @param ruleVersions
   *          the rule versions
   * @throws SccException
   *           the SCC exception
   */
  public void validate(final String rootPath, final String ruleSetName,
      final Integer ruleSetVersion, final List<RuleVersion> ruleVersions) throws SccException {
    final String fileName = file.getName();
    final String filePath = file.getAbsolutePath();
    RuleEngine ruleEngine = new RuleEngine();
    ruleEngine.setFileName(fileName);
    fileUUID = UUIDGenerator.generate();
    final ContextData contextData = ruleEngine.getContextData();
    contextData.setCheckingTime(System.currentTimeMillis());
    contextData.setRootPath(rootPath);
    if (limitFailValue != null) {
      contextData.getFailedData().setLimitFailedNum(limitFailValue);
    }

    final List<RuleValidation> ruleValidations =
        RuleValidationFactory.createRuleValidations(
            ruleVersions,
            contextData,
            DetailResultUtil.getFilePath(sessionId,
                new Timestamp(contextData.getCheckingTime()), fileUUID));

    LOG.info("File=[{}] Start reading file", fileName);

    File fin = null;
    StdfInputStream stdfStream = null;
    final FileChannel inputFileChannel = null;
    boolean flagFileZ = false;
    String fileSTDF = null;
    final long startReadTime = System.currentTimeMillis();

    if (!file.exists()) {
      LOG.error("File=[{}] File not found", fileName);
      throw new SccException("File not found");
    }

    // if file extension is .Z then extract.
    if (filePath.endsWith(".Z")) {
      try {
        final long startExtractTime = System.currentTimeMillis();
        fileSTDF = unZ(filePath, rootPath);
        LOG.info("[FileId={}] Extract Z file in {} ms", fileName, System.currentTimeMillis()
            - startExtractTime);
        flagFileZ = true;
      } catch (final IOException e) {
        LOG.error("[File=" + fileName + "] " + e.getMessage(), e);
        throw new SccException("Uncompress Z is error");
      }
    } else {
      fileSTDF = filePath;
    }

    fin = new File(fileSTDF);
    final Map<String, Object> map = new HashMap<String, Object>();
    // this parameter will be used by SC
    if (ConfigLoader.getInstance().isFindMir()) {
      map.put(ConfigLoader.FIND_MIR, fin);
    }

    final ExecutorService executorService = Executors.newFixedThreadPool(1);
    final CompletionExecutor completionExecutor = new CompletionExecutor(executorService);
    try {
      final Set<RecordEnum> supportedRecords = createRecordTypes();
      stdfStream = StdfInputStreamFactory.create(fin, supportedRecords);

      ruleEngine.setRuleSetName(ruleSetName);
      ruleEngine.setRuleSetVersion(ruleSetVersion);

      ruleEngine.initialize(ruleValidations);

      List<Record> list = new ArrayList<Record>();
      Record tmpRecord = null;
      Record lastRecord = null;
      while ((tmpRecord = stdfStream.readNext()) != null) {
        list.add(tmpRecord);
        lastRecord = tmpRecord;
        if (list.size() >= MAX_RECORD_PER_LIST) {
          List<Record> dispatchList = list;
          list = new ArrayList<Record>();
          processRecords(completionExecutor, ruleEngine, dispatchList);
          if (completionExecutor.getNumOfTasks() > MAX_NUM_OF_TASKS) {
            completionExecutor.waitForTasksCompleted();
          }
          dispatchList = null;
        }
      }
      if (lastRecord != null) {
        lastRecord.setLastRecord(true);
      }
      if (list != null && list.size() > 0) {
        processRecords(completionExecutor, ruleEngine, list);
        list = null;
      }
      completionExecutor.waitForTasksCompleted();
    } catch (final IOException e) {
      LOG.error("[File=" + fileName + "] Error when reading file", e);
      throw new SccException("Error when reading file");
    } catch (final Throwable e) {
      LOG.error("[File=" + fileName + "] Unexpected error when reading file", e);
      throw new SccException("Unexpected error when reading file");
    } finally {
      FileUtils.close(inputFileChannel);
      FileUtils.close(stdfStream);
      completionExecutor.shutdown();

      final List<RuleValidationDetail> detailResultList =
          new ArrayList<RuleValidationDetail>();
      result = DetailResultUtil.calculateResult(ruleEngine, detailResultList);
      details = new RuleValidationDetail[0];
      if (detailResultList.size() > 0) {
        details = detailResultList.toArray(new RuleValidationDetail[detailResultList.size()]);
      }

      ruleEngine.clear();
      ruleEngine = null;
      if (flagFileZ) {
        fin.delete();
      }
    }

    final long processedTime = System.currentTimeMillis() - startReadTime;
    LOG.info("[File={}] End reading file. Processed in {} ms", fileName, processedTime);
  }
}
