/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 5, 2011 1:30:22 AM - Trung - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl.order;

import java.util.LinkedHashSet;
import java.util.Set;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class PRROrder.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class PRROrder extends RuleValidation {

  /** The open PIR. */
  private final Set<String> openPIR = new LinkedHashSet<String>();

  /** The number of invalid pair. */
  private final int numOfInValidPair = 0;

  /**
   * Instantiates a new PRR order.
   */
  public PRROrder() {
    super();

  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    final RecordEnum recordType = record.getType();
    return recordType == RecordEnum.PIR || recordType == RecordEnum.PRR;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    final int count = getContextData().getCount(getRecordType());
    if (count == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
      return;
    }

    setNumOfPassedRecords(getNumOfRecords() - numOfInValidPair);

    if (getNumOfRecords() > getNumOfPassedRecords()) {
      final String msg =
          "PRR cannot occur if there is no an open PIR with same HEAD_NUM, SITE_NUM combination";
      setFailedMessage(msg);
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final Number headNum = (Number) record.getFieldValue(FieldEnum.HEAD_NUM);
    final Number siteNum = (Number) record.getFieldValue(FieldEnum.SITE_NUM);
    final String key = headNum + "::" + siteNum;
    final RecordEnum recordType = record.getType();
    switch (recordType) {
    case PIR:
      if (!openPIR.contains(key)) {
        openPIR.add(key);
      }
      break;

    case PRR:
      if (openPIR.contains(key)) {
        openPIR.remove(key);
        increaseNumOfPassedRecords();
      }
      increaseNumOfRecords();
      break;

    default:
      break;
    }
  }

}
