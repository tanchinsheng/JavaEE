/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 5, 2011 1:30:46 AM - Trung - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl.order;

import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class TestOrder extends AbsRequireOpenRecordRule {

  /** The Constant ALL_HEAD_SITE. */
  private static final int ALL_HEAD_SITE = 255;

  /** The Constant OXFFFF. */
  private static final int OXFFFF = 0xFFFF;

  /** The Constant NUM_BIT_2_BYTE. */
  private static final int NUM_BIT_2_BYTE = 16;

  /**
   * Instantiates a new test order.
   */
  public TestOrder() {
    setOpenRecordType(RecordEnum.PIR);
    setCloseRecordType(RecordEnum.PRR);
  }

  /**
   * Builds the key head site.
   * 
   * @param head
   *          the head
   * @param site
   *          the site
   * @return the int
   */
  private int buildKeyHeadSite(final Short head, final Short site) {
    final short h = head != null ? head.shortValue() : 0;
    short s = site != null ? site.shortValue() : 0;
    if (h == ALL_HEAD_SITE) {
      s = ALL_HEAD_SITE;
    }

    final int key = (h & OXFFFF) << NUM_BIT_2_BYTE | s & OXFFFF;
    return key;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.impl.order.AbsRequireOpenRecordRule#getKeyOpen(com.st.stdfparser.stdf.Record)
   */
  @Override
  protected Integer getKeyOpen(final Record record) {
    final Short head = (Short) record.getFieldValue(FieldEnum.HEAD_NUM);
    final Short site = (Short) record.getFieldValue(FieldEnum.SITE_NUM);
    return Integer.valueOf(buildKeyHeadSite(head, site));
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.impl.order.AbsRequireOpenRecordRule#postValidate()
   */
  @Override
  public void postValidate() {
    final int count = getContextData().getCount(getRecordType());
    if (count == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
      return;
    }

    if (getNumOfRecords() > getNumOfPassedRecords()) {
      setFailedMessage(getRecordType()
          + " cannot occur if there is no an open PIR with same HEAD_NUM, SITE_NUM");
    }
  }

}
