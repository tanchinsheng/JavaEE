/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 14, 2011 4:09:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.data;

import java.util.ArrayList;
import java.util.List;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.Record;

/**
 * The Class RuleEngine.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleEngine {

  /** The cross rules. */
  private final List<RuleValidation> crossRules;

  /** The rule validations. */
  private List<RuleValidation> ruleValidations;

  /** The found mir. */
  private boolean foundMir;

  /** The records. */
  private List<Record> records;

  /** The context data. */
  private final ContextData contextData;

  /** The file name. */
  private String fileName;

  /** The rule set name. */
  private String ruleSetName;

  /** The rule set version. */
  private Integer ruleSetVersion;

  /** The file error. */
  private boolean fileError;

  /** The alarm threshold. */
  private Double alarmThreshold;

  /** The log id list. */
  private final List<Integer> logIdList;

  /**
   * Instantiates a new rule engine.
   */
  public RuleEngine() {
    crossRules = new ArrayList<RuleValidation>();
    ruleValidations = new ArrayList<RuleValidation>();
    records = new ArrayList<Record>();
    contextData = new ContextData();
    fileError = false;
    logIdList = new ArrayList<Integer>();
  }

  /**
   * Clear.
   */
  public void clear() {
    crossRules.clear();
    ruleValidations.clear();
    contextData.clear();
    records.clear();
  }

  /**
   * Gets the alarm threshold.
   * 
   * @return the alarm threshold
   */
  public Double getAlarmThreshold() {
    return alarmThreshold;
  }

  /**
   * Gets the context data.
   * 
   * @return the context data
   */
  public ContextData getContextData() {
    return contextData;
  }

  /**
   * Gets the cross rules.
   * 
   * @return the cross rules
   */
  public List<RuleValidation> getCrossRules() {
    return crossRules;
  }

  /**
   * Gets the file name.
   * 
   * @return the file name
   */
  public String getFileName() {
    return fileName;
  }

  /**
   * Gets the log id list.
   * 
   * @return the log id list
   */
  public List<Integer> getLogIdList() {
    return logIdList;
  }

  /**
   * Gets the records.
   * 
   * @return the records
   */
  public List<Record> getRecords() {
    return records;
  }

  /**
   * Gets the rule set name.
   * 
   * @return the rule set name
   */
  public String getRuleSetName() {
    return ruleSetName;
  }

  /**
   * Gets the rule set version.
   * 
   * @return the rule set version
   */
  public Integer getRuleSetVersion() {
    return ruleSetVersion;
  }

  /**
   * Gets the rule validations.
   * 
   * @return the rule validations
   */
  public List<RuleValidation> getRuleValidations() {
    return ruleValidations;
  }

  /**
   * Initialize.
   * 
   * @param ruleValidationList
   *          the rule validation list
   */
  public void initialize(final List<RuleValidation> ruleValidationList) {
    ruleValidations = ruleValidationList;
    for (final RuleValidation ruleValidation : ruleValidationList) {
      if (ruleValidation.isCrossRule()) {
        crossRules.add(ruleValidation);
      }
    }
  }

  /**
   * Checks if is file error.
   * 
   * @return true, if is file error
   */
  public boolean isFileError() {
    return fileError;
  }

  /**
   * Checks if is found mir.
   * 
   * @return true, if is found mir
   */
  public boolean isFoundMir() {
    return foundMir;
  }

  /**
   * Sets the alarm threshold.
   * 
   * @param alarmThreshold
   *          the new alarm threshold
   */
  public void setAlarmThreshold(final Double alarmThreshold) {
    this.alarmThreshold = alarmThreshold;
  }

  /**
   * Sets the file error.
   * 
   * @param fileError
   *          the new file error
   */
  public void setFileError(final boolean fileError) {
    this.fileError = fileError;
  }

  /**
   * Sets the file name.
   * 
   * @param fileName
   *          the new file name
   */
  public void setFileName(final String fileName) {
    this.fileName = fileName;
  }

  /**
   * Sets the found mir.
   * 
   * @param foundMir
   *          the new found mir
   */
  public void setFoundMir(final boolean foundMir) {
    this.foundMir = foundMir;
  }

  /**
   * Sets the records.
   * 
   * @param records
   *          the new records
   */
  public void setRecords(final List<Record> records) {
    this.records = records;
  }

  /**
   * Sets the rule set name.
   * 
   * @param ruleSetName
   *          the new rule set name
   */
  public void setRuleSetName(final String ruleSetName) {
    this.ruleSetName = ruleSetName;
  }

  /**
   * Sets the rule set version.
   * 
   * @param ruleSetVersion
   *          the new rule set version
   */
  public void setRuleSetVersion(final Integer ruleSetVersion) {
    this.ruleSetVersion = ruleSetVersion;
  }
}
