/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 17, 2011 6:20:33 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.math.BigInteger;
import java.util.List;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.rule.validation.RuleValidationHelper;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class ValidateBit7.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ValidateBit7 extends RuleValidation {

  /** The Constant BIT_7. */
  private static final int BIT_7 = 7;

  /** The header fields. */
  private FieldEnum[] headerFields;

  /** The helper. */
  private final RuleValidationHelper helper;

  /**
   * The Constructor.
   * 
   * @param recordType
   *          the record type
   */
  public ValidateBit7(final RecordEnum recordType) {
    super();
    if (recordType == RecordEnum.PTR) {
      headerFields =
          new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM, FieldEnum.TEST_NUM,
              FieldEnum.LO_LIMIT, FieldEnum.HI_LIMIT, FieldEnum.RESULT, FieldEnum.TEST_FLG };
    } else if (recordType == RecordEnum.MPR) {
      headerFields =
          new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM, FieldEnum.TEST_NUM,
              FieldEnum.LO_LIMIT, FieldEnum.HI_LIMIT, FieldEnum.RTN_RSLT, FieldEnum.TEST_FLG };
    }

    helper = new RuleValidationHelper();
    helper.setReportFields(headerFields);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    return getRecordType() == record.getType();
  }

  /**
   * Check flag.
   * 
   * @param loLimit
   *          the lo limit
   * @param hiLimit
   *          the hi limit
   * @param result
   *          the result
   * @return true, if check flag
   */
  private boolean checkFlag(final Float loLimit, final Float hiLimit, final float result) {
    boolean flag = false;
    if (loLimit != null && hiLimit != null) {
      if (result >= loLimit.floatValue() && result <= hiLimit.floatValue()) {
        flag = true;
      }
    }
    return flag;
  }

  /**
   * Check flag list.
   * 
   * @param loLimit
   *          the lo limit
   * @param hiLimit
   *          the hi limit
   * @param list
   *          the list
   * @return true, if check flag list
   */
  private boolean checkFlagList(final Float loLimit, final Float hiLimit,
      final List<Float> list) {
    boolean flag = true;
    for (final Float f : list) {
      if (!checkFlag(loLimit, hiLimit, f)) {
        flag = false;
        break;
      }
    }
    return flag;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#getHelper()
   */
  @Override
  public RuleValidationHelper getHelper() {
    return helper;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    final int count = getContextData().getCount(getRecordType());
    if (count == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
      return;
    }
    setNumOfRecords(count);
  }

  /**
   * Update passed record.
   * 
   * @param testFlg
   *          the test flg
   * @param flag
   *          the flag
   */
  private void updatePassedRecord(final byte testFlg, final boolean flag) {
    if (flag) {
      if (!BigInteger.valueOf(testFlg).testBit(BIT_7)) {
        increaseNumOfPassedRecords();
      }
    } else {
      if (BigInteger.valueOf(testFlg).testBit(BIT_7)) {
        increaseNumOfPassedRecords();
      }
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  @SuppressWarnings("unchecked")
  public void validate(final Record record) {
    final Float loLimit = (Float) record.getFieldValue(FieldEnum.LO_LIMIT);
    final Float hiLimit = (Float) record.getFieldValue(FieldEnum.HI_LIMIT);
    final Byte b = (Byte) record.getFieldValue(FieldEnum.TEST_FLG);
    final int oldNumPass = getNumOfPassedRecords();

    if (loLimit != null && hiLimit != null && b != null) {
      final byte testFlg = b.byteValue();

      final RecordEnum recordType = record.getType();
      switch (recordType) {
      case PTR:
        final Float result = (Float) record.getFieldValue(FieldEnum.RESULT);
        if (result != null) {
          final boolean flag = checkFlag(loLimit, hiLimit, result.floatValue());
          updatePassedRecord(testFlg, flag);
        }
        break;

      case MPR:
        final List<Float> list = (List<Float>) record.getFieldValue(FieldEnum.RTN_RSLT);
        if (list != null) {
          final boolean flag = checkFlagList(loLimit, hiLimit, list);
          updatePassedRecord(testFlg, flag);
        }
        break;

      default:
        break;
      }
    }
    if (oldNumPass == getNumOfPassedRecords()) {
      getContextData().getFailedData().addFailedRecord(record, getHelper());
    }
  }
}
