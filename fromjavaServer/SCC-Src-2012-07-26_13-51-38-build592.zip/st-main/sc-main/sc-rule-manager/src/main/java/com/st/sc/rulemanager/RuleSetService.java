/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 3:27:48 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.st.sc.entity.RuleSet;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RulesOfRS;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleSetService {

  private BaseService baseService;

  public RuleSetService(BaseService baseService) {
    this.baseService = baseService;
  }

  /**
   * Get all rules in DB. entityManager is managed by yourself.
   * 
   * @param entityManager
   *          the entity manager used to query. After using the queried results,
   *          should close entityManager.
   * @return list of RuleSet
   */
  public List<RuleSet> getAllRuleSets(EntityManager entityManager) {
    return baseService.queryListUseNamedQuery(entityManager, RuleSet.GET_ALL_RULESET, null,
        RuleSet.class);
  }

  public List<RuleSet> getAllRuleSets() {
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    List<RuleSet> ls =
        baseService.queryListUseNamedQuery(entityManager, RuleSet.GET_ALL_RULESET, null,
            RuleSet.class);
    baseService.closeEntityManager(entityManager);
    return ls;
  }

  public List<RuleSetVersion> getActiveRuleSetVersions() {
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    TypedQuery<RuleSetVersion> query =
        entityManager
            .createNamedQuery(RuleSetVersion.GET_ACTIVE_RULESET, RuleSetVersion.class);
    List<RuleSetVersion> ls = query.getResultList();
    baseService.closeEntityManager(entityManager);
    return ls;
  }

  /**
   * Get all versions of a rule set.
   * 
   * @param ruleSetId
   *          rule set id.
   * @return list of rule set versions.
   */
  public List<RuleSetVersion> getVersions(Long ruleSetId) {
    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("ruleSetId", ruleSetId);
    List<RuleSetVersion> ls =
        baseService.queryListUseNamedQuery(RuleSetVersion.GET_RULESET_VERSIONS_OF_RULESET,
            parameters, RuleSetVersion.class);
    return ls;
  }

  /**
   * Get active version of a rule set.
   * 
   * @param ruleSetId
   * @return
   */
  public List<RuleSetVersion> getActiveVersions(Long ruleSetId) {
    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("ruleSetId", ruleSetId);
    List<RuleSetVersion> ls =
        baseService.queryListUseNamedQuery(RuleSetVersion.GET_ACTIVE_VERSION, parameters,
            RuleSetVersion.class);
    return ls;
  }

  /**
   * Get rule set by ruleSetName.
   * 
   * @param ruleSetName
   *          name of rule set.
   * @return a rule set, the result is null if it cannot find any rule set.
   */
  public RuleSet getRuleSetByName(String ruleSetName) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("name", ruleSetName.toUpperCase());
    List<RuleSet> list =
        baseService.queryListUseNamedQuery(RuleSet.GET_RULESET_BYNAME, param, RuleSet.class);
    if (list == null || list.size() == 0) {
      return null;
    }
    return list.get(0);
  }

  /**
   * Get max version of rule set.
   * 
   * @param ruleSetId
   * @return max version of rule set
   */
  public Integer getMaxVersionOfRuleSet(Long ruleSetId) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleSetId", ruleSetId);
    Object ob =
        baseService.querySingleValueUseNamedQuery(RuleSetVersion.GET_MAX_VERSION, param);
    if (ob == null) {
      return null;
    }
    if (ob instanceof BigInteger) {
      return ((BigInteger) ob).intValue();
    }
    return (Integer) ob;
  }

  /**
   * Count number active version of a rule set.
   * 
   * @param ruleSetId
   * @return
   */
  public Long countActiveVersion(Long ruleSetId) {
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleSetId", ruleSetId);
    Object ob =
        baseService.querySingleValueUseNamedQuery(RuleSetVersion.COUNT_ACTIVE_VERSION, param);
    baseService.closeEntityManager(entityManager);
    if (ob == null) {
      return null;
    }
    if (ob instanceof BigInteger) {
      return ((BigInteger) ob).longValue();
    }
    return (Long) ob;
  }

  /**
   * Count number versions of a rule set.
   * 
   * @param ruleSetId
   * @return
   */
  public Long countNumberVersion(Long ruleSetId) {
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleSetId", ruleSetId);
    Object ob =
        baseService.querySingleValueUseNamedQuery(RuleSetVersion.COUNT_NUMBER_VERSION, param);
    baseService.closeEntityManager(entityManager);
    if (ob == null) {
      return null;
    }
    if (ob instanceof BigInteger) {
      return ((BigInteger) ob).longValue();
    }
    return (Long) ob;
  }
  /**
   * Get list of RulesOfRS by rule set version id.
   * 
   * @param ruleSetVersionId
   * @return list of RulesOfRS.
   */
  public List<RulesOfRS> getListRulesOfRS(Long ruleSetVersionId) {
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleSetVersionId", ruleSetVersionId);
    List<RulesOfRS> ls =
        baseService.queryListUseNamedQuery(RulesOfRS.GET_RULE_ID_OF_RULE_SET_VERSION, param,
            RulesOfRS.class);
    baseService.closeEntityManager(entityManager);
    return ls;
  }
}
