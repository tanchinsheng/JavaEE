/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class WRR implements RecordType {

  /**
   * 
   * @param map
   *          the map
   */
  public WRR(final Map<String, Object> map) {
    initialize(map);
  }
  private Object HEAD_NUM;
  private Object SITE_GRP;
  private Object FINISH_T;
  private Object PART_CNT;
  private Object RTST_CNT;
  private Object ABRT_CNT;
  private Object GOOD_CNT;
  private Object FUNC_CNT;
  private Object WAFER_ID;
  private Object FABWF_ID;
  private Object FRAME_ID;
  private Object MASK_ID;
  private Object USR_DESC;
  private Object EXC_DESC;
  private void initialize(Map<String, Object> map) {
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_GRP = map.get("SITE_GRP");
    this.FINISH_T = map.get("FINISH_T");
    this.PART_CNT = map.get("PART_CNT");
    this.RTST_CNT = map.get("RTST_CNT");
    this.ABRT_CNT = map.get("ABRT_CNT");
    this.GOOD_CNT = map.get("GOOD_CNT");
    this.FUNC_CNT = map.get("FUNC_CNT");
    this.WAFER_ID = map.get("WAFER_ID");
    this.FABWF_ID = map.get("FABWF_ID");
    this.FRAME_ID = map.get("FRAME_ID");
    this.MASK_ID = map.get("MASK_ID");
    this.USR_DESC = map.get("USR_DESC");
    this.EXC_DESC = map.get("EXC_DESC");
  }
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  public Object getSITE_GRP() {
    return this.SITE_GRP;
  }
  public Object getFINISH_T() {
    return this.FINISH_T;
  }
  public Object getPART_CNT() {
    return this.PART_CNT;
  }
  public Object getRTST_CNT() {
    return this.RTST_CNT;
  }
  public Object getABRT_CNT() {
    return this.ABRT_CNT;
  }
  public Object getGOOD_CNT() {
    return this.GOOD_CNT;
  }
  public Object getFUNC_CNT() {
    return this.FUNC_CNT;
  }
  public Object getWAFER_ID() {
    return this.WAFER_ID;
  }
  public Object getFABWF_ID() {
    return this.FABWF_ID;
  }
  public Object getFRAME_ID() {
    return this.FRAME_ID;
  }
  public Object getMASK_ID() {
    return this.MASK_ID;
  }
  public Object getUSR_DESC() {
    return this.USR_DESC;
  }
  public Object getEXC_DESC() {
    return this.EXC_DESC;
  }

  public String getType() {
    return "WRR";
  }
}
