/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 6:58:19 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.mvel2.ParserContext;
import org.mvel2.compiler.CompiledExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.rule.validation.expression.ExpressionProcessor;
import com.st.sc.rulemanager.rule.validation.expression.ExpressionUtil;
import com.st.sc.rulemanager.rule.validation.expression.RecordTypeFactory;
import com.st.sc.rulemanager.rule.validation.expression.exception.EvaluateException;
import com.st.sc.rulemanager.rule.validation.expression.stdf.StdfContext;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.AUTOMATION;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.DLOG_FILTER;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.MERGER;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.MIR_ADD;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.REF_DIE;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.REF_DIE_XY;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.SDR_HC;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.STDF_FILL;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.STGDR;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;
import com.st.stdfparser.stdf.util.RecordUtil;

/**
 * The Class Expression.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class Expression extends RuleValidation {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(Expression.class);

  /** The Constant THIS. */
  private static final String THIS = "this";

  /** The input map. */
  private Map<String, Record> inputMap;

  /** The reference objects. */
  private Set<String> referenceObjects;

  /** The compile expression. */
  private CompiledExpression compileExpression;

  /** The expression. */
  private String expression;

  /** The validated. */
  private boolean validated;

  /** The ST GDR. */
  private STGDR stgdr;

  /**
   * Instantiates a new expression.
   * 
   * @param expression
   *          the expression
   * @param compileExpression
   *          the compile expression
   */
  public Expression(final String expression, final CompiledExpression compileExpression) {
    super();
    this.expression = expression;
    this.compileExpression = compileExpression;

    initialize(expression, compileExpression);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    final RecordEnum recordType = record.getType();
    final String name = recordType.getText();
    if (referenceObjects.contains(name)) {
      inputMap.put(name, record);
    }
    if (stgdr != null) {
      updateSTGDR(record);
    }
    return getRecordType() == recordType && referenceObjects.size() == inputMap.size();
  }

  /**
   * Gets the compile expression.
   * 
   * @return the compile expression
   */
  public CompiledExpression getCompileExpression() {
    return compileExpression;
  }

  /**
   * Gets the expression.
   * 
   * @return the expression
   */
  public String getExpression() {
    return expression;
  }

  /**
   * Initialize.
   * 
   * @param expression
   *          the expression
   * @param compileExpression
   *          the compile expression
   */
  private void initialize(final String expression, final CompiledExpression compileExpression) {
    final ParserContext parserContext = compileExpression.getParserContext();
    final Set<String> typeParameters = ExpressionUtil.getTypeParameters(parserContext);
    referenceObjects = new HashSet<String>();
    for (final String string : typeParameters) {
      if (!string.equals(THIS)) {
        referenceObjects.add(string);
      }
    }
    if (expression.contains("count")) {
      referenceObjects.add(THIS);
    }
    if (referenceObjects.contains(RecordEnum.GDR.getText())) {
      stgdr = new STGDR();
    }
    inputMap = new HashMap<String, Record>(referenceObjects.size());
    validated = false;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    validate(null);

    if (inputMap != null) {
      inputMap.clear();
    }
    if (referenceObjects != null) {
      referenceObjects.clear();
    }
  }

  /**
   * Sets the compile expression.
   * 
   * @param compileExpression
   *          the new compile expression
   */
  public void setCompileExpression(final CompiledExpression compileExpression) {
    this.compileExpression = compileExpression;
  }

  /**
   * Sets the expression.
   * 
   * @param expression
   *          the new expression
   */
  public void setExpression(final String expression) {
    this.expression = expression;
  }

  /**
   * Update ST GDR records.
   * 
   * @param record
   *          the record
   */
  private void updateSTGDR(final Record record) {
    final RecordEnum recordType = record.getType();
    switch (recordType) {
    case GDR_AUTOMATION:
      stgdr.setAUTOMATION(new AUTOMATION(RecordUtil.toMapObject(record.getFields())));
      break;

    case GDR_DLOG_FILTER:
      stgdr.setDLOG_FILTER(new DLOG_FILTER(RecordUtil.toMapObject(record.getFields())));
      break;

    case GDR_MERGER:
      stgdr.setMERGER(new MERGER(RecordUtil.toMapObject(record.getFields())));
      break;

    case GDR_MIR_ADD:
      stgdr.setMIR_ADD(new MIR_ADD(RecordUtil.toMapObject(record.getFields())));
      break;

    case GDR_REF_DIE:
      stgdr.setREF_DIE(new REF_DIE(RecordUtil.toMapObject(record.getFields())));
      break;

    case GDR_REF_DIE_XY:
      stgdr.setREF_DIE_XY(new REF_DIE_XY(RecordUtil.toMapObject(record.getFields())));
      break;

    case GDR_SDR_HC:
      stgdr.setSDR_HC(new SDR_HC(RecordUtil.toMapObject(record.getFields())));
      break;

    case GDR_STDF_FILL:
      stgdr.setSTDF_FILL(new STDF_FILL(RecordUtil.toMapObject(record.getFields())));
      break;

    default:
      break;
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {

    if (record == null && validated) {
      return;
    }

    final Set<Entry<String, Record>> entrySet = inputMap.entrySet();
    final Map<String, Object> vars = new HashMap<String, Object>();
    for (final Entry<String, Record> entry : entrySet) {
      vars.put(entry.getKey(), RecordTypeFactory.newRecordType(entry.getValue()));
    }
    final StdfContext object = new StdfContext(getContextData());
    if (stgdr != null) {
      final Record gdrRecord = inputMap.get(RecordEnum.GDR.getText());
      if (gdrRecord != null) {
        stgdr.setFLD_CNT(gdrRecord.getFieldValue(FieldEnum.FLD_CNT));
        stgdr.setGEN_DATA(gdrRecord.getFieldValue(FieldEnum.GEN_DATA));
      }
      vars.put(RecordEnum.GDR.getText(), stgdr);
    }
    try {
      final Object eval = ExpressionProcessor.eval(compileExpression, object, vars);
      if (eval instanceof Boolean && ((Boolean) eval).booleanValue()) {
        increaseNumOfPassedRecords();
      } else {
        setFailedMessage("FALSE");
      }
    } catch (final EvaluateException e) {
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
      setFailedMessage("Evaluate expression is failed");
    }
    increaseNumOfRecords();
    validated = true;
  }

}
