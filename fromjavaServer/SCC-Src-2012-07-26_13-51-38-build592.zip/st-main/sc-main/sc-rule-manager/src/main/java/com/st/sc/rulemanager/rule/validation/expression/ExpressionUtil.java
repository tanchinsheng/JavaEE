/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:37:18 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import org.mvel2.ParserContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.sc.rulemanager.rule.validation.expression.stdf.ATR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.BPS;
import com.st.sc.rulemanager.rule.validation.expression.stdf.DTR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.EPS;
import com.st.sc.rulemanager.rule.validation.expression.stdf.FAR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.FTR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.HBR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.MIR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.MPR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.MRR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PCR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PGR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PIR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PLR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PMR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PRR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.PTR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.RDR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.SBR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.SDR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.StdfContext;
import com.st.sc.rulemanager.rule.validation.expression.stdf.TSR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.WCR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.WIR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.WRR;
import com.st.sc.rulemanager.rule.validation.expression.stdf.gdr.STGDR;

/**
 * The Class ExpressionUtil.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ExpressionUtil {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ExpressionUtil.class);

  /**
   * Gets the type parameters.
   * 
   * @param parserContext
   *          the parser context
   * @return the type parameters
   */
  @SuppressWarnings("unchecked")
  public static Set<String> getTypeParameters(final ParserContext parserContext) {
    Set<String> set = null;
    try {
      final Field field = ParserContext.class.getDeclaredField("typeParameters");
      field.setAccessible(true);
      final Map<String, Map<String, Type>> map =
          (Map<String, Map<String, Type>>) field.get(parserContext);
      set = Collections.unmodifiableSet(map.keySet());
    } catch (final Exception e) {
      // ignore exception
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    }
    return set;
  }

  /**
   * Checks if the given millisecond is valid date (> 1970-01-01 00:00:00).
   * 
   * @param l
   *          the l
   * @return true, if is valid date
   */
  public static boolean isValidDate(final Long l) {
    boolean retVal = false;
    if (l != null) {
      final Calendar calendar = Calendar.getInstance();
      calendar.setTimeInMillis(0);
      calendar.set(1970, Calendar.JANUARY, 1);
      final Date date = calendar.getTime();
      retVal = l.longValue() >= date.getTime();
    }
    return retVal;
  }

  /**
   * Checks if the given millisecond object is valid date.
   * 
   * @param obj
   *          the object
   * @return true, if is valid date
   */
  public static boolean isValidDate(final Object obj) {
    boolean retVal = false;
    if (obj instanceof Long) {
      retVal = isValidDate((Long) obj);
    }
    return retVal;
  }

  /**
   * Length of string object.
   * 
   * @param obj
   *          the object
   * @return the int
   */
  public static int length(final Object obj) {
    int retVal = 0;
    if (obj instanceof String) {
      retVal = length((String) obj);
    }
    return retVal;
  }

  /**
   * Length of string.
   * 
   * @param s
   *          the s
   * @return the int
   */
  public static int length(final String s) {
    int retVal = 0;
    if (s != null) {
      retVal = s.length();
    }
    return retVal;
  }

  /**
   * New context.
   * 
   * @return the parser context
   */
  public static ParserContext newContext() {
    final ParserContext context = new ParserContext();
    context.addInput("ATR", ATR.class);
    context.addInput("BPS", BPS.class);
    context.addInput("DTR", DTR.class);
    context.addInput("EPS", EPS.class);
    context.addInput("FAR", FAR.class);
    context.addInput("FTR", FTR.class);
    context.addInput("GDR", STGDR.class);
    context.addInput("HBR", HBR.class);
    context.addInput("MIR", MIR.class);
    context.addInput("MPR", MPR.class);
    context.addInput("MRR", MRR.class);
    context.addInput("PCR", PCR.class);
    context.addInput("PGR", PGR.class);
    context.addInput("PIR", PIR.class);
    context.addInput("PLR", PLR.class);
    context.addInput("PMR", PMR.class);
    context.addInput("PRR", PRR.class);
    context.addInput("PTR", PTR.class);
    context.addInput("RDR", RDR.class);
    context.addInput("SBR", SBR.class);
    context.addInput("SDR", SDR.class);
    context.addInput("TSR", TSR.class);
    context.addInput("WCR", WCR.class);
    context.addInput("WIR", WIR.class);
    context.addInput("WRR", WRR.class);

    context.addInput("this", StdfContext.class);

    try {
      context.addImport("isValidDate",
          ExpressionUtil.class.getMethod("isValidDate", Long.class));
      context.addImport("isValidDate",
          ExpressionUtil.class.getMethod("isValidDate", Object.class));
      context.addImport("length", ExpressionUtil.class.getMethod("length", String.class));
      context.addImport("length", ExpressionUtil.class.getMethod("length", Object.class));
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    }
    context.setStrongTyping(true);

    return context;
  }

  /**
   * Instantiates a new expression utility.
   */
  private ExpressionUtil() {

  }
}
