/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 24, 2011 11:04:42 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.rule.validation.RuleValidationHelper;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class CheckUniqueness.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class CheckUniqueness extends RuleValidation {

  /** The field set. */
  private final Set<FieldEnum> fieldSet;

  /** The num of failed. */
  private int numOfFailed = 0;

  /** The helper. */
  private RuleValidationHelper helper;

  /** The fields. */
  private FieldEnum[] fields;

  /** The rule key. */
  private String ruleKey;

  /** The unique set. */
  private Map<String, Record> uniqueSet;

  /** The duplicated set. */
  private Set<String> duplicatedSet;

  /**
   * Instantiates a new check uniqueness.
   * 
   * @param fieldSet
   *          the field set
   * @param recordType
   *          the record type
   */
  public CheckUniqueness(final Set<FieldEnum> fieldSet, final RecordEnum recordType) {
    super();
    this.fieldSet = fieldSet;
    initialize(fieldSet, recordType);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    return getRecordType() == record.getType();
  }

  /**
   * Gets the duplicated set.
   * 
   * @return the duplicated set
   */
  @SuppressWarnings("unchecked")
  public Set<String> getDuplicatedSet() {
    if (duplicatedSet == null) {
      final String key = ruleKey + "duplicated";
      duplicatedSet = (Set<String>) getContextData().getDataMap().get(key);
      if (duplicatedSet == null) {
        duplicatedSet = new HashSet<String>();
        getContextData().getDataMap().put(key, duplicatedSet);
      }
    }
    return duplicatedSet;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#getHelper()
   */
  @Override
  public RuleValidationHelper getHelper() {
    return helper;
  }

  /**
   * Gets the unique set.
   * 
   * @return the unique set
   */
  @SuppressWarnings("unchecked")
  public Map<String, Record> getUniqueSet() {
    if (uniqueSet == null) {
      final String key = ruleKey + "unique";
      uniqueSet = (Map<String, Record>) getContextData().getDataMap().get(key);
      if (uniqueSet == null) {
        uniqueSet = new HashMap<String, Record>();
        getContextData().getDataMap().put(key, uniqueSet);
      }
    }
    return uniqueSet;
  }

  /**
   * Initialize.
   * 
   * @param fieldSet
   *          the field set
   * @param recordType
   *          the record type
   */
  private void initialize(final Set<FieldEnum> fieldSet, final RecordEnum recordType) {
    fields = new FieldEnum[fieldSet.size()];
    fields = fieldSet.toArray(fields);
    helper = new RuleValidationHelper();
    helper.setReportFields(fields);

    ruleKey =
        RuleTypeEnum.CHECK_UNIQUENESS.getValue() + recordType.getText() + fieldSet.toString();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    final int count = getContextData().getCount(getRecordType());
    if (count == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
      return;
    }
    setNumOfRecords(count);

    // update the passed record
    final int numOfPassed = getNumOfRecords() - numOfFailed;
    setNumOfPassedRecords(numOfPassed);

    fieldSet.clear();
    fields = null;
    getDuplicatedSet().clear();
    getUniqueSet().clear();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final String key = getKey(record, fieldSet);
    if (key != null) {
      final Set<String> dset = getDuplicatedSet();
      if (dset.contains(key)) {
        numOfFailed++;
        getContextData().getFailedData().addFailedRecord(record, helper);
      } else {
        final Map<String, Record> uset = getUniqueSet();
        if (uset.containsKey(key)) {
          dset.add(key);
          final Record oldRec = uset.remove(key);
          numOfFailed += 2;
          getContextData().getFailedData().addFailedRecord(oldRec, helper);
          getContextData().getFailedData().addFailedRecord(record, helper);
        } else {
          uset.put(key, record);
        }
      }
    } else {
      numOfFailed++;
      getContextData().getFailedData().addFailedRecord(record, helper);
    }
  }
}
