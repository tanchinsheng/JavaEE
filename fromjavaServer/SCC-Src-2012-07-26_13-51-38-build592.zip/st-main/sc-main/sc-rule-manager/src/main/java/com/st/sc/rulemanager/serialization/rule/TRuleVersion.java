/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.serialization.rule;

import java.io.Serializable;

/**
 * The Class TRuleVersion.
 */
public class TRuleVersion implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 3419071629739192411L;

  /** The description. */
  private String description;

  /** The log id. */
  private Integer logId;

  /** The point. */
  private Integer point;

  /** The version. */
  private int version;

  /** The rule value list. */
  private TRuleValue[] ruleValues;

  /** The rule type. */
  private int ruleType;

  /**
   * Instantiates a new t rule version.
   */
  public TRuleVersion() {

  }

  /**
   * Gets the description.
   * 
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets the log id.
   * 
   * @return the log id
   */
  public Integer getLogId() {
    return logId;
  }

  /**
   * Gets the point.
   * 
   * @return the point
   */
  public Integer getPoint() {
    return point;
  }

  /**
   * Gets the rule type.
   * 
   * @return the rule type
   */
  public int getRuleType() {
    return ruleType;
  }

  /**
   * Gets the rule values.
   * 
   * @return the rule values
   */
  public TRuleValue[] getRuleValues() {
    return ruleValues;
  }

  /**
   * Gets the version.
   * 
   * @return the version
   */
  public int getVersion() {
    return version;
  }

  /**
   * Sets the description.
   * 
   * @param description
   *          the new description
   */
  public void setDescription(final String description) {
    this.description = description;
  }

  /**
   * Sets the log id.
   * 
   * @param logId
   *          the new log id
   */
  public void setLogId(final Integer logId) {
    this.logId = logId;
  }

  /**
   * Sets the point.
   * 
   * @param point
   *          the new point
   */
  public void setPoint(final Integer point) {
    this.point = point;
  }

  /**
   * Sets the rule type.
   * 
   * @param ruleType
   *          the new rule type
   */
  public void setRuleType(final int ruleType) {
    this.ruleType = ruleType;
  }

  /**
   * Sets the rule values.
   * 
   * @param ruleValues
   *          the new rule values
   */
  public void setRuleValues(final TRuleValue[] ruleValues) {
    this.ruleValues = ruleValues;
  }

  /**
   * Sets the version.
   * 
   * @param version
   *          the new version
   */
  public void setVersion(final int version) {
    this.version = version;
  }

}
