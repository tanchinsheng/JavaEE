/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class PRR implements RecordType {

  /**
   * 
   * @param map
   *          the map
   */
  public PRR(final Map<String, Object> map) {
    initialize(map);
  }
  private Object HEAD_NUM;
  private Object SITE_NUM;
  private Object PART_FLG;
  private Object NUM_TEST;
  private Object HARD_BIN;
  private Object SOFT_BIN;
  private Object X_COORD;
  private Object Y_COORD;
  private Object TEST_T;
  private Object PART_ID;
  private Object PART_TXT;
  private Object PART_FIX;
  private void initialize(Map<String, Object> map) {
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_NUM = map.get("SITE_NUM");
    this.PART_FLG = map.get("PART_FLG");
    this.NUM_TEST = map.get("NUM_TEST");
    this.HARD_BIN = map.get("HARD_BIN");
    this.SOFT_BIN = map.get("SOFT_BIN");
    this.X_COORD = map.get("X_COORD");
    this.Y_COORD = map.get("Y_COORD");
    this.TEST_T = map.get("TEST_T");
    this.PART_ID = map.get("PART_ID");
    this.PART_TXT = map.get("PART_TXT");
    this.PART_FIX = map.get("PART_FIX");
  }
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  public Object getSITE_NUM() {
    return this.SITE_NUM;
  }
  public Object getPART_FLG() {
    return this.PART_FLG;
  }
  public Object getNUM_TEST() {
    return this.NUM_TEST;
  }
  public Object getHARD_BIN() {
    return this.HARD_BIN;
  }
  public Object getSOFT_BIN() {
    return this.SOFT_BIN;
  }
  public Object getX_COORD() {
    return this.X_COORD;
  }
  public Object getY_COORD() {
    return this.Y_COORD;
  }
  public Object getTEST_T() {
    return this.TEST_T;
  }
  public Object getPART_ID() {
    return this.PART_ID;
  }
  public Object getPART_TXT() {
    return this.PART_TXT;
  }
  public Object getPART_FIX() {
    return this.PART_FIX;
  }
  public String getType() {
    return "PRR";
  }
}
