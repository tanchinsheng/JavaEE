/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 14, 2011 1:31:20 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.data;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.apcd.APCDMessage;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class ContextData.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ContextData {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ContextData.class);

  /** The Constant HEAD_NUM_255. */
  private static final Short HEAD_NUM_255 = Short.valueOf((short) 255);

  /** The file id. */
  private Long fileId;

  /** The compliancy result file id. */
  private Long compliancyResultFileId;

  /** The root path for failed values. */
  private String rootPath;

  /** The count map. */
  private Map<String, Integer> countMap;

  /** The MIR record. */
  private Record mirRecord;

  /** The MRR record. */
  private Record mrrRecord;

  /** The head num set PRR. */
  private Set<Short> headNumSetPRR;

  /** The test num set TSR. */
  private Set<Long> testNumSetTSR;

  /** The set of sites per head map. */
  private Map<Short, Set<Short>> sitePerHeadMap;

  /** The SITE_CNT per head map. */
  private Map<Short, Short> siteCntPerHeadMap;

  /** The head site set. */
  private Set<String> headSiteSet;

  /** The head site test set. */
  private Set<String> headSiteTestSet;

  /** The hard bin data. */
  private final BinData hardBinData;

  /** The soft bin data. */
  private final BinData softBinData;

  /** The checking time. */
  private long checkingTime;

  /** The data map. */
  private Map<String, Object> dataMap;

  /** The APCD message. */
  private final APCDMessage apcdMessage;

  /** The failed data. */
  private FailedValueData failedData;

  /**
   * Instantiates a new context data.
   */
  public ContextData() {
    countMap = new HashMap<String, Integer>();

    testNumSetTSR = new HashSet<Long>();

    sitePerHeadMap = new HashMap<Short, Set<Short>>();
    siteCntPerHeadMap = new HashMap<Short, Short>();

    headNumSetPRR = new HashSet<Short>();

    headSiteSet = new HashSet<String>();
    headSiteTestSet = new HashSet<String>();

    hardBinData = new BinData();
    softBinData = new BinData();

    dataMap = new HashMap<String, Object>();

    apcdMessage = new APCDMessage();

    failedData = new FailedValueData();
  }

  /**
   * Clear all data to free memory.
   */
  @SuppressWarnings("rawtypes")
  public void clear() {
    if (countMap != null) {
      countMap.clear();
      countMap = null;
    }

    if (testNumSetTSR != null) {
      testNumSetTSR.clear();
      testNumSetTSR = null;
    }

    if (sitePerHeadMap != null) {
      sitePerHeadMap.clear();
      sitePerHeadMap = null;
    }
    if (siteCntPerHeadMap != null) {
      siteCntPerHeadMap.clear();
      siteCntPerHeadMap = null;
    }

    if (headNumSetPRR != null) {
      headNumSetPRR.clear();
      headNumSetPRR = null;
    }

    if (headSiteSet != null) {
      headSiteSet.clear();
      headSiteSet = null;
    }
    if (headSiteTestSet != null) {
      headSiteTestSet.clear();
      headSiteTestSet = null;
    }

    hardBinData.clear();
    softBinData.clear();

    if (dataMap != null) {
      final Set<Entry<String, Object>> entrySet = dataMap.entrySet();
      for (final Entry<String, Object> entry : entrySet) {
        final Object value = entry.getValue();
        if (value instanceof Collection) {
          ((Collection) value).clear();
        } else if (value instanceof Map) {
          ((Map) value).clear();
        }
      }
      dataMap.clear();
      dataMap = null;
    }

    failedData.clear();
  }

  /**
   * Gets the APCD message.
   * 
   * @return the APCD message
   */
  public APCDMessage getApcdMessage() {
    return apcdMessage;
  }

  /**
   * Gets the checking time.
   * 
   * @return the checking time
   */
  public long getCheckingTime() {
    return checkingTime;
  }

  /**
   * Gets the compliancy result file id.
   * 
   * @return the compliancy result file id
   */
  public Long getCompliancyResultFileId() {
    return compliancyResultFileId;
  }

  /**
   * Gets the count.
   * 
   * @param recordType
   *          the record type
   * @return the count
   */
  public int getCount(final RecordEnum recordType) {
    int retVal = 0;
    final Integer count = countMap.get(recordType.getText());
    if (count != null) {
      retVal = count.intValue();
    }
    return retVal;
  }

  /**
   * Gets the count map.
   * 
   * @return the count map
   */
  public Map<String, Integer> getCountMap() {
    return countMap;
  }

  /**
   * Gets the data map.
   * 
   * @return the data map
   */
  public Map<String, Object> getDataMap() {
    return dataMap;
  }

  /**
   * Gets the failed data.
   * 
   * @return the failed data
   */
  public FailedValueData getFailedData() {
    return failedData;
  }

  /**
   * Gets the file id.
   * 
   * @return the file id
   */
  public Long getFileId() {
    return fileId;
  }

  /**
   * Gets the hard bin data.
   * 
   * @return the hard bin data
   */
  public BinData getHardBinData() {
    return hardBinData;
  }

  /**
   * Gets the head num set PRR.
   * 
   * @return the head num set PRR
   */
  public Set<Short> getHeadNumSetPRR() {
    return headNumSetPRR;
  }

  /**
   * Gets the head site set.
   * 
   * @return the head site set
   */
  public Set<String> getHeadSiteSet() {
    return headSiteSet;
  }

  /**
   * Gets the head site test set.
   * 
   * @return the head site test set
   */
  public Set<String> getHeadSiteTestSet() {
    return headSiteTestSet;
  }

  /**
   * Gets the MIR record.
   * 
   * @return the MIR record
   */
  public Record getMirRecord() {
    return mirRecord;
  }

  /**
   * Gets the MRR record.
   * 
   * @return the MRR record
   */
  public Record getMrrRecord() {
    return mrrRecord;
  }

  /**
   * Gets the root path for failed values.
   * 
   * @return the root path
   */
  public String getRootPath() {
    return rootPath;
  }

  /**
   * Gets the SDR.SITE_CNT per head map.
   * 
   * @return the SDR.SITE_CNT per head map
   */
  public Map<Short, Short> getSiteCntPerHeadMap() {
    return siteCntPerHeadMap;
  }

  /**
   * Gets the site per head map.
   * 
   * @return the site per head map
   */
  public Map<Short, Set<Short>> getSitePerHeadMap() {
    return sitePerHeadMap;
  }

  /**
   * Gets the soft bin data.
   * 
   * @return the soft bin data
   */
  public BinData getSoftBinData() {
    return softBinData;
  }

  /**
   * Gets the test num set TSR.
   * 
   * @return the test num set TSR
   */
  public Set<Long> getTestNumSetTSR() {
    return testNumSetTSR;
  }

  /**
   * Increase count.
   * 
   * @param recordType
   *          the record type
   */
  public void increaseCount(final RecordEnum recordType) {
    final String recordName = recordType.getText();
    Integer count = countMap.get(recordName);
    if (count != null) {
      count = Integer.valueOf(count.intValue() + 1);
    } else {
      count = Integer.valueOf(1);
    }
    countMap.put(recordName, count);
  }

  /**
   * Sets the checking time.
   * 
   * @param checkingTime
   *          the new checking time
   */
  public void setCheckingTime(final long checkingTime) {
    this.checkingTime = checkingTime;
  }

  /**
   * Sets the compliancy result file id.
   * 
   * @param compliancyResultFileId
   *          the new compliancy result file id
   */
  public void setCompliancyResultFileId(final Long compliancyResultFileId) {
    this.compliancyResultFileId = compliancyResultFileId;
  }

  /**
   * Sets the file id.
   * 
   * @param fileId
   *          the new file id
   */
  public void setFileId(final Long fileId) {
    this.fileId = fileId;
  }

  /**
   * Sets the MIR record.
   * 
   * @param mirRecord
   *          the new MIR record
   */
  public void setMirRecord(final Record mirRecord) {
    this.mirRecord = mirRecord;
  }

  /**
   * Sets the mrr record.
   * 
   * @param mrrRecord
   *          the new mrr record
   */
  public void setMrrRecord(final Record mrrRecord) {
    this.mrrRecord = mrrRecord;
  }

  /**
   * Sets the root path for failed value.
   * 
   * @param rootPath
   *          the new root path
   */
  public void setRootPath(final String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   * Update data.
   * 
   * @param record
   *          the record
   */
  public void updateData(final Record record) {
    final RecordEnum recordType = record.getType();
    increaseCount(recordType);
    updateRecordData(record);
  }

  /**
   * Update PRR for head num, hard bin, soft bin.
   * 
   * @param record
   *          the record
   */
  private void updatePRR(final Record record) {
    final Integer hardBin = (Integer) record.getFieldValue(FieldEnum.HARD_BIN);
    final Set<Integer> hardBinNumSet = hardBinData.getBinNumSet();
    if (hardBin != null && !hardBinNumSet.contains(hardBin)) {
      hardBinNumSet.add(hardBin);
    }
    final Set<Integer> softBinNumSet = softBinData.getBinNumSet();
    final Integer softBin = (Integer) record.getFieldValue(FieldEnum.SOFT_BIN);
    if (softBin != null && !softBinNumSet.contains(softBin)) {
      softBinNumSet.add(softBin);
    }

    final Short headNum = (Short) record.getFieldValue(FieldEnum.HEAD_NUM);
    final Short siteNum = (Short) record.getFieldValue(FieldEnum.SITE_NUM);
    if (headNum != null && siteNum != null) {
      if (!HEAD_NUM_255.equals(headNum)) {
        final String key = headNum + "::" + siteNum;
        if (!headSiteSet.contains(key)) {
          headSiteSet.add(key);
        }

        hardBinData.add(headNum, siteNum, hardBin);
        softBinData.add(headNum, siteNum, softBin);
      }

      if (!headNumSetPRR.contains(headNum)) {
        headNumSetPRR.add(headNum);
      }

      Set<Short> siteSet = sitePerHeadMap.get(headNum);
      if (siteSet == null) {
        siteSet = new HashSet<Short>();
        sitePerHeadMap.put(headNum, siteSet);
      }
      if (!siteSet.contains(siteNum)) {
        siteSet.add(siteNum);
      }
    }
  }

  /**
   * Update context with the given record.
   * 
   * @param record
   *          the record
   */
  private void updateRecordData(final Record record) {
    switch (record.getType()) {
    case PTR:
    case MPR:
    case FTR:
      updateTest(record);
      break;

    case MIR:
      if (mirRecord == null) {
        mirRecord = record;
      } else {
        LOG.warn("Multiple record MIR. Ignore all other except the 1st MIR");
      }
      break;

    case MRR:
      if (mrrRecord == null) {
        mrrRecord = record;
      } else {
        LOG.warn("Multiple record MRR. Ignore all other except the 1st MRR");
      }
      break;

    case PCR:
      final Short head = (Short) record.getFieldValue(FieldEnum.HEAD_NUM);
      final Short site = (Short) record.getFieldValue(FieldEnum.SITE_NUM);
      if (head != null && site != null && head.shortValue() == HEAD_NUM_255.shortValue()
          && site.shortValue() == HEAD_NUM_255.shortValue()) {
        final Long partCnt = (Long) record.getFieldValue(FieldEnum.PART_CNT);
        final Long goodCnt = (Long) record.getFieldValue(FieldEnum.GOOD_CNT);
        if (goodCnt != null) {
          apcdMessage.setPassDieCount(goodCnt.intValue());
          if (partCnt != null) {
            final long failDieCount = partCnt.longValue() - goodCnt.longValue();
            if (failDieCount >= 0) {
              apcdMessage.setFailDieCount((int) failDieCount);
            }
          }
        }
      }
      break;

    case PRR:
      updatePRR(record);
      break;

    case HBR:
      hardBinData.add((Integer) record.getFieldValue(FieldEnum.HBIN_NUM));
      break;

    case SBR:
      softBinData.add((Integer) record.getFieldValue(FieldEnum.SBIN_NUM));
      break;

    case SDR:
      updateSDR(record);
      break;

    case WRR:
      final String waferId = (String) record.getFieldValue(FieldEnum.WAFER_ID);
      if (waferId != null) {
        apcdMessage.getWaferIdList().add(waferId);
      }
      break;

    case WCR:
      int waferFlatAngle = 0;
      final String wfFlat = (String) record.getFieldValue(FieldEnum.WF_FLAT);
      if ("U".equals(wfFlat)) {
        waferFlatAngle = 3;
      } else if ("D".equals(wfFlat)) {
        waferFlatAngle = 1;
      } else if ("L".equals(wfFlat)) {
        waferFlatAngle = 2;
      } else if ("R".equals(wfFlat)) {
        waferFlatAngle = 4;
      }
      apcdMessage.setWaferFlatAngle(waferFlatAngle);
      break;

    default:
      break;
    }
  }

  /**
   * Update SDR.
   * 
   * @param record
   *          the record
   */
  private void updateSDR(final Record record) {
    final Short headNum = (Short) record.getFieldValue(FieldEnum.HEAD_NUM);
    final Short siteCnt = (Short) record.getFieldValue(FieldEnum.SITE_CNT);
    if (headNum != null && siteCnt != null) {
      siteCntPerHeadMap.put(headNum, siteCnt);
    }
    final String cardId = (String) record.getFieldValue(FieldEnum.CARD_ID);
    if (cardId != null) {
      apcdMessage.getCardIdList().add(cardId);
    }
  }

  /**
   * Update Test for test num.
   * 
   * @param record
   *          the record
   */
  private void updateTest(final Record record) {
    final Long testNum = (Long) record.getFieldValue(FieldEnum.TEST_NUM);
    if (testNum != null && !testNumSetTSR.contains(testNum)) {
      testNumSetTSR.add(testNum);
    }

    final Short headNum = (Short) record.getFieldValue(FieldEnum.HEAD_NUM);
    final Short siteNum = (Short) record.getFieldValue(FieldEnum.SITE_NUM);
    if (headNum != null && siteNum != null && !HEAD_NUM_255.equals(headNum)) {
      final String key = headNum + "::" + siteNum + "::" + testNum;
      if (!headSiteTestSet.contains(key)) {
        headSiteTestSet.add(key);
      }
    }
  }
}
