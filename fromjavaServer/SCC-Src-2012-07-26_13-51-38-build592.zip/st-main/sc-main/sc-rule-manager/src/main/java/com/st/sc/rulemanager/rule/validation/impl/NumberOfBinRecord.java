/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 23, 2011 11:20:38 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import com.st.sc.rulemanager.data.BinData;
import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class NumberOfBinRecord.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class NumberOfBinRecord extends RuleValidation {

  /** The is hard bin. */
  private final boolean isHardBin;

  /**
   * Instantiates a new number of bin record.
   * 
   * @param isHardBin
   *          the is hard bin
   */
  public NumberOfBinRecord(final boolean isHardBin) {
    super();
    this.isHardBin = isHardBin;
    setCrossRule(false);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    return false;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final ContextData context = getContextData();
    int countBin = 0;
    BinData binData = null;
    if (isHardBin) {
      binData = context.getHardBinData();
      countBin = context.getCount(RecordEnum.HBR);
    } else {
      binData = context.getSoftBinData();
      countBin = context.getCount(RecordEnum.SBR);
    }
    if (countBin == 0) {
      setFailedMessage(getRecordType() + " is missing");
      return;
    }

    final int binSize = binData.getBinNumSet().size();
    int headSiteBinSize = binData.getHeadSiteBinSize();
    final int calculatedVal = headSiteBinSize + binSize;
    if (countBin == calculatedVal) {
      increaseNumOfPassedRecords();
    } else {
      final StringBuilder sb = new StringBuilder();
      sb.append("No. ").append(getRecordType().getText()).append(": ").append(countBin);
      final String binString = isHardBin ? "hard bin" : "soft bin";
      sb.append(", No. of head/site/").append(binString);
      sb.append(" combination: ").append(headSiteBinSize);
      sb.append(", No. of ").append(binString).append(": ").append(binSize);
      setFailedMessage(sb.toString());
    }
    increaseNumOfRecords();
  }
}
