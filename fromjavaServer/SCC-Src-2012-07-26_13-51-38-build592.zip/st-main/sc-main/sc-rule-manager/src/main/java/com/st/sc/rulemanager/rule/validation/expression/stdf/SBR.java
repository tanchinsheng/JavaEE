/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class SBR implements RecordType {

  /**
   * 
   * @param map
   *          the map
   */
  public SBR(final Map<String, Object> map) {
    initialize(map);
  }
  private Object HEAD_NUM;
  private Object SITE_NUM;
  private Object SBIN_NUM;
  private Object SBIN_CNT;
  private Object SBIN_PF;
  private Object SBIN_NAM;
  private void initialize(Map<String, Object> map) {
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_NUM = map.get("SITE_NUM");
    this.SBIN_NUM = map.get("SBIN_NUM");
    this.SBIN_CNT = map.get("SBIN_CNT");
    this.SBIN_PF = map.get("SBIN_PF");
    this.SBIN_NAM = map.get("SBIN_NAM");
  }
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  public Object getSITE_NUM() {
    return this.SITE_NUM;
  }
  public Object getSBIN_NUM() {
    return this.SBIN_NUM;
  }
  public Object getSBIN_CNT() {
    return this.SBIN_CNT;
  }
  public Object getSBIN_PF() {
    return this.SBIN_PF;
  }
  public Object getSBIN_NAM() {
    return this.SBIN_NAM;
  }
  public String getType() {
    return "SBR";
  }
}
