/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 30, 2011 4:29:28 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.serialization;

import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.ObjectBuffer;
import com.esotericsoftware.kryo.serialize.ArraySerializer;
import com.esotericsoftware.kryo.serialize.FieldSerializer;
import com.st.sc.rulemanager.serialization.rule.TMirCriteria;
import com.st.sc.rulemanager.serialization.rule.TRule;
import com.st.sc.rulemanager.serialization.rule.TRuleSet;
import com.st.sc.rulemanager.serialization.rule.TRuleSetVersion;
import com.st.sc.rulemanager.serialization.rule.TRuleValue;
import com.st.sc.rulemanager.serialization.rule.TRuleVersion;

/**
 * The Class KryoHelper.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class KryoHelper {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(KryoHelper.class);

  /** The object pool. */
  private static ObjectPool objectPool = new GenericObjectPool(new ObjectBufferPoolFactory(),
      20);

  /**
   * Gets the object pool.
   * 
   * @return the object pool
   */
  public static ObjectPool getObjectPool() {
    return objectPool;
  }

  /**
   * New object buffer.
   * 
   * @return the object buffer
   */
  public static ObjectBuffer newObjectBuffer() {
    return newObjectBuffer(8192, 10240000);
  }

  /**
   * New object buffer.
   * 
   * @param minBufferSize
   *          the min buffer size
   * @param maxBufferSize
   *          the max buffer size
   * @return the object buffer
   */
  public static ObjectBuffer newObjectBuffer(final int minBufferSize, final int maxBufferSize) {
    final Kryo kryo = new Kryo();

    kryo.register(Object[].class, new ArraySerializer(kryo));
    kryo.register(String[].class, new ArraySerializer(kryo));
    kryo.register(TRule[].class, new ArraySerializer(kryo));
    kryo.register(TRuleSet[].class, new ArraySerializer(kryo));
    kryo.register(TRuleVersion[].class, new ArraySerializer(kryo));
    kryo.register(TRuleSetVersion[].class, new ArraySerializer(kryo));
    kryo.register(TRuleValue[].class, new ArraySerializer(kryo));

    kryo.register(TMirCriteria.class, new FieldSerializer(kryo, TMirCriteria.class));
    kryo.register(TRule.class, new FieldSerializer(kryo, TRule.class));
    kryo.register(TRuleSet.class, new FieldSerializer(kryo, TRuleSet.class));
    kryo.register(TRuleSetVersion.class, new FieldSerializer(kryo, TRuleSetVersion.class));
    kryo.register(TRuleValue.class, new FieldSerializer(kryo, TRuleValue.class));
    kryo.register(TRuleVersion.class, new FieldSerializer(kryo, TRuleVersion.class));

    final ObjectBuffer objectBuffer = new ObjectBuffer(kryo, minBufferSize, maxBufferSize);
    return objectBuffer;
  }

  /**
   * Convert given object to byte array.
   * 
   * @param object
   *          the object
   * @return the byte array
   */
  public static byte[] toByteArray(final Object object) {
    byte[] bytes = null;
    if (object != null) {
      ObjectBuffer objectBuffer = null;
      try {
        objectBuffer = (ObjectBuffer) objectPool.borrowObject();
        synchronized (objectBuffer) {
          bytes = objectBuffer.writeClassAndObject(object);
        }
      } catch (final Exception e) {
        LOG.error(e.getMessage(), e);
        if (objectBuffer != null) {
          try {
            objectPool.invalidateObject(objectBuffer);
          } catch (final Exception ex) {
            LOG.error(e.getMessage(), e);
          } finally {
            objectBuffer = null;
          }
        }
      } finally {
        if (objectBuffer != null) {
          try {
            objectPool.returnObject(objectBuffer);
          } catch (final Exception e) {
            LOG.error(e.getMessage(), e);
          }
        }
      }
    }
    return bytes;
  }

  /**
   * Convert the byte array to Java object.
   * 
   * @param bytes
   *          the byte array
   * @return the object
   */
  public static Object toObject(final byte[] bytes) {
    Object object = null;
    if (bytes != null && bytes.length > 0) {
      ObjectBuffer objectBuffer = null;
      try {
        objectBuffer = (ObjectBuffer) objectPool.borrowObject();
        synchronized (objectBuffer) {
          object = objectBuffer.readClassAndObject(bytes);
        }
      } catch (final Exception e) {
        LOG.error(e.getMessage(), e);
        if (objectBuffer != null) {
          try {
            objectPool.invalidateObject(objectBuffer);
          } catch (final Exception ex) {
            LOG.error(e.getMessage(), e);
          } finally {
            objectBuffer = null;
          }
        }
      } finally {
        if (objectBuffer != null) {
          try {
            objectPool.returnObject(objectBuffer);
          } catch (final Exception e) {
            LOG.error(e.getMessage(), e);
          }
        }
      }
    }
    return object;
  }

  /**
   * Instantiates a new Kryo helper.
   */
  private KryoHelper() {

  }

}
