/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 28, 2011 4:17:55 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.serialization;

import java.io.Serializable;

/**
 * The Class FailedDetailReportData.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class FailedDetailReportData implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 5957131090281804944L;

  /** The headers. */
  private String[] headers;

  /** The data. */
  private Object[][] data;

  /**
   * Instantiates a new failed detail report data.
   */
  public FailedDetailReportData() {

  }

  /**
   * Gets the data.
   * 
   * @return the data
   */
  public Object[][] getData() {
    return data;
  }

  /**
   * Gets the headers.
   * 
   * @return the headers
   */
  public String[] getHeaders() {
    return headers;
  }

  /**
   * Sets the data.
   * 
   * @param data
   *          the new data
   */
  public void setData(final Object[][] data) {
    this.data = data;
  }

  /**
   * Sets the headers.
   * 
   * @param headers
   *          the new headers
   */
  public void setHeaders(final String[] headers) {
    this.headers = headers;
  }

}
