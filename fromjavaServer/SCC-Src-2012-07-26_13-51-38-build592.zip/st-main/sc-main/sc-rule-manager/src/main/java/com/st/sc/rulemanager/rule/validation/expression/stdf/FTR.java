/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * The Class FTR.
 *
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 * rights reserved.
 */
public class FTR  implements RecordType {

  /**
   * Instantiates a new fTR.
   *
   * @param map the map
   */
  public FTR(final Map<String, Object> map) {
    initialize(map);
  }

  /** The TEST_NUM. */
  private Object TEST_NUM;
  
  /** The HEAD_NUM. */
  private Object HEAD_NUM;
  
  /** The SITE_NUM. */
  private Object SITE_NUM;
  
  /** The TEST_FLG. */
  private Object TEST_FLG;
  
  /** The OPT_FLAG. */
  private Object OPT_FLAG;
  
  /** The CYCL_CNT. */
  private Object CYCL_CNT;
  
  /** The REL_VADR. */
  private Object REL_VADR;
  
  /** The REPT_CNT. */
  private Object REPT_CNT;
  
  /** The NUM_FAIL. */
  private Object NUM_FAIL;
  
  /** The XFAIL_AD. */
  private Object XFAIL_AD;
  
  /** The YFAIL_AD. */
  private Object YFAIL_AD;
  
  /** The VECT_OFF. */
  private Object VECT_OFF;
  
  /** The RTN_ICNT. */
  private Object RTN_ICNT;
  
  /** The PGM_ICNT. */
  private Object PGM_ICNT;
  
  /** The RTN_INDX. */
  private Object RTN_INDX;
  
  /** The RTN_STAT. */
  private Object RTN_STAT;
  
  /** The PGM_INDX. */
  private Object PGM_INDX;
  
  /** The PGM_STAT. */
  private Object PGM_STAT;
  
  /** The FAIL_PIN. */
  private Object FAIL_PIN;
  
  /** The VECT_NAM. */
  private Object VECT_NAM;
  
  /** The TIME_SET. */
  private Object TIME_SET;
  
  /** The OP_CODE. */
  private Object OP_CODE;
  
  /** The TEST_TXT. */
  private Object TEST_TXT;
  
  /** The ALARM_ID. */
  private Object ALARM_ID;
  
  /** The PROG_TXT. */
  private Object PROG_TXT;
  
  /** The RSLT_TXT. */
  private Object RSLT_TXT;
  
  /** The PATG_NUM. */
  private Object PATG_NUM;
  
  /** The SPIN_MAP. */
  private Object SPIN_MAP;
  
  /**
   * Initialize.
   *
   * @param map the map
   */
  private void initialize(Map<String, Object> map) {
    this.TEST_NUM = map.get("TEST_NUM");
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_NUM = map.get("SITE_NUM");
    this.TEST_FLG = map.get("TEST_FLG");
    this.OPT_FLAG = map.get("OPT_FLAG");
    this.CYCL_CNT = map.get("CYCL_CNT");
    this.REL_VADR = map.get("REL_VADR");
    this.REPT_CNT = map.get("REPT_CNT");
    this.NUM_FAIL = map.get("NUM_FAIL");
    this.XFAIL_AD = map.get("XFAIL_AD");
    this.YFAIL_AD = map.get("YFAIL_AD");
    this.VECT_OFF = map.get("VECT_OFF");
    this.RTN_ICNT = map.get("RTN_ICNT");
    this.PGM_ICNT = map.get("PGM_ICNT");
    this.RTN_INDX = map.get("RTN_INDX");
    this.RTN_STAT = map.get("RTN_STAT");
    this.PGM_INDX = map.get("PGM_INDX");
    this.PGM_STAT = map.get("PGM_STAT");
    this.FAIL_PIN = map.get("FAIL_PIN");
    this.VECT_NAM = map.get("VECT_NAM");
    this.TIME_SET = map.get("TIME_SET");
    this.OP_CODE = map.get("OP_CODE");
    this.TEST_TXT = map.get("TEST_TXT");
    this.ALARM_ID = map.get("ALARM_ID");
    this.PROG_TXT = map.get("PROG_TXT");
    this.RSLT_TXT = map.get("RSLT_TXT");
    this.PATG_NUM = map.get("PATG_NUM");
    this.SPIN_MAP = map.get("SPIN_MAP");
  }
  
  /**
   * Gets the TEST_NUM.
   *
   * @return the TEST_NUM
   */
  public Object getTEST_NUM() {
    return this.TEST_NUM;
  }
  
  /**
   * Gets the HEAD_NUM.
   *
   * @return the HEAD_NUM
   */
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  
  /**
   * Gets the SITE_NUM.
   *
   * @return the SITE_NUM
   */
  public Object getSITE_NUM() {
    return this.SITE_NUM;
  }
  
  /**
   * Gets the TEST_FLG.
   *
   * @return the TEST_FLG
   */
  public Object getTEST_FLG() {
    return this.TEST_FLG;
  }
  
  /**
   * Gets the OPT_FLAG.
   *
   * @return the OPT_FLAG
   */
  public Object getOPT_FLAG() {
    return this.OPT_FLAG;
  }
  
  /**
   * Gets the CYCL_CNT.
   *
   * @return the CYCL_CNT
   */
  public Object getCYCL_CNT() {
    return this.CYCL_CNT;
  }
  
  /**
   * Gets the REL_VADR.
   *
   * @return the REL_VADR
   */
  public Object getREL_VADR() {
    return this.REL_VADR;
  }
  
  /**
   * Gets the REPT_CNT.
   *
   * @return the REPT_CNT
   */
  public Object getREPT_CNT() {
    return this.REPT_CNT;
  }
  
  /**
   * Gets the NUM_FAIL.
   *
   * @return the NUM_FAIL
   */
  public Object getNUM_FAIL() {
    return this.NUM_FAIL;
  }
  
  /**
   * Gets the XFAIL_AD.
   *
   * @return the XFAIL_AD
   */
  public Object getXFAIL_AD() {
    return this.XFAIL_AD;
  }
  
  /**
   * Gets the YFAIL_AD.
   *
   * @return the YFAIL_AD
   */
  public Object getYFAIL_AD() {
    return this.YFAIL_AD;
  }
  
  /**
   * Gets the VECT_OFF.
   *
   * @return the VECT_OFF
   */
  public Object getVECT_OFF() {
    return this.VECT_OFF;
  }
  
  /**
   * Gets the RTN_ICNT.
   *
   * @return the RTN_ICNT
   */
  public Object getRTN_ICNT() {
    return this.RTN_ICNT;
  }
  
  /**
   * Gets the PGM_ICNT.
   *
   * @return the PGM_ICNT
   */
  public Object getPGM_ICNT() {
    return this.PGM_ICNT;
  }
  
  /**
   * Gets the RTN_INDX.
   *
   * @return the RTN_INDX
   */
  public Object getRTN_INDX() {
    return this.RTN_INDX;
  }
  
  /**
   * Gets the RTN_STAT.
   *
   * @return the RTN_STAT
   */
  public Object getRTN_STAT() {
    return this.RTN_STAT;
  }
  
  /**
   * Gets the PGM_INDX.
   *
   * @return the PGM_INDX
   */
  public Object getPGM_INDX() {
    return this.PGM_INDX;
  }
  
  /**
   * Gets the PGM_STAT.
   *
   * @return the PGM_STAT
   */
  public Object getPGM_STAT() {
    return this.PGM_STAT;
  }
  
  /**
   * Gets the FAIL_PIN.
   *
   * @return the FAIL_PIN
   */
  public Object getFAIL_PIN() {
    return this.FAIL_PIN;
  }
  
  /**
   * Gets the VECT_NAM.
   *
   * @return the VECT_NAM
   */
  public Object getVECT_NAM() {
    return this.VECT_NAM;
  }
  
  /**
   * Gets the TIME_SET.
   *
   * @return the TIME_SET
   */
  public Object getTIME_SET() {
    return this.TIME_SET;
  }
  
  /**
   * Gets the OP_CODE.
   *
   * @return the OP_CODE
   */
  public Object getOP_CODE() {
    return this.OP_CODE;
  }
  
  /**
   * Gets the TEST_TXT.
   *
   * @return the TEST_TXT
   */
  public Object getTEST_TXT() {
    return this.TEST_TXT;
  }
  
  /**
   * Gets the ALARM_ID.
   *
   * @return the ALARM_ID
   */
  public Object getALARM_ID() {
    return this.ALARM_ID;
  }
  
  /**
   * Gets the PROG_TXT.
   *
   * @return the PROG_TXT
   */
  public Object getPROG_TXT() {
    return this.PROG_TXT;
  }
  
  /**
   * Gets the RSLT_TXT.
   *
   * @return the RSLT_TXT
   */
  public Object getRSLT_TXT() {
    return this.RSLT_TXT;
  }
  
  /**
   * Gets the PATG_NUM.
   *
   * @return the PATG_NUM
   */
  public Object getPATG_NUM() {
    return this.PATG_NUM;
  }
  
  /**
   * Gets the SPIN_MAP.
   *
   * @return the SPIN_MAP
   */
  public Object getSPIN_MAP() {
    return this.SPIN_MAP;
  }
  
  /**
   * {@inheritDoc}
   * @see com.st.sc.rulemanager.rule.validation.expression.stdf.RecordType#getType()
   */
  public String getType() {
    return "FTR";
  }
}
