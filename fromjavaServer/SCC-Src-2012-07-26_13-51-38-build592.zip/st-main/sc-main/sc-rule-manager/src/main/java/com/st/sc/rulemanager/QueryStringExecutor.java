/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 2, 2011 3:30:46 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager;

import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class QueryStringExecutor implements QueryExecutor {

  /**
   * Type of query string: SQL or JPQL or named query.
   */
  private int type;
  private String queryString;
  private Map<String, Object> parameters;

  /**
   * Create a QueryEntity to update or delete using query string (SQL, JPQL,
   * Named Query).
   * 
   * @param type
   *          SQL_QUERY, JPQL_QUERY, NAMED_QUERY
   * @param query
   *          the query string.
   * @param parameters
   *          parameters for querying.
   */
  public QueryStringExecutor(int type, String query, Map<String, Object> parameters) {
    this.type = type;
    this.queryString = query;
    this.parameters = parameters;
  }

  /**
   * Update or delete using query string with parameters. {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.QueryExecutor#execute()
   */
  public boolean execute(EntityManager entityManager) {
    return executeUpdateDelete(entityManager, queryString, parameters, type);
  }

  /**
   * Execute the query.
   * 
   * @param entityManager
   *          the entity manager.
   * @param queryString
   *          if queryType = NAMED_QUERY, queryString is the name of named
   *          query. If queryType = SQL_QUERY, queryString is the sql string. If
   *          queryType = JPQL_QUERY, queryString is the jpql string.
   * @param parameters
   *          the parameters of query.
   * @param queryType
   *          SQL_QUERY, JPQL_QUERY, NAMED_QUERY.
   * @return true if executing successfully.
   */
  private boolean executeUpdateDelete(EntityManager entityManager, String queryString,
      Map<String, Object> parameters, int queryType) {
    Query q = null;
    switch (queryType) {
    case SQL_QUERY:
      q = entityManager.createNativeQuery(queryString);
      break;
    case JPQL_QUERY:
      q = entityManager.createQuery(queryString);
      break;
    case NAMED_QUERY:
      q = entityManager.createNamedQuery(queryString);
      break;
    }
    if (q == null) {
      return false;
    }
    if (parameters != null) {
      Set<String> keys = parameters.keySet();
      for (String name : keys) {
        Object value = parameters.get(name);
        q.setParameter(name, value);
      }
    }
    if (q.executeUpdate() > 0) {
      return true;
    }
    return false;
  }
}
