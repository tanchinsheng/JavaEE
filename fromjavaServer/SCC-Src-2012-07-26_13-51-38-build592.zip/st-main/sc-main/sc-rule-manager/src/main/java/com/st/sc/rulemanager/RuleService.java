/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 3, 2011 9:48:44 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleVersion;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleService {

  private BaseService baseService;

  public RuleService(BaseService baseService) {
    this.baseService = baseService;
  }

  /**
   * Get all rules in DB. entityManager is managed by yourself.
   * 
   * @param entityManager
   *          the entity manager used to query. After using the queried results,
   *          should close entityManager.
   * @return list of Rule
   */
  public List<Rule> getAllRules(EntityManager entityManager) {
    return baseService.queryListUseNamedQuery(entityManager, Rule.GET_ALL_RULES, null,
        Rule.class);
  }

  /**
   * Get all rules in DB.
   * 
   * @return list of Rule
   */
  public List<Rule> getAllRules() {
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    List<Rule> ls =
        baseService
            .queryListUseNamedQuery(entityManager, Rule.GET_ALL_RULES, null, Rule.class);
    baseService.closeEntityManager(entityManager);
    return ls;
  }


  /**
   * Get max version of rule.
   * 
   * @param ruleId
   * @return
   */
  public Integer getMaxVersionOfRule(Long ruleId) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleId", ruleId);
    Object ob = baseService.querySingleValueUseNamedQuery(RuleVersion.GET_MAX_VERSION, param);
    if (ob == null) {
      return null;
    }
    if (ob instanceof BigInteger) {
      return ((BigInteger) ob).intValue();
    }
    return (Integer) ob;
  }

  /**
   * Get rule by ruleName.
   * 
   * @param ruleName
   *          name of rule.
   * @return a rule, the result is null if it cannot find any rule.
   */
  public Rule getRuleByName(String ruleName) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleName", ruleName.toUpperCase());
    List<Rule> list =
        baseService.queryListUseNamedQuery(Rule.GET_RULE_BYNAME, param, Rule.class);
    if (list == null || list.size() == 0) {
      return null;
    }
    return list.get(0);
  }

  /**
   * Count number of rule version of rule.
   * 
   * @param ruleId
   *          rule id
   * @return number of rule version.
   */
  public Long countVersionOfRule(Long ruleId) {
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleId", ruleId);
    Object ob =
        baseService.querySingleValueUseNamedQuery(RuleVersion.COUNT_RULE_VERSION, param);
    baseService.closeEntityManager(entityManager);
    if (ob == null) {
      return null;
    }
    if (ob instanceof BigInteger) {
      return ((BigInteger) ob).longValue();
    }
    return (Long) ob;
  }

  public RuleSetVersion loadRuleVersions(RuleSetVersion ruleSet) {
    RuleSetVersion entity = null;
    EntityManager entityManager = baseService.getEntityManagerFactory().createEntityManager();
    entityManager.getTransaction().begin();
    entity = entityManager.merge(ruleSet);
    entity.getRuleVersions(); // lazy load
    entityManager.getTransaction().commit();
    return entity;
  }
  /**
   * Get all versions of rule.
   * @param ruleId
   * @return
   */
  public List<RuleVersion> getAllVersionOfRule(Long ruleId) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("ruleId", ruleId);
    List<RuleVersion> ls =
        baseService.queryListUseNamedQuery(RuleVersion.GET_VERSIONS_OF_RULE, param,
            RuleVersion.class);
    return ls;
  }
}
