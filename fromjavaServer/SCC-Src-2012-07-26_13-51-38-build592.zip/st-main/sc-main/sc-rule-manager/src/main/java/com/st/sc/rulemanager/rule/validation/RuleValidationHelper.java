/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 30, 2011 2:29:04 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation;

import java.util.ArrayList;
import java.util.List;

import com.st.scc.common.utils.ArrayUtil;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class RuleValidationHelper.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleValidationHelper {

  /** The file path. */
  private String filePath;

  /** The report fields. */
  private FieldEnum[] reportFields;

  /** The index list. */
  private final List<Integer> indexList;

  /** The first fail value. */
  private Object firstFailValue;

  /**
   * Instantiates a new record rule validation helper.
   */
  public RuleValidationHelper() {
    super();
    indexList = new ArrayList<Integer>();
  }

  /**
   * Gets the failed value.
   * 
   * @param array
   *          the array
   * @param field
   *          the field
   * @return the failed value
   */
  public Object getFailedValue(final Object[] array, final FieldEnum field) {
    final int index = ArrayUtil.search(reportFields, field);
    Object retVal = null;
    if (index >= 0) {
      retVal = array[index];
    }
    return retVal;
  }

  /**
   * Gets the file path.
   * 
   * @return the file path
   */
  public String getFilePath() {
    return filePath;
  }

  /**
   * Gets the first fail value.
   * 
   * @return the first fail value
   */
  public Object getFirstFailValue() {
    return firstFailValue;
  }

  /**
   * Gets the id fields for failed value report.
   * 
   * @param recordType
   *          the record type
   * @return the id fields
   */
  public FieldEnum[] getIdFields(final RecordEnum recordType) {
    FieldEnum[] fields = null;
    if (recordType != null) {
      switch (recordType) {
      case FAR:
      case ATR:
      case MIR:
      case MRR:
      case WCR:
      case GDR_MIR_ADD:
      case BPS:
      case DTR:
        fields = recordType.getFields();
        break;

      case PCR:
        fields = new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM };
        break;

      case HBR:
        fields = new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM, FieldEnum.HBIN_NUM };
        break;

      case SBR:
        fields = new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM, FieldEnum.SBIN_NUM };
        break;

      case PMR:
        fields = new FieldEnum[]{FieldEnum.PMR_INDX_PMR, FieldEnum.CHAN_NAM };
        break;

      case PGR:
        fields = new FieldEnum[]{FieldEnum.GRP_INDX_PGR, FieldEnum.GRP_NAM };
        break;

      case SDR:
      case WIR:
      case WRR:
      case GDR_SDR_HC:
        fields = new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_GRP };
        break;

      case PIR:
        fields = new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM };
        break;

      case PRR:
        fields =
            new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM, FieldEnum.X_COORD,
                FieldEnum.Y_COORD };
        break;

      case PTR:
      case MPR:
      case FTR:
        fields = new FieldEnum[]{FieldEnum.TEST_NUM, FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM };
        break;

      case TSR:
        fields = new FieldEnum[]{FieldEnum.HEAD_NUM, FieldEnum.SITE_NUM, FieldEnum.TEST_NUM };
        break;

      default:
        fields = new FieldEnum[0];
        break;
      }
    }
    return fields;
  }

  /**
   * Gets the index list.
   * 
   * @return the index list
   */
  public List<Integer> getIndexList() {
    return indexList;
  }

  /**
   * Adds the key with combine record index and record type.
   * 
   * @param record
   *          the record
   * @return the key
   */
  public String getKey(final Record record) {
    final String key = record.getIndex() + "_" + record.getType().getText();
    return key;
  }

  /**
   * Gets the report fields.
   * 
   * @return the report fields
   */
  public FieldEnum[] getReportFields() {
    return reportFields;
  }

  /**
   * Sets the file path.
   * 
   * @param filePath
   *          the new file path
   */
  public void setFilePath(final String filePath) {
    this.filePath = filePath;
  }

  /**
   * Sets the first fail value.
   * 
   * @param firstFailValue
   *          the new first fail value
   */
  public void setFirstFailValue(final Object firstFailValue) {
    this.firstFailValue = firstFailValue;
  }

  /**
   * Sets the report fields.
   * 
   * @param reportFields
   *          the new report fields
   */
  public void setReportFields(final FieldEnum[] reportFields) {
    this.reportFields = reportFields;
  }

}
