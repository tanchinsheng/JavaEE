/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 3, 2012 3:44:35 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.data;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.st.common.config.FolderInfo;
import com.st.sc.rulemanager.rule.validation.RuleValidationHelper;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.scc.common.utils.ArrayUtil;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class FailedValueData.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class FailedValueData {

  /** The Constant INDEX_KEY_HARDBIN. */
  public static final int INDEX_KEY_HARDBIN = 151;

  /** The Constant INDEX_KEY_SOFTBIN. */
  public static final int INDEX_KEY_SOFTBIN = 152;

  /** The Constant INDEX_KEY_SDR. */
  public static final int INDEX_KEY_SDR = 153;

  /** The Constant SPECIAL_DATA_FILE_NAME. */
  public static final String SPECIAL_DATA_FILE_NAME = "special_data";

  /** The Constant HEADER_FILE_NAME. */
  public static final String HEADER_FILE_NAME = "headers";

  /** The Constant NUM_OF_DATA_FOR_FLUSH. */
  private static final int NUM_OF_DATA_FOR_FLUSH = 1000;

  /** The record map. */
  private Map<RecordEnum, Map<Integer, Object[]>> recordMap;

  /** The special map. */
  private Map<Integer, List<Object[]>> specialMap;

  /** The header map. */
  private Map<Integer, String[]> headerMap;

  /** The report field map. */
  private Map<RecordEnum, FieldEnum[]> reportFieldMap;

  /** The written report field map. */
  private Map<RecordEnum, FieldEnum[]> writtenReportFieldMap;

  /** The written index list. */
  private Set<Integer> writtenIndexList;

  /** The limit failed num. */
  private Integer limitFailedNum;

  /** The failed value path. */
  private String failedValuePath;

  /** The upload folder. */
  private FolderInfo uploadFolder;

  /** The failed file paths. */
  private Set<String> failedFilePaths;

  /**
   * Instantiates a new failed value data.
   */
  public FailedValueData() {
    recordMap = new HashMap<RecordEnum, Map<Integer, Object[]>>();
    headerMap = new TreeMap<Integer, String[]>();
    specialMap = new TreeMap<Integer, List<Object[]>>();
    reportFieldMap = new HashMap<RecordEnum, FieldEnum[]>();
    writtenReportFieldMap = new HashMap<RecordEnum, FieldEnum[]>();
    writtenIndexList = new HashSet<Integer>();
    failedFilePaths = new HashSet<String>();
  }

  /**
   * Adds the failed record.
   * 
   * @param record
   *          the record
   * @param helper
   *          the helper
   */
  public void addFailedRecord(final Record record, final RuleValidationHelper helper) {
    final List<Integer> indexList = helper.getIndexList();
    if (limitFailedNum == null || indexList.size() < limitFailedNum.intValue()) {
      final RecordEnum recordType = record.getType();
      final FieldEnum[] reportFields = reportFieldMap.get(recordType);
      Map<Integer, Object[]> map = recordMap.get(recordType);
      if (map == null) {
        map = new TreeMap<Integer, Object[]>();
        recordMap.put(recordType, map);
      }
      final Integer index = Integer.valueOf(record.getIndex());
      if (map.get(index) == null && !writtenIndexList.contains(index)) {
        final Object[] array = DetailResultUtil.ripData(record, reportFields);
        map.put(index, array);
      }
      indexList.add(index);
    }
  }

  /**
   * Adds the failed values.
   * 
   * @param recordType
   *          the record type
   * @param fields
   *          the fields
   * @param failedValues
   *          the failed values
   * @param index
   *          the index
   * @param helper
   *          the helper
   */
  public void addFailedValues(final RecordEnum recordType, final FieldEnum[] fields,
      final Object[] failedValues, final Integer index, final RuleValidationHelper helper) {
    final List<Integer> indexList = helper.getIndexList();
    if (limitFailedNum == null || indexList.size() < limitFailedNum.intValue()) {
      final FieldEnum[] reportFields = reportFieldMap.get(recordType);
      Map<Integer, Object[]> map = recordMap.get(recordType);
      if (map == null) {
        map = new TreeMap<Integer, Object[]>();
        recordMap.put(recordType, map);
      }
      if (!writtenIndexList.contains(index)) {
        Object[] array = map.get(index);
        final int length = reportFields.length;
        if (array == null) {
          array = new Object[length];
          map.put(index, array);
        }
        for (int i = 0; i < failedValues.length; i++) {
          final int j = ArrayUtil.search(reportFields, fields[i]);
          if (j >= 0 && j < length) {
            array[j] = failedValues[i];
          }
        }
      }
      indexList.add(index);
    }
  }

  /**
   * Adds the file path for upload.
   * 
   * @param file
   *          the file
   */
  private void addFilePathForUpload(final File file) {
    final String filePath = file.getAbsolutePath();
    if (uploadFolder != null && !failedFilePaths.contains(filePath)) {
      failedFilePaths.add(filePath);
    }
  }

  /**
   * Clear all data.
   */
  public void clear() {
    if (recordMap != null) {
      for (final Entry<RecordEnum, Map<Integer, Object[]>> entry : recordMap.entrySet()) {
        final Map<Integer, Object[]> value = entry.getValue();
        if (value != null) {
          value.clear();
        }
      }
      recordMap.clear();
      recordMap = null;
    }
    if (specialMap != null) {
      for (final Entry<Integer, List<Object[]>> entry : specialMap.entrySet()) {
        final List<Object[]> value = entry.getValue();
        if (value != null) {
          value.clear();
        }
      }
      specialMap.clear();
      specialMap = null;
    }

    if (reportFieldMap != null) {
      reportFieldMap.clear();
      reportFieldMap = null;
    }

    if (writtenReportFieldMap != null) {
      writtenReportFieldMap.clear();
      writtenReportFieldMap = null;
    }

    if (headerMap != null) {
      headerMap.clear();
      headerMap = null;
    }

    if (writtenIndexList != null) {
      writtenIndexList.clear();
      writtenIndexList = null;
    }
  }

  /**
   * Flush failed values.
   * 
   * @param helpers
   *          the helpers
   */
  public void flushFailedValues(final List<RuleValidationHelper> helpers) {
    for (final Entry<RecordEnum, Map<Integer, Object[]>> entry : recordMap.entrySet()) {
      flushFailedValues(entry.getKey(), true);
    }

    for (final Entry<RecordEnum, FieldEnum[]> entry : writtenReportFieldMap.entrySet()) {
      final RecordEnum recordType = entry.getKey();
      final FieldEnum[] fields = entry.getValue();
      final String[] strings = new String[fields.length];
      for (int i = 0; i < strings.length; i++) {
        strings[i] = fields[i].getText();
      }
      headerMap.put(recordType.getId(), strings);
    }

    if (headerMap.size() > 0) {
      final File headerFile = new File(failedValuePath + HEADER_FILE_NAME);
      DetailResultUtil.flushHeaders(headerFile, headerMap);
      addFilePathForUpload(headerFile);
    }
    if (specialMap.size() > 0) {
      final File specialFile = new File(failedValuePath + SPECIAL_DATA_FILE_NAME);
      DetailResultUtil.flushSpecialData(specialFile, specialMap);
      addFilePathForUpload(specialFile);
    }

    for (final RuleValidationHelper helper : helpers) {
      final List<Integer> indexList = helper.getIndexList();
      if (indexList.size() > 0) {
        final File indexFile = new File(helper.getFilePath());
        DetailResultUtil.flushRuleIndexData(indexFile, indexList);
        addFilePathForUpload(indexFile);
      }
    }
  }

  /**
   * Flush failed values.
   * 
   * @param recordType
   *          the record type
   * @param force
   *          the force
   */
  public void flushFailedValues(final RecordEnum recordType, final boolean force) {
    final Map<Integer, Object[]> map = recordMap.get(recordType);
    if (map != null) {
      if (map.size() >= NUM_OF_DATA_FOR_FLUSH || force && map.size() > 0) {
        final File file = new File(getFailedValuePath() + recordType.getText().toLowerCase());
        List<Integer> list = null;
        if (!force) {
          list = new ArrayList<Integer>();
        }
        final boolean retVal = DetailResultUtil.flushRecordData(file, map, list);
        if (retVal) {
          if (writtenReportFieldMap.get(recordType) == null) {
            writtenReportFieldMap.put(recordType, reportFieldMap.get(recordType));
          }
          map.clear();
          if (list != null) {
            writtenIndexList.addAll(list);
          }
          addFilePathForUpload(file);
        }
      }
    }
  }

  /**
   * Gets the failed file paths.
   * 
   * @return the failed file paths
   */
  public Set<String> getFailedFilePaths() {
    return failedFilePaths;
  }

  /**
   * Gets the failed value path.
   * 
   * @return the failed value path
   */
  public String getFailedValuePath() {
    return failedValuePath;
  }

  /**
   * Gets the header map.
   * 
   * @return the header map
   */
  public Map<Integer, String[]> getHeaderMap() {
    return headerMap;
  }

  /**
   * Gets the limit failed num.
   * 
   * @return the limit failed num
   */
  public Integer getLimitFailedNum() {
    return limitFailedNum;
  }

  /**
   * Gets the record map.
   * 
   * @return the record map
   */
  public Map<RecordEnum, Map<Integer, Object[]>> getRecordMap() {
    return recordMap;
  }

  /**
   * Gets the report field map.
   * 
   * @return the report field map
   */
  public Map<RecordEnum, FieldEnum[]> getReportFieldMap() {
    return reportFieldMap;
  }

  /**
   * Gets the special map.
   * 
   * @return the special map
   */
  public Map<Integer, List<Object[]>> getSpecialMap() {
    return specialMap;
  }

  /**
   * Gets the upload folder.
   * 
   * @return the upload folder
   */
  public FolderInfo getUploadFolder() {
    return uploadFolder;
  }

  /**
   * Sets the failed value path.
   * 
   * @param failedValuePath
   *          the new failed value path
   */
  public void setFailedValuePath(final String failedValuePath) {
    this.failedValuePath = failedValuePath;
  }

  /**
   * Sets the limit failed num.
   * 
   * @param limitFailedNum
   *          the new limit failed num
   */
  public void setLimitFailedNum(final Integer limitFailedNum) {
    this.limitFailedNum = limitFailedNum;
  }

  /**
   * Sets the upload folder.
   * 
   * @param uploadFolder
   *          the new upload folder
   */
  public void setUploadFolder(final FolderInfo uploadFolder) {
    this.uploadFolder = uploadFolder;
  }
}
