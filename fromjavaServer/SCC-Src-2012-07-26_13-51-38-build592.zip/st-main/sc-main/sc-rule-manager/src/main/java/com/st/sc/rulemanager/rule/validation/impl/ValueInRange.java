/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 17, 2011 3:55:17 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class ValueInRange.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ValueInRange extends AbsFieldValueRule {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ValueInRange.class);

  /** The from value. */
  private final Number fromValue;

  /** The to value. */
  private final Number toValue;

  /**
   * The Constructor.
   * 
   * @param field
   *          the field
   * @param fromValue
   *          the from value
   * @param toValue
   *          the to value
   * @param recordType
   *          the record type
   */
  public ValueInRange(final FieldEnum field, final Number fromValue, final Number toValue,
      final RecordEnum recordType) {
    super(field, recordType);
    this.fromValue = fromValue;
    this.toValue = toValue;
  }

  /**
   * Check in range.
   * 
   * @param value
   *          the number to check
   * @param fromValue
   *          the from value
   * @param toValue
   *          the to value
   * @return true, if successful
   */
  private boolean checkInRange(final Number value, final Number fromValue, final Number toValue) {
    boolean pass = false;
    final double v = value.doubleValue();
    if (fromValue != null && toValue != null) {
      if (v >= fromValue.doubleValue() && v <= toValue.doubleValue()) {
        pass = true;
      }
    } else if (fromValue != null) {
      if (v >= fromValue.doubleValue()) {
        pass = true;
      }
    } else if (toValue != null) {
      if (v <= toValue.doubleValue()) {
        pass = true;
      }
    }
    return pass;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  @SuppressWarnings("unchecked")
  public void validate(final Record record) {
    final Object obj = record.getFieldValue(getField());
    boolean pass = false;
    if (obj instanceof Number) {
      pass = checkInRange((Number) obj, fromValue, toValue);
    } else if (obj instanceof List< ? >) {
      try {
        final List<Object> objects = (List<Object>) obj;
        pass = true;
        for (final Object e : objects) {
          if (!checkInRange((Number) e, fromValue, toValue)) {
            pass = false;
            break;
          }
        }
      } catch (final ClassCastException e) {
        pass = false;
      } catch (final Exception e) {
        LOG.error(e.getMessage());
        pass = false;
      }
    }
    if (pass) {
      increaseNumOfPassedRecords();
    } else {
      if (getHelper().getIndexList().size() == 0) {
        getHelper().setFirstFailValue(obj);
      }
      getContextData().getFailedData().addFailedRecord(record, getHelper());
    }
  }
}
