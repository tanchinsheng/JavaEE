/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 6, 2011 10:53:36 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl.order;

import java.util.LinkedHashSet;
import java.util.Set;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class AbsRequireOpenRecordRule.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public abstract class AbsRequireOpenRecordRule extends RuleValidation {

  /** The open keys. */
  private final Set<Integer> openKeys = new LinkedHashSet<Integer>();

  /** The open record type. */
  private RecordEnum openRecordType;

  /** The close record type. */
  private RecordEnum closeRecordType;

  /**
   * Instantiates a new abs require open record rule.
   */
  public AbsRequireOpenRecordRule() {
    super();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    final RecordEnum recordType = record.getType();
    if (recordType == getOpenRecordType()) {
      openKeys.add(getKeyOpen(record));
    } else if (recordType == getCloseRecordType()) {
      openKeys.remove(getKeyOpen(record));
    }
    return recordType == getRecordType();
  }

  /**
   * Gets the close record type.
   * 
   * @return the close record type
   */
  public RecordEnum getCloseRecordType() {
    return closeRecordType;
  }

  /**
   * Gets the key open.
   * 
   * @param record
   *          the record
   * @return the key open
   */
  protected abstract Integer getKeyOpen(Record record);

  /**
   * Gets the open record type.
   * 
   * @return the open record type
   */
  public RecordEnum getOpenRecordType() {
    return openRecordType;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    final int count = getContextData().getCount(getRecordType());
    if (count == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
      return;
    }
  }

  /**
   * Sets the close record type.
   * 
   * @param closeRecordType
   *          the new close record type
   */
  public void setCloseRecordType(final RecordEnum closeRecordType) {
    this.closeRecordType = closeRecordType;
  }

  /**
   * Sets the open record type.
   * 
   * @param openRecordType
   *          the new open record type
   */
  public void setOpenRecordType(final RecordEnum openRecordType) {
    this.openRecordType = openRecordType;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    if (openKeys.contains(getKeyOpen(record))) {
      increaseNumOfPassedRecords();
    }
    increaseNumOfRecords();
  }

}
