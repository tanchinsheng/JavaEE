/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf.gdr;

import com.st.sc.rulemanager.rule.validation.expression.stdf.RecordType;


/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class STGDR implements RecordType {

  private Object FLD_CNT;
  private Object GEN_DATA;
  
  private AUTOMATION AUTOMATION;
  private DLOG_FILTER DLOG_FILTER;
  private MERGER MERGER;
  private MIR_ADD MIR_ADD;
  private REF_DIE_XY REF_DIE_XY;
  private REF_DIE REF_DIE;
  private SDR_HC SDR_HC;
  private STDF_FILL STDF_FILL;
  
  public STGDR() {
    
  }
  
  public Object getFLD_CNT() {
    return this.FLD_CNT;
  }
  public Object getGEN_DATA() {
    return this.GEN_DATA;
  }
  public String getType() {
    return "GDR";
  }
  public SDR_HC getSDR_HC() {
    return SDR_HC;
  }
  public void setSDR_HC(SDR_HC SDR_HC) {
    this.SDR_HC = SDR_HC;
  }
  public void setFLD_CNT(Object FLD_CNT) {
    this.FLD_CNT = FLD_CNT;
  }
  public void setGEN_DATA(Object GEN_DATA) {
    this.GEN_DATA = GEN_DATA;
  }

  public AUTOMATION getAUTOMATION() {
    return AUTOMATION;
  }

  public void setAUTOMATION(AUTOMATION AUTOMATION) {
    this.AUTOMATION = AUTOMATION;
  }

  public DLOG_FILTER getDLOG_FILTER() {
    return DLOG_FILTER;
  }

  public void setDLOG_FILTER(DLOG_FILTER DLOG_FILTER) {
    this.DLOG_FILTER = DLOG_FILTER;
  }

  public MERGER getMERGER() {
    return MERGER;
  }

  public void setMERGER(MERGER MERGER) {
    this.MERGER = MERGER;
  }

  public MIR_ADD getMIR_ADD() {
    return MIR_ADD;
  }

  public void setMIR_ADD(MIR_ADD MIR_ADD) {
    this.MIR_ADD = MIR_ADD;
  }

  public REF_DIE_XY getREF_DIE_XY() {
    return REF_DIE_XY;
  }

  public void setREF_DIE_XY(REF_DIE_XY REF_DIE_XY) {
    this.REF_DIE_XY = REF_DIE_XY;
  }

  public REF_DIE getREF_DIE() {
    return REF_DIE;
  }

  public void setREF_DIE(REF_DIE REF_DIE) {
    this.REF_DIE = REF_DIE;
  }

  public STDF_FILL getSTDF_FILL() {
    return STDF_FILL;
  }

  public void setSTDF_FILL(STDF_FILL STDF_FILL) {
    this.STDF_FILL = STDF_FILL;
  }
  
  
}
