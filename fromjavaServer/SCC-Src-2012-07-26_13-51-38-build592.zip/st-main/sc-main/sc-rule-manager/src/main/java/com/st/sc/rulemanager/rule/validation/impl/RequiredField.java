/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 17, 2011 1:40:24 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;

/**
 * The Class RequiredField.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RequiredField extends RuleValidation {

  /** The field. */
  private final FieldEnum field;

  /**
   * The Constructor.
   * 
   * @param field
   *          the field
   */
  public RequiredField(final FieldEnum field) {
    super();
    this.field = field;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  public boolean canValidate(final Record record) {
    return getRecordType() == record.getType();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.RuleValidation#postValidate()
   */
  @Override
  public void postValidate() {
    if (getNumOfRecords() == 0) {
      setFailedMessage(getRecordType().getText() + " is missing");
    } else if (getNumOfRecords() > getNumOfPassedRecords()) {
      setFailedMessage(getRecordType().getText() + "." + field.getText() + " is missing");
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  public void validate(final Record record) {
    final Object value = record.getFieldValue(field);
    if (value != null) {
      increaseNumOfPassedRecords();
    }
    increaseNumOfRecords();
  }

}
