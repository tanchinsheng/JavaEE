/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 10, 2012 4:52:20 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.util;

import java.util.Arrays;
import java.util.List;

import com.st.sc.entity.MirCriteria;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleOwners;
import com.st.sc.entity.RuleSet;
import com.st.sc.entity.RuleSetOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleValue;
import com.st.sc.entity.RuleVersion;
import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.entity.enums.RuleValueKeyEnum;
import com.st.sc.rulemanager.serialization.KryoHelper;
import com.st.sc.rulemanager.serialization.rule.TMirCriteria;
import com.st.sc.rulemanager.serialization.rule.TRule;
import com.st.sc.rulemanager.serialization.rule.TRuleSet;
import com.st.sc.rulemanager.serialization.rule.TRuleSetVersion;
import com.st.sc.rulemanager.serialization.rule.TRuleValue;
import com.st.sc.rulemanager.serialization.rule.TRuleVersion;

/**
 * The Class RuleHelper.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public final class RuleHelper {

  /**
   * Convert to entity.
   * 
   * @param mirCriteria
   *          the MIR criteria
   * @return the MIR criteria
   */
  private static MirCriteria convertToEntity(final TMirCriteria mirCriteria) {
    MirCriteria entity = null;
    if (mirCriteria != null) {
      entity = new MirCriteria();
      entity.setCmodCod(mirCriteria.getCmodCod());
      entity.setDsgnRev(mirCriteria.getDsgnRev());
      entity.setExecTyp(mirCriteria.getExecTyp());
      entity.setExecVer(mirCriteria.getExecVer());
      entity.setFlowId(mirCriteria.getFlowId());
      entity.setJobNam(mirCriteria.getJobNam());
      entity.setJobRev(mirCriteria.getJobRev());
      entity.setModeCod(mirCriteria.getModeCod());
      entity.setOperFrq(mirCriteria.getOperFrq());
      entity.setPartTyp(mirCriteria.getPartTyp());
      entity.setProcId(mirCriteria.getProcId());
      entity.setSpecNam(mirCriteria.getSpecNam());
      entity.setSpecVer(mirCriteria.getSpecVer());
      entity.setSuprNam(mirCriteria.getSuprNam());
      entity.setTstrTyp(mirCriteria.getTstrTyp());
    }
    return entity;
  }

  /**
   * Convert to entity.
   * 
   * @param rule
   *          the rule
   * @return the rule
   */
  public static Rule convertToEntity(final TRule rule) {
    Rule entity = null;
    if (rule != null) {
      entity = new Rule();
      entity.setCreatedBy(rule.getCreatedBy());
      entity.setName(rule.getName());
      entity.setOrigin(rule.getOrigin());
      entity.setRecordType(rule.getRecordType());
      final String[] owners = rule.getOwners();
      if (owners != null) {
        for (final String owner : owners) {
          entity.getUserRules().add(new RuleOwners(owner, null));
        }
      }
      final TRuleVersion[] ruleVersions = rule.getRuleVersions();
      if (ruleVersions != null) {
        for (final TRuleVersion tVersion : ruleVersions) {
          final RuleVersion version = new RuleVersion();
          version.setDescription(tVersion.getDescription());
          version.setLogId(tVersion.getLogId());
          version.setPoint(tVersion.getPoint());
          version.setRuleType(RuleTypeEnum.fromValue(tVersion.getRuleType()));
          version.setVersion(tVersion.getVersion());
          final TRuleValue[] ruleValues = tVersion.getRuleValues();
          if (ruleValues != null) {
            for (final TRuleValue tValue : ruleValues) {
              final RuleValue value =
                  new RuleValue(RuleValueKeyEnum.fromValue(tValue.getParamKey()),
                      tValue.getParamValue());
              version.getRuleValueList().add(value);
            }
          }
          version.setRule(entity);
          entity.getRuleVersions().add(version);
        }
      }
    }
    return entity;
  }

  /**
   * Convert to entity.
   * 
   * @param ruleSet
   *          the rule set
   * @return the rule set
   */
  public static RuleSet convertToEntity(final TRuleSet ruleSet) {
    RuleSet entity = null;
    if (ruleSet != null) {
      entity = new RuleSet();
      entity.setCreatedBy(ruleSet.getCreatedBy());
      entity.setName(ruleSet.getName());
      entity.setOrigin(ruleSet.getOrigin());
      final String[] owners = ruleSet.getOwners();
      if (owners != null) {
        for (final String owner : owners) {
          entity.getUserRuleSets().add(new RuleSetOwners(owner, null));
        }
      }
      final TRuleSetVersion[] ruleSetVersions = ruleSet.getRuleSetVersions();
      if (ruleSetVersions != null) {
        for (final TRuleSetVersion tRuleSetVersion : ruleSetVersions) {
          final RuleSetVersion ruleSetVersion = new RuleSetVersion();
          ruleSetVersion.setAlarmThreshold(tRuleSetVersion.getAlarmThreshold());
          ruleSetVersion.setDescription(tRuleSetVersion.getDescription());
          ruleSetVersion.setMirCriteria(convertToEntity(tRuleSetVersion.getMirCriteria()));
          ruleSetVersion.setStatus(tRuleSetVersion.getStatus());
          ruleSetVersion.setVersion(tRuleSetVersion.getVersion());
          final TRule[] tRules = tRuleSetVersion.getRules();
          if (tRules != null) {
            for (final TRule tRule : tRules) {
              final Rule rule = convertToEntity(tRule);
              ruleSetVersion.getRuleVersions().addAll(rule.getRuleVersions());
            }
          }
          entity.getRuleSetVersions().add(ruleSetVersion);
        }
      }
    }
    return entity;
  }

  /**
   * Convert to object.
   * 
   * @param mirCriteria
   *          the MIR criteria
   * @return the type MIR criteria
   */
  private static TMirCriteria convertToObject(final MirCriteria mirCriteria) {
    TMirCriteria object = null;
    if (mirCriteria != null) {
      object = new TMirCriteria();
      object.setCmodCod(mirCriteria.getCmodCod());
      object.setDsgnRev(mirCriteria.getDsgnRev());
      object.setExecTyp(mirCriteria.getExecTyp());
      object.setExecVer(mirCriteria.getExecVer());
      object.setFlowId(mirCriteria.getFlowId());
      object.setJobNam(mirCriteria.getJobNam());
      object.setJobRev(mirCriteria.getJobRev());
      object.setModeCod(mirCriteria.getModeCod());
      object.setOperFrq(mirCriteria.getOperFrq());
      object.setPartTyp(mirCriteria.getPartTyp());
      object.setProcId(mirCriteria.getProcId());
      object.setSpecNam(mirCriteria.getSpecNam());
      object.setSpecVer(mirCriteria.getSpecVer());
      object.setSuprNam(mirCriteria.getSuprNam());
      object.setTstrTyp(mirCriteria.getTstrTyp());
    }
    return object;
  }

  /**
   * Convert to object.
   * 
   * @param rule
   *          the rule
   * @return the t rule
   */
  public static TRule convertToObject(final Rule rule) {
    return convertToObject(rule, null);
  }

  /**
   * Convert to object.
   * 
   * @param rule
   *          the rule
   * @return the t rule
   */
  private static TRule convertToObject(final Rule rule, final RuleVersion ruleVersion) {
    TRule obj = null;
    if (rule != null) {
      obj = new TRule();
      obj.setCreatedBy(rule.getCreatedBy());
      obj.setName(rule.getName());
      obj.setOrigin(rule.getOrigin());
      obj.setRecordType(rule.getRecordType());
      final List<RuleOwners> userRules = rule.getUserRules();
      final String[] owners = new String[userRules.size()];
      int i = 0;
      for (final RuleOwners ruleOwner : userRules) {
        owners[i++] = ruleOwner.getId().getUserName();
      }
      obj.setOwners(owners);
      List<RuleVersion> ruleVersions = null;
      if (ruleVersion != null) {
        ruleVersions = Arrays.asList(ruleVersion);
      } else {
        ruleVersions = rule.getRuleVersions();
      }
      final TRuleVersion[] tVersions = new TRuleVersion[ruleVersions.size()];
      i = 0;
      for (final RuleVersion rv : ruleVersions) {
        final TRuleVersion tVersion = new TRuleVersion();
        tVersion.setDescription(rv.getDescription());
        tVersion.setLogId(rv.getLogId());
        tVersion.setPoint(rv.getPoint());
        tVersion.setRuleType(rv.getRuleType().getValue());
        tVersion.setVersion(rv.getVersion().intValue());
        final List<RuleValue> ruleValueList = rv.getRuleValueList();
        final TRuleValue[] tRuleValues = new TRuleValue[ruleValueList.size()];
        int j = 0;
        for (final RuleValue ruleValue : ruleValueList) {
          final TRuleValue tRuleValue = new TRuleValue();
          tRuleValue.setParamKey(ruleValue.getId().getRuleValueKey().getValue());
          tRuleValue.setParamValue(ruleValue.getParamValue());
          tRuleValues[j++] = tRuleValue;
        }
        tVersion.setRuleValues(tRuleValues);
        tVersions[i++] = tVersion;
      }
      obj.setRuleVersions(tVersions);
    }
    return obj;
  }

  /**
   * Convert to object.
   * 
   * @param ruleSet
   *          the rule set
   * @return the t rule set
   */
  public static TRuleSet convertToObject(final RuleSet ruleSet) {
    TRuleSet obj = null;
    if (ruleSet != null) {
      obj = new TRuleSet();
      obj.setCreatedBy(ruleSet.getCreatedBy());
      obj.setName(ruleSet.getName());
      obj.setOrigin(ruleSet.getOrigin());
      final List<RuleSetOwners> ruleSetOwners = ruleSet.getUserRuleSets();
      final String[] owners = new String[ruleSetOwners.size()];
      int i = 0;
      for (final RuleSetOwners ruleSetOwner : ruleSetOwners) {
        owners[i++] = ruleSetOwner.getId().getUserName();
      }
      obj.setOwners(owners);
      final List<RuleSetVersion> ruleSetVersions = ruleSet.getRuleSetVersions();
      final TRuleSetVersion[] tRuleSetVersions = new TRuleSetVersion[ruleSetVersions.size()];
      i = 0;
      for (final RuleSetVersion ruleSetVersion : ruleSetVersions) {
        final TRuleSetVersion tRuleSetVersion = new TRuleSetVersion();
        tRuleSetVersion.setAlarmThreshold(ruleSetVersion.getAlarmThreshold());
        tRuleSetVersion.setDescription(ruleSetVersion.getDescription());
        tRuleSetVersion.setStatus(ruleSetVersion.getStatus());
        tRuleSetVersion.setVersion(ruleSetVersion.getVersion());
        tRuleSetVersion.setMirCriteria(convertToObject(ruleSetVersion.getMirCriteria()));
        final List<RuleVersion> ruleVersions = ruleSetVersion.getRuleVersions();
        final TRule[] tRules = new TRule[ruleVersions.size()];
        int j = 0;
        for (final RuleVersion ruleVersion : ruleVersions) {
          final TRule tRule = convertToObject(ruleVersion.getRule(), ruleVersion);
          tRules[j++] = tRule;
        }
        tRuleSetVersion.setRules(tRules);
        tRuleSetVersions[i++] = tRuleSetVersion;
      }
      obj.setRuleSetVersions(tRuleSetVersions);
    }
    return obj;
  }

  /**
   * Convert array of rules to bytes.
   * 
   * @param array
   *          the array
   * @return the byte[]
   */
  public static byte[] toBytes(final TRule[] array) {
    return KryoHelper.toByteArray(array);
  }

  /**
   * Convert array of rule sets to bytes.
   * 
   * @param array
   *          the array
   * @return the byte[]
   */
  public static byte[] toBytes(final TRuleSet[] array) {
    return KryoHelper.toByteArray(array);
  }

  /**
   * Convert byte array to rule array.
   * 
   * @param bytes
   *          the bytes
   * @return the t rule[]
   */
  public static TRule[] toRuleArray(final byte[] bytes) {
    return (TRule[]) KryoHelper.toObject(bytes);
  }

  /**
   * Convert byte array to rule set array.
   * 
   * @param bytes
   *          the bytes
   * @return the t rule set[]
   */
  public static TRuleSet[] toRuleSetArray(final byte[] bytes) {
    return (TRuleSet[]) KryoHelper.toObject(bytes);
  }
}
