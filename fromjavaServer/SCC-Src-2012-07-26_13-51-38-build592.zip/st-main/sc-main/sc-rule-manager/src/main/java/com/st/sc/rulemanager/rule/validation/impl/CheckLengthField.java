/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 17, 2011 6:16:07 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.sc.rulemanager.rule.validation.enums.OperatorEnum;
import com.st.sc.rulemanager.util.OperatorComparision;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class CheckLengthField.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class CheckLengthField extends AbsFieldValueRule {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(CheckLengthField.class);

  /** The operator. */
  private final OperatorEnum operator;

  /** The length. */
  private final int length;

  /**
   * The Constructor.
   * 
   * @param field
   *          the field
   * @param operator
   *          the operator
   * @param length
   *          the length
   * @param recordType
   *          the record type
   */
  public CheckLengthField(final FieldEnum field, final OperatorEnum operator,
      final int length, final RecordEnum recordType) {
    super(field, recordType);
    this.operator = operator;
    this.length = length;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#canValidate(com.st.stdfparser.stdf.Record)
   */
  @Override
  public boolean canValidate(final Record record) {
    return getRecordType() == record.getType();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  @SuppressWarnings("unchecked")
  public void validate(final Record record) {
    final Object obj = record.getFieldValue(getField());
    boolean passed = false;
    if (obj instanceof String) {
      final String str = (String) obj;
      if (OperatorComparision.check(operator, str.length(), length)) {
        passed = true;
      }
    } else if (obj instanceof List< ? >) {
      try {
        final List<String> strings = (List<String>) obj;
        passed = true;
        for (final String str : strings) {
          if (!OperatorComparision.check(operator, str.length(), length)) {
            passed = false;
            break;
          }
        }
      } catch (final ClassCastException e) {
        passed = false;
      } catch (final Exception e) {
        LOG.error(e.getMessage());
        passed = false;
      }
    }
    if (passed) {
      increaseNumOfPassedRecords();
    } else {
      if (getHelper().getIndexList().size() == 0) {
        getHelper().setFirstFailValue(obj);
      }
      getContextData().getFailedData().addFailedRecord(record, getHelper());
    }
  }
}
