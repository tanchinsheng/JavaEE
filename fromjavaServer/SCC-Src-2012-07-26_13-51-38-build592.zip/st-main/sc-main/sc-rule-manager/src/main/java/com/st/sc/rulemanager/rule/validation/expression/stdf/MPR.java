/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 21, 2011 5:25:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.expression.stdf;

import java.util.Map;

/**
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class MPR  implements RecordType {

  /**
   * 
   * @param map
   *          the map
   */
  public MPR(final Map<String, Object> map) {
    initialize(map);
  }
  private Object TEST_NUM;
  private Object HEAD_NUM;
  private Object SITE_NUM;
  private Object TEST_FLG;
  private Object PARM_FLG;
  private Object RTN_ICNT;
  private Object RSLT_CNT;
  private Object RTN_STAT;
  private Object RTN_RSLT;
  private Object TEST_TXT;
  private Object ALARM_ID;
  private Object OPT_FLAG;
  private Object RES_SCAL;
  private Object LLM_SCAL;
  private Object HLM_SCAL;
  private Object LO_LIMIT;
  private Object HI_LIMIT;
  private Object START_IN;
  private Object INCR_IN;
  private Object RTN_INDX;
  private Object UNITS;
  private Object UNITS_IN;
  private Object C_RESFMT;
  private Object C_LLMFMT;
  private Object C_HLMFMT;
  private Object LO_SPEC;
  private Object HI_SPEC;
  private void initialize(Map<String, Object> map) {
    this.TEST_NUM = map.get("TEST_NUM");
    this.HEAD_NUM = map.get("HEAD_NUM");
    this.SITE_NUM = map.get("SITE_NUM");
    this.TEST_FLG = map.get("TEST_FLG");
    this.PARM_FLG = map.get("PARM_FLG");
    this.RTN_ICNT = map.get("RTN_ICNT");
    this.RSLT_CNT = map.get("RSLT_CNT");
    this.RTN_STAT = map.get("RTN_STAT");
    this.RTN_RSLT = map.get("RTN_RSLT");
    this.TEST_TXT = map.get("TEST_TXT");
    this.ALARM_ID = map.get("ALARM_ID");
    this.OPT_FLAG = map.get("OPT_FLAG");
    this.RES_SCAL = map.get("RES_SCAL");
    this.LLM_SCAL = map.get("LLM_SCAL");
    this.HLM_SCAL = map.get("HLM_SCAL");
    this.LO_LIMIT = map.get("LO_LIMIT");
    this.HI_LIMIT = map.get("HI_LIMIT");
    this.START_IN = map.get("START_IN");
    this.INCR_IN = map.get("INCR_IN");
    this.RTN_INDX = map.get("RTN_INDX");
    this.UNITS = map.get("UNITS");
    this.UNITS_IN = map.get("UNITS_IN");
    this.C_RESFMT = map.get("C_RESFMT");
    this.C_LLMFMT = map.get("C_LLMFMT");
    this.C_HLMFMT = map.get("C_HLMFMT");
    this.LO_SPEC = map.get("LO_SPEC");
    this.HI_SPEC = map.get("HI_SPEC");
  }
  public Object getTEST_NUM() {
    return this.TEST_NUM;
  }
  public Object getHEAD_NUM() {
    return this.HEAD_NUM;
  }
  public Object getSITE_NUM() {
    return this.SITE_NUM;
  }
  public Object getTEST_FLG() {
    return this.TEST_FLG;
  }
  public Object getPARM_FLG() {
    return this.PARM_FLG;
  }
  public Object getRTN_ICNT() {
    return this.RTN_ICNT;
  }
  public Object getRSLT_CNT() {
    return this.RSLT_CNT;
  }
  public Object getRTN_STAT() {
    return this.RTN_STAT;
  }
  public Object getRTN_RSLT() {
    return this.RTN_RSLT;
  }
  public Object getTEST_TXT() {
    return this.TEST_TXT;
  }
  public Object getALARM_ID() {
    return this.ALARM_ID;
  }
  public Object getOPT_FLAG() {
    return this.OPT_FLAG;
  }
  public Object getRES_SCAL() {
    return this.RES_SCAL;
  }
  public Object getLLM_SCAL() {
    return this.LLM_SCAL;
  }
  public Object getHLM_SCAL() {
    return this.HLM_SCAL;
  }
  public Object getLO_LIMIT() {
    return this.LO_LIMIT;
  }
  public Object getHI_LIMIT() {
    return this.HI_LIMIT;
  }
  public Object getSTART_IN() {
    return this.START_IN;
  }
  public Object getINCR_IN() {
    return this.INCR_IN;
  }
  public Object getRTN_INDX() {
    return this.RTN_INDX;
  }
  public Object getUNITS() {
    return this.UNITS;
  }
  public Object getUNITS_IN() {
    return this.UNITS_IN;
  }
  public Object getC_RESFMT() {
    return this.C_RESFMT;
  }
  public Object getC_LLMFMT() {
    return this.C_LLMFMT;
  }
  public Object getC_HLMFMT() {
    return this.C_HLMFMT;
  }
  public Object getLO_SPEC() {
    return this.LO_SPEC;
  }
  public Object getHI_SPEC() {
    return this.HI_SPEC;
  }
  public String getType() {
    return "MPR";
  }
}
