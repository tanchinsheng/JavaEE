/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 17, 2011 1:56:58 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.rulemanager.rule.validation.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class ValueFieldInList.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ValueFieldInList extends AbsFieldValueRule {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ValueFieldInList.class);

  /** The list. */
  private final List<Object> list;

  /** The in. */
  private final boolean in;

  /**
   * Instantiates a new value field in list.
   * 
   * @param field
   *          the field
   * @param list
   *          the list
   * @param in
   *          the in
   * @param recordType
   *          the record type
   */
  public ValueFieldInList(final FieldEnum field, final List<Object> list, final boolean in,
      final RecordEnum recordType) {
    super(field, recordType);
    this.list = list;
    this.in = in;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.rulemanager.rule.validation.BaseRule#validate(com.st.stdfparser.stdf.Record)
   */
  @SuppressWarnings("unchecked")
  public void validate(final Record record) {
    final Object value = record.getFieldValue(getField());
    boolean pass = false;
    if (value != null) {
      if (value instanceof List< ? >) {
        try {
          final List<Object> objects = (List<Object>) value;
          if (in) {
            pass = true;
            for (final Object e : objects) {
              if (!list.contains(e)) {
                pass = false;
                break;
              }
            }
          } else {
            pass = true;
            for (final Object e : objects) {
              if (list.contains(e)) {
                pass = false;
                break;
              }
            }
          }
        } catch (final Exception e) {
          LOG.error(e.getMessage());
          pass = false;
        }
      } else {
        pass = list.contains(value);
        if (!in) {
          pass = !pass;
        }
      }
    }
    if (pass) {
      increaseNumOfPassedRecords();
    } else {
      if (getHelper().getIndexList().size() == 0) {
        getHelper().setFirstFailValue(value);
      }
      getContextData().getFailedData().addFailedRecord(record, getHelper());
    }
  }
}
