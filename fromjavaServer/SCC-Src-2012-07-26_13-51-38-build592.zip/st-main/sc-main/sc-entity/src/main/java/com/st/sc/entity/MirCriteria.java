/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 * The persistent class for the MIR_CRITERIA database table.
 */
@Entity
@Table(name = "MIR_CRITERIA")
public class MirCriteria implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "RULE_SET_VERSION_ID")
  private Long ruleSetVersionId;

  @Column(name = "CMOD_COD")
  private String cmodCod;

  @Column(name = "DSGN_REV")
  private String dsgnRev;

  @Column(name = "EXEC_TYP")
  private String execTyp;

  @Column(name = "EXEC_VER")
  private String execVer;

  @Column(name = "FLOW_ID")
  private String flowId;

  @Column(name = "JOB_NAM")
  private String jobNam;

  @Column(name = "JOB_REV")
  private String jobRev;

  @Column(name = "MODE_COD")
  private String modeCod;

  @Column(name = "OPER_FRQ")
  private String operFrq;

  @Column(name = "PART_TYP")
  private String partTyp;

  @Column(name = "PROC_ID")
  private String procId;

  @Column(name = "SPEC_NAM")
  private String specNam;

  @Column(name = "SPEC_VER")
  private String specVer;

  @Column(name = "SUPR_NAM")
  private String suprNam;

  @Column(name = "TSTR_TYP")
  private String tstrTyp;

  @OneToOne
  @PrimaryKeyJoinColumn
  private RuleSetVersion ruleSetVersion = new RuleSetVersion();

  public MirCriteria() {
  }

  public Long getRuleSetVersionId() {
    return this.ruleSetVersionId;
  }

  public void setRuleSetVersionId(Long ruleSetVersionId) {
    this.ruleSetVersionId = ruleSetVersionId;
  }

  public String getCmodCod() {
    return this.cmodCod;
  }

  public void setCmodCod(String cmodCod) {
    this.cmodCod = cmodCod;
  }

  public String getDsgnRev() {
    return this.dsgnRev;
  }

  public void setDsgnRev(String dsgnRev) {
    this.dsgnRev = dsgnRev;
  }

  public String getExecTyp() {
    return this.execTyp;
  }

  public void setExecTyp(String execTyp) {
    this.execTyp = execTyp;
  }

  public String getExecVer() {
    return this.execVer;
  }

  public void setExecVer(String execVer) {
    this.execVer = execVer;
  }

  public String getFlowId() {
    return this.flowId;
  }

  public void setFlowId(String flowId) {
    this.flowId = flowId;
  }

  public String getJobNam() {
    return this.jobNam;
  }

  public void setJobNam(String jobNam) {
    this.jobNam = jobNam;
  }

  public String getJobRev() {
    return this.jobRev;
  }

  public void setJobRev(String jobRev) {
    this.jobRev = jobRev;
  }

  public String getModeCod() {
    return this.modeCod;
  }

  public void setModeCod(String modeCod) {
    this.modeCod = modeCod;
  }

  public String getOperFrq() {
    return this.operFrq;
  }

  public void setOperFrq(String operFrq) {
    this.operFrq = operFrq;
  }

  public String getPartTyp() {
    return this.partTyp;
  }

  public void setPartTyp(String partTyp) {
    this.partTyp = partTyp;
  }

  public String getProcId() {
    return this.procId;
  }

  public void setProcId(String procId) {
    this.procId = procId;
  }

  public String getSpecNam() {
    return this.specNam;
  }

  public void setSpecNam(String specNam) {
    this.specNam = specNam;
  }

  public String getSpecVer() {
    return this.specVer;
  }

  public void setSpecVer(String specVer) {
    this.specVer = specVer;
  }

  public String getSuprNam() {
    return this.suprNam;
  }

  public void setSuprNam(String suprNam) {
    this.suprNam = suprNam;
  }

  public String getTstrTyp() {
    return this.tstrTyp;
  }

  public void setTstrTyp(String tstrTyp) {
    this.tstrTyp = tstrTyp;
  }

  /**
   * @return the ruleSetVersion
   */
  public RuleSetVersion getRuleSetVersion() {
    return ruleSetVersion;
  }

  /**
   * @param ruleSetVersion the ruleSetVersion to set
   */
  public void setRuleSetVersion(RuleSetVersion ruleSetVersion) {
    this.ruleSetVersion = ruleSetVersion;
  }

  
}
