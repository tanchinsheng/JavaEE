/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.st.sc.entity.util.Util;

/**
 * The persistent class for the RULE_SET_VERSION database table.
 */
@Entity
@Table(name = "RULE_SET_VERSION")
@NamedQueries({
    @NamedQuery(name = RuleSetVersion.GET_RULESET_VERSIONS_OF_RULESET, query = "SELECT rsv FROM RuleSetVersion rsv " +
    		"WHERE rsv.ruleSetId=:ruleSetId ORDER BY rsv.version"),
    @NamedQuery(name = RuleSetVersion.GET_ACTIVE_RULESET, query = "FROM RuleSetVersion v WHERE v.status = true"),
    @NamedQuery(name = RuleSetVersion.GET_ACTIVE_VERSION, query = "FROM RuleSetVersion v WHERE v.ruleSetId = :ruleSetId and v.status = true"),
    @NamedQuery(name = RuleSetVersion.GET_MAX_VERSION, query = "Select max(rsv.version) from RuleSetVersion rsv "
        + " where rsv.ruleSetId=:ruleSetId"),
    @NamedQuery(name = RuleSetVersion.COUNT_ACTIVE_VERSION, query = "SELECT count(v.ruleSetVersionId) "
        + "FROM RuleSetVersion v WHERE v.ruleSetId = :ruleSetId and v.status = true"),
    @NamedQuery(name = RuleSetVersion.COUNT_NUMBER_VERSION, query = "SELECT count(v.ruleSetVersionId) "
        + "FROM RuleSetVersion v WHERE v.ruleSetId = :ruleSetId ") })
public class RuleSetVersion implements Serializable {
  private static final long serialVersionUID = 1L;

  public static final String GET_RULESET_VERSIONS_OF_RULESET =
      "RuleSetVersion.GetVersionOfRuleSet";
  public static final String GET_ACTIVE_RULESET = "RuleSetVersion.GetActiveRuleSet";
  public static final String GET_ACTIVE_VERSION = "RuleSetVersion.GetActiveVersion";
  public static final String GET_MAX_VERSION = "RuleSetVersion.GetMaxVersion";
  public static final String COUNT_ACTIVE_VERSION = "RuleSetVersion.CountActiveVersion";
  public static final String COUNT_NUMBER_VERSION = "RuleSetVersion.CountNumberVersion";
  @Id
  @Column(name = "RULE_SET_VERSION_ID", unique = true, nullable = false, precision = 16)
  private Long ruleSetVersionId;

  @Column(name = "RULE_SET_ID")
  private Long ruleSetId;

  @Column(name = "ALARM_THRESHOLD", precision = 5, scale = 2)
  private Double alarmThreshold;

  @Column(length = 1024)
  private String description;

  @Column(nullable = false, precision = 2)
  private boolean status;

  @Column(name = "STATUS_UPDATED_TIME")
  private Timestamp statusUpdatedTime;

  @Column(name = "UPDATED_BY", nullable = false, length = 255)
  private String updatedBy;

  @Column(name = "UPDATED_ON", nullable = false)
  private Timestamp updatedOn;

  @Column(nullable = false, precision = 6)
  private Integer version;

  // bi-directional one-to-one association to MirCriteria
  @OneToOne(mappedBy = "ruleSetVersion", cascade = CascadeType.ALL)
  private MirCriteria mirCriteria;

  // bi-directional many-to-many association to RuleVersion
  @ManyToMany(mappedBy = "ruleSetVersionList")
  private List<RuleVersion> ruleVersions;

  // bi-directional many-to-one association to RuleSet
  @ManyToOne
  @JoinColumn(name = "RULE_SET_ID", nullable = false, insertable = false, updatable = false)
  private RuleSet ruleSet;

  @Transient
  private int countMirCriteria;

  public RuleSetVersion() {
    ruleVersions = new ArrayList<RuleVersion>();
  }

  @PostLoad
  protected void populateTransientFields() {
    countMirCriteria = Util.countMirCriteria(mirCriteria);
  }

  /**
   * Prevent null pointer if ruleSet is null.
   * 
   * @return ruleSet
   */
  public RuleSet getRuleSet() {
    if (ruleSet == null) {
      ruleSet = new RuleSet();
    }
    return this.ruleSet;
  }

  /**
   * Prevent null pointer when mirCriteria null;
   * 
   * @return
   */
  public MirCriteria getMirCriteria() {
    return this.mirCriteria;
  }

  public void setRuleSet(RuleSet ruleSet) {
    this.ruleSet = ruleSet;
  }

  public Long getRuleSetVersionId() {
    return this.ruleSetVersionId;
  }

  public void setRuleSetVersionId(Long ruleSetVersionId) {
    this.ruleSetVersionId = ruleSetVersionId;
  }

  public Double getAlarmThreshold() {
    return this.alarmThreshold;
  }

  public void setAlarmThreshold(Double alarmThreshold) {
    this.alarmThreshold = alarmThreshold;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public boolean getStatus() {
    return this.status;
  }

  public void setStatus(boolean status) {
    this.status = status;
  }

  public Timestamp getStatusUpdatedTime() {
    return this.statusUpdatedTime;
  }

  public void setStatusUpdatedTime(Timestamp statusUpdatedTime) {
    this.statusUpdatedTime = statusUpdatedTime;
  }

  public String getUpdatedBy() {
    return this.updatedBy;
  }

  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  public Timestamp getUpdatedOn() {
    return this.updatedOn;
  }

  public void setUpdatedOn(Timestamp updatedOn) {
    this.updatedOn = updatedOn;
  }

  public Integer getVersion() {
    return this.version;
  }

  public void setVersion(Integer version) {
    this.version = version;
  }

  public void setMirCriteria(MirCriteria mirCriteria) {
    this.mirCriteria = mirCriteria;
  }

  public List<RuleVersion> getRuleVersions() {
    return this.ruleVersions;
  }

  protected void setRuleVersions(List<RuleVersion> ruleVersions) {
    this.ruleVersions = ruleVersions;
  }

  /**
   * @return the ruleSetId
   */
  public Long getRuleSetId() {
    return ruleSetId;
  }

  /**
   * @param ruleSetId
   *          the ruleSetId to set
   */
  public void setRuleSetId(Long ruleSetId) {
    this.ruleSetId = ruleSetId;
  }

  public int getCountMirCriteria() {
    return countMirCriteria;
  }

}
