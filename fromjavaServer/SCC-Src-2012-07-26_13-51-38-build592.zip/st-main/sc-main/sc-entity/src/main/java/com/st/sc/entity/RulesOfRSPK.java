/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the RULES_OF_RS database table.
 */
@Embeddable
public class RulesOfRSPK implements Serializable {
  // default serial version id, required for serializable classes.
  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The rule version id. */
  @Column(name = "RULE_VERSION_ID")
  private Long ruleVersionId;

  /** The rule set version id. */
  @Column(name = "RULE_SET_VERSION_ID")
  private Long ruleSetVersionId;

  /**
   * Instantiates a new rules of rule set primary key.
   */
  public RulesOfRSPK() {
  }

  /**
   * Instantiates a new rules of rule set primary key.
   * 
   * @param ruleVersionId
   *          the rule version id
   * @param ruleSetVersionId
   *          the rule set version id
   */
  public RulesOfRSPK(final Long ruleVersionId, final Long ruleSetVersionId) {
    this.ruleSetVersionId = ruleSetVersionId;
    this.ruleVersionId = ruleVersionId;
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final RulesOfRSPK other = (RulesOfRSPK) obj;
    if (ruleSetVersionId == null) {
      if (other.ruleSetVersionId != null) {
        return false;
      }
    } else if (!ruleSetVersionId.equals(other.ruleSetVersionId)) {
      return false;
    }
    if (ruleVersionId == null) {
      if (other.ruleVersionId != null) {
        return false;
      }
    } else if (!ruleVersionId.equals(other.ruleVersionId)) {
      return false;
    }
    return true;
  }

  /**
   * Gets the rule set version id.
   * 
   * @return the rule set version id
   */
  public Long getRuleSetVersionId() {
    return ruleSetVersionId;
  }

  /**
   * Gets the rule version id.
   * 
   * @return the rule version id
   */
  public Long getRuleVersionId() {
    return ruleVersionId;
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (ruleSetVersionId == null ? 0 : ruleSetVersionId.hashCode());
    result = prime * result + (ruleVersionId == null ? 0 : ruleVersionId.hashCode());
    return result;
  }

  /**
   * Sets the rule set version id.
   * 
   * @param ruleSetVersionId
   *          the new rule set version id
   */
  public void setRuleSetVersionId(final Long ruleSetVersionId) {
    this.ruleSetVersionId = ruleSetVersionId;
  }

  /**
   * Sets the rule version id.
   * 
   * @param ruleVersionId
   *          the new rule version id
   */
  public void setRuleVersionId(final Long ruleVersionId) {
    this.ruleVersionId = ruleVersionId;
  }

}
