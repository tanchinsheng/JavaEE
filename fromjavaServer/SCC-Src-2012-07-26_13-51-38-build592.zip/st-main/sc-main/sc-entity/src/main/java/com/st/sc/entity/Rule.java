/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the RULES database table.
 */
@Entity
@Table(name = "RULES")
@NamedQueries({
    @NamedQuery(name = Rule.GET_RULE_BYNAME, query = "SELECT r FROM Rule r WHERE upper(r.name) = :ruleName"),
    @NamedQuery(name = Rule.GET_ALL_RULES, query = "SELECT r FROM Rule r ORDER BY r.name") })
public class Rule implements Serializable {
  private static final long serialVersionUID = 1L;

  public static final String GET_ALL_RULES = "Rule.GetAllRules";
  public static final String GET_RULE_BYNAME = "Rule.GetRuleByName";

  @Id
  @Column(name = "RULE_ID")
  private Long ruleId;

  @Column(name = "CREATED_BY")
  private String createdBy;

  private String name;

  private String origin;

  @Column(name = "RECORD_TYPE")
  private String recordType;

  @Column(name = "UPDATED_ON")
  private Timestamp updatedOn;

  // bi-directional many-to-one association to UserRule
  @OneToMany(mappedBy = "rule", cascade=CascadeType.REMOVE ,fetch=FetchType.EAGER)
  private List<RuleOwners> userRules;

  @OneToMany(mappedBy = "rule", cascade=CascadeType.REMOVE)
  private List<RuleVersion> ruleVersions;

  public Rule() {
    userRules = new ArrayList<RuleOwners>();
    ruleVersions = new ArrayList<RuleVersion>();
  }

  public Long getRuleId() {
    return this.ruleId;
  }

  public void setRuleId(Long ruleId) {
    this.ruleId = ruleId;
  }

  public String getCreatedBy() {
    return this.createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getName() {
    if (this.name != null) {
      this.name = this.name.trim();
    }
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getOrigin() {
    return this.origin;
  }

  public void setOrigin(String origin) {
    this.origin = origin;
  }

  public String getRecordType() {
    return this.recordType;
  }

  public void setRecordType(String recordType) {
    this.recordType = recordType;
  }

  public Timestamp getUpdatedOn() {
    return this.updatedOn;
  }

  public void setUpdatedOn(Timestamp updatedOn) {
    this.updatedOn = updatedOn;
  }

  public List<RuleOwners> getUserRules() {
    return this.userRules;
  }

  public void setUserRules(List<RuleOwners> userRules) {
    this.userRules = userRules;
  }

  public List<RuleVersion> getRuleVersions() {
    return ruleVersions;
  }

  public void setRuleVersions(List<RuleVersion> ruleVersions) {
    this.ruleVersions = ruleVersions;
  }

}
