/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import com.st.sc.entity.enums.RuleValueKeyEnum;

/**
 * The persistent class for the RULE_TYPE database table.
 */
@Entity
@Table(name = "RULE_VALUE")
@NamedQueries({
    @NamedQuery(name = RuleValue.DELETE_PARAMTERS, query = "Delete from RuleValue rv where rv.id.ruleVersionId=:ruleVersionId") })
public class RuleValue implements Serializable {
  private static final long serialVersionUID = 1L;

  public static final String DELETE_PARAMTERS = "RuleValue.DeleteParameters";

  @EmbeddedId
  private RuleValuePK id;

  @Column(name = "PARA_VALUE")
  private String paramValue;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "RULE_VERSION_ID", insertable = false, updatable = false)
  private RuleVersion ruleVersion;

  public RuleValue() {
  }

  public RuleValue(RuleValueKeyEnum key, String value) {
    if (id == null) {
      id = new RuleValuePK();
    }
    id.setRuleValueKey(key);
    paramValue = value;
  }

  @PostLoad
  protected void populateTransientFields() {
    if (id != null) {
      id.setRuleValueKey(RuleValueKeyEnum.fromValue(id.getParamKey()));
    }
  }

  @PrePersist
  protected void populateDatabaseFields() {
    if (id != null && id.getRuleValueKey() != null) {
      id.setParamKey(id.getRuleValueKey().getText());
    }
  }
  
  public RuleValuePK getId() {
    return this.id;
  }

  public void setId(RuleValuePK id) {
    this.id = id;
  }

  /**
   * @return the paramValue
   */
  public String getParamValue() {
    return paramValue;
  }

  /**
   * @param paramValue
   *          the paramValue to set
   */
  public void setParamValue(String paramValue) {
    this.paramValue = paramValue;
  }

  /**
   * @return the ruleVersion
   */
  public RuleVersion getRuleVersion() {
    return ruleVersion;
  }

  /**
   * @param ruleVersion
   *          the ruleVersion to set
   */
  public void setRuleVersion(RuleVersion ruleVersion) {
    this.ruleVersion = ruleVersion;
  }

}
