package com.st.sc.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Version;

/**
 * The persistent class for the OFFLINE_REPORT database table.
 */
@Entity
@Table(name = "OFFLINE_REPORT")
@NamedQueries({
    @NamedQuery(name = OfflineReport.GET_BY_ID, query = "FROM OfflineReport o WHERE o.offlineReportId = :offlineReportId"),
    @NamedQuery(name = OfflineReport.UPDATE_REPORT_STATUS, 
        query = "UPDATE OfflineReport o SET o.status =:newstatus, o.errorMessage = :errorMessage WHERE o.status = :oldstatus AND o.serverId = :serverId"),
    @NamedQuery(name = OfflineReport.UPDATE_REPORT_STATUS_TIMEOUT, 
        query = "UPDATE OfflineReport o SET o.status = :newstatus, o.errorMessage = :errorMessage WHERE o.status = :oldstatus AND o.reportTime <= :timeout") })
public class OfflineReport implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -5409687180060557350L;

  public static final String GET_BY_ID = "OfflineReport.GET_BY_ID";
  public static final String UPDATE_REPORT_STATUS = "OfflineReport.UPDATE_REPORT_STATUS";
  public static final String UPDATE_REPORT_STATUS_TIMEOUT =
      "OfflineReport.UPDATE_REPORT_STATUS_TIMEOUT";

  public static final String STATUS_IN_PROGRESS = "In-progress";
  public static final String STATUS_FAIL = "Failed";
  public static final String STATUS_DONE = "Done";

  /** The offline report id. */
  @Id
  @Column(name = "OFFLINE_REPORT_ID")
  private Long offlineReportId;

  /** The checking time. */
  @Column(name = "CHECKING_TIME")
  private String checkingTime;

  /** The email list. */
  @Column(name = "EMAIL_LIST")
  private String emailList;

  /** The error message. */
  @Column(name = "ERROR_MESSAGE")
  private String errorMessage;

  /** The mir start t. */
  @Column(name = "MIR_START_T")
  private String mirStartT;

  /** The mrr finish t. */
  @Column(name = "MRR_FINISH_T")
  private String mrrFinishT;

  /** The owners. */
  private String owners;

  /** The report name. */
  @Column(name = "REPORT_NAME")
  private String reportName;

  /** The report time. */
  @Column(name = "REPORT_TIME")
  private Timestamp reportTime;

  /** The report type. */
  @Column(name = "REPORT_TYPE")
  private String reportType;

  /** The status. */
  private String status;

  /** The server_id. */
  @Column(name = "SERVER_ID")
  private String serverId;
  
  /** The report data. */
  @Lob()
  @Column(name = "REPORT_DATA")
  private byte[] reportData;
  
  /** The version. */
  @Version
  private int version;

  /**
   * The Constructor.
   */
  public OfflineReport() {
  }

  /**
   * Gets the offline report id.
   * 
   * @return the offline report id
   */
  public Long getOfflineReportId() {
    return this.offlineReportId;
  }

  /**
   * Sets the offline report id.
   * 
   * @param offlineReportId
   *          the offline report id
   */
  public void setOfflineReportId(Long offlineReportId) {
    this.offlineReportId = offlineReportId;
  }

  /**
   * Gets the email list.
   * 
   * @return the email list
   */
  public String getEmailList() {
    return this.emailList;
  }

  /**
   * Sets the email list.
   * 
   * @param emailList
   *          the email list
   */
  public void setEmailList(String emailList) {
    this.emailList = emailList;
  }

  /**
   * Gets the error message.
   * 
   * @return the error message
   */
  public String getErrorMessage() {
    return this.errorMessage;
  }

  /**
   * Sets the error message.
   * 
   * @param errorMessage
   *          the error message
   */
  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  /**
   * Gets the owners.
   * 
   * @return the owners
   */
  public String getOwners() {
    return this.owners;
  }

  /**
   * Sets the owners.
   * 
   * @param owners
   *          the owners
   */
  public void setOwners(String owners) {
    this.owners = owners;
  }

  /**
   * Gets the report name.
   * 
   * @return the report name
   */
  public String getReportName() {
    return this.reportName;
  }

  /**
   * Sets the report name.
   * 
   * @param reportName
   *          the report name
   */
  public void setReportName(String reportName) {
    this.reportName = reportName;
  }

  /**
   * Gets the report time.
   * 
   * @return the report time
   */
  public Timestamp getReportTime() {
    return this.reportTime;
  }

  /**
   * Sets the report time.
   * 
   * @param reportTime
   *          the report time
   */
  public void setReportTime(Timestamp reportTime) {
    this.reportTime = reportTime;
  }

  /**
   * Gets the report type.
   * 
   * @return the report type
   */
  public String getReportType() {
    return this.reportType;
  }

  /**
   * Sets the report type.
   * 
   * @param reportType
   *          the report type
   */
  public void setReportType(String reportType) {
    this.reportType = reportType;
  }

  /**
   * Gets the status.
   * 
   * @return the status
   */
  public String getStatus() {
    return this.status;
  }

  /**
   * Sets the status.
   * 
   * @param status
   *          the status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * @return the checkingTime
   */
  public String getCheckingTime() {
    return checkingTime;
  }

  /**
   * @param checkingTime
   *          the checkingTime to set
   */
  public void setCheckingTime(String checkingTime) {
    this.checkingTime = checkingTime;
  }

  /**
   * @return the mirStartT
   */
  public String getMirStartT() {
    return mirStartT;
  }

  /**
   * @param mirStartT
   *          the mirStartT to set
   */
  public void setMirStartT(String mirStartT) {
    this.mirStartT = mirStartT;
  }

  /**
   * @return the mrrFinishT
   */
  public String getMrrFinishT() {
    return mrrFinishT;
  }

  /**
   * @param mrrFinishT
   *          the mrrFinishT to set
   */
  public void setMrrFinishT(String mrrFinishT) {
    this.mrrFinishT = mrrFinishT;
  }

  /**
   * @return the serverId
   */
  public String getServerId() {
    return serverId;
  }

  /**
   * @param serverId
   *          the serverId to set
   */
  public void setServerId(String serverId) {
    this.serverId = serverId;
  }

  /**
   * Gets the report data.
   *
   * @return the report data
   */
  public byte[] getReportData() {
    return reportData;
  }

  /**
   * Sets the report data.
   *
   * @param reportData the new report data
   */
  public void setReportData(byte[] reportData) {
    this.reportData = reportData;
  }

  /**
   * Gets the version.
   *
   * @return the version
   */
  public int getVersion() {
    return version;
  }

  /**
   * Sets the version.
   *
   * @param version the new version
   */
  public void setVersion(int version) {
    this.version = version;
  }
}
