/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 3:40:02 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.entity.enums;

/**
 * The Enum RuleTypeEnum.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public enum RuleTypeEnum {

  /** The REQUIRED_RECORD. */
  REQUIRED_RECORD(1, "REQUIRED_RECORD"),

  /** The OCCURRENCE_RECORD. */
  OCCURRENCE_RECORD(2, "OCCURRENCE_RECORD"),

  /** The OCCURRENCE_TWO_RECORDS. */
  OCCURRENCE_TWO_RECORDS(3, "OCCURRENCE_2_RECORDS"),

  /** The NUMBER_OF_PCR. */
  NUMBER_OF_PCR(4, "NUMBER_OF_PCR"),

  /** The NUMBER_OF_BIN_RECORD_OP1. */
  NUMBER_OF_BIN_RECORD_OP1(5, "NUMBER_OF_BIN"),

  /** The NUMBER_OF_BIN_RECORD_OP2. */
  NUMBER_OF_BIN_RECORD_OP2(6, "NUMBER_OF_BIN_PER_BINNUM"),

  /** The NUMBER_OF_TEST_RECORD. */
  NUMBER_OF_TEST_RECORD(7, "NUMBER_OF_TEST_RECORD"),

  /** The MUST_IN_GROUP. */
  MUST_IN_GROUP(8, "MUST_IN_GROUP"),

  /** The ORDER_TERADYNE. */
  ORDER_TERADYNE(9, "ORDER_TERADYNE"),

  /** The REQUIRED_FIELD. */
  REQUIRED_FIELD(10, "REQUIRED_FIELD"),

  /** The NUMBER_OF_SDR. */
  NUMBER_OF_SDR(11, "NUMBER_OF_SDR"),

  /** The VALUE_FIELD_IN_LIST. */
  VALUE_FIELD_IN_LIST(12, "VALUE_FIELD_IN_LIST"),

  /** The VALUE_FIELD_NOT_IN_LIST. */
  VALUE_FIELD_NOT_IN_LIST(13, "VALUE_FIELD_NOT_IN_LIST"),

  /** The VALUE_IN_RANGE. */
  VALUE_IN_RANGE(14, "VALUE_IN_RANGE"),

  /** The CHECK_LENGTH_FIELD. */
  CHECK_LENGTH_FIELD(15, "CHECK_LENGTH_FIELD"),

  /** The VALIDATE_BIT7. */
  VALIDATE_BIT7(16, "VALIDATE_BIT7"),

  /** The CHECK_UNIQUENESS. */
  CHECK_UNIQUENESS(17, "CHECK_UNIQUENESS"),

  /** The CORRESPONDENT_BETWEEN_RECORDS. */
  CORRESPONDENT_BETWEEN_RECORDS(18, "CORRESPONDENT_2_RECORDS"),

  /** The EXPRESSION. */
  EXPRESSION(19, "EXPRESSION");

  /**
   * From integer value.
   * 
   * @param value
   *          the value
   * @return the rule type enum
   */
  public static RuleTypeEnum fromValue(final int value) {
    RuleTypeEnum retVal = null;
    for (final RuleTypeEnum ruleType : values()) {
      if (ruleType.getValue() == value) {
        retVal = ruleType;
        break;
      }
    }
    return retVal;
  }

  /**
   * From string value.
   * 
   * @param value
   *          the value
   * @return the rule type enum
   */
  public static RuleTypeEnum fromValue(final String value) {
    RuleTypeEnum retVal = null;
    for (final RuleTypeEnum ruleType : values()) {
      if (ruleType.getText().equals(value)) {
        retVal = ruleType;
        break;
      }
    }
    return retVal;
  }

  /** The value. */
  private int value;

  /** The text. */
  private String text;

  /**
   * Instantiates a new rule type enum.
   * 
   * @param value
   *          the value
   * @param text
   *          the text
   */
  RuleTypeEnum(final int value, final String text) {
    this.value = value;
    this.text = text;
  }

  /**
   * Gets the text.
   * 
   * @return the text
   */
  public String getText() {
    return text;
  }

  /**
   * Gets the value.
   * 
   * @return the value
   */
  public int getValue() {
    return value;
  }
}
