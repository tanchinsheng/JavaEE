/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 6, 2011 3:12:12 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.entity.enums;

/**
 * The Enum RuleValueKeyEnum.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public enum RuleValueKeyEnum {

  /** The OCCURRENCE_RECORD_OPERATOR. */
  OCCURRENCE_RECORD_OPERATOR(1, "OCCURRENCE_RECORD_OPERATOR"),

  /** The OCCURRENCE_RECORD_COUNT. */
  OCCURRENCE_RECORD_COUNT(2, "OCCURRENCE_RECORD_COUNT"),

  /** The OCCURRENCE_2_RECORD_OPERATOR. */
  OCCURRENCE_2_RECORD_OPERATOR(3, "OCCURRENCE_2_RECORD_OPERATOR"),

  /** The OCCURRENCE_2_RECORD_TYPE. */
  OCCURRENCE_2_RECORD_TYPE(4, "OCCURRENCE_2_RECORD_TYPE"),

  /** The EXIST_IN_GROUP. */
  EXIST_IN_GROUP(5, "EXIST_IN_GROUP"),

  /** The FIELD_NAME. */
  FIELD_NAME(6, "FIELD_NAME"),

  /** The FIELD_NAME_IN_LIST. */
  FIELD_NAME_IN_LIST(7, "FIELD_NAME_IN_LIST"),

  /** The FIELD_NAME_NOT_IN_LIST. */
  FIELD_NAME_NOT_IN_LIST(8, "FIELD_NAME_NOT_IN_LIST"),

  /** The FIELD_IN_RANGE_FROM. */
  FIELD_IN_RANGE_FROM(9, "FIELD_IN_RANGE_FROM"),

  /** The FIELD_IN_RANGE_TO. */
  FIELD_IN_RANGE_TO(10, "FIELD_IN_RANGE_TO"),

  /** The FIELD_LENGTH_OPERATOR. */
  FIELD_LENGTH_OPERATOR(11, "FIELD_LENGTH_OPERATOR"),

  /** The FIELD_LENGTH_VALUE. */
  FIELD_LENGTH_VALUE(12, "FIELD_LENGTH_VALUE"),

  /** The FIELD_UNIQUE. */
  FIELD_UNIQUE(13, "FIELD_UNIQUE"),

  /** The FIELD_MATCHING_SRC_RECORD. */
  FIELD_MATCHING_SRC_RECORD(14, "FIELD_MATCH_SRC_RECORD"),

  /** The FIELD_MATCHING_SRC_FIELD. */
  FIELD_MATCHING_SRC_FIELD(15, "FIELD_MATCH_SRC_FIELD"),

  /** The FIELD_MATCHING_TARGET_RECORD. */
  FIELD_MATCHING_TARGET_RECORD(16, "FIELD_MATCH_TARGET_RECORD"),

  /** The FIELD_MATCHING_TARGET_FIELD. */
  FIELD_MATCHING_TARGET_FIELD(17, "FIELD_MATCH_TARGET_FIELD"),

  /** The EXPRESSION. */
  EXPRESSION(18, "EXPRESSION");

  /**
   * From integer value.
   * 
   * @param value
   *          the value
   * @return the rule type enum
   */
  public static RuleValueKeyEnum fromValue(final int value) {
    RuleValueKeyEnum retVal = null;
    for (final RuleValueKeyEnum key : values()) {
      if (key.getValue() == value) {
        retVal = key;
        break;
      }
    }
    return retVal;
  }

  /**
   * From string value.
   * 
   * @param value
   *          the value
   * @return the rule type enum
   */
  public static RuleValueKeyEnum fromValue(final String value) {
    RuleValueKeyEnum retVal = null;
    for (final RuleValueKeyEnum key : values()) {
      if (key.getText().equals(value)) {
        retVal = key;
        break;
      }
    }
    return retVal;
  }

  /** The value. */
  private int value;

  /** The text. */
  private String text;

  /**
   * Instantiates a new rule value key enum.
   * 
   * @param value
   *          the value
   * @param text
   *          the text
   */
  RuleValueKeyEnum(final int value, final String text) {
    this.value = value;
    this.text = text;
  }

  /**
   * Gets the text.
   * 
   * @return the text
   */
  public String getText() {
    return text;
  }

  /**
   * Gets the value.
   * 
   * @return the value
   */
  public int getValue() {
    return value;
  }
}
