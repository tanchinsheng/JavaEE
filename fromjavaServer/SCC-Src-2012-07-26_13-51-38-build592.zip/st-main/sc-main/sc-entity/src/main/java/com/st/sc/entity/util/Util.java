/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 3:01:50 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.entity.util;

import com.st.sc.entity.MirCriteria;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class Util {

  /**
   * Count MIR criteria.
   * 
   * @param mc
   *          the MIR criteria
   * @return the count of MIR criteria
   */
  public static int countMirCriteria(final MirCriteria mc) {
    int count = 0;
    if (mc != null) {
      count = isNullOrEmpty(mc.getCmodCod()) ? count : count + 1;
      count = isNullOrEmpty(mc.getDsgnRev()) ? count : count + 1;
      count = isNullOrEmpty(mc.getExecTyp()) ? count : count + 1;
      count = isNullOrEmpty(mc.getExecVer()) ? count : count + 1;
      count = isNullOrEmpty(mc.getFlowId()) ? count : count + 1;
      count = isNullOrEmpty(mc.getJobNam()) ? count : count + 1;
      count = isNullOrEmpty(mc.getJobRev()) ? count : count + 1;
      count = isNullOrEmpty(mc.getModeCod()) ? count : count + 1;
      count = isNullOrEmpty(mc.getOperFrq()) ? count : count + 1;
      count = isNullOrEmpty(mc.getPartTyp()) ? count : count + 1;
      count = isNullOrEmpty(mc.getProcId()) ? count : count + 1;
      count = isNullOrEmpty(mc.getSpecNam()) ? count : count + 1;
      count = isNullOrEmpty(mc.getSpecVer()) ? count : count + 1;
      count = isNullOrEmpty(mc.getSuprNam()) ? count : count + 1;
      count = isNullOrEmpty(mc.getTstrTyp()) ? count : count + 1;
    }
    return count;
  }

  /**
   * Checks if is empty.
   * 
   * @param str
   *          the string
   * @return true, if is empty
   */
  public static boolean isEmpty(final String str) {
    return str != null && str.length() == 0;
  }

  /**
   * Checks if is null or empty.
   * 
   * @param str
   *          the string
   * @return true, if checks if is null or empty
   */
  public static boolean isNullOrEmpty(final String str) {
    return str == null || str.length() == 0;
  }

  /**
   * Instantiates a new utility class.
   */
  private Util() {

  }
}
