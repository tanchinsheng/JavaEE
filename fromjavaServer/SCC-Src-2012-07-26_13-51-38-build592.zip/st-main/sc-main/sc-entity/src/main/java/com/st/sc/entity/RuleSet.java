/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the RULE_SET database table.
 */
@Entity
@Table(name = "RULE_SET")
@NamedQueries({
    @NamedQuery(name = RuleSet.GET_RULESET_BYNAME, query = "FROM RuleSet r where upper(r.name) = :name"),
    @NamedQuery(name = RuleSet.GET_ALL_RULESET, query = "FROM RuleSet r ORDER BY r.name") })
public class RuleSet implements Serializable {
  private static final long serialVersionUID = 1L;

  public static final String GET_ALL_RULESET = "RuleSet.GetAllRuleSet";
  public static final String GET_RULESET_BYNAME = "RuleSet.GetRuleSetByName";

  @Id
  @Column(name = "RULE_SET_ID")
  private Long ruleSetId;

  @Column(name = "CREATED_BY")
  private String createdBy;

  private String name;

  private String origin;

  @Column(name = "UPDATED_ON")
  private Timestamp updatedOn;

  // bi-directional many-to-one association to UserRuleSet
  @OneToMany(mappedBy = "ruleSet" ,cascade=CascadeType.REMOVE ,fetch=FetchType.EAGER)
  private List<RuleSetOwners> userRuleSets;

  // bi-directional many-to-one association to UserRuleSet
  @OneToMany(mappedBy = "ruleSet" ,cascade=CascadeType.REMOVE)
  private List<RuleSetVersion> ruleSetVersions;

  public RuleSet() {
    ruleSetVersions = new ArrayList<RuleSetVersion>();
    userRuleSets = new ArrayList<RuleSetOwners>();
  }

  public Long getRuleSetId() {
    return this.ruleSetId;
  }

  public void setRuleSetId(Long ruleSetId) {
    this.ruleSetId = ruleSetId;
  }

  public String getCreatedBy() {
    return this.createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public String getName() {
    if (this.name != null) {
      this.name = this.name.trim();
    }
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getOrigin() {
    return this.origin;
  }

  public void setOrigin(String origin) {
    this.origin = origin;
  }

  public Timestamp getUpdatedOn() {
    return this.updatedOn;
  }

  public void setUpdatedOn(Timestamp updatedOn) {
    this.updatedOn = updatedOn;
  }

  public List<RuleSetOwners> getUserRuleSets() {
    return this.userRuleSets;
  }

  public void setUserRuleSets(List<RuleSetOwners> userRuleSets) {
    this.userRuleSets = userRuleSets;
  }

  /**
   * @return the ruleSetVersions
   */
  public List<RuleSetVersion> getRuleSetVersions() {
    return ruleSetVersions;
  }

  /**
   * @param ruleSetVersions
   *          the ruleSetVersions to set
   */
  public void setRuleSetVersions(List<RuleSetVersion> ruleSetVersions) {
    this.ruleSetVersions = ruleSetVersions;
  }
  
}
