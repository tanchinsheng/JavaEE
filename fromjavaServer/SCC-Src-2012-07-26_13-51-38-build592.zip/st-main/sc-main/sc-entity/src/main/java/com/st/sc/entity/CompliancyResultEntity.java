/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the COMPLIANCY_RESULT database table.
 */
@Entity
@Table(name = "COMPLIANCY_RESULT")
public class CompliancyResultEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 3377454591033095269L;

  @Id
  @Column(name = "FILE_ID")
  private Long fileId;

  @Column(name = "CHECKING_TIME")
  private Timestamp checkingTime;

  @Column(name = "COMPLIANCY_SCORE")
  private Double compliancyScore;

  @Column(name = "FILE_NAME")
  private String fileName;

  @Column(name = "MIR_CMOD_COD")
  private String mirCmodCod;

  @Column(name = "MIR_DSGN_REV")
  private String mirDsgnRev;

  @Column(name = "MIR_EXEC_TYP")
  private String mirExecTyp;

  @Column(name = "MIR_EXEC_VER")
  private String mirExecVer;

  @Column(name = "MIR_FLOW_ID")
  private String mirFlowId;

  @Column(name = "MIR_JOB_NAM")
  private String mirJobNam;

  @Column(name = "MIR_JOB_REV")
  private String mirJobRev;

  @Column(name = "MIR_MODE_COD")
  private String mirModeCod;

  @Column(name = "MIR_OPER_FRQ")
  private String mirOperFrq;

  @Column(name = "MIR_PART_TYP")
  private String mirPartTyp;

  @Column(name = "MIR_PROC_ID")
  private String mirProcId;

  @Column(name = "MIR_SPEC_NAM")
  private String mirSpecNam;

  @Column(name = "MIR_SPEC_VER")
  private String mirSpecVer;

  @Column(name = "MIR_START_T")
  private Timestamp mirStartT;

  @Column(name = "MIR_SUPR_NAM")
  private String mirSuprNam;

  @Column(name = "MIR_TSTR_TYP")
  private String mirTstrTyp;

  @Column(name = "MRR_FINISH_T")
  private Timestamp mrrFinishT;

  @Column(name = "RULE_SET_NAME")
  private String ruleSetName;

  @Column(name = "RULE_SET_VER")
  private Integer ruleSetVer;

  public CompliancyResultEntity() {
  }

  public Long getFileId() {
    return this.fileId;
  }

  public void setFileId(Long fileId) {
    this.fileId = fileId;
  }

  public Timestamp getCheckingTime() {
    return this.checkingTime;
  }

  public void setCheckingTime(Timestamp checkingTime) {
    this.checkingTime = checkingTime;
  }

  public Double getCompliancyScore() {
    return this.compliancyScore;
  }

  public void setCompliancyScore(Double compliancyScore) {
    this.compliancyScore = compliancyScore;
  }

  public String getFileName() {
    return this.fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getMirCmodCod() {
    return this.mirCmodCod;
  }

  public void setMirCmodCod(String mirCmodCod) {
    this.mirCmodCod = mirCmodCod;
  }

  public String getMirDsgnRev() {
    return this.mirDsgnRev;
  }

  public void setMirDsgnRev(String mirDsgnRev) {
    this.mirDsgnRev = mirDsgnRev;
  }

  public String getMirExecTyp() {
    return this.mirExecTyp;
  }

  public void setMirExecTyp(String mirExecTyp) {
    this.mirExecTyp = mirExecTyp;
  }

  public String getMirExecVer() {
    return this.mirExecVer;
  }

  public void setMirExecVer(String mirExecVer) {
    this.mirExecVer = mirExecVer;
  }

  public String getMirFlowId() {
    return this.mirFlowId;
  }

  public void setMirFlowId(String mirFlowId) {
    this.mirFlowId = mirFlowId;
  }

  public String getMirJobNam() {
    return this.mirJobNam;
  }

  public void setMirJobNam(String mirJobNam) {
    this.mirJobNam = mirJobNam;
  }

  public String getMirJobRev() {
    return this.mirJobRev;
  }

  public void setMirJobRev(String mirJobRev) {
    this.mirJobRev = mirJobRev;
  }

  public String getMirModeCod() {
    return this.mirModeCod;
  }

  public void setMirModeCod(String mirModeCod) {
    this.mirModeCod = mirModeCod;
  }

  public String getMirOperFrq() {
    return this.mirOperFrq;
  }

  public void setMirOperFrq(String mirOperFrq) {
    this.mirOperFrq = mirOperFrq;
  }

  public String getMirPartTyp() {
    return this.mirPartTyp;
  }

  public void setMirPartTyp(String mirPartTyp) {
    this.mirPartTyp = mirPartTyp;
  }

  public String getMirProcId() {
    return this.mirProcId;
  }

  public void setMirProcId(String mirProcId) {
    this.mirProcId = mirProcId;
  }

  public String getMirSpecNam() {
    return this.mirSpecNam;
  }

  public void setMirSpecNam(String mirSpecNam) {
    this.mirSpecNam = mirSpecNam;
  }

  public String getMirSpecVer() {
    return this.mirSpecVer;
  }

  public void setMirSpecVer(String mirSpecVer) {
    this.mirSpecVer = mirSpecVer;
  }

  public Timestamp getMirStartT() {
    return this.mirStartT;
  }

  public void setMirStartT(Timestamp mirStartT) {
    this.mirStartT = mirStartT;
  }

  public String getMirSuprNam() {
    return this.mirSuprNam;
  }

  public void setMirSuprNam(String mirSuprNam) {
    this.mirSuprNam = mirSuprNam;
  }

  public String getMirTstrTyp() {
    return this.mirTstrTyp;
  }

  public void setMirTstrTyp(String mirTstrTyp) {
    this.mirTstrTyp = mirTstrTyp;
  }

  public Timestamp getMrrFinishT() {
    return this.mrrFinishT;
  }

  public void setMrrFinishT(Timestamp mrrFinishT) {
    this.mrrFinishT = mrrFinishT;
  }

  public String getRuleSetName() {
    return this.ruleSetName;
  }

  public void setRuleSetName(String ruleSetName) {
    this.ruleSetName = ruleSetName;
  }

  public Integer getRuleSetVer() {
    return this.ruleSetVer;
  }

  public void setRuleSetVer(Integer ruleSetVer) {
    this.ruleSetVer = ruleSetVer;
  }

}
