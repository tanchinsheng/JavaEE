/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the USER_RULE database table.
 */
@Entity
@Table(name = "RULE_OWNERS")
@NamedQueries({@NamedQuery(name = RuleOwners.DELETE_USERS, query = "DELETE FROM RuleOwners ur " +
		"WHERE ur.id.ruleId=:ruleId") })
public class RuleOwners implements Serializable {
  private static final long serialVersionUID = 1L;

  public static final String DELETE_USERS = "RuleOwners.DeleteByRuleId";

  @EmbeddedId
  private RuleOwnerPK id;

  // bi-directional many-to-one association to Rule
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "RULE_ID", insertable = false, updatable = false)
  private Rule rule;

  public RuleOwners() {
  }

  /**
   * Constructor
   * 
   * @param userId
   *          userId
   * @param ruleId
   *          ruleId
   */
  public RuleOwners(String userName, Long ruleId) {
    id = new RuleOwnerPK(userName, ruleId);
  }

  public RuleOwnerPK getId() {
    return this.id;
  }

  public void setId(RuleOwnerPK id) {
    this.id = id;
  }

  public Rule getRule() {
    return this.rule;
  }

  protected void setRule(Rule rule) {
    this.rule = rule;
  }

}
