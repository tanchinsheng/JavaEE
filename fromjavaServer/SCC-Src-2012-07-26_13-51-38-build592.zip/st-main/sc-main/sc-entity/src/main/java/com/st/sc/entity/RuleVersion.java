/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.st.sc.entity.enums.RuleTypeEnum;

/**
 * The persistent class for the RULE_VERSION database table.
 */
@Entity
@Table(name = "RULE_VERSION")
@NamedQueries({
    @NamedQuery(name = RuleVersion.COUNT_RULE_VERSION, query = "Select count(rv.ruleVersionId) from RuleVersion rv "
        + "where rv.ruleId= :ruleId"),
    @NamedQuery(name = RuleVersion.GET_MAX_VERSION, query = "Select max(rv.version) from RuleVersion rv "
        + " where rv.ruleId=:ruleId"),
    @NamedQuery(name = RuleVersion.GET_VERSIONS_OF_RULE, query = "SELECT rv FROM RuleVersion rv "
        + " where rv.ruleId=:ruleId") })
public class RuleVersion implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 7909002007701824979L;

  public static final String COUNT_RULE_VERSION = "RuleVersion.CountRuleVersions";
  public static final String GET_MAX_VERSION = "RuleVersion.GetMaxVersion";
  public static final String GET_VERSIONS_OF_RULE = "RuleVersion.GetAllVersion";

  @Id
  @Column(name = "RULE_VERSION_ID")
  private Long ruleVersionId;

  @Column(name = "UPDATED_BY")
  private String updatedBy;

  private String description;

  @Column(name = "LOG_ID")
  private Integer logId;

  private Integer point;

  @Column(name = "RULE_ID")
  private Long ruleId;

  @Column(name = "UPDATED_ON")
  private Timestamp updatedOn;

  private Integer version;

  @ManyToOne
  @JoinColumn(name = "RULE_ID", insertable = false, updatable = false)
  private Rule rule;

  @ManyToMany(fetch = FetchType.LAZY)
  @JoinTable(name = "RULES_OF_RS", joinColumns = {@JoinColumn(name = "RULE_VERSION_ID") }, inverseJoinColumns = {@JoinColumn(name = "RULE_SET_VERSION_ID") })
  private List<RuleSetVersion> ruleSetVersionList;

  /**
   * When remove a rule version, list of rule parameters will be removed.
   */
  @OneToMany(mappedBy = "ruleVersion", cascade = CascadeType.REMOVE)
  private List<RuleValue> ruleValueList;

  @Column(name = "RULE_CONDITION", nullable = false)
  private String ruleCondition;

  @Transient
  private RuleTypeEnum ruleType;

  public RuleVersion() {
    ruleValueList = new ArrayList<RuleValue>();
  }

  @PostLoad
  protected void populateTransientFields() {
    ruleType = RuleTypeEnum.fromValue(getRuleCondition());
  }

  @PrePersist
  protected void populateDatabaseFields() {
    if (ruleType != null) {
      ruleCondition = ruleType.getText();
    }
  }

  /**
   * @return the ruleVersionId
   */
  public Long getRuleVersionId() {
    return ruleVersionId;
  }

  /**
   * @param ruleVersionId
   *          the ruleVersionId to set
   */
  public void setRuleVersionId(Long ruleVersionId) {
    this.ruleVersionId = ruleVersionId;
  }

  /**
   * @return the updatedBy
   */
  public String getUpdatedBy() {
    return updatedBy;
  }

  /**
   * @param updatedBy
   *          the updatedBy to set
   */
  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description
   *          the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the logId
   */
  public Integer getLogId() {
    return logId;
  }

  /**
   * @param logId
   *          the logId to set
   */
  public void setLogId(Integer logId) {
    this.logId = logId;
  }

  /**
   * @return the point
   */
  public Integer getPoint() {
    return point;
  }

  /**
   * @param point
   *          the point to set
   */
  public void setPoint(Integer point) {
    this.point = point;
  }

  /**
   * @return the ruleId
   */
  public Long getRuleId() {
    return ruleId;
  }

  /**
   * @param ruleId
   *          the ruleId to set
   */
  public void setRuleId(Long ruleId) {
    this.ruleId = ruleId;
  }

  /**
   * @return the updatedOn
   */
  public Timestamp getUpdatedOn() {
    return updatedOn;
  }

  /**
   * @param updatedOn
   *          the updatedOn to set
   */
  public void setUpdatedOn(Timestamp updatedOn) {
    this.updatedOn = updatedOn;
  }

  /**
   * @return the version
   */
  public Integer getVersion() {
    return version;
  }

  /**
   * @param version
   *          the version to set
   */
  public void setVersion(Integer version) {
    this.version = version;
  }

  /**
   * @return the rule
   */
  public Rule getRule() {
    return rule;
  }

  /**
   * @param rule
   *          the rule to set
   */
  public void setRule(Rule rule) {
    this.rule = rule;
  }

  /**
   * @return the ruleSetVersionList
   */
  public List<RuleSetVersion> getRuleSetVersionList() {
    return ruleSetVersionList;
  }

  /**
   * @param ruleSetVersionList
   *          the ruleSetVersionList to set
   */
  public void setRuleSetVersionList(List<RuleSetVersion> ruleSetVersionList) {
    this.ruleSetVersionList = ruleSetVersionList;
  }

  /**
   * @return the ruleValueList
   */
  public List<RuleValue> getRuleValueList() {
    return ruleValueList;
  }
  
  protected void setRuleValueList(List<RuleValue> ruleValueList) {
    this.ruleValueList = ruleValueList;
  }

  public RuleTypeEnum getRuleType() {
    return ruleType;
  }

  public void setRuleType(RuleTypeEnum ruleType) {
    this.ruleType = ruleType;
    if (ruleType != null) {
      setRuleCondition(ruleType.getText());
    }
  }

  protected String getRuleCondition() {
    return ruleCondition;
  }

  protected void setRuleCondition(String ruleCondition) {
    this.ruleCondition = ruleCondition;
  }

}
