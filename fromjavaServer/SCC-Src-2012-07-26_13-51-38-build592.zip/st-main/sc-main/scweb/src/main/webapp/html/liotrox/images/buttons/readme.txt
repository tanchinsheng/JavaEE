To create an icon button create a GIF image of width=20, height=21 pixels (256 colors)
