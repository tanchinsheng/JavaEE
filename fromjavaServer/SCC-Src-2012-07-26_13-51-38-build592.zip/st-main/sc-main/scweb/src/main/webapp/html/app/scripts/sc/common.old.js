
function trim(s)
{
	var l=0; var r=s.length -1;
	while(l < s.length && s[l] == ' ')
	{	l++; }
	while(r > l && s[r] == ' ')
	{	r-=1;	}
	return s.substring(l, r+1);
}
function numberOnly(e , alowNegative){
	var key;
	var keychar;
	var objEvent = window.event ? window.event : e;
	key = objEvent.keyCode ? objEvent.keyCode : objEvent.charCode;
	
	keychar = String.fromCharCode(key);
	// control keys
	if ((key==null) || (key==0) || (key==8) || 
		(key==9) || (key==13) || (key==27) || 
		 (key==37) || (key==39) || (key==46) ) //left,right,delete
	   return true;				   
	// numbers
	else if ((("0123456789").indexOf(keychar) > -1))
	   return true;
	
	// decimal point jump
	else if ( (keychar == '.') || (keychar == ','))
	   return true;
	if(alowNegative == true){
		if(keychar == '-'){
			return true;
		}
	}
	if(objEvent.preventDefault) {
		objEvent.preventDefault();
	} else {
		objEvent.returnValue = false;
	}
	return false;				
}

function nowildcards(e){
	var key;
	var isShift = false;
	var objEvent = window.event ? window.event : e;
	key = objEvent.keyCode ? objEvent.keyCode : objEvent.charCode;
	isShift = objEvent.shiftKey;
	
	// control keys
	if ((key==null) || (key==0) || (key==8) || 
		(key==9) || (key==13) || (key==27) || 
		 (key==37 && !isShift) ||
		 (key==39 && !isShift) || 
		 (key==46 && !isShift) ||
		 (key==34 && isShift) ||
		 (key==44 && !isShift) ||
			(key == 45) ||
		 (key == 95 && isShift) ||
		 (key == 61 )) //left,right,delete,"", ","
		 //note: 45 : "-"; 95 & shift : "_" ; 44 & !shift: "," ; 34 & shift : '"' 
		// 39 :"'" and left ;  61: "="
	   return true;				   
	// numbers
	else if ( (key>= 65 && key <=90) || 
			(key>= 97 && key <=122) || 
			(key>= 48 && key <=59) || key == 32) 
		// note : 58: ":" ; 59: ";" , get from ASCII.
	   return true;
	
	if(objEvent.preventDefault) {
		objEvent.preventDefault();
	} else {
		objEvent.returnValue = false;
	}
	return false;				
}
function doSCEvent(e){
	doLiotroEvent(e.encode());
}
function checkNameContainWildcards(name){
	if(name.length > 0){
		if(name.charAt(0) == ' ' || name.charAt(name.length-1) == ' '){
			return false;
		}
	}
	for(var i=0 ; i < name.length ;i++){
		var ch = name.charAt(i);
		if( ! (( ch <= '9' && ch >= '0') 
				||(ch <= 'z' && ch >= 'a')
				||(ch <= 'Z' && ch >= 'A')
				|| ch == ' '
				|| ch == '_' || ch == '-'
				|| ch == '\'' || ch == '"'
				|| ch == ',' || ch == '.'
				|| ch == ':' || ch == ';' || ch == '=') ){						
			return false;
		}
	}
	return true;
}
