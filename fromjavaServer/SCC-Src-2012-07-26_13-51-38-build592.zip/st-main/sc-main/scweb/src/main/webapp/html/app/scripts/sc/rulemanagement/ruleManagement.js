
var ruleManagePath = "/pages/sc/ruleManagement/ruleManagement";
//show confirm message when delete
function showConfirmDelete(type){
	if(type == 1){
		setActionConfirmDialog(doDeleteRule);
	}
	if(type == 2){
		setActionConfirmDialog(doDeleteRuleVersions);
	}
	openDialogWithMessage("#confirm_dialog" , "" , confirmDeleteMsg , 1);
}
function doDeleteRule(){
	//submit data server.
	var e = new LiotroEvent("deleteRule", ruleManagePath, "doDeleteRule");
	doSCEvent(e);
}
function doDeleteRuleVersions(){
	//submit data server.
	var e = new LiotroEvent("doDeleteRuleVersion", ruleManagePath, "doDeleteRuleVersion");
	doSCEvent(e);
}
