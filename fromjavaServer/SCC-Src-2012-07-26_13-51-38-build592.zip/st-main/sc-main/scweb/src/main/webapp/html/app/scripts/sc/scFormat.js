
$(function(){
	//set number only for input fields
	$j(".numbersOnly").format({precision: 0,autofix:true ,allow_negative:false});
	$j(".decimalOnly").format({precision: 2 ,allow_negative:false});
	$j(".numbersNegative").format();
	
});