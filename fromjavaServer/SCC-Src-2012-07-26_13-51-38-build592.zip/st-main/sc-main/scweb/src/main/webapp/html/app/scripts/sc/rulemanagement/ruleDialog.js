
function openDataDiaglog(dialogType){
	var record="";
	//Get record from selected record
	if(dialogType == "fieldUnique" || dialogType == "fieldMatchingRecord1" ){
		var actionType = $j("#actionType").val();
		if(actionType == "edit"){
			record = $j("#selectedRecord").val();
		}
		if(actionType == "add") {
			record = $j("#selectedRecordCb").val();
		}
	}
	if(dialogType == "fieldMatchingRecord2" ){
		//Get from target combobox of matching rule condition.
		record = $j("#CORRESPONDENT_BETWEEN_RECORDS_cb1").val();
	}
	url ="/scweb/app/path/pages/sc/ruleManagement/dialogPage.doShow?type=" + dialogType;
	if (record != ""){
		url += "&record=" + record;
	}
	var w = 400;
	var h = 400;
	var left = (screen.width/2)-(w/2);
	var top = (screen.height/2)-(h/2);
	spec ="menubar=no,status=no,resizable=no,scrollbars=yes,modal=yes;" ;
	spec += ",width="+ h + ",height="+ w;
	spec += ",top=" + top + ",left=" + left;
	var newPopup = window.open(url, dialogType ,spec);
	newPopup.focus();
	
	//clear cookie
	setCookie("selectedData" , "" , -1);
	setCookie("action" , "" , -1);
	//get data from popup
	var A = setInterval(function(){
		if(newPopup.closed){
			clearInterval(A);
			setDataAfterClosePopup(dialogType);
			
			//clear cookie after get value
			setCookie("selectedData" , "" , -1);
			setCookie("action" , "" , -1);
		}
	},1000);
}

function setDataAfterClosePopup(dialogType){
	var act = getCookie("action");
	if(act != 'apply'){
		return;
	}
	var selectedData = getCookie("selectedData"); 
	if(dialogType == 'userRule' ) {
		document.xform.owner_list.value = mergeItems(document.xform.owner_list.value , selectedData);
	} else 
	if(dialogType == 'userRuleSet') {
		document.xform.ruleset_owners.value  = mergeItems(document.xform.ruleset_owners.value , selectedData);
	} else  
	if(dialogType == 'recordInGroup' ) {
		document.xform.MUST_IN_GROUP_txt1.value  = mergeItems(document.xform.MUST_IN_GROUP_txt1.value , selectedData);
	} else 				
	if( dialogType == 'fieldUnique'	) {
		document.xform.CHECK_UNIQUENESS_txt1.value  = mergeItems(document.xform.CHECK_UNIQUENESS_txt1.value , selectedData);
	} else 
	if( dialogType == 'fieldMatchingRecord1' ) {
		document.xform.CORRESPONDENT_BETWEEN_RECORDS_txt2.value  = mergeItems(document.xform.CORRESPONDENT_BETWEEN_RECORDS_txt2.value , selectedData);
	} else 
	if( dialogType == 'fieldMatchingRecord2' ) {
		document.xform.CORRESPONDENT_BETWEEN_RECORDS_txt3.value  = mergeItems(document.xform.CORRESPONDENT_BETWEEN_RECORDS_txt3.value , selectedData);
	}
}

function mergeItems(item1, item2){
	if(item1 == null || item1==""){
		return item2;
	}
	if(item2 == null || item2==""){
		return item1;
	}
	var listItem1 =item1.split(",");
	var listItem2 = item2.split(",");
	var result = item1;
	for(var i = 0; i < listItem2.length ; i++){
		j=0;
		for(; j <listItem1.length ; j++){
			if(listItem2[i] == listItem1[j]){
				break;
			}
		}
		if(j==listItem1.length){
			//item 2 not in list item1.
			result += "," +listItem2[i] ;
		}
	}
	return result;
}