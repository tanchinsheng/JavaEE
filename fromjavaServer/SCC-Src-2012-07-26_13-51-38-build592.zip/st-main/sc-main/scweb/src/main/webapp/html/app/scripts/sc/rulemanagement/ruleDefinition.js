
//Check on radio button
function checkOnRadioButton(){
	var list = document.xform.group1;
	if(!list)
		return;			
	var checkedValue = document.xform.ruleConditionType.value;
	if (!checkedValue)
		return;
		
	for (var i=0; i < list.length ; i++){
		if (list[i].value == checkedValue){
			list[i].checked = true;
			break;
		}
	}
}

function checkIncreaseVersion(){
	var editValue = document.xform.rule_point.value;
	if (editValue != origin_point) {
		document.xform.increaseVersion.value = 'true';
		return;
	}
	editValue = document.xform.rule_desc.value;
	if (editValue != origin_description) {
		document.xform.increaseVersion.value = 'true';
		return;
	}
	editValue = document.xform.rule_log.value;
	if (editValue != origin_logid) {
		document.xform.increaseVersion.value = 'true';
		return;
	}
}

/*----Max Length of Field-----------*/
var maxRuleName = 255;
var maxRuleDesc = 1024;
var maxLogId	= 7; //include '-'
var maxPoint	= 6;	
var maxRuleConditionText = 255;
var maxRuleConditionNum = 7;
/*----End Max Length of Field-----------*/
function initMaxLengthFields(){
	$j("#rule_name").attr("maxlength" , maxRuleName);
	$j("#rule_desc").attr("maxlength" , maxRuleDesc);
	$j("#rule_log").attr("maxlength" , maxLogId);
	$j("#rule_point").attr("maxlength" , maxPoint);
	
	//max length for rule condition fields
	$j("table.recordOccurrenceTable input[type=text]").attr("maxlength" , maxRuleConditionText);
	$j("table.recordOccurrenceTable input[type=text].numbersOnly").attr("maxlength" , maxRuleConditionNum);
}
function validateRuleCondition(){
	var list = document.xform.group1;
	for (var i=0; i < list.length ; i++){
		if (list[i].checked == true){
			rs = validateFieldCheck(list[i].value);
			if (rs == false){
				return false;
			}
			//check fields
			return validateElementOfRuleCondition(list[i].value);
		}
	}
	return false;
}

var exceedMaxlength = false;
function validateElementOfRuleCondition(conditionValue){
	if(conditionValue == "VALUE_IN_RANGE"){
		val1 = $j("#VALUE_IN_RANGE_txt1").val();
		val2 = $j("#VALUE_IN_RANGE_txt2").val();
		if(val1 != "" || val2 !=""){
			return true;
		}
		return false;
	}
	for(var t=1; t <=2 ;t++) {
		//check textbox and combobox
		if (t==1){
			includedName = "_txt";
		}
		if (t==2){
			includedName = "_cb";
		}
		for(var i=1 ; i <= 5; i++) {
			element = $j("#" + conditionValue + includedName + i);
			if (element){
				val = element.val();
				if (val != undefined) {
					if (val.length == 0){
						return false;
					} else {
						if(val.length > maxRuleConditionText){
							exceedMaxlength = true;
							return false;
						}
					}
				} else {
					//element is not exist, do not check next element.
					break;
				}
			} else {
				//element is not exist, do not check next element.
				break;
			}
		}
	}
	return true;
}
function validateFieldCheck(conditionValue){
	if (conditionValue == "REQUIRED_FIELD" ||
			conditionValue == "VALUE_FIELD_IN_LIST" ||
			conditionValue == "VALUE_FIELD_NOT_IN_LIST" ||
			conditionValue == "VALUE_IN_RANGE" ||
			conditionValue == "CHECK_LENGTH_FIELD" ){
		//check selected fields
		selectedFields = document.xform.comboboxField.options[document.xform.comboboxField.selectedIndex].value;
		if (selectedFields == ""){
			return false;
		}
	}
	return true;
}
function checkRequiredFields(){
	ruleName = document.xform.rule_name.value;
	if (ruleName =="" || trim(ruleName) == ""){
		return false;
	}
//	ruleDescription = document.xform.rule_desc.value;
//	if (ruleDescription =="" || trim(ruleDescription) ==""){
//		return false;
//	}
	rulePoint = document.xform.rule_point.value;
	if (rulePoint =="" || trim(rulePoint) ==""){
		return false;
	}
	ruleLog = document.xform.rule_log.value;
	if (ruleLog =="" || trim(ruleLog) ==""){
		return false;
	}
	//check record type
	if (document.xform.selectedRecordCb) {
		selectedRecord = document.xform.selectedRecordCb.options[document.xform.selectedRecordCb.selectedIndex].value;
		if (selectedRecord == ""){
			return false;
		}
	}
	
	return true;
}
var ruleDefinitionPath = "/pages/sc/ruleManagement/ruleDefinition";
var saveTypeGlobal;
function doSave(saveType){
	exceedMaxlength = false;
	if ( checkRequiredFields() == false ){
		showErrorMessage("messageAreaRuleDefinition" , requiredFieldMsg);
		return;
	}
	//check max log ID
	ruleLog = document.xform.rule_log.value;
	if(ruleLog=="-" || ruleLog - 0 >= 0){
		showErrorMessage("messageAreaRuleDefinition" , logIdError);
		return;
	}
	//check willcards or leading/trailing space
	if (checkNameContainWildcards(document.xform.rule_name.value) == false){
		showErrorMessage("messageAreaRuleDefinition" , "Rule name " + nameError);
		return;
	}
	if (validateRuleCondition() == false){
		if(exceedMaxlength == false){
			showErrorMessage("messageAreaRuleDefinition" , ruleConditionError);
		} else {
			showErrorMessage("messageAreaRuleDefinition" , exeedMaxLengthRulecondition + maxRuleConditionText);
		}
		return;
	}
	saveTypeGlobal = saveType;
	if(confirmEditMsg != ""){
		setActionConfirmDialog(submitData);
		openDialogWithMessage("#confirm_dialog" , "" , confirmEditMsg , 1);
	} else {
		submitData();
	}
}
function submitData(){
	checkIncreaseVersion();
	
	//submit data
	var e = new LiotroEvent("saveRule", ruleDefinitionPath, "doSave");
	//saveTypeGlobal is global variable in panelGeneral.template.
	e.setParameter("saveType" , saveTypeGlobal);
	doSCEvent(e);
}

$j(function(){
	//check selected rule condition
	checkOnRadioButton();
	
	//init data for source record of matching field.
	var selectedRecord="";
	var actionType = $j("#actionType").val();
	if(actionType == "edit"){
		selectedRecord = $j("#selectedRecord").val();
	}
	if(actionType == "add") {
		selectedRecord = $j("#selectedRecordCb").val();
	}
	if (selectedRecord != ""){
		//assign value to source record of matching rule condition
		$j("#CORRESPONDENT_BETWEEN_RECORDS_h").val(selectedRecord);
		$j("#CORRESPONDENT_BETWEEN_RECORDS_lb").val(selectedRecord);	
	}
	initMaxLengthFields();
	
	disableControl();
});

function changeRecordType(){
	selectedRecord = $j("#selectedRecordCb").val();
	if (selectedRecord != ""){
		//assign value to source record of matching rule condition
		$j("#CORRESPONDENT_BETWEEN_RECORDS_h").val(selectedRecord);
		$j("#CORRESPONDENT_BETWEEN_RECORDS_lb").val(selectedRecord);	
		//submit data
		var e = new LiotroEvent("changerecordtype", ruleDefinitionPath, "doShow");
		doSCEvent(e);
	}
}
function changeRecordTypeOfTargetMatching(){
	$j("#CORRESPONDENT_BETWEEN_RECORDS_txt3").val("");
}

function disableControl(){
	isOwners = document.xform.isOwnerOfRule_h.value;
	if(isOwners == 'false') {
		/*document.xform.rule_name.disabled = true;
		document.xform.rule_desc.disabled = true;
		document.xform.rule_point.disabled = true;
		document.xform.rule_log.disabled = true;*/
		
		selectboxs = $j("table.panelContent select");
		if(selectboxs.length > 0){
			selectboxs.each(function(){
				$j(this).attr("disabled","true");
			});
		}
		textboxs = $j("table.panelContent input");
		if(textboxs.length > 0){
			textboxs.each(function(){
				type = $j(this).attr("type");
				if(type != "hidden"){
					$j(this).attr("disabled","true");
					if("text" == type){
						// show tool tip
						$j(this).attr("title", $j(this).val());
					}
				}
			});
		}
		//Fire fox does not show tooltip, workaround it.
		if ($j.browser.mozilla) {
			$j('table.panelContent :text')
				.removeAttr('disabled')
				.addClass('disabled')
				.click(function() {return false})
				.keypress(function() {return false});
		}
		selectboxs = null;
		textboxs = null;
	}
}

//Change Field of record -> Change validation of field type: U1,U2,U4,I1,I2,I4,...
function changeFieldType(){
	fieldType = $j("#comboboxField").val();
}