

function showInputRuleSetDialog(){
	openDialogWithMessage("#input_dialog" , "Input Rule Set Name" , "" , 1);
}

var ruleSetManagePath = "/pages/sc/rulesetManagement/rulesetManagement";
function doCopyRuleSet(){
	ruleSetName = $j("#new_rule_set_name").val();
	if(ruleSetName != "" && trim(ruleSetName) != ""){
		//check willcards or leading/trailing space
		if (checkNameContainWildcards(ruleSetName) == false){
			showErrorMessage("errorCopyDiv" , "Rule Set name " + nameError);
			return;
		}
		//clear error msg.
		$j("#errorCopyDiv").html("");
		
		//submit data server.
		var e = new LiotroEvent("copyRuleSet", ruleSetManagePath, "doCopyRuleSetVersion");
		e.setParameter("newRuleSetName", ruleSetName);
		doSCEvent(e);
		closeDialog('#input_dialog');
	} else {
		showErrorMessage("errorCopyDiv" , requiredFieldMsg );
	}
}

//show confirm message when delete
function showConfirmDelete(type){
	if(type == 1){
		setActionConfirmDialog(doDeleteRuleSet);
	}
	if(type == 2){
		setActionConfirmDialog(doDeleteRuleSetVersions);
	}
	openDialogWithMessage("#confirm_dialog" , "" , confirmDeleteMsg , 1);
}
function doDeleteRuleSet(){
	//submit data server.
	var e = new LiotroEvent("deleteRuleSet", ruleSetManagePath, "doDeleteRuleSet");
	doSCEvent(e);
}
function doDeleteRuleSetVersions(){
	//submit data server.
	var e = new LiotroEvent("deleteRuleSetVersion", ruleSetManagePath, "doDeleteRuleSetVersion");
	doSCEvent(e);
}
