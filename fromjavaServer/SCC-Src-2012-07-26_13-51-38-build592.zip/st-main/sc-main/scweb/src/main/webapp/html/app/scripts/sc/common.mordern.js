/*
DIALOG
---------------------------------------------------------------------------
*/
$j =jQuery.noConflict();
				
 $j(function(){
	//Add close button.
	$j(".dialog .config-box h2").after($j("<a>", {
		"class": "dialog-close",
		"href": "javascript:void(0)",
		"title": "Close"
	}));
	$j(".dialog .config-box a.dialog-close").click(function() {
		var id = "#" + $j(this).parents(".dialog").attr("id");
		closeDialog(id);
	});
	$j(".dialog .config-box").keypress(function(e){
		/*
		if (e.keyCode == 13) {
			$j(this).find("a[id$=okDialog_label]").click();
		}*/
		if (e.keyCode == 27) {
			$j(this).find("a.dialog-close").click();
		}
	});
	
	//addControlStyles
	addControlStyles();
});

function openDialogWithMessage(id, title, message,order) {
	// Check if the current dialog has opened or not
	if (!$j(id).hasClass("isOpened")) {
		if($j("#mainOverlay").css("display") == "none"){
			$j("#mainOverlay").height($j(window).height() + $j(window).scrollTop());
			$j("#mainOverlay").show();
		} else {
			if($j("#secondOverlay").css("display") == "none"){
				$j("#secondOverlay").height($j(window).height() + $j(window).scrollTop());
				$j("#secondOverlay").show();
			} else {
				$j("#thirdOverlay").height($j(window).height() + $j(window).scrollTop());
				$j("#thirdOverlay").show();
			}
		}
		$j(id).fadeIn(200, function() {
			$j(id).addClass("isOpened");
		});			
		
		setDialogPosition(id);
		$j(id).draggable({
			cursor: 'move',
			containment: "window"
			//handle: $j(id + " h2")
		});		
		
		if(order == 1)
			$j(id).addClass("dialog");
		if(order == 2)
			$j(id).addClass("dialog mid");
		if(order == 3)
			$j(id).addClass("dialog top");
		
		hideIE6DropDowns(id);
		
		if (message && message.length > 0) {
			$j(id + " .message_content_class").html(message);
		}				
		if(title && title.length > 0){
			$j(id + " h2").text(title);	
		}
		
		//focus on close button.
		$j(id).find("a.dialog-close:first").focus();
	}	
}

function closeDialog(id) {
	$j(id).fadeOut(200, function() {
		if($j("#thirdOverlay").css("display") != "none")
			$j("#thirdOverlay").hide();
		else {
			if($j("#secondOverlay").css("display") != "none")
				$j("#secondOverlay").hide();
			else
				$j("#mainOverlay").hide();
		}
		$j(id).removeClass("isOpened");
		showIE6DropDowns(id);
	});
}

//Fix to hide select boxes in IE6
function hideIE6DropDowns(id) {
	if (browserDetect.isIE6) {
		var calcValue = 0;
		$j("select").each(function() {
			calcValue = $j(id).css("zIndex") - $j(this).css("zIndex");
			if ($j(this).css("display") != "none" && (calcValue > 0 && calcValue <= 20)) {				
				$j(this).addClass("layerHide").hide();
				$j(this).attr("hide-by", getObjectId(id));
			}
		});
	}
}

//Fix to hide select boxes in IE6
function showIE6DropDowns(id) {
	if (browserDetect.isIE6) {
		var calcValue = 0;
		$j("select.layerHide").each(function() {
			calcValue = $j(id).css("zIndex") - $j(this).css("zIndex");
			if ((calcValue > 0 && calcValue <= 20) && $j(this).attr("hide-by") == id) {
				$j(this).show();
				$j(this).removeClass("layerHide");
				$j(this).removeAttr("hide-by");
			}
		});
	}
}

//Detect if provided var is an obj
function getObjectId(obj) {
	if (typeof(obj) != "object") {		
		return obj;
	} else {
		return "#" + obj.attr("id");
	}
}

function setDialogPosition(id) {
	$j(id).css({
		left: ($j(".overlay-layer").width() - $j(id).width()) / 2,
		top: ($j(window).height() - $j(id).height()) / 2 + $j(window).scrollTop()
	});
}

function addControlStyles() {
	
	//set required for input fields
	$j(".requiredField").each(function(){
		addrequired($j(this).attr("id"));
	});
	//Set max length for text area.
	$j("textarea[class*=maxLength]").each(function() {
		var maxLength = $j.grep($j(this).attr("class").split(/\[|\]/), function(n) {
			return /\d/.test(n);
		})[0];
		$j(this).keypress(function(event) {
			var excludeValues = [8, 37, 38, 39, 40, 46]; 
			var i=0;
			for(; i < excludeValues.length ; i++){
				if(excludeValues[i] == event.keyCode){
					break;
				}
			}
			if (i == excludeValues.length) {
				if ($j(this).val().length >= maxLength)
					event.preventDefault();
			}
			
		}).bind("paste", function() {
			setTimeout("setSubstring('" + $j(this).attr("id") + "'," + maxLength + ");", 10);
		}).blur(function() {
			setSubstring($j(this).attr("id"), maxLength);
		});
	});
	
	//no wildcard
	$j(".nowildcard").each(function(){
		$j(this).keypress(function(e){
			nowildcards(e);
		});
	});
	
	//add tooltip of image on IE8,9
	if (browserDetect.browser == "Explorer") {
		if(browserDetect.version != 7 && browserDetect.version != 6){
			$j("img").each(function(){
				alt =  $j(this).attr("alt");
				if(alt != undefined && alt != ""){
					$j(this).attr("title", alt);
				}
			});
		}
	}
}

function setSubstring(id, maxLength) {
	var target = $j("#" + id);
	if (target.val().length > maxLength)
		target.val(target.val().substring(0, maxLength));
}

function addrequired(id){
	$j("#" + id).after($j("<span class='required'>(*)</span>"));				
}
function readOnly(id){
	$j(".readonly").attr("disabled" , "disabled");
}

function showErrorMessage(id , errorMsg){
	htmlContent = '<p class="message-container alert">'	;
	htmlContent	+= '<img src="/scweb/html/liotrox/images/icons/icon_alert.gif" />';
	htmlContent	+= errorMsg	;							
	htmlContent	+= '</p>' ;
	$j("#" + id).html(htmlContent);
}