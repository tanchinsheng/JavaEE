
function getCookie(c_name)
{
	var i,x,y,ARRcookies=document.cookie.split(";");
	for (i=0;i<ARRcookies.length;i++)
	  {
		j = ARRcookies[i].indexOf("=");	
		  x=ARRcookies[i].substr(0,j);
		  y=ARRcookies[i].substr(j+1);
		  x=x.replace(/^\s+|\s+$/g,"");
		  if (x==c_name)
		    {
		    return unescape(y);
		    }
	  }
	return null;
}

function setCookie(c_name,value,exdays)
{
	var exdate=new Date();
	exdate.setDate(exdate.getDate() + exdays);
	var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
	c_value += "; path=/scweb/app/path/pages/sc/";
	//this cookie is used at client side, don't pass to server.
	//We will delete it after get data.
	//Don't set 'HttpOnly', because on client side, we can't get data from this cookie.
	document.cookie=c_name + "=" + c_value;
}