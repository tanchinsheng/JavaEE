
function splitValue(str , type){
	list = str.split(",");
	for(int i=0 ;i < list.length ; i++){
		checkNumberValue(list[i] , type);
	}
}

//U1, U2, U4
//I1, I2, I4
//R4, R8
var maxU1 = Math.pow(2,8) - 1;
var maxU2 = Math.pow(2,16) - 1;
var maxU4 = Math.pow(2,32) - 1;
var maxU8 = Math.pow(2,64) - 1;
var maxI1 = Math.pow(2,7) - 1;
var minI1 = Math.pow(2,7) * (-1);
var maxI2 = Math.pow(2,15) - 1;
var minI2 = Math.pow(2,15) * (-1);
var maxI4 = Math.pow(2,31) - 1;
var minI4 = Math.pow(2,31) * (-1);
function checkNumberValue(value , type){
	min = 0;
	max = 1;
	if(type == "U1"){
		max = maxU1;
	} else if (type == "U2"){
		max = maxU2;
	} else if (type == "U4"){
		max = maxU4;
	} else if (type == "U8"){
		max = maxU8;
	} else if (type == "I1"){
		max = maxI1;
		min = minI1;
	} else if (type == "I2"){
		max = maxI2;
		min = minI2;
	} else if (type == "I4"){
		max = maxI4;
		min = minI4;	
	} else if (type == "R4"){
		max = maxR4;
		min = minR4;
	} else if (type == "R8"){
		max = maxR8;
		min = minR8;
	} 
	if(value >= min &&  value <= max){
		return true;
	}
	return false;
}

function checkStringValue(value , type){
	
}
