
function checkSelectedDataview(dataViewName ){
	selector = ":checkbox[name*=" + dataViewName + "]:checked";
	checkedList = $j(selector);
	if(checkedList.length == 0){
		return -1;
	}
	if(checkedList.length > 1){
		return -2;
	}
	return 0;
	//get select Id.
	/*var selectId;
	checkedList.each(function(){
		selector = "input[name*=" + dataViewName + "_" + hiddenFieldName +"]";
		hidden = $j(this).parent().find(selector)
		if(hidden){
			selectId = hidden.val();
		}
	});
	return selectId;*/
}

/*----Max Length of Field-----------*/
var maxRulesetName = 255;
var maxRulesetDesc = 1024;
var maxAlarm = 5;
var maxMIRCriteria = 255;	
/*----End Max Length of Field-----------*/
function initMaxLengthFields(){
	$j("#def_ruleset_name").attr("maxlength" , maxRulesetName);
	$j("#ruleset_desc").attr("maxlength" , maxRulesetDesc);
	$j("#ruleset_alarmThreshole").attr("maxlength" , maxAlarm);
	
	$j("input[name*=MIR_]").attr("maxlength" , maxMIRCriteria);
}
$j(function(){
	initMaxLengthFields();
	
	disableControl();
});

function validateRuleSet(){
	var valid = true;
	if ($j.trim( $j("#def_ruleset_name").val() ) == ""){
		valid = false;
	}

	alarm = $j("#ruleset_alarmThreshole").val();
	if (valid && $j.trim( alarm ) != ""){
		if(alarm - 0 > 100 || alarm - 0 < 0 ){
			showErrorMessage("rulesetConditionError" , errorMsgAlarm);
			return false;
		}
	}
	if(!valid){
		showErrorMessage("rulesetConditionError" , requiredFieldMsg);
	}
	if(valid){
		if(document.xform.loginRole_h.value != "admin") {
			valid = validateMIRCriteria();	
		}
	}
	return valid;
}
function validateMIRCriteria(){
	var valid = false;
	$j("input[name*=MIR_]").each(function(){
		var value = $j(this).val();
		if($j.trim(value) != ""){
			valid = true;
			return;
		}
	});
	if(!valid){
		showErrorMessage("rulesetConditionError" , errorMsgChooseMIRCriteria);
	}
	return valid;
}

function checkIncreaseVersion(){
	//check description
	if($j.trim( $j("#ruleset_desc").val() ) != origin_description){
		return true;
	}	
	//check alarm threshole
	if($j.trim( $j("#ruleset_alarmThreshole").val() ) != origin_alarm_threshole){
		return true;
	}
	increase = false;
	//check MIR Criteria
	$j("input[name*=MIR_]").each(function(){
		var value = $j(this).val();
		var name = $j(this).attr("name");
		if($j.trim(value) != $j("#" + name + "_h").val() ){
			increase = true;
			return;
		}
	});
	return increase;
}
var ruleSetDefinitionPath = "/pages/sc/rulesetManagement/rulesetDefinition";
function doSave(nextAction){
	//Validate data before save.
	valid = validateRuleSet();
	//check willcards or leading/trailing space
	if (checkNameContainWildcards($j("#def_ruleset_name").val()) == false){
		showErrorMessage("rulesetConditionError" , "Rule Set name " + nameError);
		return;
	}
	if(valid){
		//Check increase version
		increase = checkIncreaseVersion();
		if(increase){
			$j("#increaseVersion").val('true');
		}
		
		//submit data server.
		var e = new LiotroEvent("saveRuleSet", ruleSetDefinitionPath, "doSave");
		e.setParameter("nextAction",nextAction);
		doSCEvent(e);
	}
}

function disableControl(){
	isOwners = document.xform.isOwnerOfRuleSet_h.value;
	if(isOwners == 'false') {
		/*document.xform.def_ruleset_name.disabled = true;
		document.xform.ruleset_desc.disabled = true;
		document.xform.ruleset_alarmThreshole.disabled = true;
		//MIR textbox
		document.xform.MIR_PartType.disabled = true;
		document.xform.MIR_DsgnRev.disabled = true;
		document.xform.MIR_modecode.disabled = true;
		document.xform.MIR_cmodecod.disabled = true;
		document.xform.MIR_OperFrq.disabled = true;
		document.xform.MIR_flowid.disabled = true;
		document.xform.MIR_TstrType.disabled = true;
		document.xform.MIR_ExecType.disabled = true;
		document.xform.MIR_ExecVer.disabled = true;
		document.xform.MIR_JobName.disabled = true;
		document.xform.MIR_JobRev.disabled = true;
		document.xform.MIR_SPEC_NAM.disabled = true;
		document.xform.MIR_SPEC_VER.disabled = true;
		document.xform.MIR_PROC_ID.disabled = true;
		document.xform.MIR_SUPR_NAM.disabled = true;*/		
		
		textboxs = $j(":text");
		if(textboxs.length > 0){
			textboxs.each(function(){
				$j(this).attr("disabled","true");
				// show tool tip
				$j(this).attr("title", $j(this).val());
			});
		}
		//Fire fox does not show tooltip, workaround it.
		if ($j.browser.mozilla) {
			$j(':text')
				.removeAttr('disabled')
				.addClass('disabled')
				.click(function() {return false})
				.keypress(function() {return false});
		}
		textboxs = null;
	}
}
