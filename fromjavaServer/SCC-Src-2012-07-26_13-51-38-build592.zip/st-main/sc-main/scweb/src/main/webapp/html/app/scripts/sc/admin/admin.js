
function stdfFolderChange(disableNFSOnly){
	//disable /enable user name, password, host, port corresponding folder type : NFS, FTP, SFTP
	foldertype = $j("#stdf_foldertype").val();
	host = $j("#stdf_host_txt");
	port = $j("#stdf_port_txt");
	username = $j("#stdf_username_txt");
	password = $j("#stdf_password_txt");
	if(disableNFSOnly != undefined && disableNFSOnly == true){
		disableNFS(foldertype,host,username,password,port); 
	} else {
		enableDisableInfo(foldertype,host,username,password,port);
	}
	host = null;
	port = null;
	username = null;
	password = null;
}
function stdfArchiveFolderChange(disableNFSOnly){
	//disable /enable user name, password, host, port corresponding folder type : NFS, FTP, SFTP
	foldertype = $j("#archive_stdf_foldertype").val();
	host = $j("#archive_stdf_host_txt");
	port = $j("#archive_stdf_port_txt");
	username = $j("#archive_stdf_username_txt");
	password = $j("#archive_stdf_password_txt");
	if(disableNFSOnly != undefined && disableNFSOnly == true){
		disableNFS(foldertype,host,username,password,port); 
	} else {
		enableDisableInfo(foldertype,host,username,password,port);
	}
	host = null;
	port = null;
	username = null;
	password = null;
}
function stdfErrorFolderChange(disableNFSOnly){
	//disable /enable user name, password, host, port corresponding folder type : NFS, FTP, SFTP
	foldertype = $j("#error_stdf_foldertype").val();
	host = $j("#error_stdf_host_txt");
	port = $j("#error_stdf_port_txt");
	username = $j("#error_stdf_username_txt");
	password = $j("#error_stdf_password_txt");
	if(disableNFSOnly != undefined && disableNFSOnly == true){
		disableNFS(foldertype,host,username,password,port); 
	} else {
		enableDisableInfo(foldertype,host,username,password,port);
	}
	host = null;
	port = null;
	username = null;
	password = null;
}
function failValuesFolderChange(disableNFSOnly){
	//disable /enable user name, password, host, port corresponding folder type : NFS, FTP, SFTP
	foldertype = $j("#fail_values_foldertype").val();
	host = $j("#fail_values_host_txt");
	port = $j("#fail_values_port_txt");
	username = $j("#fail_values_username_txt");
	password = $j("#fail_values_password_txt");
	if(disableNFSOnly != undefined && disableNFSOnly == true){
		disableNFS(foldertype,host,username,password,port); 
	} else {
		enableDisableInfo(foldertype,host,username,password,port);
	}
	host = null;
	port = null;
	username = null;
	password = null;
}
function enableDisableInfo(foldertype,host,username,password,port){
	if(foldertype == "NFS"){
		disableNFS(foldertype,host,username,password,port);
	} else {
		if(foldertype == "FTP"){
			port.val(21);
		} else {
			if(foldertype == "SFTP"){
				port.val(22);
			}
		}
		host.removeAttr("disabled");
		host.addClass("requiredField");
		port.removeAttr("disabled");
		port.addClass("requiredField");
		username.removeAttr("disabled");
		username.addClass("requiredField");
		password.removeAttr("disabled");
		password.addClass("requiredField");
		//add (*) after text box
		host.next().remove();
		host.after($j("<span class='required'>(*)</span>"));
		port.next().remove();
		port.after($j("<span class='required'>(*)</span>"));
		username.next().remove();
		username.after($j("<span class='required'>(*)</span>"));
		password.next().remove();
		password.after($j("<span class='required'>(*)</span>"));
	}
}
function disableNFS(foldertype,host,username,password,port){
	if(foldertype == "NFS"){
		host.val("");
		host.attr("disabled","true");
		host.removeClass("requiredField");
		port.val("");
		port.attr("disabled","true");
		port.removeClass("requiredField");
		username.val("");
		username.attr("disabled","true");
		username.removeClass("requiredField");
		password.val("");
		password.attr("disabled","true");
		password.removeClass("requiredField");
		
		//remove (*)
		host.next().remove();
		port.next().remove();
		username.next().remove();
		password.next().remove();
	} 
}

var maxVarCharField = 255;
var maxDefaultAlarm = 5;
var maxScanFileInterval = 5;
var maxNumFileNotified = 3;

var maxCompliancyScore = 2;
var maxPort = 6;
var maxDepthFolder = 2;
function initMaxValues(){
	//init max length of fields.
	$j("#defaultAlarmThreshold_txt").attr("maxlength", maxDefaultAlarm);
	$j("#scanFileInterval_txt").attr("maxlength", maxScanFileInterval);
	$j("#plantCode_txt").attr("maxlength", maxVarCharField);
	$j("#maxNumFileNotify_txt").attr("maxlength", maxNumFileNotified);
	$j("#limitFailedValue_txt").attr("maxlength", 5);
	
	$j("#compliancyto_txt").attr("maxlength", maxCompliancyScore);
	$j("#onlinereport_txt").attr("maxlength", 6);
	$j("#maxRowDataView_txt").attr("maxlength", 8);
	
	$j("#apcdHost_txt").attr("maxlength", maxVarCharField);
	$j("#apcdMailbox_txt").attr("maxlength", maxVarCharField);
	$j("#apcdMbx_txt").attr("maxlength", maxVarCharField);
	$j("#apcdPort_txt").attr("maxlength", maxPort);
	
	$j("#stdf_folderPath_txt").attr("maxlength", maxVarCharField);
	$j("#stdf_folderDepth_txt").attr("maxlength", maxDepthFolder);
	$j("#stdf_host_txt").attr("maxlength", maxVarCharField);
	$j("#stdf_username_txt").attr("maxlength", maxVarCharField);
	$j("#stdf_password_txt").attr("maxlength", maxVarCharField);
	$j("#stdf_port_txt").attr("maxlength", maxPort);
	
	$j("#archive_stdf_folderPath_txt").attr("maxlength", maxVarCharField);
	$j("#archive_stdf_host_txt").attr("maxlength", maxVarCharField);
	$j("#archive_stdf_username_txt").attr("maxlength", maxVarCharField);
	$j("#archive_stdf_password_txt").attr("maxlength", maxVarCharField);
	$j("#archive_stdf_port_txt").attr("maxlength", maxPort);
	
	$j("#error_stdf_folderPath_txt").attr("maxlength", maxVarCharField);
	$j("#error_stdf_host_txt").attr("maxlength", maxVarCharField);
	$j("#error_stdf_username_txt").attr("maxlength", maxVarCharField);
	$j("#error_stdf_password_txt").attr("maxlength", maxVarCharField);
	$j("#error_stdf_port_txt").attr("maxlength", maxPort);
	
	$j("#fail_values_folderPath_txt").attr("maxlength", maxVarCharField);
	$j("#fail_values_host_txt").attr("maxlength", maxVarCharField);
	$j("#fail_values_username_txt").attr("maxlength", maxVarCharField);
	$j("#fail_values_password_txt").attr("maxlength", maxVarCharField);
	$j("#fail_values_port_txt").attr("maxlength", maxPort);
}

$j(function(){
	initMaxValues();	
	stdfFolderChange(true);
	stdfArchiveFolderChange(true);
	stdfErrorFolderChange(true);
	failValuesFolderChange(true);
});
function checkDataChanged(){
	return true;
}
function checkRequiredFields(){
	list = $j(".requiredField");
	valid = true;
	if(list.length > 0){
		list.each(function(){
			//required field in dialog template: new_rule_set_name
			if("new_rule_set_name" != $j(this).attr("id")){
				if ( trim($j(this).val()) == ""){
					valid = false;
					return;
				}
			}
		});
	}
	return valid;
}
function validateSpecialFields(){
	var errorMsg = "";
	value = $j("#defaultAlarmThreshold_txt").val();
	if(value-0 > 100 || value-0 < 0){
		errorMsg = msg_alarm_threshod_valid;
	}
	interval = $j("#scanFileInterval_txt").val();
	if(interval-0 <5 || interval-0 > 300){
		if(errorMsg != ""){
			errorMsg += "<br/>";
		}
		errorMsg += intervalTimeMsg;
	}
	value = $j("#limitFailedValue_txt").val();
	if(value-0 < 100 || value-0 > 10000){
		if(errorMsg != ""){
			errorMsg += "<br/>";
		}
		errorMsg += limitFailedValueMsg;
	}
	
	value = $j("#compliancyto_txt").val();
	if(value-0 > 10 || value-0 <1){
		if(errorMsg != ""){
			errorMsg += "<br/>";
		}
		errorMsg += compliancyValidMsg;
	}
	
	value = $j("#maxNumFileNotify_txt").val();
	if(value-0 < 10 || value-0 > 50 ){
		if(errorMsg != ""){
			errorMsg += "<br/>";
		}
		errorMsg += maxNumFileNotifiedMsg;
	}
	
	if(errorMsg != ""){
		showErrorMessage("messageAreaConfiguration" , errorMsg);
		return false;
	}
	return true;
}
function compareValueToWarning(){
	originValue = $j("#scanFileInterval_h").val();
	interval = $j("#scanFileInterval_txt").val();
	if(originValue != interval){
		setActionConfirmDialog(submitData);
		openDialogWithMessage("#confirm_dialog" , "" , confirmApplyMsg + "<br/>" + confirmIntervalMsg , 1);
		return false;
	}
	return true;
}

var adminPath = "/pages/sc/admin/admin";
function doSave(){
	if(checkRequiredFields() == false){
		showErrorMessage("messageAreaConfiguration" , requiredFieldMsg);
		return;
	}
	if(validateSpecialFields() == false){
		return;
	}
	//submit data
	submitData();
	
}
function submitData(){
	var e = new LiotroEvent("saveConfig", adminPath, "doSave");
	doSCEvent(e);
}