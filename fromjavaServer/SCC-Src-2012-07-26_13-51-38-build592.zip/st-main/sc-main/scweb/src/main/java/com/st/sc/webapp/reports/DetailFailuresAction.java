/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import java.io.File;
import java.sql.Timestamp;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.ColumnList;
import st.liotrox.dataview.DataView;
import st.liotrox.db.DataSet;
import st.liotrox.db.DefaultDataSet;
import st.liotrox.template.element.control.DataViewElement;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.config.ConfigLoader;
import com.st.common.config.FolderInfo;
import com.st.common.fileaccess.FileAccessFactory;
import com.st.common.fileaccess.SccFileAccess;
import com.st.common.web.config.ConfigReloader;
import com.st.common.web.util.ServletUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.rulemanager.data.FailedValueData;
import com.st.sc.rulemanager.serialization.FailedDetailReportData;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.sc.util.SCCache;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.webapp.BaseAction;
import com.st.scc.common.utils.DateUtils;
import com.st.stdfparser.stdf.RecordEnum;

/**
 * The Class DetailFailuresAction.
 */
public class DetailFailuresAction extends BaseAction {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(DetailFailuresAction.class);

  /** The failures data view. */
  private DataView failuresDataView;

  /** The failures dataset. */
  private DataSet failuresDataset;

  /** The record. */
  private String ruleName;

  /** The dataview lables. */
  private String[] dataviewLables;

  /**
   * Before populate.
   * 
   * @param request
   *          the request {@inheritDoc}
   * @see st.liotrox.page.WPage#beforePopulate(st.liotrox.WRequest)
   */
  @Override
  public void beforePopulate(final WRequest request) {
    // Get DataView object
    failuresDataView = getFailuresDataView();
  }

  /**
   * This method is invoked by the framework BEFORE rendering the page.
   * 
   * @param request
   *          the request
   */
  @Override
  public void beforeRender(final WRequest request) {
    // Get DataView object
    failuresDataView = getFailuresDataView();
    if (failuresDataView != null && failuresDataset != null) {
      failuresDataView.getModel().setDataSet(failuresDataset);
      final ColumnList columns = failuresDataView.getModel().getColumns();
      if (dataviewLables != null) {
        for (int i = 0; i < dataviewLables.length; i++) {
          columns.get(i + 1).setLabel(dataviewLables[i]);
//          columns.get(i + 1).setWidth("200px");
//          columns.get(i + 1).setDynamicContent("@PAGE.formatText");
        }
      }
    }
  }

  /**
   * Gets the failures dataset.
   * 
   * @return the failures dataset
   */
  public DataSet getFailuresDataset() {
    return failuresDataset;
  }

  /**
   * Gets the failures data view.
   * 
   * @return the failures data view
   */
  public DataView getFailuresDataView() {
    if (failuresDataView == null) {
      final DataViewElement dvElement = (DataViewElement) findControl("failuresDataView");
      if (dvElement != null) {
        failuresDataView = dvElement.getDataView(WRequest.getCurrentInstance());
      }
    }
    return failuresDataView;
  }

  /**
   * Gets the rule name.
   * 
   * @return the rule name
   */
  public String getRuleName() {
    return ruleName;
  }

  /**
   * init the page.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  @SuppressWarnings("unchecked")
  public void init(final WRequest request, final Event event) {
    LOGGER.debug("init DetailFailuresAction");
    // clear messages
    infoMessage = "";
    errorMessage = "";

    failuresDataset = new DefaultDataSet();
    final FullDetailReportAction fullDetailComp;
    //check this page whether is called from "fullDetailReport" page
    //or from "fullDetailReportRuleSetValidation" page
    if ("true".equals(request.getParameter("fromRuleSetValidate"))) {
      fullDetailComp =
          (FullDetailReportAction) request
              .resolvePath("/pages/sc/reports/fullDetailReportRuleSetValidation");
    } else {
      fullDetailComp =
          (FullDetailReportAction) request.resolvePath("/pages/sc/reports/fullDetailReport");
    }
    final int rowIndex = Integer.valueOf(request.getParameter("row"));
    final long ruleVersionId =
        (Long) fullDetailComp.getDataView().getModel().getDataSet()
            .getValue(rowIndex, "ruleVersionId");

    ruleName =
        (String) fullDetailComp.getDataView().getModel().getDataSet()
            .getValue(rowIndex, "ruleName");

    RuleValidationDetail detail = null;
    if (fullDetailComp.getRuleValidationDetailArr() != null) {
      for (int i = 0; i < fullDetailComp.getRuleValidationDetailArr().length; i++) {
        if (fullDetailComp.getRuleValidationDetailArr()[i].getRuleVersionId() == ruleVersionId) {
          detail = fullDetailComp.getRuleValidationDetailArr()[i];
        }
      }
    }

    // It is used for rule set validation.
    String rootPath = request.getParameter("specifiedFailedValuesFolder");
    boolean download = false;
    final FolderInfo folder =
        ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getFolder(
            ConfigLoader.FOLDER_NAME_FAIL_VALUES);
    if (rootPath == null || rootPath.length() == 0) {
      // get path from configuration.
      if (folder != null) {
        rootPath = folder.getFolder();
      } else {
        rootPath = SCConstants.ROOT_FULL_DETAIL;
      }
      LOGGER.info("Location of failed-value: " + rootPath);
    } else {
      // path is encoded before.
      rootPath = ServletUtils.decodeUrlParam(rootPath);
    }
    if (rootPath == null || rootPath.length() == 0) {
      LOGGER.error("Location of failed-value cannot be empty.");
      infoMessage = "Location of failed-value cannot be empty.";
      return;
    }
    FailedDetailReportData data = null;
    SccFileAccess fileAccess = null;
    try {
      final Timestamp checkingTime =
          DateUtils.stringToTimeStamp(fullDetailComp.getCheckingTime(),
              SCConstants.FULL_DATE_FORMAT);

      Long fileId = null;
      String failValuePath = "";
      if (fullDetailComp.getFileId() != null) {
        fileId = Long.valueOf(fullDetailComp.getFileId());
        // get failed value of rule set validation.
        failValuePath =
            rootPath + File.separator + DetailResultUtil.getFilePath(checkingTime, fileId);
        if (folder != null && folder.getFolderType() != FileTypeEnum.NFS) {
          download = true;
        }
      } else {
        failValuePath =
            rootPath
                + File.separator
                + DetailResultUtil.getFilePath(fullDetailComp.getSessionId(), checkingTime,
                    fullDetailComp.getFileUUID());
      }

      final String detailFileName = DetailResultUtil.getResultDetailFileName(ruleVersionId);
      final String dataKey = failValuePath + detailFileName;
      // get data from the cache base on STDF file path
      data = (FailedDetailReportData) SCCache.getInstance().getValueFromCache(dataKey);
      if (data == null) {
        final String headerKey = failValuePath + FailedValueData.HEADER_FILE_NAME;
        Map<Integer, String[]> headerMap =
            (Map<Integer, String[]>) SCCache.getInstance().getValueFromCache(headerKey);

        final String tmpFailPath =
            SCConstants.ROOT_FULL_DETAIL + File.separator + fileId + File.separator;
        if (headerMap == null) {
          File headerFile = null;
          if (download) {
            final FileInfo fileInfo = new FileInfo(headerKey, rootPath, 0);
            fileInfo.setFileType(folder.getFolderType());
            fileInfo.setUserName(folder.getUserName());
            fileInfo.setPassWord(folder.getPassword());
            fileInfo.setPort(folder.getPort());
            fileInfo.setHost(folder.getFileServer());

            fileAccess = FileAccessFactory.copy(fileInfo, fileAccess);
            if (fileAccess != null) {
              if (fileAccess.exists()) {
                headerFile =
                    fileAccess.download(tmpFailPath + FailedValueData.HEADER_FILE_NAME);
              }
            }
          } else {
            headerFile = new File(headerKey);
          }
          if (headerFile != null && headerFile.exists()) {
            headerMap = DetailResultUtil.getHeaderData(headerFile);
            if (download) {
              headerFile.delete();
            }
          }
          SCCache.getInstance().putIntoCache(headerKey, headerMap);
        }

        if (headerMap != null) {
          if (download) {
            final String specialFilePath =
                failValuePath + FailedValueData.SPECIAL_DATA_FILE_NAME;
            File specialFile = new File(tmpFailPath + FailedValueData.SPECIAL_DATA_FILE_NAME);
            if (!specialFile.exists()) {
              final FileInfo fileInfo = new FileInfo(specialFilePath, rootPath, 0);
              fileInfo.setFileType(folder.getFolderType());
              fileInfo.setUserName(folder.getUserName());
              fileInfo.setPassWord(folder.getPassword());
              fileInfo.setPort(folder.getPort());
              fileInfo.setHost(folder.getFileServer());

              fileAccess = FileAccessFactory.copy(fileInfo, fileAccess);
              if (fileAccess != null && fileAccess.exists()) {
                specialFile = fileAccess.download(specialFile.getAbsolutePath());
              }
            }
            final String indexFilePath = failValuePath + detailFileName;
            File indexFile = new File(tmpFailPath + detailFileName);
            if (!indexFile.exists()) {
              FileInfo fileInfo = new FileInfo(indexFilePath, rootPath, 0);
              fileInfo.setFileType(folder.getFolderType());
              fileInfo.setUserName(folder.getUserName());
              fileInfo.setPassWord(folder.getPassword());
              fileInfo.setPort(folder.getPort());
              fileInfo.setHost(folder.getFileServer());

              fileAccess = FileAccessFactory.copy(fileInfo, fileAccess);
              if (fileAccess != null && fileAccess.exists()) {
                indexFile = fileAccess.download(indexFile.getAbsolutePath());
              }
              if (indexFile != null) {
                final RecordEnum recordType = RecordEnum.fromValue(detail.getRecordType());
                if (recordType != null) {
                  final String recordFileName = recordType.getText().toLowerCase();
                  final String recordFilePath = failValuePath + recordFileName;
                  File recordFile = new File(tmpFailPath + recordFileName);
                  if (!recordFile.exists()) {
                    fileInfo = new FileInfo(recordFilePath, rootPath, 0);
                    fileInfo.setFileType(folder.getFolderType());
                    fileInfo.setUserName(folder.getUserName());
                    fileInfo.setPassWord(folder.getPassword());
                    fileInfo.setPort(folder.getPort());
                    fileInfo.setHost(folder.getFileServer());

                    fileAccess = FileAccessFactory.copy(fileInfo, fileAccess);
                    if (fileAccess != null && fileAccess.exists()) {
                      recordFile = fileAccess.download(recordFile.getAbsolutePath());
                    }
                  }
                }
              }
            }
            failValuePath = tmpFailPath;
          }
          // data is not in the cache, get from the file
          data = DetailResultUtil.getFailedReportData(failValuePath, detail, headerMap);
          // put data in the cache for after using.
          SCCache.getInstance().putIntoCache(dataKey, data);
        }
      }
      if (data == null) {
        LOGGER.error("The error loading failured data");
        errorMessage = "The error loading failured data";
        return;
      }

      final String[] headers = data.getHeaders();
      final int colCount = headers.length;

      failuresDataset.appendColumns(colCount);
      final String[] columnNames = new String[colCount];

      for (int i = 0; i < colCount; i++) {
        columnNames[i] = "col_" + i;
      }
      failuresDataset.setColumnNames(columnNames);
      dataviewLables = headers;

      final Object[][] matrix = data.getData();

      failuresDataset.loadFromMatrix(matrix);
    } catch (final Exception e) {
      LOGGER.error(e.getMessage(), e);
    } finally {
      if (fileAccess != null) {
        fileAccess.disconnect();
      }
    }
  }

}
