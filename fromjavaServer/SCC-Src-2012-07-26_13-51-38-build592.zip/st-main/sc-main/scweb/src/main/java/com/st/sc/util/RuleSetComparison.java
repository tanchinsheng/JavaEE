/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 30, 2011 4:29:17 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.util;

import java.util.List;

import com.st.sc.entity.MirCriteria;
import com.st.sc.entity.RuleSetOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleVersion;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleSetComparison {

  public static void differentRuleSet(RuleSetVersion oldVersion, RuleSetVersion newVersion,
      StringBuilder builder) {
    final String connector = ";";
    if (checkStringDifferent(oldVersion.getDescription(), newVersion.getDescription())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Description: OldValue=").append(oldVersion.getDescription())
          .append(", NewValue=").append(newVersion.getDescription());
    }
    if (checkNumberDifferent(oldVersion.getAlarmThreshold(), newVersion.getAlarmThreshold())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Alarm Threshold: OldValue=").append(oldVersion.getAlarmThreshold())
          .append(", NewValue=").append(newVersion.getAlarmThreshold());
    }
    differentMIRCriteria(oldVersion.getMirCriteria(), newVersion.getMirCriteria(), builder);
  }

  public static void differentMIRCriteria(MirCriteria oldEntity, MirCriteria newEntity,
      StringBuilder builder) {
    final String connector = ";";
    if (oldEntity == null && newEntity == null) {
      return;
    }
    if (oldEntity == null) {
      oldEntity = new MirCriteria();
    }
    if (newEntity == null) {
      newEntity = new MirCriteria();
    }
    
    if (checkStringDifferent(oldEntity.getCmodCod(), newEntity.getCmodCod())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.CMOD_COD: OldValue=").append(oldEntity.getCmodCod())
          .append(", NewValue=").append(newEntity.getCmodCod());
    }
    if (checkStringDifferent(oldEntity.getDsgnRev(), newEntity.getDsgnRev())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.DSGN_REV: OldValue=").append(oldEntity.getDsgnRev())
          .append(", NewValue=").append(newEntity.getDsgnRev());
    }
    if (checkStringDifferent(oldEntity.getExecTyp(), newEntity.getExecTyp())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.EXEC_TYP: OldValue=").append(oldEntity.getExecTyp())
          .append(", NewValue=").append(newEntity.getExecTyp());
    }
    if (checkStringDifferent(oldEntity.getExecVer(), newEntity.getExecVer())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.EXEC_VER: OldValue=").append(oldEntity.getExecVer())
          .append(", NewValue=").append(newEntity.getExecVer());
    }
    if (checkStringDifferent(oldEntity.getFlowId(), newEntity.getFlowId())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.FLOW_ID: OldValue=").append(oldEntity.getFlowId())
          .append(", NewValue=").append(newEntity.getFlowId());
    }
    if (checkStringDifferent(oldEntity.getJobNam(), newEntity.getJobNam())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.JOB_NAM: OldValue=").append(oldEntity.getJobNam())
          .append(", NewValue=").append(newEntity.getJobNam());
    }
    if (checkStringDifferent(oldEntity.getJobRev(), newEntity.getJobRev())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.JOB_VER: OldValue=").append(oldEntity.getJobRev())
          .append(", NewValue=").append(newEntity.getJobRev());
    }
    if (checkStringDifferent(oldEntity.getModeCod(), newEntity.getModeCod())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.MODE_COD: OldValue=").append(oldEntity.getModeCod())
          .append(", NewValue=").append(newEntity.getModeCod());
    }
    if (checkStringDifferent(oldEntity.getOperFrq(), newEntity.getOperFrq())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.OPER_FRQ : OldValue=").append(oldEntity.getOperFrq())
          .append(", NewValue=").append(newEntity.getOperFrq());
    }
    if (checkStringDifferent(oldEntity.getPartTyp(), newEntity.getPartTyp())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.PART_TYP : OldValue=").append(oldEntity.getPartTyp())
          .append(", NewValue=").append(newEntity.getPartTyp());
    }
    if (checkStringDifferent(oldEntity.getProcId(), newEntity.getProcId())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.PROC_ID : OldValue=").append(oldEntity.getProcId())
          .append(", NewValue=").append(newEntity.getProcId());
    }
    if (checkStringDifferent(oldEntity.getProcId(), newEntity.getProcId())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.PROC_ID : OldValue=").append(oldEntity.getProcId())
          .append(", NewValue=").append(newEntity.getProcId());
    }
    if (checkStringDifferent(oldEntity.getSpecNam(), newEntity.getSpecNam())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.SPEC_NAM : OldValue=").append(oldEntity.getSpecNam())
          .append(", NewValue=").append(newEntity.getSpecNam());
    }
    if (checkStringDifferent(oldEntity.getSpecVer(), newEntity.getSpecVer())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.SPEC_VER : OldValue=").append(oldEntity.getSpecVer())
          .append(", NewValue=").append(newEntity.getSpecVer());
    }
    if (checkStringDifferent(oldEntity.getSuprNam(), newEntity.getSuprNam())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.SUPR_NAM : OldValue=").append(oldEntity.getSuprNam())
          .append(", NewValue=").append(newEntity.getSuprNam());
    }
    if (checkStringDifferent(oldEntity.getTstrTyp(), newEntity.getTstrTyp())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("MIR.TSTR_TYP : OldValue=").append(oldEntity.getTstrTyp())
          .append(", NewValue=").append(newEntity.getTstrTyp());
    }
  }

  public static boolean checkStringDifferent(String oldValue, String newValue) {
    boolean different = false;
    if (oldValue == null || oldValue.length() == 0) {
      if (newValue != null && newValue.length() > 0) {
        different = true;
      }
    } else {
      different = !oldValue.equals(newValue);
    }
    return different;
  }

  public static boolean checkNumberDifferent(Object oldValue, Object newValue) {
    boolean different = false;
    if (oldValue == null) {
      if (newValue != null) {
        different = true;
      }
    } else {
      different = !oldValue.equals(newValue);
    }
    return different;
  }
  /**
   * Check 2 list users whether different.
   * 
   * @param newUsers
   * @param oldUsers
   * @return true if 2 user list are different.
   */
  public static boolean isUserListDifferent(List<RuleSetOwners> newUsers,
      List<RuleSetOwners> oldUsers) {
    if (newUsers == null || newUsers.size() == 0) {
      if (oldUsers != null && oldUsers.size() > 0) {
        return true;
      }
    } else {
      if (oldUsers == null) {
        return true;
      }
    }
    if (newUsers.size() != oldUsers.size()) {
      return true;
    }
    boolean different = false;
    for (RuleSetOwners newOwner : newUsers) {
      boolean same = false;
      for (RuleSetOwners oldOwner : oldUsers) {
        if (newOwner.getId().getUserName().equalsIgnoreCase(oldOwner.getId().getUserName())) {
          same = true;
          break;
        }
      }
      if (!same) {
        different = true;
      }
    }
    return different;
  }

  public static void differentRule(RuleVersion oldVersion, RuleVersion newVersion,
      StringBuilder builder) {
    final String connector = ";";
    if (checkStringDifferent(oldVersion.getDescription(), newVersion.getDescription())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Description: OldValue=").append(oldVersion.getDescription())
          .append(", NewValue=").append(newVersion.getDescription());
    }
    if (checkNumberDifferent(oldVersion.getLogId(), newVersion.getLogId())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("LogId: OldValue=").append(oldVersion.getLogId()).append(", NewValue=")
          .append(newVersion.getLogId());
    }
    if (checkNumberDifferent(oldVersion.getPoint(), newVersion.getPoint())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Point: OldValue=").append(oldVersion.getPoint()).append(", NewValue=")
          .append(newVersion.getPoint());
    }
  }
}
