/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.dataview.SCDataview;
import st.liotrox.db.DataSet;

import com.st.sc.entity.CompliancyResultEntity;
import com.st.sc.service.ReportService;
import com.st.sc.util.ReportUtil;

/**
 * The Class SCReportDataView.
 */
public class SCReportDataView extends SCDataview {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SCReportDataView.class);

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.SCDataview#updateDataset(st.liotrox.db.DataSet)
   */
  public void updateDataset(final DataSet ds) {
    ReportService service = new ReportService();
    String viewName = ReportUtil.getViewName();

    int pageRows = getPageRows();

    // TODO update row_count of dataset (the data of view possible already
    // updated)
    // setRowCount(service.getViewRowCount(viewName));
    int rowCount = getRowCount();

    // get data from view
    List<CompliancyResultEntity> beans =
        service.getAllViewData(viewName, getFirstDisplayedRow() - 1, pageRows);

    if (LOG.isDebugEnabled()) {
      LOG.debug("beans = " + beans);
    }
    try {
      if (beans.size() > 0) {
        Object[][] matrix = service.buildDatasetMatrix(beans);
        ds.loadFromMatrix(matrix);
      }
    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
    }
  }
}
