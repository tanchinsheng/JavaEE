/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 2:28:09 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.WRequest;

import com.st.common.exception.SccException;
import com.st.common.exception.ServiceException;
import com.st.common.web.LiotroxContants;
import com.st.sc.common.CommonUtils;
import com.st.sc.service.CompliancyReportService;
import com.st.sc.util.DateTimeUtils;
import com.st.sc.web.data.ReportData;
import com.st.scc.common.utils.DateUtils;

/**
 * The Class BaseReportSetting.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public abstract class BaseReportSetting implements Serializable {

  /**
   * 
   */
  protected static final long serialVersionUID = -8963169155866907957L;

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(BaseReportSetting.class);

  /** The Constant FRACTIAL_UNIT. */
  private static final double FRACTIAL_UNIT = 0.01f;

  /** The Constant ASC_ORDER. */
  public static final String ASC_ORDER = "ASC";

  /** The Constant DESC_ORDER. */
  public static final String DESC_ORDER = "DESC";

  private final int MAX_RECORD_LIST = 200000;
  
  /** The number of series. */
  protected int numberOfSeries = 1;

  /** The operator. */
  protected String operator;

  /** The serie values. */
  protected double[] serieValues = new double[]{100 };

  /** The mir field. */
  protected String mirField;

  /**
   * This contains ranges of compliancy score, format : "A% to B%". This is used
   * internal to query data, not used in template file.
   */
  protected String[] scoreRanges;

  /**
   * This is used internal class to check whether call validateInputData().
   * Because when querying data, we must initialize some input, we do it in
   * validateInputData().
   */
  protected boolean alreadyInitData = false;

  /**
   * The time-out time when generating report.
   */
  private long reportTimeOutConfig;
  /**
   * Indicate whether the report is timeout.
   */
  private boolean isTimeOut = false;
  
  /**
   * The Constant THREAD_POOL_SIZE.
   */
  private static final int THREAD_POOL_SIZE = getThreadPoolSize();

  /**
   * Gets the thread pool size.
   * 
   * @return the thread pool size
   */
  private static int getThreadPoolSize() {
    /**
     * no. of threads = no. of CPU * target CPU utilization (> 0 and <=1) *
     * ratio of wait time to compute time
     */
    int nthread = Runtime.getRuntime().availableProcessors() * 8;
    return nthread;
  }

  public abstract String validateInputData();

  public abstract ReportData getDataToShowReport(final String viewName,
      final boolean isOnlineReport) throws SccException;

  public abstract void generateSeries();

  protected String validateInputData(final String textBoxName) {
    LOG.debug("Begin BaseReportSetting.validateInputData()");
    // mark already initialize data
    alreadyInitData = true;

    String value = "";
    String errorMessage = "";
    serieValues = new double[numberOfSeries];
    for (int i = 0; i < numberOfSeries; i++) {
      value = WRequest.getCurrentInstance().getParameter(textBoxName + i);
      if (value == null || value.length() == 0) {
        errorMessage = "Please input series.";
        // don't break here, to keep valid input value of user.
      } else {
        serieValues[i] = CommonUtils.roundDouble(Double.valueOf(value));
      }
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("Number Series=" + numberOfSeries + "; operator=" + operator
          + "; seriesValues=" + Arrays.toString(serieValues));
    }
    if (errorMessage.length() == 0) {
      // validate value of series is valid or not.
      // build compliancy score ranges
      StringBuilder errorMsg = new StringBuilder();
      scoreRanges = getRanges(operator, serieValues, errorMsg);
      if (errorMsg.length() > 0) {
        errorMessage = "Invalid ranges: " + errorMsg.toString();
      }
    }
    LOG.debug("End BaseReportSetting.validateInputData()");
    return errorMessage;
  }

  protected void initializeInputData() {
    if (!alreadyInitData) {
      validateInputData();
    }
    // set false to the next call will initialize data again.
    alreadyInitData = false;
  }

  /**
   * Update setting.
   * 
   * @param setting
   *          must be not null.
   */
  protected void updateSetting(BaseReportSetting setting) {
    if (setting != null) {
      // don't get data from request again.
      setting.alreadyInitData = true;
      setting.setMirField(mirField);
      setting.setNumberOfSeries(numberOfSeries);
      setting.setOperator(operator);
      setting.setScoreRanges(scoreRanges);
      setting.setSerieValues(serieValues);
    }
  }
  
  /**
   * Check the report is timeout.
   * @param startTime
   * @return
   */
  private boolean checkTimeOut(final long startTime) {
    long pastTime = System.currentTimeMillis() - startTime;
    if (reportTimeOutConfig > 0) {
      if (reportTimeOutConfig < pastTime) {
        isTimeOut = true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Do for a future of thread.
   * @param future
   * @param startTime
   * @throws InterruptedException
   * @throws ExecutionException
   */
  private void doFuture(final Future future, final long startTime)
      throws InterruptedException, ExecutionException {
    if (!isTimeOut) {
      try {
    	  // wait for execute query
    	  if(reportTimeOutConfig > 0){
    		  future.get(reportTimeOutConfig, TimeUnit.MILLISECONDS);
    	  } else {
    		  future.get();
    	  }
      } catch (TimeoutException e) {
        isTimeOut = true;
      }
      checkTimeOut(startTime);
    } else {
      // the report is timeout, must cancel all.
      future.cancel(true);
    }
  }

  /**
   * Get data to create score table, bar chart.
   * 
   * @param mirField
   * @param orderOfCategories
   * @param needColumnGroup
   * @param scoreRanges
   *          ranges of compliancy score, format " A% to B%".
   * @param orderOfSeries
   * @param viewName
   *          view name in DB to query data
   * @return
   * @throws SccException
   */
  @SuppressWarnings("unchecked")
  protected ReportData getValuesToCreateScoreTableAndChart(final String mirField,
      final String orderOfCategories, boolean needColumnGroup, final String[] scoreRanges,
      final String orderOfSeries, final String viewName, final boolean isOnlineReport)
      throws SccException {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Begin getValuesToCreateScoreTableAndChart(), MIR field=" + mirField
          + "; orderOfCategories=" + orderOfCategories + "; scoreRanges="
          + Arrays.toString(scoreRanges) + "; orderOfSeries=" + orderOfSeries + "; viewName="
          + viewName);
    }
    final long startTime = System.currentTimeMillis();
    final String mirCriteria = "MIR_" + mirField;
    // check dependencies MIR values: JOB_NAM & JOB_REV, SPEC_NAM & SPEC_VER
    // and EXEC_TYP & EXEC_VER
    String mirVerField = "";
    if (needColumnGroup) {
      mirVerField = findMirVersion(mirCriteria);
    }
    String[] mirFieldName = null;
    if (mirVerField.length() == 0) {
      mirFieldName = new String[]{mirCriteria };
    } else {
      mirFieldName = new String[]{mirCriteria, mirVerField };
    }
    List<Object[]> mirFieldList =
        queryMirValues(mirCriteria, mirVerField, viewName, orderOfCategories);

    if (mirFieldList == null || mirFieldList.size() == 0) {
      return null;
    }
    if(checkTimeOut(startTime)){
      return null;
    }
    
    // put data to map of column group
    final Map<String, List<String>> mapGroupColumns =
        fillDataToMapGroup(mirFieldList, mirVerField.length() > 0);

    // sort order of score ranges following setting.
    if (orderOfSeries != null) {
      // If sort ASC, score ranges is already sorted when call getRanges(),
      // don't sort again, it will fail if there is '100' in ranges.
      if (DESC_ORDER.equals(orderOfSeries)) {
        sortArray(scoreRanges, orderOfSeries);
      }
    }

    final int colCount = mirFieldList.size();
    final int rowCount = scoreRanges.length;

    // matrix data of number stdf file
    final Object[][] matrixData = new Object[rowCount][colCount + 1];

    Map<String, List<String>> groupRows = new LinkedHashMap<String, List<String>>();
    for (int row = 0; row < rowCount; row++) {
      matrixData[row][0] = scoreRanges[row];
      // store text into list.
      groupRows.put(scoreRanges[row], null);
    }

    // create a new thread pool for executes queries from database
    ExecutorService pool;
    if (isOnlineReport) {
      pool = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
    } else {
      pool = Executors.newFixedThreadPool(2);
    }
    try {
      final CompliancyReportService service = new CompliancyReportService();
      // Determine we will query data following column or row.
      if (colCount >= rowCount) {
        // query by Row, Group by MIR field
        Future[] matrixFeatures = new Future[rowCount];
        final String[] mirFields = mirFieldName;
        for (int row = 0; row < rowCount; row++) {
          // parse text to get 2 value to query
          final double[] scores = convertToArr(scoreRanges[row]);
          final int finalRow = row;
          Runnable runable = new Runnable() {
            public void run() {
              List<Object[]> resultList =
                  service.queryGroupByMirField(mirFields, scores[0], scores[1], viewName);

              for (Object[] objects : resultList) {
                int colIndex = findIndexOfMirFieldInMap(objects, mapGroupColumns);
                if (colIndex > -1) {
                  // the first column is score label
                  matrixData[finalRow][colIndex + 1] =
                      ((Number) objects[objects.length - 1]).intValue();
                }
              }
            }
          };
          Future future = pool.submit(runable);
          matrixFeatures[row] = future;
        }
        // wait for all thread finished
        for (int row = 0; row < rowCount; row++) {
          final Future future = matrixFeatures[row];
          doFuture(future, startTime);
        }
      } else {
        // Query by Column, query by each MIR field.
        Future[] matrixFeatures = new Future[colCount];
        final String[] mirFields = mirFieldName;
        for (int col = 0; col < colCount; col++) {
          final String[] mirValues;
          if (mirFields.length > 1) {
            mirValues =
                new String[]{(String) mirFieldList.get(col)[0],
                    (String) mirFieldList.get(col)[1] };
          } else {
            mirValues = new String[]{(String) mirFieldList.get(col)[0] };
          }
          final int finalCol = col;
          Runnable runable = new Runnable() {
            public void run() {
              Map<String, Integer> stdfCount = new LinkedHashMap<String, Integer>();
              int firstRecord = 0;
              while (true) {
                List resultList =
                    service.queryByMirFieldValue(new String[]{"COMPLIANCY_SCORE" }, viewName,
                        mirFields, mirValues, firstRecord, MAX_RECORD_LIST);
                if (resultList != null && resultList.size() > 0) {
                  // Count number stdf in each score ranges.
                  countResultByScoreRange(resultList, scoreRanges, orderOfSeries, stdfCount);
                  int size = resultList.size();
                  resultList.clear();
                  if (size < MAX_RECORD_LIST) {
                    break;
                  }
                  firstRecord += MAX_RECORD_LIST;
                } else {
                  break;
                }
              }
              for (int row = 0; row < rowCount; row++) {
                // the first column is score label
                matrixData[row][finalCol + 1] = stdfCount.get(scoreRanges[row]);
              }
            }
          };
          Future future = pool.submit(runable);
          matrixFeatures[col] = future;
        }
        // wait for all thread finish
        for (int col = 0; col < colCount; col++) {
          Future future = matrixFeatures[col];
          doFuture(future, startTime);
        }
      }
      pool.shutdown();

    } catch (PersistenceException e) {
      throw new ServiceException(e);
    } catch (Throwable e) {
      throw new SccException(e);
    } finally {
      try {
        pool.awaitTermination(2, TimeUnit.SECONDS);
      } catch (InterruptedException ie) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(ie.getMessage(), ie);
        }
      }
    }
    if (isTimeOut) {
      return null;
    }

    // update matrix on null cell, from 1.(first column is label)
    updateZeroForMatrix(matrixData, 1);

    int[] columnLabelIndexs = new int[mapGroupColumns.keySet().size()];
    String[] columnLabels = ReportData.parseMapToArray(mapGroupColumns, columnLabelIndexs);
    int[] rowLabelIndexs = new int[groupRows.keySet().size()];
    String[] rowLabels = ReportData.parseMapToArray(groupRows, rowLabelIndexs);
    ReportData dataEntity =
        new ReportData(columnLabels, columnLabelIndexs, rowLabels, rowLabelIndexs, matrixData);

    LOG.debug("End BaseReportSetting.getValuesToCreateScoreTableAndChart()");
    return dataEntity;
  }

  /**
   * Get data to create trend table, trend and line chart.
   * 
   * @param columnOption
   * @param rowOption
   * @param groupBy
   * @param mirField
   * @param scoreRanges
   *          ranges of compliancy score, format " A% to B%".
   * @param rowSortOrder
   * @param viewName
   *          view name in DB to query data.
   * @return
   * @throws SccException
   */
  @SuppressWarnings("unchecked")
  protected ReportData getValuesToCreateTrendTableAndChart(final String columnOption,
      final String rowOption, final String groupBy, final String mirField,
      final String[] scoreRanges, final String rowSortOrder, final String viewName,
      final boolean isOnlineReport)
      throws SccException {
    final CompliancyReportService service = new CompliancyReportService();
    if (LOG.isDebugEnabled()) {
      LOG.debug("Begin getValuesToCreateTrendTableAndChart(), columnOption=" + columnOption
          + "; rowOption=" + rowOption + "; groupBy=" + groupBy + "; MIR field=" + mirField
          + "; scoreRanges=" + Arrays.toString(scoreRanges) + "; rowSortOrder=" + rowSortOrder
          + "; viewName=" + viewName);
    }
    final long startTime = System.currentTimeMillis();
    List<Date> dates = service.getMinMaxDate(groupBy, viewName);
    if (dates == null) {
      return null;
    }
    Date from = dates.get(0); //service.getFromDate(groupBy, viewName);
    Date to = dates.get(1); //service.getToDate(groupBy, viewName);
    
    if (checkTimeOut(startTime)) {
      return null;
    }
    // get X axis, this is categories
    final String[] shortHeader;
    final String[] headerLabels;
    final int[] year;

    if (TrendTableSetting.WEEK_OPTION.equals(columnOption)) {
      String[] tmp = DateTimeUtils.getWeekNumbers(from, to);
      headerLabels = new String[tmp.length];
      shortHeader = new String[tmp.length];
      year = new int[tmp.length];

      for (int i = 0; i < tmp.length; i++) {
        String[] weekAndYear = tmp[i].split(DateTimeUtils.CONNECTOR_WEEK);
        year[i] = Integer.parseInt(weekAndYear[1]);
        headerLabels[i] =
            "W"
                + weekAndYear[0]
                + "("
                + DateUtils.dateToString(DateTimeUtils.getFirstDayFromWeekNumber(
                    Integer.parseInt(weekAndYear[0]), Integer.parseInt(weekAndYear[1])),
                    LiotroxContants.DEFAULT_DATE_FORMAT) + ")";
        shortHeader[i] = "W" + weekAndYear[0];
      }
    } else if (TrendTableSetting.MONTH_OPTION.equals(columnOption)) {
      headerLabels = DateUtils.getMonthDate(from, to);
      shortHeader = headerLabels;
      // don't need year, year is included in label of month.
      year = null;
    } else if (TrendTableSetting.QUARTER_OPTION.equals(columnOption)) {
      String[] tmp = DateUtils.getQuarterNumbers(from, to);
      headerLabels = new String[tmp.length];
      shortHeader = new String[tmp.length];
      year = new int[tmp.length];

      for (int i = 0; i < tmp.length; i++) {
        String[] quaterAndYear = tmp[i].split(DateUtils.CONNECTOR_QUATER);
        year[i] = Integer.parseInt(quaterAndYear[1]);

        headerLabels[i] = "Q" + quaterAndYear[0] + DateUtils.CONNECTOR_QUATER + year[i];
        shortHeader[i] = "Q" + quaterAndYear[0];
      }
    } else {
      return null;
    }

    final Map<String, List<String>> mapGroupRows;
    final Object[][] matrixData;
    if (TrendTableSetting.MIR_FIELD_OPTION.equals(rowOption)) {
      final String mirCriteria = "MIR_" + mirField;
      // check dependencies MIR values: JOB_NAM & JOB_REV, SPEC_NAM & SPEC_VER
      // and EXEC_TYP & EXEC_VER
      String mirVerField = findMirVersion(mirCriteria);
      String[] mirFieldName = null;
      if (mirVerField.length() == 0) {
        mirFieldName = new String[]{mirCriteria };
      } else {
        mirFieldName = new String[]{mirCriteria, mirVerField };
      }
      List<Object[]> mirFieldList =
          queryMirValues(mirCriteria, mirVerField, viewName, rowSortOrder);

      if (mirFieldList == null || mirFieldList.size() == 0) {
        return null;
      }
      if (checkTimeOut(startTime)) {
        return null;
      }

      // put data to map of row group
      mapGroupRows = fillDataToMapGroup(mirFieldList, mirVerField.length() > 0);

      final int numberFirstColumn;
      if (mirVerField.length() > 0) {
        numberFirstColumn = 2;
      } else {
        numberFirstColumn = 1;
      }
      final int columnCount = headerLabels.length;
      final int rowCount = mirFieldList.size();

      // matrix contains data queried from DB.
      matrixData = new Object[rowCount][columnCount + numberFirstColumn];

      // fill values to first or (first and second) column,
      // it is labels, don't need query.
      int rowIndex = 0;
      for (String group : mapGroupRows.keySet()) {
        List<String> ls = mapGroupRows.get(group);
        if (ls == null) {
          // column 0
          matrixData[rowIndex++][0] = group;
        } else {
          for (String value : ls) {
            // column 1
            matrixData[rowIndex][0] = group;
            // column 2
            matrixData[rowIndex][1] = value;
            rowIndex++;
          }
        }
      }

      // create a new thread pool for executes queries from database
      ExecutorService pool;
      if (isOnlineReport) {
        pool = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
      } else {
        pool = Executors.newFixedThreadPool(2);
      }
      try {
        // Determine we will query data following column or row.
        if (columnCount <= rowCount) {
          // query by Column, group by MIR
          Future[] matrixFeatures = new Future[columnCount];
          final String[] mirFields = mirFieldName;
          for (int col = 0; col < columnCount; col++) {
            final Date[] fromToArr = getFromTo(columnOption, shortHeader, year, col);
            final int finalCol = col;
            Runnable runable = new Runnable() {
              public void run() {
                List<Object[]> resultList =
                    service.queryGroupByMirField(mirFields, viewName, fromToArr[0],
                        fromToArr[1], groupBy);

                for (Object[] objects : resultList) {
                  int rowFoundIndex = findIndexOfMirFieldInMap(objects, mapGroupRows);
                  if (rowFoundIndex > -1) {
                    matrixData[rowFoundIndex][finalCol + numberFirstColumn] =
                        ((Number) objects[objects.length - 1]).intValue();
                  }
                }
              }
            };
            Future future = pool.submit(runable);
            matrixFeatures[col] = future;
          }
          // wait retrieves data from the thread pool
          for (int col = 0; col < columnCount; col++) {
            Future future = matrixFeatures[col];
            doFuture(future, startTime);
          }
        } else {
          // Query following Row, query by each MIR value
          Future[] matrixFeatures = new Future[rowCount];
          final String[] mirFields = mirFieldName;
          for (int row = 0; row < rowCount; row++) {
            final String[] mirValues;
            if (mirFields.length > 1) {
              mirValues =
                  new String[]{(String) mirFieldList.get(row)[0],
                      (String) mirFieldList.get(row)[1] };
            } else {
              mirValues = new String[]{(String) mirFieldList.get(row)[0] };
            }
            final int finalRow = row;
            Runnable runable = new Runnable() {
              public void run() {
                Map<String, Integer> stdfCount = new LinkedHashMap<String, Integer>();
                int firstRecord = 0;
                while (true) {
                  List resultList =
                      service.queryByMirFieldValue(new String[]{groupBy }, viewName,
                          mirFields, mirValues, firstRecord, MAX_RECORD_LIST);
                  if (resultList != null && resultList.size() > 0) {
                    // Count number stdf in each time ranges.
                    countResultByTimeRange(resultList, columnOption, shortHeader, year,
                        stdfCount);
                    int size = resultList.size();
                    resultList.clear();
                    if (size < MAX_RECORD_LIST) {
                      break;
                    }
                    firstRecord += MAX_RECORD_LIST;
                  } else {
                    break;
                  }
                }
                for (int col = 0; col < columnCount; col++) {
                  matrixData[finalRow][col + numberFirstColumn] =
                      stdfCount.get(createKeyOfMap(shortHeader[col], year != null ? year[col]
                          : 0));
                }
              }
            };
            Future future = pool.submit(runable);
            matrixFeatures[row] = future;
          }
          // wait retrieves data from the thread pool
          for (int row = 0; row < rowCount; row++) {
            Future future = matrixFeatures[row];
            doFuture(future, startTime);
          }
        }
        pool.shutdown();
        
        // update matrix on null cell, (these first columns are labels)
        updateZeroForMatrix(matrixData, numberFirstColumn);
        
      } catch (PersistenceException e) {
        throw new ServiceException(e);
      } catch (Throwable e) {
        throw new SccException(e);
      } finally {
        try {
          pool.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException ie) {
          if (LOG.isDebugEnabled()) {
            LOG.debug(ie.getMessage(), ie);
          }
        }
      }

    } else if (TrendTableSetting.NUMBER_OF_STDF_OPTION.equals(rowOption)) {

      // sort order of compliancy score range following setting.
      if (rowSortOrder != null) {
        // If sort ASC, score ranges is already sorted when call getRanges(),
        // don't sort again, it will fail if there is '100' in ranges.
        if (DESC_ORDER.equals(rowSortOrder)) {
          sortArray(scoreRanges, rowSortOrder);
        }
      }

      final int columnCount = headerLabels.length;
      final int rowCount = scoreRanges.length;

      // matrix contains data queried from DB.
      matrixData = new Object[rowCount][columnCount + 1];
      mapGroupRows = new LinkedHashMap<String, List<String>>();
      // fill values to first column,
      // it is labels, don't need query.
      for (int row = 0; row < rowCount; row++) {
        // column 1
        matrixData[row][0] = scoreRanges[row];

        // put data to group to return
        mapGroupRows.put(scoreRanges[row], null);
      }

      // create a new thread pool for executes queries from database
      ExecutorService pool = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
      try {
        // Determine whether we will query following column or by row
        if (rowCount >= columnCount) {
          // Query by column, query following time range
          Future[] matrixFeatures = new Future[columnCount];
          for (int col = 0; col < columnCount; col++) {
            final Date[] fromToArr = getFromTo(columnOption, shortHeader, year, col);
            final int finalCol = col;
            Runnable runable = new Runnable() {
              public void run() {
                Map<String, Integer> stdfCount = new LinkedHashMap<String, Integer>();
                int firstRecord = 0;
                while (true) {
                  List resultList =
                      service.queryByTimeRange(new String[]{"COMPLIANCY_SCORE" }, viewName,
                          fromToArr[0], fromToArr[1], groupBy, firstRecord, MAX_RECORD_LIST);
                  if (resultList != null && resultList.size() > 0) {
                    // Count number stdf in each time ranges.
                    countResultByScoreRange(resultList, scoreRanges, rowSortOrder, stdfCount);
                    int size = resultList.size();
                    resultList.clear();
                    if (size < MAX_RECORD_LIST) {
                      break;
                    }
                    firstRecord += MAX_RECORD_LIST;
                  } else {
                    break;
                  }
                }
                for (int row = 0; row < rowCount; row++) {
                  // the first column is score label
                  matrixData[row][finalCol + 1] = stdfCount.get(scoreRanges[row]);
                }
              }
            };
            Future future = pool.submit(runable);
            matrixFeatures[col] = future;
          }
          // wait retrieves data from the thread pool
          for (int col = 0; col < columnCount; col++) {
            Future future = matrixFeatures[col];
            doFuture(future, startTime);
          }
        } else {
          // Query by row, query following score range
          Future[] matrixFeatures = new Future[rowCount];
          for (int row = 0; row < rowCount; row++) {
            // parse text to get 2 value to query
            final double[] scores = convertToArr(scoreRanges[row]);
            final int finalRow = row;
            Runnable runable = new Runnable() {
              public void run() {
                Map<String, Integer> stdfCount = new LinkedHashMap<String, Integer>();
                int firstRecord = 0;
                while (true) {
                  List resultList =
                      service.queryByScoreRange(new String[]{groupBy }, viewName, scores[0],
                          scores[1], firstRecord, MAX_RECORD_LIST);
                  if (resultList != null && resultList.size() > 0) {
                    countResultByTimeRange(resultList, columnOption, shortHeader, year,
                        stdfCount);
                    int size = resultList.size();
                    resultList.clear();
                    if (size < MAX_RECORD_LIST) {
                      break;
                    }
                    // Still has record, continue query
                    firstRecord += MAX_RECORD_LIST;
                  } else {
                    break;
                  }
                }
                for (int col = 0; col < columnCount; col++) {
                  // the first column is score label.
                  matrixData[finalRow][col + 1] =
                      stdfCount.get(createKeyOfMap(shortHeader[col], year != null ? year[col]
                          : 0));
                }
              }
            };
            Future future = pool.submit(runable);
            matrixFeatures[row] = future;
          }
          // wait retrieves data from the thread pool
          for (int row = 0; row < rowCount; row++) {
            Future future = matrixFeatures[row];
            doFuture(future, startTime);
          }
        }
        pool.shutdown();
        
        // update zero for null cell, exclude the first label column
        updateZeroForMatrix(matrixData, 1);
        
      } catch (PersistenceException e) {
        throw new ServiceException(e);
      } catch (Throwable e) {
        e.printStackTrace();
        throw new SccException(e);
      } finally {
        try {
          pool.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException ie) {
          if (LOG.isDebugEnabled()) {
            LOG.debug(ie.getMessage(), ie);
          }
        }
      }
    } else {
      return null;
    }

    if (isTimeOut) {
      return null;
    }

    int[] headerLabelIndexs = new int[headerLabels.length];
    for (int i = 0; i < headerLabelIndexs.length; i++) {
      headerLabelIndexs[i] = i;
    }
    int[] rowLabelIndexs = new int[mapGroupRows.keySet().size()];
    String[] rowLabels = ReportData.parseMapToArray(mapGroupRows, rowLabelIndexs);

    ReportData data =
        new ReportData(headerLabels, headerLabelIndexs, rowLabels, rowLabelIndexs, matrixData);

    LOG.debug("End BaseReportSetting.getValuesToCreateTrendTableAndChart()");
    return data;
  }

  /**
   * Query MIR values. Sort MIR value following orderBy, default is sorted ASC.
   * 
   * @param baseMirField
   * @param mirVerField
   * @param viewName
   * @param orderBy
   * @return
   */
  private List<Object[]> queryMirValues(final String baseMirField, final String mirVerField,
      final String viewName, final String orderBy) {
    final CompliancyReportService service = new CompliancyReportService();
    List<Object[]> mirFieldList = null;
    if (mirVerField.length() == 0) {
      String[] mirFieldName = new String[]{baseMirField };
      List<String> mirValues = service.queryMirFieldValues(mirFieldName, viewName, null);
      if (mirValues != null) {
        mirFieldList = new ArrayList<Object[]>();
        for (String mir : mirValues) {
          mirFieldList.add(new Object[]{mir });
        }
      }
    } else {
      String[] mirFieldName = new String[]{baseMirField, mirVerField };
      mirFieldList = service.queryMirFieldValues(mirFieldName, viewName, null);
    }
    if (mirFieldList != null) {
      MirFieldComparator comparator = new MirFieldComparator();
      Collections.sort(mirFieldList, comparator);
      if (DESC_ORDER.equals(orderBy)) {
        Collections.reverse(mirFieldList);
      }
    }
    return mirFieldList;
  }

  /**
   * Fill data to map.
   * 
   * @param mirFieldList
   * @param groupMirField
   * @return
   */
  private Map<String, List<String>> fillDataToMapGroup(final List<Object[]> mirFieldList,
      final boolean groupMirField) {
    Map<String, List<String>> mapGroup = new LinkedHashMap<String, List<String>>();
    if (groupMirField) {
      for (Object[] pairValues : mirFieldList) {
        List<String> mirVerList = mapGroup.get((String) pairValues[0]);
        if (mirVerList == null) {
          mirVerList = new ArrayList<String>();
        }
        mirVerList.add((String) pairValues[1]);
        mapGroup.put((String) pairValues[0], mirVerList);
      }
    } else {
      for (Object[] pairValues : mirFieldList) {
        mapGroup.put((String) pairValues[0], null);
      }
    }
    return mapGroup;
  }

  /**
   * Find MIR version of a mir field.
   * 
   * @param mirCriteria
   * @return
   */
  private String findMirVersion(final String mirCriteria) {
    String mirVerField = "";
    if ("MIR_JOB_NAM".equals(mirCriteria)) {
      mirVerField = "MIR_JOB_REV";
    } else if ("MIR_SPEC_NAM".equals(mirCriteria)) {
      mirVerField = "MIR_SPEC_VER";
    } else if ("MIR_EXEC_TYP".equals(mirCriteria)) {
      mirVerField = "MIR_EXEC_VER";
    }
    return mirVerField;
  }

  /**
   * Find the index of result in map MIR field.
   * 
   * @param resultObjects
   * @param map
   * @return
   */
  private int findIndexOfMirFieldInMap(final Object[] resultObjects,
      final Map<String, List<String>> map) {
    // find column index
    int colIndex = 0;
    boolean isFind = false;
    Set<Entry<String, List<String>>> entrySet = map.entrySet();
    for (Entry<String, List<String>> entry : entrySet) {
      List<String> list = entry.getValue();
      // compare MIR value
      if (compareString(entry.getKey(), (String) resultObjects[0]) == 0) {
        if (list == null) {
          // No MIR version, we find correct index
          isFind = true;
          break;
        } else {
          for (String mirVer : list) {
            if (compareString(mirVer, (String) resultObjects[1]) == 0) {
              isFind = true;
              break;
            }
            colIndex++;
          }
          if (isFind) {
            break;
          }
        }
      } else {
        if (list == null) {
          colIndex++;
        } else {
          colIndex += list.size();
        }
      }
    }
    if (isFind) {
      return colIndex;
    }
    return -1;
  }

  /**
   * Update zero value for null cell.
   * 
   * @param matrix
   * @param startColum
   */
  private void updateZeroForMatrix(final Object[][] matrix, int startColum) {
    int rowCount = matrix.length;
    int columnCount = 0;
    if (rowCount > 0) {
      columnCount = matrix[0].length;
    }
    for (int i = 0; i < rowCount; i++) {
      for (int j = startColum; j < columnCount; j++) {
        if (matrix[i][j] == null) {
          matrix[i][j] = 0;
        }
      }
    }
  }

  /**
   * Count number stdf from result, by score ranges.
   * @param resultList
   * @param scoreRanges
   * @param orderOfScore
   * @param stdfCount contain result
   */
  private void countResultByScoreRange(final List resultList, final String[] scoreRanges,
      final String orderOfScore, final Map<String, Integer> stdfCount) {
    long startTime = System.currentTimeMillis();
    LOG.debug("Begin count number stdf of each score range");

    if (resultList == null || resultList.size() == 0) {
      LOG.debug("countResultByScoreRange(): List is empty");
      return;
    }
    int k = 0;
    // ignore null element
    while (k < resultList.size() && resultList.get(k) == null) {
      k++;
    }
    if (k == resultList.size()) {
      LOG.debug("countResultByScoreRange(): All element of list is NULL.");
      return;
    }
    boolean isNumber = true;
    if (resultList.get(k).getClass().isArray()) {
      isNumber = false;
    }
    final int rowCount = scoreRanges.length;
    for (; k < resultList.size(); k++) {
      Number number = null;
      if (isNumber) {
        number = (Number) resultList.get(k);
      } else {
        // Results of 'Select where rownum > ? and rownum <?'
        Object[] objects = (Object[]) resultList.get(k);
        number = (Number) objects[0];
      }
      // count number stdf by score range
      double[] scores;
      double value = number.doubleValue();
      // score ranges is sorted, we use binary search
      int l = 0;
      int r = rowCount - 1;
      while (l <= r) {
        int midIndex = (l + r) / 2;
        // parse text to get 2 value to query
        scores = convertToArr(scoreRanges[midIndex]);
        if (scores[0] <= value && scores[1] >= value) {
          Integer count = stdfCount.get(scoreRanges[midIndex]);
          if (count == null) {
            count = 0;
          }
          count++;
          stdfCount.put(scoreRanges[midIndex], count);
          // don't scan
          break;
        }
        if (DESC_ORDER.equals(orderOfScore)) {
          if (scores[0] > value) {
            l = midIndex + 1;
          } else if (scores[1] < value) {
            r = midIndex - 1;
          }
        } else {
          // Default is sorted increase.
          if (scores[0] > value) {
            r = midIndex - 1;
          } else if (scores[1] < value) {
            l = midIndex + 1;
          }
        }
      }
      // for (int row = 0; row < rowCount; row++) {
      // // parse text to get 2 value to query
      // scores = convertToArr(scoreRanges[row]);
      // if (scores[0] <= value && scores[1] >= value) {
      // Integer count = stdfCount.get(scoreRanges[row]);
      // if (count == null) {
      // count = 0;
      // }
      // count++;
      // stdfCount.put(scoreRanges[row], count);
      // //don't scan
      // break;
      // }
      // }
    }

    LOG.debug("Finished count number stdf of each score range, total time="
        + (System.currentTimeMillis() - startTime));
  }

  /**
   * 
   * @param resultList
   * @param timeOption Checked_Time or finished_T or Start_T
   * @param header list header of table, each header is a time range.
   * @param year if header is week, this contains year corresponding with each week.
   * @param stdfCount contain result, number stdf files of each time range
   */
  private void countResultByTimeRange(final List resultList,
      final String timeOption, String[] header, int[] year,final Map<String, Integer> stdfCount) {
    long startTime = System.currentTimeMillis();
    LOG.debug("Begin count number stdf of each time range");
    if (resultList == null || resultList.size() == 0) {
      LOG.debug("countResultByTimeRange(): List is empty.");
      return;
    }
    int k = 0;
    // ignore null element
    while (k < resultList.size() && resultList.get(k) == null) {
      k++;
    }
    if (k == resultList.size()) {
      LOG.debug("countResultByTimeRange(): All element of list is NULL.");
      return;
    }
    boolean isTime = true;
    if (resultList.get(k).getClass().isArray()) {
      isTime = false;
    }
    final int columnCount = header.length;
    for (; k < resultList.size(); k++) {
      Timestamp time = null;
      if (isTime) {
        time = (Timestamp) resultList.get(k);
      } else {
        // Results of 'Select where rownum > ? and rownum <?'
        Object[] objects = (Object[]) resultList.get(k);
        time = (Timestamp) objects[0];
      }
      if (time == null) {
        continue;
      }
      // count number stdf by score range
      long value = time.getTime();
      // because time ranges are sorted, we apply binary search.
      int l = 0;
      int r = columnCount - 1;
      while (l <= r) {
        int midIndex = (l + r) / 2;
        final Date[] fromToArr = getFromTo(timeOption, header, year, midIndex);
        if (fromToArr[0].getTime() <= value && fromToArr[1].getTime() >= value) {
          String key = createKeyOfMap(header[midIndex], year != null ? year[midIndex] : 0);
          Integer count = stdfCount.get(key);
          if (count == null) {
            count = 0;
          }
          count++;
          stdfCount.put(key, count);
          // don't scan
          break;
        }
        if (fromToArr[0].getTime() > value) {
          r = midIndex - 1;
        } else if (fromToArr[1].getTime() < value) {
          l = midIndex + 1;
        }

        // for (int col = 0; col < columnCount; col++) {
        // final Date[] fromToArr = getFromTo(timeOption, header, year, col);
        // if (fromToArr[0].getTime() <= value && fromToArr[1].getTime() >=
        // value) {
        // Integer count = stdfCount.get(createKeyOfMap(header[col],
        // year[col]));
        // if (count == null) {
        // count = 0;
        // }
        // count++;
        // stdfCount.put(createKeyOfMap(header[col], year[col]), count);
        // //don't scan
        // break;
        // }
        // }
      }
    }
    LOG.debug("Finished count number stdf of each time range, total time="
        + (System.currentTimeMillis() - startTime));
  }

  private String createKeyOfMap(String str1, int number) {
    return str1 + "_" + number;
  }

  /**
   * Gets the ranges.
   * 
   * @param op
   *          the op
   * @param arr
   *          the arr
   * @return the ranges
   */
  private static String[] getRanges(final String op, final double[] arr,
      StringBuilder errorMessage) {
    List<String> ranges = new ArrayList<String>();
    if (op == null || arr.length == 0) {
      return new String[0];
    }
    // Must sort array before get ranges to create true orders.
    Arrays.sort(arr);
    // Check series is not same.
    boolean haveSame = false;
    for (int i = 0; i < arr.length - 1; i++) {
      if (arr[i] == arr[i + 1]) {
        haveSame = true;
        break;
      }
    }
    if (haveSame) {
      errorMessage.append("Series must be different.");
      return new String[0];
    }
    if ("<".equals(op) && arr[0] == 0) {
      errorMessage.append(op + arr[0]);
      return new String[0];
    }
    if (">".equals(op) && arr[arr.length - 1] == 100) {
      errorMessage.append(op + arr[arr.length - 1]);
      return new String[0];
    }

    final String TO_CONNECTOR = "% to ";
    final String END_CONNECTOR = "%";
    double fromValue = 0;
    double toValue = 0;
    // build middle ranges
    for (int i = 0; i < arr.length - 1; i++) {
      if ("<".equals(op)) {
        fromValue = arr[i];
        toValue = CommonUtils.roundDouble(arr[i + 1] - FRACTIAL_UNIT);
      } else if ("<=".equals(op)) {
        if (arr[i] >= 0) {
          fromValue = CommonUtils.roundDouble(arr[i] + FRACTIAL_UNIT);
        } else {
          fromValue = 0;
        }
        toValue = CommonUtils.roundDouble(arr[i + 1]);
      } else if (">".equals(op)) {
        fromValue = CommonUtils.roundDouble(arr[i] + FRACTIAL_UNIT);
        double tmp = arr[i + 1];
        if (tmp > 100) {
          tmp = 100;
        }
        toValue = CommonUtils.roundDouble(tmp);
      } else if (">=".equals(op)) {
        fromValue = CommonUtils.roundDouble(arr[i]);
        double tmp = arr[i + 1];
        if (tmp > 100) {
          tmp = 100;
        } else {
          tmp = tmp - FRACTIAL_UNIT;
        }
        toValue = CommonUtils.roundDouble(tmp);
      }
      ranges.add(fromValue + TO_CONNECTOR + toValue + END_CONNECTOR);

    }
    // build first range
    if ("<".equals(op)) {
      if (arr[0] > 0) {
        fromValue = 0;
        toValue = CommonUtils.roundDouble(arr[0] - FRACTIAL_UNIT);
        ranges.add(0, fromValue + TO_CONNECTOR + toValue + END_CONNECTOR);
      }
    } else if ("<=".equals(op)) {
      if (arr[0] >= 0) {
        fromValue = 0;
        toValue = CommonUtils.roundDouble(arr[0]);
        ranges.add(0, fromValue + TO_CONNECTOR + toValue + END_CONNECTOR);
      }
    }

    // build last range
    if (">=".equals(op)) {
      double tmp = arr[arr.length - 1];
      if (tmp <= 100) {
        fromValue = CommonUtils.roundDouble(tmp);
        toValue = 100;
        ranges.add(fromValue + TO_CONNECTOR + toValue + END_CONNECTOR);
      }
    } else if (">".equals(op)) {
      double tmp = arr[arr.length - 1];
      if (tmp < 100) {
        fromValue = CommonUtils.roundDouble(tmp + FRACTIAL_UNIT);
        toValue = 100;
        ranges.add(fromValue + TO_CONNECTOR + toValue + END_CONNECTOR);
      }
    }

    return ranges.toArray(new String[ranges.size()]);
  }

  /**
   * Convert to arr.
   * 
   * @param range
   *          the range
   * @return the double[]
   */
  private static double[] convertToArr(final String range) {
    String arr[] = range.split("to");
    double d1 = Double.valueOf(arr[0].split("%")[0].trim());
    double d2 = Double.valueOf(arr[1].split("%")[0].trim());
    return new double[]{d1, d2 };
  }

  /**
   * Gets the from to.
   * 
   * @param timeOption
   *          the time option
   * @param header
   *          the header
   * @param year
   *          the year
   * @param headerIndex
   *          the header index
   * @return the from to
   * @throws ParseException
   *           the parse exception
   */
  private static Date[] getFromTo(final String timeOption, final String[] header,
      final int[] year, final int headerIndex) {
    Calendar cal = Calendar.getInstance();

    Date fromTime = null;
    Date toTime = null;
    if ("w".equals(timeOption)) {
      int weekNum = Integer.valueOf(header[headerIndex].substring(1));
      fromTime = DateTimeUtils.getFirstDayFromWeekNumber(weekNum, year[headerIndex]);
      toTime = DateTimeUtils.getLastDayFromWeekNumber(weekNum, year[headerIndex]);
    } else if ("m".equals(timeOption)) {
      Date tmpDate = DateUtils.strToDate(header[headerIndex], "MMM-yyyy");
      cal.clear();
      cal.setTimeInMillis(tmpDate.getTime());
      cal.set(Calendar.DAY_OF_MONTH, 1);
      fromTime = cal.getTime();
      cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
      toTime = cal.getTime();
    } else if ("q".equals(timeOption)) {
      int quarterNum = Integer.valueOf(header[headerIndex].substring(1));
      int startMonth = (quarterNum - 1) * 3 + 1;
      int endMonth = quarterNum * 3;

      Date tmpDate = DateUtils.strToDate(startMonth + "-" + year[headerIndex], "MM-yyyy");
      cal.setTimeInMillis(tmpDate.getTime());
      fromTime = cal.getTime();

      tmpDate = DateUtils.strToDate(endMonth + "-" + year[headerIndex], "MM-yyyy");
      cal.setTimeInMillis(tmpDate.getTime());
      cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
      toTime = cal.getTime();
    }
    if (fromTime != null) {
      // Reset from time to : 0h,0minute,0s
      cal.clear();
      cal.setTimeInMillis(fromTime.getTime());
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 0);
      cal.set(Calendar.MILLISECOND, 0);
      fromTime = cal.getTime();
    }
    if (toTime != null) {
      // Reset to time to : 23h,59m,59s.
      cal.clear();
      cal.setTimeInMillis(toTime.getTime());
      cal.set(Calendar.HOUR_OF_DAY, 23);
      cal.set(Calendar.MINUTE, 59);
      cal.set(Calendar.SECOND, 59);
      cal.set(Calendar.MILLISECOND, 999);
      toTime = cal.getTime();
    }

    return new Date[]{fromTime, toTime };
  }

  /**
   * Sort array.
   * 
   * @param <T>
   *          the generic type
   * @param values
   *          the values
   * @param order
   *          the order
   */
  private static <T> void sortArray(T[] values, final String order) {
    if (values != null && values.length > 1) {
      if (ASC_ORDER.equals(order)) {
        Arrays.sort(values);
      } else if (DESC_ORDER.equals(order)) {
        // Arrays.sort(values);
        // reverse order
        T tmp;
        final int l = values.length - 1;
        final int mid = values.length / 2;
        for (int i = 0; i < mid; i++) {
          tmp = values[i];
          values[i] = values[l - i];
          values[l - i] = tmp;
        }
      }
    }
  }

  /**
   * Generate series.
   * 
   * @param numberSeries
   *          the number series
   * @return the double[]
   */
  protected static double[] generateSeries(final int numberSeries) {
    double step = 100.0 / (numberSeries);
    double[] series = new double[numberSeries];
    series[numberSeries - 1] = 100;
    for (int i = 0; i < numberSeries - 1; i++) {
      series[i] = CommonUtils.roundDouble((i + 1) * step);
    }
    return series;
  }

  /**
   * Compare 2 string. Return 0 if they are equal.
   * 
   * @param str1
   * @param str2
   * @return
   */
  private int compareString(final String str1, final String str2) {
    if (str1 == null && str2 == null) {
      return 0;
    }
    if (str1 == null) {
      return -1;
    }
    if (str2 == null) {
      return 1;
    }
    return str1.compareTo(str2);
  }

  private class MirFieldComparator implements Comparator<Object[]> {

    /**
     * 2 arrays are not null and the length are equals. {@inheritDoc}
     * 
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(Object[] o1, Object[] o2) {
      // 2 array are not null and the length are equals.
      int rs = 0;
      for (int i = 0; i < o1.length; i++) {
        rs = compareString((String) o1[i], (String) o2[i]);
        if (rs != 0) {
          return rs;
        }
      }
      return 0;
    }
  }

  /**
   * @return the numberOfSeries
   */
  public int getNumberOfSeries() {
    return numberOfSeries;
  }

  /**
   * @param numberOfSeries
   *          the numberOfSeries to set
   */
  public void setNumberOfSeries(int numberOfSeries) {
    this.numberOfSeries = numberOfSeries;
  }

  /**
   * @return the operator
   */
  public String getOperator() {
    return operator;
  }

  /**
   * @param operator
   *          the operator to set
   */
  public void setOperator(String operator) {
    this.operator = operator;
  }

  /**
   * @return the serieValues
   */
  public double[] getSerieValues() {
    return serieValues;
  }

  /**
   * @param serieValues
   *          the serieValues to set
   */
  public void setSerieValues(double[] serieValues) {
    this.serieValues = serieValues;
  }

  /**
   * @return the mirField
   */
  public String getMirField() {
    return mirField;
  }

  /**
   * @param mirField
   *          the mirField to set
   */
  public void setMirField(String mirField) {
    this.mirField = mirField;
  }

  /**
   * @return the scoreRanges
   */
  public String[] getScoreRanges() {
    return scoreRanges;
  }

  /**
   * @param scoreRanges
   *          the scoreRanges to set
   */
  public void setScoreRanges(String[] scoreRanges) {
    this.scoreRanges = scoreRanges;
  }

  public void setReportTimeOutConfig(long time) {
    reportTimeOutConfig = time;
  }

  public long getReportTimeOutConfig() {
    return reportTimeOutConfig;
  }

  public boolean isTimeOut() {
    return isTimeOut;
  }
}
