/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - June 22, 2011 05:34:56 PM - hoand - Initialize version
/******************************************************************************/
package com.st.sc.common;

import java.io.File;

import st.liotrox.WRequest;

import com.st.common.config.ConfigLoader;

/**
 * The Class Constants.
 */
public class SCConstants {

  public static final String SHORT_DATE_FORMAT = "yyyy-MM-dd";

  public static final String FULL_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

  /** The Constant FILE_SEPARATOR. */
  public static final String FILE_SEPARATOR = System.getProperty("file.separator");

  /** The Constant VIEW_BY_APHABET. */
  public static final String VIEW_BY_APHABET = " View by alphabet";

  /** The Constant VIEW_BY_STDF_ORDER. */
  public static final String VIEW_BY_STDF_ORDER = " View by STDF order";

  public static final long ONE_DAY_MILISECONDS = 1000 * 60 * 60 * 24;
  /**
   * The connector in a string.
   */
  public static final String STRING_CONNECTOR = ",";
  public static final String NEW_LINE = ".<br/>";

  public static final int DATASET_PAGE_ROW = 100;
  /**
   * Name of rule bundle.
   */
  public static final String BUNDLE_RULE_NAME = "app/sc/rule_management";
  public static final String BUNDLE_COMMON_NAME = "app/sc/sc";
  public static final String BUNDLE_RULESET_NAME = "app/sc/ruleset_management";
  public static final String BUNDLE_VALIDATE_RULESET_NAME = "app/sc/validate_rule_set";
  public static final String BUNDLE_REPORT = "app/sc/report";
  public static final String BUNDLE_ADMIN = "app/sc/admin";
  public static final String BUNDLE_PROFILE = "app/sc/profile";
  public static final String BUNDLE_LOGIN_NAME = "app/sc/login";
  /**
   * The url of rule definition page.
   */
  public static final String RULE_DEFINITION_URL =
      "/app/path/pages/sc/ruleManagement/ruleDefinition";
  public static final String RULE_LIST_SHOW_URL =
      "/app/path/pages/sc/ruleManagement/ruleManagement.doShow";
  public static final String RULE_LIST_PAGE_URL =
      "/app/path/pages/sc/ruleManagement/ruleManagement.lxp";
  public static final String RULE_LIST_BACK_URL =
      "/app/path/pages/sc/ruleManagement/ruleManagement.doBackToPage";
  public static final String RULE_SET_LIST_BACK_URL =
      "/app/path/pages/sc/rulesetManagement/rulesetManagement.doBackToPage";
  public static final String RULE_SET_CONDITION_URL =
      "/app/path/pages/sc/rulesetManagement/rulesetDefinition";
  public static final String RULE_LIST_OF_RULE_SET_URL =
      "/app/path/pages/sc/rulesetManagement/showRuleList";
  public static final String RULE_LIST_OF_RULE_SET_DEFINITION_URL =
      "/app/path/pages/sc/rulesetManagement/ruleListDefinition";
  public static final String RULE_SET_VALIDATION_URL =
      "/app/path/pages/sc/rulesetManagement/validateRuleSet.doShow";
  public static final String FILTERING_PAGE_URL =
      "/app/path/pages/sc/reports/filterringPage.lxp";
  public static final String OFFLINE_REPORT_URL =
      "/app/path/pages/sc/reports/offlineReportPage.displayOfflineReportTab";
  public static final String ERROR_NOT_IMPORTED_URL =
      "/app/path/pages/sc/error/userNotImported.lxp";
  

  /*------------------- Begin Sequence of DB---------------*/
  public static final String SEQ_RULE = "SEQ_RULE";
  public static final String SEQ_RULE_VERSION = "SEQ_RULE_VERSION";
  public static final String SEQ_RULE_SET = "SEQ_RULE_SET";
  public static final String SEQ_RULE_SET_VERSION = "SEQ_RULE_SET_VERSION";
  public static final String SEQ_OFFLINE_REPORT = "SEQ_OFFLINE_REPORT";
  /*------------------- End Sequence of DB---------------*/

  /*------------------Session Key, and parameters --------------------*/
  public static final String PARAMETER_RULE_SET_ID = "ruleSetId";
  public static final String PARAMETER_RULE_SET_VERSION_ID = "ruleSetVersionId";
  public static final String PARAMETER_NEW_RECORD = "newRecord";
  public static final String PARAMETER_NEW_RECORD_VERSION = "newRecordVersion";
  public static final String PARAMETER_CALL_FROM_SHOW_RULE_LIST = "callFromShowRuleList";
  public static final String PARAMETER_CALL_FROM_RULESET_DEFINITION =
      "callFromRuleSetDefinition";
  public static final String SESSION_KEY_RULESET_VERSION = "sc_sk_rulesetversion";
  public static final String PARAMETER_RULE_ID = "ruleId";
  public static final String PARAMETER_RULE_VERSION_ID = "ruleVersionId";
  /*------------------End Session Key, and parameters --------------------*/

  /**
   * Key is used to stored in session, data are details of rule set validation.
   */
  public static final String KEY_RULESET_VALIDATION_DETAIL = "KEY_RULESET_VALIDATION_DETAIL";
  /**
   * Key is used to stored in session, data is the RuleSetVersion object used to
   * validate.
   */
  public static final String KEY_RULESET_VALIDATION_VERSION = "KEY_RULESET_VALIDATION_VERSION";

  public static final String DB_COMMON_ERROR_KEY = "db_common_error";

  public static final String SESSION_KEY_BAR_CHART = "BAR_CHART_SESSION_KEY";

  public static final String SESSION_KEY_BAR_CHART_WIDTH = "SESSION_KEY_BAR_CHART_WIDTH";

  public static final String NA_VALUE = "n/a";

  public static final String ROOT_FULL_DETAIL = ConfigLoader.getInstance().getWebappHomeDir()
      + File.separator + "tmp" + File.separator + "sc_data";
  
  
  private static String contextPath = null;

  public static String getContextPath() {
    if (contextPath == null) {
      contextPath = WRequest.getCurrentInstance().getHttpRequest().getContextPath();
    }
    return contextPath;
  }
}
