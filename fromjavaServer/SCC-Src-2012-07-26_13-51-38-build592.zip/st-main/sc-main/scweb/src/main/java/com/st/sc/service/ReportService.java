/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.service;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.ConfigLoader;
import com.st.common.web.util.DBFunctionConverter;
import com.st.persistence.DatabaseType;
import com.st.persistence.SQLExecutor;
import com.st.persistence.util.ReflecttionUtils;
import com.st.sc.entity.CompliancyResultBinary;
import com.st.sc.entity.CompliancyResultEntity;
import com.st.sc.entity.OfflineReport;
import com.st.sc.entity.OfflineReportBinary;
import com.st.sc.entity.OfflineReportEntity;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.CompliancyResultDTO;
import com.st.sc.webapp.WebContext;

/**
 * The Class ReportService.
 */
public class ReportService {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ReportService.class);

  /** The Constant DATASET_COLUMNS. */
  public static final String[] DATASET_COLUMNS = new String[]{"fileId", "checkingTime",
      "compliancyScore", "fileName", "mirCmodCod", "mirDsgnRev", "mirExecTyp", "mirExecVer",
      "mirFlowId", "mirJobNam", "mirJobRev", "mirModeCod", "mirOperFrq", "mirPartTyp",
      "mirProcId", "mirSpecNam", "mirSpecVer", "mirStartT", "mirSuprNam", "mirTstrTyp",
      "mrrFinishT", "ruleSetName", "ruleSetVer" };

  /** The Constant FULL_DETAIL_COLUMNS. */
  public static final String[] FULL_DETAIL_COLUMNS = new String[]{"ruleVersionId",
      "recordType", "ruleName", "point", "numOfRecords", "numOfPassedRecords",
      "obtainedPoint", "resultStr", "failedValue", "ruleVersion" };

  /**
   * Build matrix from beans and fields.
   * 
   * @param beans
   *          the beans
   * @param fields
   *          the fields
   * @return matrix as Object[][]
   * @throws Exception
   *           the exception
   */
  public static Object[][] buildMatrix(final Object[] beans, final String[] fields)
      throws Exception {
    // beans.length rows and fields.length columns.
    final Object[][] matrix = new Object[beans.length][fields.length];
    for (int row = 0; row < matrix.length; row++) {
      matrix[row] = convertToArray(beans[row], fields);
    }
    return matrix;
  }

  /**
   * Convert to array.
   * 
   * @param data
   *          the data
   * @param fields
   *          the fields
   * @return the object[]
   * @throws Exception
   *           the exception
   */
  private static Object[] convertToArray(final Object data, final String[] fields)
      throws Exception {
    final Object[] result = new Object[fields.length];
    if (data == null) {
      return result;
    }
    for (int i = 0; i < result.length; i++) {
      final Method getMethod =
          ReflecttionUtils.getGetMethodFromClass(fields[i], data.getClass());
      result[i] = getMethod.invoke(data);
    }
    return result;
  }

  /**
   * Builds the matrix.
   * 
   * @param beans
   *          the beans
   * @return the object[][]
   * @throws Exception
   *           the exception
   */
  public Object[][] buildDatasetMatrix(final List<CompliancyResultEntity> beans)
      throws Exception {
    int i = 0;
    final CompliancyResultDTO[] array = new CompliancyResultDTO[beans.size()];
    for (final CompliancyResultEntity bean : beans) {
      if (bean != null) {
        array[i++] = new CompliancyResultDTO(bean);
      }
    }
    return buildMatrix(array, DATASET_COLUMNS);
  }

  /**
   * Builds the matrix.
   * 
   * @param beans
   *          the beans
   * @return the object[][]
   * @throws Exception
   *           the exception
   */
  public Object[][] buildFullDetailMatrix(final RuleValidationDetail[] beans) throws Exception {
    return buildMatrix(beans, FULL_DETAIL_COLUMNS);
  }

  /**
   * Creates the view.
   * 
   * @param viewName
   *          the view name
   * @param whereCondition
   *          the where
   * @param params
   *          the params
   */
  public void createView(final String viewName, final String whereCondition,
      final Map<String, Object> params) {

    final StringBuilder ddl = new StringBuilder();
    ddl.append("CREATE OR REPLACE VIEW ");
    ddl.append(viewName).append(" AS ");
    ddl.append("SELECT ");
    ddl.append("FILE_ID, FILE_NAME, CHECKING_TIME, COMPLIANCY_SCORE, RULE_SET_NAME, RULE_SET_VER, ");
    ddl.append("MIR_PART_TYP, MIR_DSGN_REV, MIR_CMOD_COD, MIR_OPER_FRQ, MIR_FLOW_ID, MIR_TSTR_TYP, ");
    ddl.append("MIR_EXEC_TYP, MIR_EXEC_VER, MIR_JOB_NAM, MIR_JOB_REV, MIR_SPEC_NAM, MIR_SPEC_VER, ");
    ddl.append("MIR_PROC_ID, MIR_SUPR_NAM, MIR_START_T, MIR_MODE_COD, MRR_FINISH_T ");
    ddl.append("FROM COMPLIANCY_RESULT ");
    if (whereCondition != null && whereCondition.trim().length() > 0) {
      ddl.append("WHERE 1 = 1");
      ddl.append(whereCondition);
    }
    String sql = ddl.toString();

    if (LOGGER.isDebugEnabled()) {
      LOGGER.debug("createView ddl = " + sql);
    }
    final SQLExecutor executor = SCWebServiceFactory.getSCExecutor();
    executor.executeSQL(sql, params);
  }

  /**
   * De serialize.
   * 
   * @param detailResult
   *          the detail result
   * @return the list
   */
  public RuleValidationDetail[] deSerialize(final byte[] detailResult) {
    return DetailResultUtil.toDetail(detailResult);
  }

  /**
   * Drop temporary views.
   */
  @SuppressWarnings("rawtypes")
  public void dropTmpViews() {
    final SQLExecutor exe = SCWebServiceFactory.getSCExecutor();
    Collection collection = Collections.EMPTY_LIST;

    final Boolean clearAll =
        (Boolean) ConfigLoader.getInstance().getValue(ConfigLoader.CLEAR_ALL_VIEWS,
            Boolean.TRUE);
    if (clearAll != null && clearAll.booleanValue()) {
      final StringBuilder sql = new StringBuilder();
      final String[] columns = new String[1];
      if (exe.getDatabaseType() == DatabaseType.ORACLE) {
        sql.append("SELECT VIEW_NAME FROM USER_VIEWS WHERE VIEW_NAME LIKE '");
        columns[0] = "VIEW_NAME";
      } else {
        sql.append("SELECT TABLE_NAME FROM information_schema.VIEWS WHERE UPPER(TABLE_NAME) LIKE '");
        columns[0] = "TABLE_NAME";
      }
      sql.append("V_TMP_%'");

      collection = exe.query(sql.toString(), null, columns);
    } else {
      collection = WebContext.getInstance().getTempViews();
    }

    for (final Object viewName : collection) {
      try {
        dropView(String.valueOf(viewName));
      } catch (Exception e) {
        LOGGER.error("Failed to drop view {}", viewName);
      }
    }
    LOGGER.info("Drop all temporary view finished");
  }

  /**
   * Drop view.
   * 
   * @param viewName
   *          the view name
   */
  public void dropView(final String viewName) {
    if (viewIsExist(viewName)) {
      final SQLExecutor exe = SCWebServiceFactory.getSCExecutor();
      exe.executeSQL("DROP VIEW " + viewName, new Object[0]);
      if (LOGGER.isDebugEnabled()) {
        LOGGER.debug("Droped view: " + viewName);
      }
    }
  }

  /**
   * Gets the all view data.
   * 
   * @param viewName
   *          the view name
   * @param firstResult
   *          the first result
   * @param maxResult
   *          the max result
   * @return the all view data
   */
  public List<CompliancyResultEntity> getAllViewData(final String viewName,
      final int firstResult, final int maxResult) {
    if (viewIsExist(viewName)) {
      final String viewQuery = "SELECT * FROM " + viewName;
      final Map<String, Object> params = new HashMap<String, Object>();
      final List<CompliancyResultEntity> ls =
          SCWebServiceFactory.getSCExecutor().query(viewQuery, CompliancyResultEntity.class,
              params, firstResult, maxResult);
      return ls;
    }
    return Collections.emptyList();
  }

  /**
   * Gets the data.
   * 
   * @param fileId
   *          the file id
   * @return the data
   * @throws Exception
   *           the exception
   */
  public CompliancyResultBinary getData(final Long fileId) throws Exception {
    if (fileId == null) {
      return null;
    }
    return SCWebServiceFactory.getSCExecutor()
        .findEntity(CompliancyResultBinary.class, fileId);
  }

  /**
   * Gets the view row count.
   * 
   * @param viewName
   *          the view name
   * @return the view row count
   */
  public int getViewRowCount(final String viewName) {
    if (viewIsExist(viewName)) {
      final SQLExecutor exe = SCWebServiceFactory.getSCExecutor();
      final String sql = "SELECT COUNT(*) FROM " + viewName;
      final BigDecimal result = exe.getNumberValue(sql, new Object[]{});
      if (result != null) {
        return result.intValue();
      }
    }
    return 0;
  }

  /**
   * View is exist.
   * 
   * @param viewName
   *          the view name
   * @return true, if successful
   */
  public boolean viewIsExist(final String viewName) {
    if (viewName == null) {
      return false;
    }
    final SQLExecutor exe = SCWebServiceFactory.getSCExecutor();
    final StringBuilder sql = new StringBuilder();
    if (exe.getDatabaseType() == DatabaseType.ORACLE) {
      sql.append("SELECT VIEW_NAME FROM USER_VIEWS WHERE VIEW_NAME = '");
    } else {
      sql.append("SELECT TABLE_NAME FROM information_schema.VIEWS WHERE UPPER(TABLE_NAME) = '");
    }
    sql.append(viewName.toUpperCase()).append("'");
    final Object result = exe.getScalarValue(sql.toString(), new Object[]{});
    if (result != null) {
      return true;
    }
    return false;
  }

  /**
   * Get offline report by report name.
   * 
   * @param reportName
   * @return
   */
  public OfflineReportEntity getOfflineReportByName(String reportName) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("reportName", reportName.toUpperCase());
    List<OfflineReportEntity> list =
        SCWebServiceFactory.getScBaseService().queryListUseNamedQuery(
            OfflineReportEntity.GET_BY_REPORT_NAME, param, OfflineReportEntity.class);
    if (list == null || list.size() == 0) {
      return null;
    }
    return list.get(0);
  }

  public OfflineReportEntity getOfflineReportEntityById(Long reportId) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("offlineReportId", reportId);
    List<OfflineReportEntity> list =
        SCWebServiceFactory.getScBaseService().queryListUseNamedQuery(
            OfflineReportEntity.GET_BY_ID, param, OfflineReportEntity.class);
    if (list == null || list.size() == 0) {
      return null;
    }
    return list.get(0);
  }

  public OfflineReport getOfflineReportById(Long reportId) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("offlineReportId", reportId);
    List<OfflineReport> list =
        SCWebServiceFactory.getScBaseService().queryListUseNamedQuery(OfflineReport.GET_BY_ID,
            param, OfflineReport.class);
    if (list == null || list.size() == 0) {
      return null;
    }
    return list.get(0);
  }

  public OfflineReportBinary getOfflineReportBinaryData(long reportId) {
    Map<String, Object> param = new HashMap<String, Object>();
    param.put("offlineReportId", reportId);
    List<OfflineReportBinary> list =
        SCWebServiceFactory.getScBaseService().queryListUseNamedQuery(
            OfflineReportBinary.GET_BINARY_BY_ID, param, OfflineReportBinary.class);
    if (list == null || list.size() == 0) {
      return null;
    }
    return list.get(0);
  }

  public List<OfflineReportEntity> getAllOfflineReport() {
    List<OfflineReportEntity> list =
        SCWebServiceFactory.getScBaseService().queryListUseNamedQuery(
            OfflineReportEntity.GET_ALL_REPORT, null, OfflineReportEntity.class);
    return list;
  }

  public boolean deleteOfflineReport(long reportId) {
    try {
      SCWebServiceFactory.getScBaseService().deleteEntity(OfflineReportEntity.class, reportId);
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      return false;
    }
    return true;
  }

  public void updateInProgessReportToFail(final String errorMsg, Date timeOut) {
    try {
      StringBuilder sb = new StringBuilder();
      sb.append("UPDATE OFFLINE_REPORT ");
      sb.append("SET STATUS=?, ERROR_MESSAGE=? ");
      sb.append("WHERE STATUS=? AND REPORT_TIME<=");
      sb.append(DBFunctionConverter.getInstance().dateToString(timeOut));
      SCWebServiceFactory.getSCExecutor()
          .executeSQL(
              sb.toString(),
              new Object[]{OfflineReport.STATUS_FAIL, errorMsg,
                  OfflineReport.STATUS_IN_PROGRESS });
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }

  }

  public void updateInProgessReportToFail(final String errorMsg, final String serverId) {
    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("errorMessage", errorMsg);
    parameters.put("serverId", serverId);
    parameters.put("newstatus", OfflineReport.STATUS_FAIL);
    parameters.put("oldstatus", OfflineReport.STATUS_IN_PROGRESS);
    try {
      SCWebServiceFactory.getScBaseService().updateDeleteNamedQuery(
          OfflineReport.UPDATE_REPORT_STATUS, parameters);
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
  }

  public OfflineReport updateDone(Long offlineReportId, String reportName, byte[] byteArray) {
    final EntityManager em =
        SCWebServiceFactory.getScEntityManagerFactory().createEntityManager();
    OfflineReport entity = null;
    try {
      em.getTransaction().begin();
      entity =
          em.find(OfflineReport.class, offlineReportId, LockModeType.PESSIMISTIC_WRITE, null);
      entity.setReportData(byteArray);
      entity.setStatus(OfflineReport.STATUS_DONE);
      if (byteArray != null) {
        entity.setReportData(byteArray);
      }
      entity = em.merge(entity);
      em.getTransaction().commit();
    } catch (Exception e) {
      if (em.getTransaction().isActive()) {
        em.getTransaction().rollback();
      }
      LOGGER.error("Failed to update offline report, name = {}", reportName);
    } finally {
      em.clear();
      em.close();
    }

    return entity;
  }

  public OfflineReport updateFailed(Long offlineReportId, String errorMessage) {
    final EntityManager em =
        SCWebServiceFactory.getScEntityManagerFactory().createEntityManager();
    OfflineReport entity = null;
    try {
      em.getTransaction().begin();
      entity =
          em.find(OfflineReport.class, offlineReportId, LockModeType.PESSIMISTIC_WRITE, null);
      entity.setStatus(OfflineReport.STATUS_FAIL);
      entity.setErrorMessage(errorMessage);
      entity = em.merge(entity);
      em.getTransaction().commit();
    } catch (Exception e) {
      if (em.getTransaction().isActive()) {
        em.getTransaction().rollback();
      }
      LOGGER.error("Failed to update offline report");
    } finally {
      em.clear();
      em.close();
    }

    return entity;
  }

}
