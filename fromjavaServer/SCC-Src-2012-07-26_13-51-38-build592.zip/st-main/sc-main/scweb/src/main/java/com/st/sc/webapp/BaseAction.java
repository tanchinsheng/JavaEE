/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - June 22, 2011 05:34:56 PM - hoand - Initialize version
/******************************************************************************/

package com.st.sc.webapp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import st.liotrox.WRequest;
import st.liotrox.dataview.Column;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.db.DataSet;
import st.liotrox.db.DataSetBean;
import st.liotrox.db.JavaBeanDataSet;
import st.liotrox.page.DefaultWPage;
import st.liotrox.template.element.control.DataViewElement;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.web.html.WriteHTML;

import com.st.common.config.ConfigLoader;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.persistence.service.actionlog.ActionLog;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleOwners;
import com.st.sc.entity.RuleSet;
import com.st.sc.entity.RuleSetOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleVersion;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.RuleVersionDTO;
import com.st.scc.common.utils.StringUtil;

public class BaseAction extends DefaultWPage {

  /** The Constant META_DATA. */
  private static final String META_DATA =
      "<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />";

  private static final String CONTINUE_VALUE = "...";
  private static final int MAX_SIZE_PARAMETERS = 1024;
  /**
   * Message is showed on client.
   */
  protected String infoMessage = "";
  protected String errorMessage = "";
  protected boolean isManaged;

  /**
   * Gets the doc type.
   * 
   * @return the doc type {@inheritDoc}
   * @see st.liotrox.page.WPage#getDocType()
   */
  @Override
  public String getDocType() {
    return "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
        + META_DATA;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#getLeftMargin()
   */
  @Override
  public String getLeftMargin() {
    WRequest request = WRequest.getCurrentInstance();
    // Set margin to 0 for Netscape 4
    if (request.is_NS_Browser()) {
      FastStringBuffer fsb = request.getResponseBuffer();
      WriteHTML.Page.attribute(fsb, "marginwidth", 0);
      WriteHTML.Page.attribute(fsb, "marginheight", 0);
    }

    return super.getLeftMargin();
  }

  /**
   * @return the scVersion
   */
  public String getScVersion() {
    return ConfigLoader.getInstance().getVersion();
  }
 
  /**
   * Check role of user. If users are operator, they have no permission to
   * create,delete,edit rule,rule set.
   * 
   * @param request
   */
  protected void checkUserRole(WRequest request) {
    isManaged = true;
    String role = request.getUserProfile().getAttribute("liotrox.role");
    if ("operator".equals(role) || request.is_NS_Browser()) {
      isManaged = false;
    }
  }

  /**
   * Get dataview from request
   * 
   * @param dataviewControlName
   * @return
   */
  public DataView getDataViewFromRequest(String dataviewControlName) {
    DataView dataView =
        ((DataViewElement) findControl(dataviewControlName)).getDataView(WRequest
            .getCurrentInstance());
    return dataView;
  }

  /**
   * Create data set from list of object.
   * 
   * @param listObject
   *          list of object.
   * @return data set.
   */
  public DataSet createDataSet(List listObject) {
    DataSet ds = null;
    if (listObject != null && listObject.size() > 0) {
      DataSet jbDataSet = new JavaBeanDataSet(listObject);
      ds = new DataSetBean(jbDataSet).createDataSet();
    }
    return ds;
  }

  /**
   * Tracking this action by insert to DB.
   * 
   * @param actionEntity
   */
  public void trackAction(ActionTrackingEntity actionEntity) {
    // Add this action to service to be inserted to DB.
    actionEntity.setAuthor(WRequest.getCurrentInstance().getUserProfile()
        .getAttribute("liotrox.user"));
    // If length of parameter > 1024 , must cut it.
    String customPamam = appendContinueText(actionEntity.getParameters());
    actionEntity.setParameters(customPamam);
    ActionLog.getInstance().insertTracking("SC", SCWebServiceFactory.getSCExecutor(),
        actionEntity);
  }

  /**
   * Append continue value '...' to a string with a fixed length.
   * 
   * @param builder
   *          data will be appended continue value '...'
   */
  private String appendContinueText(String text) {
    String result = text;
    // Remove some last character to append '...'
    if (text != null && text.length() > MAX_SIZE_PARAMETERS) {
      result = text.substring(0, MAX_SIZE_PARAMETERS - CONTINUE_VALUE.length());
      // Append the continue value ...
      result += CONTINUE_VALUE;
    }
    return result;
  }

  /**
   * Create list of RuleVersionDTO from a Rule.
   * 
   * @param rule
   *          a Rule.
   * @return list of RuleVersionDTO.
   */
  protected List<RuleVersionDTO> createListRuleVersionDTO(Rule rule) {
    List<RuleVersionDTO> ruleVersionList = new ArrayList<RuleVersionDTO>();
    if (rule.getRuleVersions() != null && rule.getRuleVersions().size() > 0) {
      // Sort Rule version increase by version.
      sortVersion(rule.getRuleVersions());
      for (RuleVersion rv : rule.getRuleVersions()) {
        RuleVersionDTO dto = createRuleVersionDTO(rule);
        updateDataRuleVersionDTO(dto, rv);
        ruleVersionList.add(dto);
      }
    } else {
      RuleVersionDTO dto = createRuleVersionDTO(rule);
      ruleVersionList.add(dto);
    }
    return ruleVersionList;
  }

  private static class RuleVersionComparator implements Comparator<RuleVersion> {

    /**
     * {@inheritDoc}
     * 
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(RuleVersion o1, RuleVersion o2) {
      if (o1 == null && o2 == null) {
        return 0;
      }
      if (o1 == null) {
        return -1;
      }
      if (o2 == null) {
        return 1;
      }
      return o1.getVersion().compareTo(o2.getVersion());
    }
  }

  private void sortVersion(List<RuleVersion> ruleVersionList) {
    if (ruleVersionList != null && ruleVersionList.size() > 0) {
      RuleVersionComparator comparator = new RuleVersionComparator();
      Collections.sort(ruleVersionList, comparator);
    }
  }

  /**
   * Update data from RuleVersion to RuleVersionDTO.
   * 
   * @param dto
   * @param rv
   */
  protected void updateDataRuleVersionDTO(RuleVersionDTO dto, RuleVersion rv) {
    dto.setRuleVersionId(rv.getRuleVersionId());
    dto.setDescription(rv.getDescription());
    dto.setVersion(rv.getVersion());
    dto.setPoint(rv.getPoint());
    dto.setLogID(StringUtil.getEmptyIfNull(rv.getLogId()));
    dto.setUpdatedBy(rv.getUpdatedBy());
    final Timestamp timestamp = rv.getUpdatedOn();
    if (timestamp != null) {
      dto.setLastUpdate(new Date(timestamp.getTime()));
    }
    if (rv.getRuleSetVersionList() != null && rv.getRuleSetVersionList().size() > 0) {
      List<String> ruleSetNames = new ArrayList<String>();
      for (RuleSetVersion ruleSetVersion : rv.getRuleSetVersionList()) {
        if (!ruleSetNames.contains(ruleSetVersion.getRuleSet().getName())) {
          ruleSetNames.add(ruleSetVersion.getRuleSet().getName());
        }
      }
      StringBuilder builder = new StringBuilder();
      for (String name : ruleSetNames) {
        builder.append(name).append(SCConstants.STRING_CONNECTOR);
      }
      // Remove the last connector string.
      if (builder.length() > 0) {
        builder.setLength(builder.length() - SCConstants.STRING_CONNECTOR.length());
      }
      dto.setUsedBy(builder.toString());
    }
  }

  /**
   * Create a RuleVersionDTO which contains information of a Rule.
   * 
   * @param rule
   *          a Rule
   * @return a RuleVersionDTO entity.
   */
  protected RuleVersionDTO createRuleVersionDTO(Rule rule) {
    RuleVersionDTO dto = new RuleVersionDTO();
    dto.setRuleId(rule.getRuleId());
    dto.setRuleName(rule.getName());
    dto.setRecordType(rule.getRecordType());
    dto.setCreatedBy(rule.getCreatedBy());
    dto.setOrigin(rule.getOrigin());
    // Get owners list.
    if (rule.getUserRules() != null && rule.getUserRules().size() > 0) {
      StringBuilder builder = new StringBuilder();
      for (RuleOwners user : rule.getUserRules()) {
        builder.append(user.getId().getUserName()).append(SCConstants.STRING_CONNECTOR);
      }
      // Remove the last connector string.
      if (builder.length() > 0) {
        builder.setLength(builder.length() - SCConstants.STRING_CONNECTOR.length());
      }
      dto.setOwners(builder.toString());
    }
    return dto;
  }

  /**
   * Check login user whether is owners of rule set.
   * 
   * @param request
   * @param ruleSet
   * @return true if login user is owners of rule set.
   */
  protected boolean checkLoginUserIsOwnerRuleSet(WRequest request, RuleSet ruleSet) {
    boolean isOwnersOfRuleSet = false;
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");
    List<RuleSetOwners> ruleSetOwners = ruleSet.getUserRuleSets();
    if (ruleSetOwners != null && ruleSetOwners.size() > 0) {
      for (RuleSetOwners rso : ruleSetOwners) {
        if (loginUser.equalsIgnoreCase(rso.getId().getUserName())) {
          isOwnersOfRuleSet = true;
          break;
        }
      }
    }
    return isOwnersOfRuleSet;
  }

  /**
   * Check login user whether is owners of rule.
   * 
   * @param request
   * @param rule
   * @return true if login user is owner of rule.
   */
  protected boolean checkLoginUserIsOwnerRule(WRequest request, Rule rule) {
    boolean isOwnersOfRule = false;
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");
    List<RuleOwners> ruleSetOwners = rule.getUserRules();
    if (ruleSetOwners != null && ruleSetOwners.size() > 0) {
      for (RuleOwners ro : ruleSetOwners) {
        if (loginUser.equalsIgnoreCase(ro.getId().getUserName())) {
          isOwnersOfRule = true;
          break;
        }
      }
    }
    return isOwnersOfRule;
  }

  /**
   * Adjust text, trim if text is too long.
   * 
   * @param text
   *          the text
   * @param width
   *          the width
   * @return new text.
   */
  protected String adjustText(final Object text, final int width) {
    if (text == null || text.toString().length() == 0) {
      return "";
    }
    if (WRequest.getCurrentInstance().is_NS_Browser()) {
      return text.toString();
    }
    return "<div style='text-overflow:ellipsis; width:" + width
        + "px; overflow:hidden;' title='" + text.toString() + "'>" + text.toString()
        + "</div>";
  }

  /**
   * Format text in dataview, if it is so long, we just display a short text and
   * display all in tooltip value.
   * 
   * @param request
   * @param event
   * @return
   */
  public String formatText(final WRequest request, final DataViewEvent event) {
    Column[] columns = event.getDataView().getModel().getColumns().getAll();
    int width = 150;
    if (columns != null) {
      String widthText = columns[event.getColumnIndex() - 1].getWidth();
      if (widthText != null) {
        widthText = widthText.substring(0, widthText.indexOf("px"));
        try {
          width = Integer.parseInt(widthText);
        } catch (Exception e) {
        }
      }
    }
    return adjustText(event.getValue(), width);
  }

  protected void redirectToShowRuleListPage(WRequest request, Long ruleSetVersionId) {
    String url =
        SCConstants.getContextPath() + SCConstants.RULE_LIST_OF_RULE_SET_URL
            + ".doShow?ruleSetVersionId=" + ruleSetVersionId;
    request.redirectTo(url);
  }

  protected void redirectToEditRuleListOfRuleSetPage(WRequest request, Long ruleSetVersionId,
      String[] parameters) {
    String url = SCConstants.getContextPath() + SCConstants.RULE_LIST_OF_RULE_SET_DEFINITION_URL;
    url += ".doShow?ruleSetVersionId=" + ruleSetVersionId;
    if (parameters != null && parameters.length > 0) {
      for (String param : parameters) {
        url += "&" + param;
      }
    }
    request.redirectTo(url);
  }

  protected void redirectBackToRuleSetList(WRequest request, Long ruleSetId,
      Long ruleSetVersionId, boolean isNewRecordRuleSet, boolean isNewRecordRuleSetVersion) {
    String url = SCConstants.getContextPath() + SCConstants.RULE_SET_LIST_BACK_URL;
    url += "?" + SCConstants.PARAMETER_RULE_SET_ID + "=" + ruleSetId;
    url += "&" + SCConstants.PARAMETER_RULE_SET_VERSION_ID + "=" + ruleSetVersionId;
    if (isNewRecordRuleSet) {
      url += "&" + SCConstants.PARAMETER_NEW_RECORD + "=true";
    }
    if (isNewRecordRuleSetVersion) {
      url += "&" + SCConstants.PARAMETER_NEW_RECORD_VERSION + "=true";
    }
    request.redirectTo(url);
  }

  protected void redirectBackToRuleList(WRequest request, Long ruleId, Long ruleVersionId,
      boolean isNewRecordRule, boolean isNewRecordRuleVersion) {
    String url = SCConstants.getContextPath() + SCConstants.RULE_LIST_BACK_URL;
    url += "?" + SCConstants.PARAMETER_RULE_ID + "=" + ruleId;
    url += "&" + SCConstants.PARAMETER_RULE_VERSION_ID + "=" + ruleVersionId;
    if (isNewRecordRule) {
      url += "&" + SCConstants.PARAMETER_NEW_RECORD + "=true";
    }
    if (isNewRecordRuleVersion) {
      url += "&" + SCConstants.PARAMETER_NEW_RECORD_VERSION + "=true";
    }
    request.redirectTo(url);
  }

  protected String buildSelectedRow(int[] selectedRows) {
    if (selectedRows == null || selectedRows.length == 0) {
      return "";
    }
    StringBuilder builder = new StringBuilder();
    for (int row : selectedRows) {
      builder.append(row).append(":").append(row);
      builder.append(",");
    }
    // Remove the last ','
    if (builder.length() > 1) {
      builder.setLength(builder.length() - 1);
    }
    return builder.toString();
  }

  /**
   * @return the errorMessage
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * @return the infoMessage
   */
  public String getInfoMessage() {
    return infoMessage;
  }

  /**
   * @return the isManaged
   */
  public boolean getIsManaged() {
    return isManaged;
  }

}
