/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 20, 2012 2:14:56 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.webapp;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.web.util.ServletUtils;
import com.st.persistence.service.actionlog.ActionLog;
import com.st.sc.util.SCCache;

/**
 * The Class WebContext.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class WebContext {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(WebContext.class);

  /** The Constant instance. */
  private static final WebContext instance = new WebContext();

  /**
   * Gets the single instance of WebContext.
   * 
   * @return single instance of WebContext
   */
  public static WebContext getInstance() {
    return instance;
  }

  /** server ID */
  private String serverId;

  /** The offline report view name. */
  private String offlineReportViewName;

  /** The pool. */
  private final ExecutorService offlineReportPool = Executors
      .newSingleThreadExecutor(new ThreadFactory() {

        public Thread newThread(final Runnable r) {
          final Thread t = new Thread(r);
          t.setPriority(Thread.MIN_PRIORITY);
          return t;
        }
      });

  /** The temp views. */
  private final Set<String> tempViews;

  /**
   * Instantiates a new web context.
   */
  private WebContext() {
    tempViews = new HashSet<String>();

    final String serverIP = ServletUtils.getServerIp().toUpperCase();
    final int port = getPort();
    serverId = serverIP + ":" + port;
    offlineReportViewName = "OV_" + serverIP.replace('.', '_') + "_" + port;
    if (offlineReportViewName.length() > 30) {
      offlineReportViewName = offlineReportViewName.substring(0, 30);
    }
  }

  /**
   * Adds the temp view.
   * 
   * @param viewName
   *          the view name
   */
  public void addTempView(final String viewName) {
    tempViews.add(viewName);
  }

  /**
   * Gets the offline report pool.
   * 
   * @return the offline report pool
   */
  public ExecutorService getOfflineReportPool() {
    return offlineReportPool;
  }

  /**
   * Gets the offline report view name.
   * 
   * @return the offline report view name
   */
  public String getOfflineReportViewName() {
    return offlineReportViewName;
  }

  /**
   * Gets the port.
   * 
   * @return the port
   */
  private int getPort() {
    int port = 0;
    try {
      port = com.st.sc.util.TomcatUtil.getPort();
    } catch (final Throwable e) {
      LOG.error(e.getMessage());
    }
    return port;
  }

  /**
   * Gets the server id.
   * 
   * @return the server id
   */
  public String getServerId() {
    return serverId;
  }

  /**
   * Gets the temp views.
   * 
   * @return the temp views
   */
  public Set<String> getTempViews() {
    return tempViews;
  }

  /**
   * Removes the temp view.
   * 
   * @param viewName
   *          the view name
   */
  public void removeTempView(final String viewName) {
    tempViews.remove(viewName);
  }

  /**
   * Shutdown.
   */
  public void shutdown() {
    SCCache.getInstance().shutdown();
    ActionLog.getInstance().closeTracking();

    if (offlineReportPool != null) {
      offlineReportPool.shutdown();
      try {
        offlineReportPool.awaitTermination(2, TimeUnit.SECONDS);
      } catch (final InterruptedException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
  }
}
