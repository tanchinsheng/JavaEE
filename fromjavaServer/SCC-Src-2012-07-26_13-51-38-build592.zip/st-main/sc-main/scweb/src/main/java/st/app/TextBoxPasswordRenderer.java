/**
 * TextBoxPasswordRenderer.java
 *
 * Copyright (c) STMicroelectronics
 *
 * CHANGES
 * Jun 7, 2012 - First Release (G. Scapellato)
 */
package st.app;

import st.liotrox.WRequest;
import st.liotrox.template.DynamicElement;
import st.liotrox.template.ElementRenderer;
import st.liotrox.template.TemplateException;
import st.liotrox.template.element.control.AbstractTextElement;
import st.liotrox.template.element.control.BoundControl;
import st.liotrox.template.element.control.TextBoxElement;
import st.liotrox.util.Convert;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.util.ItemList;
import st.liotrox.util.ItemListFactory;
import st.liotrox.web.html.HelpList;
import st.liotrox.web.html.Input;
import st.liotrox.web.html.WriteHTML;

/**
 * @author scapelg
 *
 */
public class TextBoxPasswordRenderer implements ElementRenderer {

	
    private TextBoxElement textBoxElement;
    private Context ctx = new Context();

    
    /**
     * Returns the TextBoxElement
     * @return the TextBoxElement
     */
    public TextBoxElement getTextBoxElement()
    {
        return textBoxElement;
    }
    
               
    /**
     * Returns the HTML Input type. By default it is Input.TEXT
     * @return the HTML Input type
     */
    protected String getInputType() { return Input.PASSWORD; }

         
    /**
     * Writes the HTML Input Tag
     * @param request
     * @param fsb
     */
    protected final void writeHTMLTag(WRequest request, FastStringBuffer fsb)
    {               
        TextBoxElement textBox = getTextBoxElement();
        
        // Retrieve attributes and validate it
        // -----------------------------------------------------------------------        
        // retrieve the value to display
        String valueToDisplay = (String)getContext().modelValue;              
                        
        // Writes the HTML Input tags and all icons (if needed)
        // -----------------------------------------------------------------------                
        //create a Html input tag
        WriteHTML.Input.inputStartWithAttrs(fsb).type(fsb, getInputType())
                 .value(fsb, valueToDisplay).name(fsb, textBox.getName(request));
       
        // Set size for the Input tag
        WriteHTML.Input.size(fsb, getSize(request));
        
        textBox.applyClientEventAttributes(request, fsb);
        
        WriteHTML.Input.maxSize(fsb, ctx.maxSize);

        // Apply Style and Css
        String style = textBox.resolveAttributeAsString(request,AbstractTextElement.ATTRIBUTE_STYLE);
        String css   = textBox.resolveAttributeAsString(request,AbstractTextElement.ATTRIBUTE_CSS);
        WriteHTML.Input.style(fsb, style).css(fsb, css);

        // manage disabled attribute
        if(textBox.isDisabled(request))
        {
            WriteHTML.Input.attribute(fsb, "DISABLED");
            if(request.is_NS_Browser()) WriteHTML.Input.onFocus(fsb, "this.blur()");
        } // if
                
        WriteHTML.Input.attribute(fsb, "autocomplete", "off");
        
        WriteHTML.Input.closeTag(fsb);
    } // func


    /**
     * Write optional icons between error icon and required icon
     * @param request The WRequest instance
     * @param fsb The FastStringBuffer instance
     */
    protected void writeIcons(WRequest request, FastStringBuffer fsb) {/* nothing to do */}
    
    /**
     * Write icons for textbox. It internally call the writeIcons() method that
     * can be redefined to add additional icons 
     */
    protected final void writeIcons(WRequest request, FastStringBuffer fsb, boolean isBeforeHTMLTag)
    {
        if(isBeforeHTMLTag)
        {
            // Write the help list (if needed)
            writeHelpList(request, fsb);

            writeIcons(request, fsb);            
        }
        else
        {
            writeIcons(request, fsb);

            // Write the help list (if needed)
            writeHelpList(request, fsb);
        }
    } // func
    
    /**
     * Writes the help list
     */
    private void writeHelpList(WRequest request, FastStringBuffer fsb)
    {
        //retrieve items and codes to create the ListModel
        TextBoxElement tb = getTextBoxElement();

        if (tb.getAttribute(TextBoxElement.ATTRIBUTE_HELP_LIST) == null) return;
        
        Object objItems = tb.resolveAttribute(request, TextBoxElement.ATTRIBUTE_HELP_LIST);
        Object objCodes = tb.resolveAttribute(request, TextBoxElement.ATTRIBUTE_HELP_LIST_CODES);

        ItemList itemList = null;

        if (objItems != null)
            itemList = ItemListFactory.create(objItems, objCodes);

        String iconToolTip = tb.resolveAttributeAsString(request, TextBoxElement.ATTRIBUTE_HELP_LIST_TOOLTIP);

        HelpList.write(request, fsb, ctx.ctrlName, itemList, 
                                       tb.getPage(), "icons/icon_help.gif", iconToolTip);

    } // func
    
       
    /**
     * Return localized error message if value is greater then max value
     * @param request WRequest instance
     * @return localized error message
     */
    protected String getMaxErrorMessage(WRequest request)
    {
        if(ctx.maxStr == null) return null;
        return  getI18NMessage(request, TextBoxElement.I18N_KEY_INVALID_MAX_VALUE, 
                                        new Object[] {ctx.label, ctx.maxStr});
    } // func
    
    /**
     * Return localized error message if value is less then min value 
     * @param request WRequest instance
     * @return localized error message
     */
    protected String getMinErrorMessage(WRequest request)
    {
        if(ctx.minStr == null) return null;
        return  getI18NMessage(request, TextBoxElement.I18N_KEY_INVALID_MIN_VALUE, 
                                        new Object[] {ctx.label,  ctx.minStr});
    } // func
    
    /**
     * Return localized error message if value is less then min or greater then max values 
     * @param request WRequest instance
     * @return localized error message
     */
    protected String getRangeErrorMessage(WRequest request)
    {
        if(ctx.minStr == null || ctx.maxStr == null) return null;
        
        return getI18NMessage(request, TextBoxElement.I18N_KEY_INVALID_RANGE, 
                                        new Object[] {ctx.minStr, ctx.maxStr});
    } // func

    


	
	
	/* (non-Javadoc)
	 * @see st.liotrox.template.ElementRenderer#write(st.liotrox.WRequest, st.liotrox.util.FastStringBuffer, st.liotrox.template.DynamicElement)
	 */
	public void write(WRequest request, FastStringBuffer fsb, DynamicElement element) {
		
		this.textBoxElement = (TextBoxElement) element;
		
		fillContext(request);
		
		this.writeHTMLTag(request, fsb);
	}
	
	
	
	
	  // -----------------------------------------------------------------------------
    //                        GET METHODS FOR COMMON ATTRIBUTES
    // -----------------------------------------------------------------------------        
                        
    /**
     * Gets the default input size ("20")
     * @param request the current request
     * @return the default input size
     */
    protected String getDefaultSize(WRequest request) { return "20"; }

    /**
     * Get the Size to be used.
     * @param request the WRequest instance
     * @return the Max Size
     */
    protected String getSize(WRequest request)
    {
        String size = getTextElement().resolveAttributeAsString(request, TextBoxElement.ATTRIBUTE_SIZE);
        
        // check if the SIZE is a valid number
        if (size != null)
        {
            try { Integer.parseInt(size); }
            catch(Exception e) 
            { 
                raiseException ("The 'SIZE' attribute in the " + getTextElement().getClass().getName() 
                            + " is not a valid integer. "); 
            }
        }
        else size = getDefaultSize(request);
        
        return size;
    } // func


	private TextBoxElement getTextElement() {
		return getTextBoxElement();
	}


	/**
     * Get the Max Size to be used
     * @param request the WRequest instance
     * @return the Max Size
     */
    protected String getMaxSize(WRequest request)
    {
        // retrieve the max size attribute value or set the default value
        String maxSize = getTextElement().resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_MAX_SIZE);
        if (maxSize != null)
        {
            try { Integer.parseInt(maxSize); }
            catch(Exception e) 
            { 
                raiseException ("The 'MAX SIZE' attribute in the " 
                            + getTextElement().getClass().getName() + " is not a valid integer."); 
            }
        }
        else maxSize = getDefaultMaxSize(request);
        
        return maxSize;
    } // func
     
    /**
     * Get the Min Size to be used
     * @param request the WRequest instance
     * @return the Min Size
     */
    protected String getMinSize(WRequest request)
    {
        // retrieve the min size attribute value or set the default value
        String minSize = getTextElement().resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_MIN_SIZE);
        if (minSize == null) return null;

        try { Integer.parseInt(minSize); }
        catch(Exception e) 
        { 
            raiseException ("The 'MIN SIZE' attribute in the " 
                        + getTextElement().getClass().getName() + " is not a valid integer."); 
        }
        return minSize;
    } // func
     
    /**
     * Gets the default input max size. It is NULL
     * @param request the current request 
     * @return the default input max size
     */
    protected String getDefaultMaxSize(WRequest request) { return null; }

    /**
     * Get the validation group name
     * @param request the current request
     * @return the validation group name
     */
    protected String getValidationGroupName(WRequest request)
    {
        return getTextElement().resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_VALIDATION_GROUP);
    } // fun

    
    /**
     * Get the icons position
     * @param request the current request
     * @return the Max Size
     */
    protected String getDecoratorsPosition(WRequest request)
    {
        // retrieve the icons attribute value or set right as default value
        String iconsPosition = getTextElement().resolveAttributeAsString(request, 
                                                         AbstractTextElement.ATTRIBUTE_DECORATOR_POS, 
                                                         AbstractTextElement.ATTRIBUTE_DECORATOR_RIGHT);
        //che allowed values for iconsPosition attribute
        if(!iconsPosition.equalsIgnoreCase(AbstractTextElement.ATTRIBUTE_DECORATOR_RIGHT) && !iconsPosition.equalsIgnoreCase(AbstractTextElement.ATTRIBUTE_DECORATOR_LEFT))
            raiseException ("Allowed values for 'decoratorsPosition' attribue are: left and right." );
        return iconsPosition;
    } // func
        
    
    /**
     * Return localized error message for required check 
     * @param request the current request
     * @return localized error message for required check
     */
    protected String getRequiredErrorMessage(WRequest request)
    {
        if(!ctx.required) return null;

        return getI18NMessage(request, AbstractTextElement.I18N_KEY_REQUIRED, 
                                       new Object[] {ctx.label});
    } // func
    
    /**
     * Return localized error message for minSize check 
     * @param request WRequest instance
     * @return localized error message for minSize check
     */
    protected String getMaxSizeErrorMessage(WRequest request)
    {
        if(ctx.maxSize == null) return null;
        
        return getI18NMessage(request, AbstractTextElement.I18N_KEY_MAX_SIZE, 
                                       new Object[] {ctx.label, ctx.maxSize});
    } // func

    /**
     * Return localized error message for minSize check 
     * @param request WRequest instance
     * @return localized error message for minSize check
     */
    protected String getMinSizeErrorMessage(WRequest request)
    {
        if(ctx.minSize == null) return null;
        
        return getI18NMessage(request, AbstractTextElement.I18N_KEY_MIN_SIZE, 
                                       new Object[] {ctx.label, ctx.minSize});
    } // func

    
    /**
     * Get the I18NMessage using the passed parameters
     * @param request the current request
     * @param key the I18N key
     * @param parameters the parameters to substitute in the I18N message
     * @return the I18N message related to the passed key 
     */
    protected final String getI18NMessage (WRequest request, String key, Object[] parameters)
    {
        return getTextElement().getI18NMessage(request, key, parameters);
    }
    
    /**
     * Raise a exception calling the AbstractTextElement.internalRaiseException
     * @param message the message
     * @see AbstractTextElement#internalRaiseException(String)
     */
    protected void raiseException(String message) 
    {
    	throw new TemplateException(message, null, getTextBoxElement());
    }
    
    // -----------------------------------------------------------------------------        
        
        

    // -----------------------------------------------------------------------------
    //                        CONTEXT MANAGEMENT
    // -----------------------------------------------------------------------------    
    /**
     * Creates a Context Object. It is called in the constructor.
     * Subclasses can redefine this method to create specialized context
     * @return the context object
     */
    protected Context buildContext()
    {
        return new Context();
    }
    
    /**
     * Get the current Context instance
     * @return the context instance
     */
    protected Context getContext()
    {
        return ctx;
    }
    
    /**
     * Fill context value getting value from the incoming request.
     * Subclasses may redefine this method filling more attributes
     * @param request the current request
     */
    protected void fillContext(WRequest request)
    {   
        Context context = getContext();
        
        AbstractTextElement txtElem = getTextElement();
        
        context.ctrlName             = txtElem.getName(request);
        context.disableErrorHandling = Convert.stringToBoolean(txtElem.resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_DIS_ERR_HANDL, "false"));
        context.required             = Convert.stringToBoolean(txtElem.resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_REQUIRED, "false"));
        context.label                = txtElem.resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_LABEL, txtElem.getName(request));
        context.trim                 = Convert.stringToBoolean(txtElem.resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_TRIM, "true"));
        context.modelValue           = txtElem.resolvePathAttribute(request, BoundControl.ATTRIBUTE_BINDING, "");
        context.transform            = txtElem.resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_TRANSFORM, null);                    
        context.validateAction       = txtElem.resolveAttributeAsString(request, AbstractTextElement.ATTRIBUTE_VALID_ACTION);
        context.maxSize              = getMaxSize(request);
        context.minSize              = getMinSize(request);
                
        if(context.validateAction != null && context.validateAction.endsWith(";")) 
            context.validateAction = context.validateAction.substring(0, context.validateAction.length() - 2);
        
            
        TextBoxElement tb      = getTextBoxElement();
        
        context.nullAsZero    = Convert.stringToBoolean(tb.resolveAttributeAsString(request, TextBoxElement.ATTRIBUTE_NULLASZERO, "true"));
        
    } // func
    
    // -----------------------------------------------------------------------------
           
    
    /**
     * Context class used for TextBox and TextArea. 
     * It contains attributes needed for the populate and rendering phase.
     * The method fillContext() is used to resolve control values and store
     * it in the context both in the populate phase and in the rendering phase
     */
    protected class Context
    {
        String   ctrlName;
        String   label;
        boolean  disableErrorHandling;
        boolean  required;        
        boolean  trim;
        String   transform;
        String   maxSize;
        String   minSize;

        String   validateAction;
        
        Object   modelValue;
        String   valueFromRequest;
                
        boolean    nullAsZero;        
        Comparable minValue, maxValue;  
        String     minStr, maxStr;
    } // class
    

}
