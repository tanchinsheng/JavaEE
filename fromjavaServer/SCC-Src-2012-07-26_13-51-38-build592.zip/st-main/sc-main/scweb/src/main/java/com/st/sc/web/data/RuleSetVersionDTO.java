/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 17, 2011 10:02:01 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.util.Date;

import com.st.sc.entity.MirCriteria;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleSetVersionDTO {

  public static final String FIELD_RULESET_VERSION_ID = "ruleSetVersionId";
  public static final String FIELD_RULESET_ID = "ruleSetId";
  public static final String FIELD_ALARM_THRESHOLD = "alarmThresholdStr";
  public static final String FIELD_DESCRIPTION = "description";
  public static final String FIELD_VERSION = "version";
  public static final String FIELD_STATUS = "status";

  private Long ruleSetVersionId;
  private Long ruleSetId;
  private String alarmThresholdStr;
  private String description;
  private Boolean status;
  private Date lastStatusDate;
  private Date updatedOn;
  private Integer version;

  private String cmodCod;
  private String dsgnRev;
  private String execTyp;
  private String execVer;
  private String flowId;
  private String jobNam;
  private String jobRev;
  private String modeCod;
  private String operFrq;
  private String partTyp;
  private String procId;
  private String specNam;
  private String specVer;
  private String suprNam;
  private String tstrTyp;

  public void createMirCriteria(MirCriteria mir) {
    if (mir != null) {
      cmodCod = mir.getCmodCod();
      dsgnRev = mir.getDsgnRev();
      execTyp = mir.getExecTyp();
      execVer = mir.getExecVer();
      flowId = mir.getFlowId();
      jobNam = mir.getJobNam();
      jobRev = mir.getJobRev();
      modeCod = mir.getModeCod();
      operFrq = mir.getOperFrq();
      partTyp = mir.getPartTyp();
      procId = mir.getProcId();
      specNam = mir.getSpecNam();
      specVer = mir.getSpecVer();
      suprNam = mir.getSuprNam();
      tstrTyp = mir.getTstrTyp();
    }
  }

  /**
   * @return the ruleSetVersionId
   */
  public Long getRuleSetVersionId() {
    return ruleSetVersionId;
  }

  /**
   * @param ruleSetVersionId
   *          the ruleSetVersionId to set
   */
  public void setRuleSetVersionId(Long ruleSetVersionId) {
    this.ruleSetVersionId = ruleSetVersionId;
  }

  /**
   * @return the ruleSetId
   */
  public Long getRuleSetId() {
    return ruleSetId;
  }

  /**
   * @param ruleSetId
   *          the ruleSetId to set
   */
  public void setRuleSetId(Long ruleSetId) {
    this.ruleSetId = ruleSetId;
  }

  /**
   * @return the alarmThresholdStr
   */
  public String getAlarmThresholdStr() {
    return alarmThresholdStr;
  }

  /**
   * @param alarmThresholdStr
   *          the alarmThresholdStr to set
   */
  public void setAlarmThresholdStr(String alarmThresholdStr) {
    this.alarmThresholdStr = alarmThresholdStr;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description
   *          the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * @return the status
   */
  public Boolean getStatus() {
    return status;
  }

  /**
   * @param status
   *          the status to set
   */
  public void setStatus(Boolean status) {
    this.status = status;
  }

  /**
   * @return the updatedOn
   */
  public Date getUpdatedOn() {
    return updatedOn;
  }

  /**
   * @param updatedOn
   *          the updatedOn to set
   */
  public void setUpdatedOn(Date updatedOn) {
    this.updatedOn = updatedOn;
  }

  /**
   * @return the version
   */
  public Integer getVersion() {
    return version;
  }

  /**
   * @param version
   *          the version to set
   */
  public void setVersion(Integer version) {
    this.version = version;
  }
  

  /**
   * @return the lastStatusDate
   */
  public Date getLastStatusDate() {
    return lastStatusDate;
  }

  /**
   * @param lastStatusDate the lastStatusDate to set
   */
  public void setLastStatusDate(Date lastStatusDate) {
    this.lastStatusDate = lastStatusDate;
  }

  /**
   * @return the cmodCod
   */
  public String getCmodCod() {
    return cmodCod;
  }

  /**
   * @param cmodCod
   *          the cmodCod to set
   */
  public void setCmodCod(String cmodCod) {
    this.cmodCod = cmodCod;
  }

  /**
   * @return the dsgnRev
   */
  public String getDsgnRev() {
    return dsgnRev;
  }

  /**
   * @param dsgnRev
   *          the dsgnRev to set
   */
  public void setDsgnRev(String dsgnRev) {
    this.dsgnRev = dsgnRev;
  }

  /**
   * @return the execTyp
   */
  public String getExecTyp() {
    return execTyp;
  }

  /**
   * @param execTyp
   *          the execTyp to set
   */
  public void setExecTyp(String execTyp) {
    this.execTyp = execTyp;
  }

  /**
   * @return the execVer
   */
  public String getExecVer() {
    return execVer;
  }

  /**
   * @param execVer
   *          the execVer to set
   */
  public void setExecVer(String execVer) {
    this.execVer = execVer;
  }

  /**
   * @return the flowId
   */
  public String getFlowId() {
    return flowId;
  }

  /**
   * @param flowId
   *          the flowId to set
   */
  public void setFlowId(String flowId) {
    this.flowId = flowId;
  }

  /**
   * @return the jobNam
   */
  public String getJobNam() {
    return jobNam;
  }

  /**
   * @param jobNam
   *          the jobNam to set
   */
  public void setJobNam(String jobNam) {
    this.jobNam = jobNam;
  }

  /**
   * @return the jobRev
   */
  public String getJobRev() {
    return jobRev;
  }

  /**
   * @param jobRev
   *          the jobRev to set
   */
  public void setJobRev(String jobRev) {
    this.jobRev = jobRev;
  }

  /**
   * @return the modeCod
   */
  public String getModeCod() {
    return modeCod;
  }

  /**
   * @param modeCod
   *          the modeCod to set
   */
  public void setModeCod(String modeCod) {
    this.modeCod = modeCod;
  }

  /**
   * @return the operFrq
   */
  public String getOperFrq() {
    return operFrq;
  }

  /**
   * @param operFrq
   *          the operFrq to set
   */
  public void setOperFrq(String operFrq) {
    this.operFrq = operFrq;
  }

  /**
   * @return the partTyp
   */
  public String getPartTyp() {
    return partTyp;
  }

  /**
   * @param partTyp
   *          the partTyp to set
   */
  public void setPartTyp(String partTyp) {
    this.partTyp = partTyp;
  }

  /**
   * @return the procId
   */
  public String getProcId() {
    return procId;
  }

  /**
   * @param procId
   *          the procId to set
   */
  public void setProcId(String procId) {
    this.procId = procId;
  }

  /**
   * @return the specNam
   */
  public String getSpecNam() {
    return specNam;
  }

  /**
   * @param specNam
   *          the specNam to set
   */
  public void setSpecNam(String specNam) {
    this.specNam = specNam;
  }

  /**
   * @return the specVer
   */
  public String getSpecVer() {
    return specVer;
  }

  /**
   * @param specVer
   *          the specVer to set
   */
  public void setSpecVer(String specVer) {
    this.specVer = specVer;
  }

  /**
   * @return the suprNam
   */
  public String getSuprNam() {
    return suprNam;
  }

  /**
   * @param suprNam
   *          the suprNam to set
   */
  public void setSuprNam(String suprNam) {
    this.suprNam = suprNam;
  }

  /**
   * @return the tstrTyp
   */
  public String getTstrTyp() {
    return tstrTyp;
  }

  /**
   * @param tstrTyp
   *          the tstrTyp to set
   */
  public void setTstrTyp(String tstrTyp) {
    this.tstrTyp = tstrTyp;
  }

}
