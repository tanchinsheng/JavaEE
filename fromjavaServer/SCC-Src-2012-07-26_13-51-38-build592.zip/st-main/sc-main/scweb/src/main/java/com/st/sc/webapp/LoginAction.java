/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - June 22, 2011 05:34:56 PM - hoand - Initialize version
/******************************************************************************/
package com.st.sc.webapp;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.login.LoginPage;
import st.liotrox.profile.UserProfile;

import com.st.common.config.ConfigLoader;
import com.st.common.exception.ServiceException;
import com.st.common.web.WebConstants;
import com.st.common.web.login.LDAPSetting;
import com.st.common.web.login.LoginUtil;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.persistence.service.SettingService;
import com.st.persistence.service.actionlog.ActionLog;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.util.SCWebServiceFactory;
import com.st.scc.common.utils.DateUtils;
import com.st.um.entity.UserEntity;
import com.st.um.enums.UserTypeEnum;
import com.st.um.service.UserService;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class LoginAction extends LoginPage {

  private static final Logger LOGGER = LoggerFactory.getLogger(LoginAction.class);

  private String appVersion;

  private String casLoginURL;

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.login.LoginPage#beforeRender(st.liotrox.WRequest)
   */
  @Override
  protected void beforeRender(WRequest request) {
    // check error message when login by CAS
    String casError = (String) request.getSession().getAttribute(WebConstants.CAS_LOGIN_ERROR);
    request.getSession().removeAttribute(WebConstants.CAS_LOGIN_ERROR);
    if (casError != null) {
      setErrorMessage(casError);
    }
    super.beforeRender(request);
    
    // set JSESSIONID Cookie : httpOnly;
    //String cookieStr = "JSESSIONID=" + request.getSession().getId() + "; Path=/scweb; HttpOnly";//;Secure
    //request.getHttpResponse().addHeader("Set-Cookie", cookieStr);
  }

  /**
   * @return the current password to compare when changing password.
   */
  public String getCurPassword() {
    WRequest request = WRequest.getCurrentInstance();
    UserProfile userProfile = request.getUserProfile();
    String curPassword = userProfile.getAttribute("liotrox.password");
    return curPassword;
  }

  /**
   * this method is set always remember password when open login page.
   * {@inheritDoc}
   * 
   * @see st.liotrox.login.LoginPage#getRememberMeValue()
   */
  public boolean getRememberMeValue() {
    return true;
  }

  /**
   * Already login with first login or not.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return true, if successful
   */
  public boolean isFirstTimeLogin(WRequest request, Event event) {
    UserService userService = SCWebServiceFactory.getUserService();
    return LoginUtil.isFirstTimeLogin(request, userService);
  }

  public LoginAction() {
    appVersion = ConfigLoader.getInstance().getVersion();
    casLoginURL =
        (String) WRequest.getCurrentInstance().getSession()
            .getAttribute(WebConstants.CAS_LOGIN_URL);
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.login.LoginPage#authenticate(st.liotrox.WRequest)
   */
  @Override
  protected void authenticate(WRequest request) {
    long startLogin = System.currentTimeMillis();
    try {
      UserService userService = SCWebServiceFactory.getUserService();
      // get LDAP settings
      SettingService umSetting = SCWebServiceFactory.getUmSettingService();
      Map<String, Object> mapSettings = umSetting.loadAll();
      LDAPSetting ldapSetting = getLDAPSettings(mapSettings);

      String errorMsg =
          LoginUtil.authenticate(request, getUserName(), getPassword(), userService,
              ldapSetting, SCConstants.BUNDLE_LOGIN_NAME);
      // User already login successfully.
      if (errorMsg == null) {
        // Login successful.
        String roleName = request.getUserProfile().getAttribute("liotrox.role");
        setRole(roleName);
        // store user name into cookie.
        //storeUserNameCookie(request);

        // Action tracking for login action
        ActionTrackingEntity actionEntity = new ActionTrackingEntity();
        actionEntity.setAction("Login local");
        actionEntity.setAuthor(getUserName());
        actionEntity.setParameters("Login at: "
            + DateUtils.dateToString(new Date(), "yyyy-MM-dd HH:mm:ss"));
        actionEntity.setElapsedTime(System.currentTimeMillis() - startLogin);
        ActionLog.getInstance().insertTracking("SC", SCWebServiceFactory.getSCExecutor(),
            actionEntity);
        
        // check first login
        UserEntity user = userService.getUserByUserName(getUserName());
        if (user != null) {
          if (user.getLastLoginDate() == null && user.getUserType() == UserTypeEnum.LOCAL_USER) {
            if (request.is_NS_Browser()) {
              request.redirectTo(SCConstants.getContextPath() +"/app/path/pages/sc/login/changePasswordPageNS.lxp");
            }
            return;
          }
        }

        // redirect to offline report when user click from email.
        String originUrl = (String) request.getParameter("lx_origURL");
        if (originUrl != null && originUrl.endsWith(SCConstants.OFFLINE_REPORT_URL)) {
          request.redirectTo(SCConstants.getContextPath() + SCConstants.OFFLINE_REPORT_URL);
        } else {
          request.redirectTo(SCConstants.getContextPath() + SCConstants.FILTERING_PAGE_URL);
        }
      } else {
        setErrorMessage(errorMsg);
      }
    } catch (ServiceException e) {
      setErrorMessage(CommonUtils.getCommonBundleMessage(SCConstants.DB_COMMON_ERROR_KEY));
      LOGGER.error(e.getMessage(), e);
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }

  }

  private LDAPSetting getLDAPSettings(Map<String, Object> map) {
    LDAPSetting setting = new LDAPSetting();
    setting.setLdapHost((String) map.get(ConfigLoader.LDAP_HOST));
    setting.setLdapHostPort(getInteger(map.get(ConfigLoader.LDAP_HOST_PORT)));
    setting.setLdapScope(getInteger(map.get(ConfigLoader.LDAP_SCOPE)));
    setting.setLdapVersion(getInteger(map.get(ConfigLoader.LDAP_VERSION)));
    return setting;
  }

  private Integer getInteger(Object ob) {
    if (ob != null) {
      if (ob instanceof Double) {
        return ((Double) ob).intValue();
      }
      return Integer.valueOf(ob.toString());
    } else {
      return null;
    }
  }

  /**
   * Change password of the first login of user.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void changePassword(WRequest request, Event event) {
    LOGGER.debug("changePassword");
    UserService userService = SCWebServiceFactory.getUserService();
    String errorMsg =
        LoginUtil.changePassword(request, userService, SCConstants.BUNDLE_LOGIN_NAME);
    if (errorMsg == null) {
      // Change password successfully.
      request.redirectTo(SCConstants.getContextPath() + SCConstants.FILTERING_PAGE_URL);
    }
  }

  /**
   * @return the appVersion
   */
  public String getAppVersion() {
    return appVersion;
  }

  /**
   * @return the casLoginURL
   */
  public String getCasLoginURL() {
    return casLoginURL;
  }

}
