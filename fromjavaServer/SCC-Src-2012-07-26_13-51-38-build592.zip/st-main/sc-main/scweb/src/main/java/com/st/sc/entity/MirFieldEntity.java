package com.st.sc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="COMPLIANCY_RESULT")
public class MirFieldEntity implements Serializable {

  private static final long serialVersionUID = 7570088830966229027L;

  @Id
  @Column(name = "MIR_FIELD")
  private String mirField;

  public String getMirField() {
    return mirField;
  }

  public void setMirField(String mirField) {
    this.mirField = mirField;
  }

}
