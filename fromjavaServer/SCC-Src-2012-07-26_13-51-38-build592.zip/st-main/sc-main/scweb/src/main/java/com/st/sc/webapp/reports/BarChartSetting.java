/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 22, 2012 9:04:22 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import st.liotrox.WRequest;

import com.st.common.exception.SccException;
import com.st.sc.web.data.ReportData;

/**
 * The Class BarChartSetting.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class BarChartSetting extends ScoreTableSetting {

  /** The Constant ONE_CATEGORY. */
  public static final String ONE_CATEGORY = "one";

  /** The Constant MULTIPLE_CATEGORY. */
  public static final String MULTIPLE_CATEGORY = "multi";

  /** The Constant BAR_CHART_CLUSTERED_COLUMN. */
  public static final String BAR_CHART_CLUSTERED_COLUMN = "Clustered Column";

  /** The Constant BAR_CHART_STACKED_COLUMN. */
  public static final String BAR_CHART_STACKED_COLUMN = "Stacked Column";

  /** The Constant BAR_CHART_100_STACKED_COLUMN. */
  public static final String BAR_CHART_100_STACKED_COLUMN = "100% Stacked Column";

  /** The series order. */
  private String seriesOrder;

  /** The categories order. */
  private String categoriesOrder;

  /** The category option. */
  private String categoryOption;

  /** The is one category checked. */
  private boolean isOneCategoryChecked;

  /** The chart type. */
  private String chartType;

  private int percentageBarChartWidth = 100;

  /**
   * Get list of bar chart type.
   * 
   * @return the bar chart list
   */
  public String[] getBarChartList() {
    return new String[]{BAR_CHART_CLUSTERED_COLUMN, BAR_CHART_STACKED_COLUMN,
        BAR_CHART_100_STACKED_COLUMN };
  }

  public String validateInputData() {
    // bind category, because when create offline report, cannot get value from
    // request.
    bindCategoryOption();
    return validateInputData("bar_chart_series_");
  }

  /**
   * Gets the data of bar chart. Must call validateInputData() before call this
   * method.
   * 
   * @return the data of bar chart
   * @throws SccException
   */
  public ReportData getDataToShowReport(final String viewName, final boolean isOnlineReport) throws SccException {
    initializeInputData();

    boolean needGroupColumn = false;
    String orderCategories = null;
    if (MULTIPLE_CATEGORY.equals(categoryOption)) {
      needGroupColumn = true;
      orderCategories = categoriesOrder;
    }
    ReportData reportData =
        getValuesToCreateScoreTableAndChart(mirField, orderCategories, needGroupColumn,
            scoreRanges, seriesOrder, viewName, isOnlineReport);
    // if there is data
    if (reportData != null) {
      // set setting to draw chart
      reportData.setSetting(this.copySetting());
    }
    return reportData;
  }

  /**
   * Generate series. {@inheritDoc}
   * 
   * @see com.st.sc.webapp.reports.ScoreTableSetting#generateSeries()
   */
  @Override
  public void generateSeries() {
    super.generateSeries();
    // keep selection one or multiple category
    bindCategoryOption();
  }

  /**
   * Bind category option.
   */
  private void bindCategoryOption() {
    categoryOption = WRequest.getCurrentInstance().getParameter("categoryOption");
    if (ONE_CATEGORY.equals(categoryOption)) {
      isOneCategoryChecked = true;
    } else if (MULTIPLE_CATEGORY.equals(categoryOption)) {
      isOneCategoryChecked = false;
    }
  }

  public BarChartSetting copySetting() {
    BarChartSetting setting = new BarChartSetting();
    updateSetting(setting);
    setting.setCategoriesOrder(categoriesOrder);
    setting.setSeriesOrder(seriesOrder);
    setting.setCategoryOption(categoryOption);
    setting.setChartType(chartType);
    setting.setPercentageBarChartWidth(percentageBarChartWidth);
    return setting;
  }

  /**
   * Gets the one category checked.
   * 
   * @return the one category checked
   */
  public String getOneCategoryChecked() {
    if (isOneCategoryChecked) {
      return "checked";
    }
    return "";
  }

  /**
   * Gets the multiple category checked.
   * 
   * @return the multiple category checked
   */
  public String getMultipleCategoryChecked() {
    if (!isOneCategoryChecked) {
      return "checked";
    }
    return "";
  }

  /**
   * Gets the series order.
   * 
   * @return the seriesOrder
   */
  public String getSeriesOrder() {
    return seriesOrder;
  }

  /**
   * Sets the series order.
   * 
   * @param seriesOrder
   *          the seriesOrder to set
   */
  public void setSeriesOrder(String seriesOrder) {
    this.seriesOrder = seriesOrder;
  }

  /**
   * Gets the categories order.
   * 
   * @return the categoriesOrder
   */
  public String getCategoriesOrder() {
    return categoriesOrder;
  }

  /**
   * Sets the categories order.
   * 
   * @param categoriesOrder
   *          the categoriesOrder to set
   */
  public void setCategoriesOrder(String categoriesOrder) {
    this.categoriesOrder = categoriesOrder;
  }

  /**
   * Gets the category option.
   * 
   * @return the categoryOption
   */
  public String getCategoryOption() {
    return categoryOption;
  }

  /**
   * @param categoryOption
   *          the categoryOption to set
   */
  public void setCategoryOption(String categoryOption) {
    this.categoryOption = categoryOption;
  }

  /**
   * Gets the chart type.
   * 
   * @return the chartType
   */
  public String getChartType() {
    return chartType;
  }

  /**
   * Sets the chart type.
   * 
   * @param chartType
   *          the chartType to set
   */
  public void setChartType(String chartType) {
    this.chartType = chartType;
  }

  /**
   * @return the percentageBarChartWidth
   */
  public int getPercentageBarChartWidth() {
    return percentageBarChartWidth;
  }

  /**
   * @param percentageBarChartWidth
   *          the percentageBarChartWidth to set
   */
  public void setPercentageBarChartWidth(int percentageBarChartWidth) {
    this.percentageBarChartWidth = percentageBarChartWidth;
  }

}
