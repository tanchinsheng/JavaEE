/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 3, 2011 8:55:28 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.ruleandruleset;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.db.DataSet;
import st.liotrox.web.html.Html;

import com.st.common.web.filter.HTTPCacheHeader;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.persistence.util.ReflecttionUtils;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.RuleSet;
import com.st.sc.entity.RuleSetOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RulesOfRS;
import com.st.sc.entity.util.Util;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.rulemanager.EntityExecutor;
import com.st.sc.rulemanager.QueryExecutor;
import com.st.sc.rulemanager.QueryStringExecutor;
import com.st.sc.rulemanager.RuleSetService;
import com.st.sc.rulemanager.serialization.rule.TRuleSet;
import com.st.sc.rulemanager.util.RuleHelper;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.RuleSetDTO;
import com.st.sc.web.data.RuleSetVersionDTO;
import com.st.sc.webapp.BaseAction;

public class RulesetManagementAction extends BaseAction {

  private static final Logger LOGGER = LoggerFactory.getLogger(RulesetManagementAction.class);

  private DataView dataViewRuleSet;
  private DataView dataViewRuleSetVersion;
  private DataSet ruleSetDataSet = null;
  private DataSet ruleSetVerionDataSet = null;

  private String errorCheckSelectedRecord;
  private String errorCopyRuleSet;
  private boolean showVersion = false;
  private boolean isOwnersOfRuleSet = false;

  private final String CONNECTOR = ",";

  private static final String[] DS_RULE_SET_COLUMNS = new String[]{"ruleSetId", "name",
      "owners", "origin", "defaultRuleSet", "lastUpdate", "activeVersionId",
      "activeVersionNum", "alarmThesholdStr", "description" };

  private static final String[] DS_RULE_SET_VERSION_COLUMNS = new String[]{"ruleSetId",
      "ruleSetVersionId", "alarmThresholdStr", "status", "description", "origin", "updatedOn",
      "version" };

  private Long selectedRuleSetId;
  private String selectedRuleSetName;

  /**
   * Constructor.
   */
  public RulesetManagementAction() {
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#beforeRender(st.liotrox.WRequest)
   */
  @Override
  protected void beforeRender(WRequest request) {
    // Add javacript function call in OnLoad(), to show error message if have.
    addOnLoadCode("checkAndShowErrorMesage();");
    // This function is not used on Netscape.
    // it is used for show input popup to copy rule set.
    if (!request.is_NS_Browser()) {
      addOnLoadCode("checkCopyRuleSet();");
    }
    checkUserRole(request);
    super.beforeRender(request);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.webapp.BaseAction#checkUserRole(st.liotrox.WRequest)
   */
  @Override
  protected void checkUserRole(WRequest request) {
    super.checkUserRole(request);
    if (!getIsManaged()) {
      isOwnersOfRuleSet = false;
    }
  }

  /**
   * This is called when event such as: click next,previous page. It not go to
   * doShow() function. Therefore, must create dataSet to display. {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#beforePopulate(st.liotrox.WRequest)
   */
  @Override
  protected void beforePopulate(WRequest request) {
    if (dataViewRuleSet == null) {
      dataViewRuleSet = getDataViewFromRequest("ruleSetDataView");
    }

    if (dataViewRuleSetVersion == null) {
      dataViewRuleSetVersion = getDataViewFromRequest("rulesetVersionDataView");
    }
    clearErrorMessage();
    super.beforePopulate(request);
  }

  private void clearErrorMessage() {
    errorCheckSelectedRecord = "";
    errorMessage = "";
    infoMessage = "";
    errorCopyRuleSet = "";
  }

  public void doShow(WRequest request, Event event) {
    clearErrorMessage();
    showVersion = false;
    refeshRuleSetDataSet();
  }

  private void refeshRuleSetDataSet() {
    ruleSetDataSet = createRuleSetDataSet();

    int currentPage = getDataViewRuleSet().getCurrentPage();
    getDataViewRuleSet().getModel().setDataSet(ruleSetDataSet);
    if (currentPage > 0) {
      getDataViewRuleSet().gotoPage(currentPage);
    }
  }

  private DataView getDataViewRuleSet() {
    if (dataViewRuleSet == null) {
      dataViewRuleSet = getDataViewFromRequest("ruleSetDataView");
    }
    return dataViewRuleSet;
  }

  /**
   * Gets the data set.
   * 
   * @return the data set
   */
  public DataSet createRuleSetDataSet() {
    final EntityManager entityManager =
        SCWebServiceFactory.getScEntityManagerFactory().createEntityManager();
    DataSet dsRuleset = null;
    try {
      RuleSetService ruleSetSer = new RuleSetService(SCWebServiceFactory.getScBaseService());
      List<RuleSet> rulesetList = ruleSetSer.getAllRuleSets(entityManager);
      // Create DTO list to display on dataview.
      List<RuleSetDTO> listDto = createRuleSetDTO(rulesetList);
      dsRuleset = createDataSet(listDto);
    } finally {
      entityManager.close();
    }
    return dsRuleset;
  }

  /**
   * Create list of RuleSetDTO from list of RuleSet.
   * 
   * @param rulesetList
   * @return list of RuleSetDTO
   */
  private List<RuleSetDTO> createRuleSetDTO(List<RuleSet> rulesetList) {
    List<RuleSetDTO> listDTO = new ArrayList<RuleSetDTO>();
    if (rulesetList != null && rulesetList.size() > 0) {
      for (RuleSet rs : rulesetList) {
        RuleSetDTO dto = new RuleSetDTO();
        dto.setRuleSetId(rs.getRuleSetId());
        dto.setName(rs.getName());
        dto.setOrigin(rs.getOrigin());
        final Timestamp timestamp = rs.getUpdatedOn();
        if (timestamp != null) {
          dto.setLastUpdate(new Date(timestamp.getTime()));
        }
        List<RuleSetVersion> rsVersions = rs.getRuleSetVersions();
        if (rsVersions != null && rsVersions.size() > 0) {
          for (RuleSetVersion rsv : rsVersions) {
            if (rsv.getStatus()) {
              dto.setActiveVersionId(rsv.getRuleSetVersionId());
              dto.setActiveVersionNum(rsv.getVersion());
              dto.setAlarmTheshold(rsv.getAlarmThreshold());
              dto.setDescription(rsv.getDescription());
              // If there is a active version, we get the last update on of rule
              // set version.
              // dto.setLastUpdate(rsv.getUpdatedOn());
              break;
            }
          }
        }
        // Get owners list.
        if (rs.getUserRuleSets() != null && rs.getUserRuleSets().size() > 0) {
          StringBuilder builder = new StringBuilder();
          for (RuleSetOwners user : rs.getUserRuleSets()) {
            builder.append(user.getId().getUserName()).append(SCConstants.STRING_CONNECTOR);
          }
          // Remove the last connector string.
          if (builder.length() > 0) {
            builder.setLength(builder.length() - SCConstants.STRING_CONNECTOR.length());
          }
          dto.setOwners(builder.toString());
        }
        listDTO.add(dto);
      }
    }
    return listDTO;
  }

  private boolean checkSelectedRecordOfRuleSetList() {
    int[] selectedRows = getDataViewRuleSet().getSelectedRows();
    if (selectedRows.length != 1) {
      errorCheckSelectedRecord = CommonUtils.getCommonBundleMessage("choose_one_record");
      return false;
    } else {
      return true;
    }
  }

  private Long getRuleSetId(int rowIndex) {
    Long ruleSetId =
        (Long) getDataViewRuleSet().getModel().getDataSet().getValue(rowIndex, "ruleSetId");
    return ruleSetId;
  }

  private String getRuleSetName(int rowIndex) {
    String name =
        (String) getDataViewRuleSet().getModel().getDataSet().getValue(rowIndex, "name");
    return name;
  }

  public void doDeleteRuleSet(WRequest request, Event event) {
    // clear message.
    clearErrorMessage();
    long startTime = System.currentTimeMillis();
    int[] selectedRows = getDataViewRuleSet().getSelectedRows();
    if (selectedRows.length == 0) {
      errorCheckSelectedRecord = CommonUtils.getCommonBundleMessage("choose_least_one_record");
    } else {
      // Build error message to show on GUI.
      StringBuilder errorBuilder1 = new StringBuilder();
      StringBuilder errorBuilder2 = new StringBuilder();
      StringBuilder errorBuilder3 = new StringBuilder();
      final String errorMsgHaveActiveVersion =
          CommonUtils.getRuleSetBundleMessage("cannot_delete_becaseof_active_version");
      final String errorDelete = CommonUtils.getRuleSetBundleMessage("error_delete_rule_set");
      final String errorOwners =
          CommonUtils.getRuleSetBundleMessage("user_not_owner_rule_set");
      errorBuilder1.append(errorMsgHaveActiveVersion);
      errorBuilder2.append(errorDelete);
      errorBuilder3.append(errorOwners);
      StringBuilder trackingBuilder = new StringBuilder();
      RuleSetService ruleSetServ = new RuleSetService(SCWebServiceFactory.getScBaseService());
      for (int i = 0; i < selectedRows.length; i++) {
        Long ruleSetId = getRuleSetId(selectedRows[i]);
        // Get rule set to check owners.
        RuleSet ruleSet =
            SCWebServiceFactory.getScBaseService().queryByPrimaryKey(RuleSet.class, ruleSetId);
        if (ruleSet != null) {
          boolean isOwner = checkLoginUserIsOwnerRuleSet(request, ruleSet);
          if (isOwner) {
            // Check active version of rule set. If all is 'InActive' , you can
            // delete.
            // Long count = ruleSetServ.countActiveVersion(ruleSetId);
            List<RuleSetVersion> ls = ruleSetServ.getActiveVersions(ruleSetId);
            if (ls == null || ls.size() == 0) {
              try {
                List<QueryExecutor> listQuery = new ArrayList<QueryExecutor>();
                List<RuleSetVersion> rsVersions = ruleSetServ.getVersions(ruleSetId);
                if (rsVersions != null && rsVersions.size() > 0) {
                  for (RuleSetVersion rsv : rsVersions) {
                    Map<String, Object> parameters = new HashMap<String, Object>();
                    parameters.put("ruleSetVersionId", rsv.getRuleSetVersionId());
                    listQuery.add(new QueryStringExecutor(QueryExecutor.NAMED_QUERY,
                        RulesOfRS.DELETE_RULES_OF_RSV, parameters));
                  }
                }
                // delete rule set.
                listQuery.add(new EntityExecutor(RuleSet.class, ruleSetId));
                SCWebServiceFactory.getScBaseService().executeMultipleQuery(listQuery);
                trackingBuilder.append(ruleSet.getName()).append(";");
              } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
                errorBuilder2.append(getRuleSetName(selectedRows[i])).append(CONNECTOR);
              }

            } else {
              errorBuilder1.append("[").append(getRuleSetName(selectedRows[i]))
                  .append(",Version=").append(ls.get(0).getVersion()).append("]")
                  .append(CONNECTOR);
            }
          } else {
            errorBuilder3.append(getRuleSetName(selectedRows[i])).append(CONNECTOR);
          }
        }
      }
      try {
        // Action log if there is deleted rule set.
        String parameters = trackingBuilder.toString();
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Delete Rule Set");
          // remove last ';'
          tracking.setParameters(parameters.substring(0, parameters.length() - 1));
          tracking.setElapsedTime(System.currentTimeMillis() - startTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }
      // show message to user.
      if (errorBuilder1.length() > errorMsgHaveActiveVersion.length()
          || errorBuilder2.length() > errorDelete.length()
          || errorBuilder3.length() > errorOwners.length()) {
        if (errorBuilder1.length() > errorMsgHaveActiveVersion.length()) {
          combineErrorMsg(errorBuilder1);
        }
        // Have error when delete
        if (errorBuilder2.length() > errorDelete.length()) {
          combineErrorMsg(errorBuilder2);
        }
        if (errorBuilder3.length() > errorOwners.length()) {
          combineErrorMsg(errorBuilder3);
        }
      } else {
        infoMessage = CommonUtils.getRuleSetBundleMessage("delete_successful");
      }
      // refesh page
      refeshRuleSetDataSet();
      showVersion = false;
    }
  }

  private void combineErrorMsg(StringBuilder builder) {
    // remove last connector character ';'
    builder.setLength(builder.length() - CONNECTOR.length());
    if (errorMessage.length() > 0) {
      errorMessage += SCConstants.NEW_LINE;
    }
    errorMessage += builder.toString();
  }

  public void showRuleSetVersion(WRequest request, Event event) {
    // clear message.
    clearErrorMessage();

    refeshRuleSetVersionDataView(request);
  }

  private void refeshRuleSetVersionDataView(WRequest request) {
    if (!checkSelectedRecordOfRuleSetList()) {
      return;
    }
    showVersion = true;
    int[] selectedRows = dataViewRuleSet.getSelectedRows();
    selectedRuleSetId = getRuleSetId(selectedRows[0]);
    // get rule set name to display on GUI.
    selectedRuleSetName = getRuleSetName(selectedRows[0]);
    if (!checkExistRuleSet(request, selectedRuleSetId)) {
      return;
    }

    RuleSetService serv = new RuleSetService(SCWebServiceFactory.getScBaseService());
    List<RuleSetVersion> ruleSetVersionList = serv.getVersions(selectedRuleSetId);
    List<RuleSetVersionDTO> listDto = createRuleSetVersionDTO(ruleSetVersionList);
    ruleSetVerionDataSet = createDataSet(listDto);
    dataViewRuleSetVersion.getModel().setDataSet(ruleSetVerionDataSet);

    // Check authorized for user
    if (ruleSetVersionList != null && ruleSetVersionList.size() > 0) {
      if (getIsManaged()) {
        isOwnersOfRuleSet =
            checkLoginUserIsOwnerRuleSet(request, ruleSetVersionList.get(0).getRuleSet());
      }
    } else {
      isOwnersOfRuleSet = false;
    }
  }

  private boolean checkSelectedRecordOfRuleSetVersionList() {
    int[] selectedRows = dataViewRuleSetVersion.getSelectedRows();
    if (selectedRows.length != 1) {
      errorCheckSelectedRecord = CommonUtils.getCommonBundleMessage("choose_one_record");
      return false;
    } else {
      return true;
    }
  }

  private Long getRuleSetVersionIdOfRuleSetVersionDataView(int rowIndex) {
    Long ruleSetVersionId =
        (Long) dataViewRuleSetVersion.getModel().getDataSet()
            .getValue(rowIndex, RuleSetVersionDTO.FIELD_RULESET_VERSION_ID);
    return ruleSetVersionId;
  }

  private Long getRuleSetIdOfRuleSetVersionDataView(int rowIndex) {
    Long ruleSetId =
        (Long) dataViewRuleSetVersion.getModel().getDataSet()
            .getValue(rowIndex, RuleSetVersionDTO.FIELD_RULESET_ID);
    return ruleSetId;
  }

  private Boolean getRuleSetVersionStatus(int rowIndex) {
    Boolean status =
        (Boolean) dataViewRuleSetVersion.getModel().getDataSet()
            .getValue(rowIndex, RuleSetVersionDTO.FIELD_STATUS);
    return status;
  }

  private Integer getRuleSetVersion(int rowIndex) {
    Integer version =
        (Integer) dataViewRuleSetVersion.getModel().getDataSet()
            .getValue(rowIndex, RuleSetVersionDTO.FIELD_VERSION);
    return version;
  }

  public void doEditRuleSetVersion(WRequest request, Event event) {
    if (!checkSelectedRecordOfRuleSetVersionList()) {
      return;
    }
    Long ruleSetVersionId =
        getRuleSetVersionIdOfRuleSetVersionDataView(dataViewRuleSetVersion.getSelectedRows()[0]);

    // Check whether rule set was deleted.
    if (!checkExistRuleSetVersion(request, ruleSetVersionId)) {
      return;
    }

    String url =
        SCConstants.getContextPath() + SCConstants.RULE_SET_CONDITION_URL
            + ".doShow?type=edit&ruleSetVersionId=" + ruleSetVersionId;
    request.redirectTo(url);
  }

  public void showRuleListOfRuleSetVersion(WRequest request, Event event) {
    if (!checkSelectedRecordOfRuleSetVersionList()) {
      return;
    }
    Long ruleSetVersionId =
        getRuleSetVersionIdOfRuleSetVersionDataView(dataViewRuleSetVersion.getSelectedRows()[0]);

    // Check whether rule set was deleted.
    if (!checkExistRuleSetVersion(request, ruleSetVersionId)) {
      return;
    }

    redirectToShowRuleListPage(request, ruleSetVersionId);
  }

  public void doDeleteRuleSetVersion(WRequest request, Event event) {
    // clear message.
    clearErrorMessage();
    long startTime = System.currentTimeMillis();
    int[] selectedRows = dataViewRuleSetVersion.getSelectedRows();
    if (selectedRows.length == 0) {
      errorCheckSelectedRecord = CommonUtils.getCommonBundleMessage("choose_least_one_record");
    } else {
      StringBuilder errorBuilder = new StringBuilder();
      final String errorDelete =
          CommonUtils.getRuleSetBundleMessage("error_when_delete_version");
      errorBuilder.append(errorDelete);

      StringBuilder trackingBuilder = new StringBuilder();
      Long ruleSetVersionId = null;
      for (int i = 0; i < selectedRows.length; i++) {
        ruleSetVersionId = getRuleSetVersionIdOfRuleSetVersionDataView(selectedRows[i]);
        Boolean status = getRuleSetVersionStatus(selectedRows[i]);
        if (status != null && status == true) {
          // Active version
          errorMessage = CommonUtils.getRuleSetBundleMessage("cannot_delete_active_version");
        } else {
          List<QueryExecutor> listQuery = new ArrayList<QueryExecutor>();
          Map<String, Object> parameters = new HashMap<String, Object>();
          parameters.put("ruleSetVersionId", ruleSetVersionId);
          listQuery.add(new QueryStringExecutor(QueryExecutor.NAMED_QUERY,
              RulesOfRS.DELETE_RULES_OF_RSV, parameters));
          listQuery.add(new EntityExecutor(RuleSetVersion.class, ruleSetVersionId));
          try {
            SCWebServiceFactory.getScBaseService().executeMultipleQuery(listQuery);
            if (trackingBuilder.length() == 0) {
              trackingBuilder.append("Rule Set Name: " + selectedRuleSetName).append(
                  ". Version=");
            }
            trackingBuilder.append(getRuleSetVersion(selectedRows[i])).append(";");
          } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            errorBuilder.append(getRuleSetVersion(selectedRows[i])).append(CONNECTOR);
          }
        }
      }
      if (errorBuilder.length() > errorDelete.length()) {
        // remove last connector.
        errorBuilder.setLength(errorBuilder.length() - CONNECTOR.length());
        errorMessage += SCConstants.NEW_LINE + errorBuilder.toString();
      }

      // Check : If this rule set has no version, system will remove this rule
      // set.
      RuleSetService ruleSetSer = new RuleSetService(SCWebServiceFactory.getScBaseService());
      Long ruleSetId = getRuleSetIdOfRuleSetVersionDataView(selectedRows[0]);
      long numVersion = ruleSetSer.countNumberVersion(ruleSetId);
      if (numVersion == 0) {
        try {
          SCWebServiceFactory.getScBaseService().deleteEntity(RuleSet.class, ruleSetId);
        } catch (Exception e) {
          LOGGER.error(e.getMessage(), e);
          errorMessage +=
              SCConstants.NEW_LINE
                  + CommonUtils.getRuleSetBundleMessage("error_delete_ruleset_and_version");
        }
      }

      try {
        // Action log if there is deleted rule set version.
        String parameters = trackingBuilder.toString();
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Delete Rule Set Version");
          // remove last ';'
          tracking.setParameters(parameters.substring(0, parameters.length() - 1));
          tracking.setElapsedTime(System.currentTimeMillis() - startTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }
      if (errorMessage == null || errorMessage.length() == 0) {
        infoMessage = CommonUtils.getRuleSetBundleMessage("delete_successful");
      }

      if (numVersion > 0) {
        // refesh list of rule set version.
        doRefeshRuleSetVersionNoClearMsg(request);
      } else {
        // refesh rule set list.
        refeshRuleSetDataSet();
        showVersion = false;
      }
    }
  }

  public void doActiveDeactive(WRequest request, Event event) {
    // clear message.
    clearErrorMessage();
    long startTime = System.currentTimeMillis();
    if (!checkSelectedRecordOfRuleSetVersionList()) {
      return;
    }
    // Get rule set version id from view.
    Long ruleSetVersionId =
        getRuleSetVersionIdOfRuleSetVersionDataView(dataViewRuleSetVersion.getSelectedRows()[0]);

    BaseService base = new BaseService(SCWebServiceFactory.getScEntityManagerFactory());
    EntityManager entityManager = base.getEntityManagerFactory().createEntityManager();
    RuleSetVersion ruleSetVersion =
        base.queryByPrimaryKey(entityManager, RuleSetVersion.class, ruleSetVersionId);
    if (ruleSetVersion == null) {
      errorCheckSelectedRecord =
          CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");

      doRefeshRuleSetVersionNoClearMsg(request);
      return;
    }
    // If active version, must check number rules of rule set.
    if (!ruleSetVersion.getStatus()) {
      // Get number of rules of rule set.
      List<RulesOfRS> listRuleOfRS =
          new RuleSetService(base).getListRulesOfRS(ruleSetVersionId);
      // check this rule set have any rule .
      if (listRuleOfRS.size() == 0) {
        errorMessage = CommonUtils.getRuleSetBundleMessage("active_rule_set_must_have_rule");
        return;
      }
    }
    StringBuilder trackingBuilder = new StringBuilder();
    trackingBuilder.append("Rule Set Name: ").append(ruleSetVersion.getRuleSet().getName());
    Timestamp current = SCWebServiceFactory.getSCExecutor().getSysDate();
    ruleSetVersion.setStatusUpdatedTime(current);
    List<QueryExecutor> listExecutor = new ArrayList<QueryExecutor>();
    if (ruleSetVersion.getStatus()) {
      // Deactive status of this rule set version.
      ruleSetVersion.setStatus(false);
      listExecutor.add(new EntityExecutor(QueryExecutor.UPDATE_ENTITY, ruleSetVersion));
      trackingBuilder.append(".Deactive version=").append(ruleSetVersion.getVersion());
    } else {
      // Active this version, must deactive another version.
      ruleSetVersion.setStatus(true);
      listExecutor.add(new EntityExecutor(QueryExecutor.UPDATE_ENTITY, ruleSetVersion));
      // Get active vesion of rule set and deactive it.
      RuleSetService ruleSetServ = new RuleSetService(base);
      List<RuleSetVersion> listActiveVersion =
          ruleSetServ.getActiveVersions(ruleSetVersion.getRuleSetId());
      if (listActiveVersion != null && listActiveVersion.size() > 0) {
        for (RuleSetVersion rsv : listActiveVersion) {
          rsv.setStatus(false);
          rsv.setStatusUpdatedTime(current);
          listExecutor.add(new EntityExecutor(QueryExecutor.UPDATE_ENTITY, rsv));
        }
      }
      trackingBuilder.append(".Active version=").append(ruleSetVersion.getVersion());
    }
    try {
      base.executeMultipleQuery(listExecutor);

      try {
        // Action log if there is active rule set version.
        String parameters = trackingBuilder.toString();
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Active/Deactive Rule Set");
          // remove last ';'
          tracking.setParameters(parameters);
          tracking.setElapsedTime(System.currentTimeMillis() - startTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }
    } catch (Exception ex) {
      LOGGER.error(ex.getMessage(), ex);
      errorMessage = CommonUtils.getRuleSetBundleMessage("fail_active_version");
    }
    base.closeEntityManager(entityManager);

    // Update view of rule set list.
    updateRuleSetList(ruleSetVersion.getStatus());

    // refesh rule set version view
    showRuleSetVersion(request, event);
  }

  public void doEditRuleList(final WRequest request, final Event event) {
    if (!checkSelectedRecordOfRuleSetVersionList()) {
      return;
    }
    Long ruleSetVersionId =
        getRuleSetVersionIdOfRuleSetVersionDataView(dataViewRuleSetVersion.getSelectedRows()[0]);

    // Check whether rule set was deleted.
    if (!checkExistRuleSetVersion(request, ruleSetVersionId)) {
      return;
    }

    redirectToEditRuleListOfRuleSetPage(request, ruleSetVersionId, null);
  }

  public void doValidateRuleSet(final WRequest request, final Event event) {
    if (!checkSelectedRecordOfRuleSetVersionList()) {
      return;
    }
    Long ruleSetVersionId =
        getRuleSetVersionIdOfRuleSetVersionDataView(dataViewRuleSetVersion.getSelectedRows()[0]);

    // Check whether rule set was deleted.
    BaseService base = SCWebServiceFactory.getScBaseService();
    EntityManager entityManager = base.getEntityManagerFactory().createEntityManager();
    RuleSetVersion ruleSetVersion =
        base.queryByPrimaryKey(entityManager, RuleSetVersion.class, ruleSetVersionId);
    boolean stop = false;
    if (ruleSetVersion == null) {
      errorCheckSelectedRecord =
          CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");

      doRefeshRuleSetVersionNoClearMsg(request);
      stop = true;
    } else {
      if (ruleSetVersion.getRuleVersions() == null
          || ruleSetVersion.getRuleVersions().size() == 0) {
        errorMessage = CommonUtils.getRuleSetBundleMessage("validate_ruleset_must_have_rule");
        stop = true;
      }
    }
    base.closeEntityManager(entityManager);
    if (stop) {
      return;
    }
    String url =
        SCConstants.getContextPath() + SCConstants.RULE_SET_VALIDATION_URL + "?"
            + SCConstants.PARAMETER_RULE_SET_VERSION_ID + "=" + ruleSetVersionId;
    request.redirectTo(url);
  }

  public void doCopyRuleSetVersion(final WRequest request, final Event event) {
    // clear message.
    clearErrorMessage();
    if (!checkSelectedRecordOfRuleSetVersionList()) {
      return;
    }
    long startTime = System.currentTimeMillis();
    Long ruleSetVersionId =
        getRuleSetVersionIdOfRuleSetVersionDataView(dataViewRuleSetVersion.getSelectedRows()[0]);

    // Check whether rule set was deleted.
    if (!checkExistRuleSetVersion(request, ruleSetVersionId)) {
      return;
    }
    BaseService baseSvr = SCWebServiceFactory.getScBaseService();
    RuleSetService ruleSetSer = new RuleSetService(baseSvr);

    EntityManager entityManager = baseSvr.getEntityManagerFactory().createEntityManager();
    try {
      RuleSetVersion ruleSetVersion =
          baseSvr.queryByPrimaryKey(entityManager, RuleSetVersion.class, ruleSetVersionId);
      // Check role of user, if user is engineer and rule set have no MIR
      // criteria, do not permit copy.
      String role = request.getUserProfile().getAttribute("liotrox.role");
      if (!"admin".equals(role) && Util.countMirCriteria(ruleSetVersion.getMirCriteria()) == 0) {
        errorMessage = CommonUtils.getRuleSetBundleMessage("rule_set_mir_empty_cannot_copy");
        return;
      }
      // Get new rule set name
      String newRuleSetName = event.getParameter("newRuleSetName");
      if (newRuleSetName == null || "".equals(newRuleSetName)) {
        // Please user input new rule set name.
        errorCopyRuleSet =
            CommonUtils.getRuleSetBundleMessage("please_input_new_rule_set_name");
        return;
      }
      // Check name exist or not.
      if (ruleSetSer.getRuleSetByName(newRuleSetName) != null) {
        errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_name_exist");
        return;
      }
      // begin insert
      RuleSet ruleSet = ruleSetVersion.getRuleSet();
      List<RuleSetOwners> listUsers = ruleSet.getUserRuleSets();
      // close this session.
      baseSvr.closeEntityManager(entityManager);
      // Get list rule of rule set.
      List<RulesOfRS> listOfRule = ruleSetSer.getListRulesOfRS(ruleSetVersionId);

      // Get new rule set Id.
      Long newRuleSetId =
          SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET);
      // Get new rule set version id.
      Long newRuleSetVersionId =
          SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET_VERSION);

      String loginUser = request.getUserProfile().getAttribute("liotrox.user");
      // Get current time
      Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
      // Update new id, name to current rule set.
      ruleSet.setRuleSetId(newRuleSetId);
      ruleSet.setName(newRuleSetName);
      ruleSet.setUpdatedOn(currentTime);
      ruleSet.setCreatedBy(loginUser);
      // Update new id, version to current rule set version.
      ruleSetVersion.setRuleSetId(newRuleSetId);
      ruleSetVersion.setRuleSetVersionId(newRuleSetVersionId);
      ruleSetVersion.setVersion(1);
      ruleSetVersion.setStatus(false); // No active.
      ruleSetVersion.setUpdatedBy(loginUser);
      ruleSetVersion.setUpdatedOn(currentTime);
      if (Util.countMirCriteria(ruleSetVersion.getMirCriteria()) > 0) {
        // Update Id for MiR criteria
        ruleSetVersion.getMirCriteria().setRuleSetVersionId(newRuleSetVersionId);
        ruleSetVersion.getMirCriteria().setRuleSetVersion(ruleSetVersion);
      } else {
        ruleSetVersion.setMirCriteria(null);
      }
      // Update new id for list users.
      if (listUsers != null && listUsers.size() > 0) {
        boolean existUserInList = false;
        for (RuleSetOwners user : listUsers) {
          user.getId().setRuleSetId(newRuleSetId);
          if (loginUser.equalsIgnoreCase(user.getId().getUserName())) {
            existUserInList = true;
          }
        }
        if (!existUserInList) {
          listUsers.add(new RuleSetOwners(loginUser, newRuleSetId));
        }
      } else {
        listUsers.add(new RuleSetOwners(loginUser, newRuleSetId));
      }

      // empty users of rule to not exception.
      ruleSet.setUserRuleSets(null);

      // Update new id for list of rule.
      if (listOfRule != null && listOfRule.size() > 0) {
        for (RulesOfRS r : listOfRule) {
          r.getId().setRuleSetVersionId(newRuleSetVersionId);
        }
      }

      // Begin insert to database.
      List<QueryExecutor> listExecutor = new ArrayList<QueryExecutor>();
      // Update rule set and its version
      listExecutor.add(new EntityExecutor(QueryExecutor.INSERT_ENTITY, ruleSet));
      listExecutor.add(new EntityExecutor(QueryExecutor.INSERT_ENTITY, ruleSetVersion));
      // Update new id for list users.
      if (listUsers != null && listUsers.size() > 0) {
        for (RuleSetOwners userRuleset : listUsers) {
          listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, userRuleset));
        }
      }
      // Update new id for list of rule.
      if (listOfRule != null && listOfRule.size() > 0) {
        for (RulesOfRS rulesOfRS : listOfRule) {
          listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, rulesOfRS));
        }
      }
      baseSvr.executeMultipleQuery(listExecutor);

      try {
        // Action log if there is deleted rule set version.
        Integer version = getRuleSetVersion(dataViewRuleSetVersion.getSelectedRows()[0]);
        String parameters =
            "Selected Rule Set: " + selectedRuleSetName + ", Version=" + version
                + ". New Rule Set:" + newRuleSetName;
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Copy Rule Set Version");
          // remove last ';'
          tracking.setParameters(parameters);
          tracking.setElapsedTime(System.currentTimeMillis() - startTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }
      refeshRuleSetDataSet();
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = CommonUtils.getRuleSetBundleMessage("error_when_save_ruleset");
    }

  }

  public void doRefeshRuleSetVersion(WRequest request, Event event) {
    // check rule set on dataview
    checkSelectRuleSet();

    showRuleSetVersion(request, event);
  }

  private void doRefeshRuleSetVersionNoClearMsg(WRequest request) {
    // check rule set on dataview
    checkSelectRuleSet();

    refeshRuleSetVersionDataView(request);
  }

  private boolean checkExistRuleSet(WRequest request, Long ruleSetId) {
    BaseService base = SCWebServiceFactory.getScBaseService();
    RuleSet ruleSet = base.queryByPrimaryKey(RuleSet.class, ruleSetId);
    if (ruleSet == null) {
      errorCheckSelectedRecord = CommonUtils.getRuleSetBundleMessage("ruleset_was_deleted");

      refeshRuleSetDataSet();
      showVersion = false;
      return false;
    }
    return true;
  }

  private boolean checkExistRuleSetVersion(WRequest request, Long ruleSetVersionId) {
    BaseService base = SCWebServiceFactory.getScBaseService();
    RuleSetVersion ruleSetVersion =
        base.queryByPrimaryKey(RuleSetVersion.class, ruleSetVersionId);
    if (ruleSetVersion == null) {
      errorCheckSelectedRecord =
          CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");

      doRefeshRuleSetVersionNoClearMsg(request);
      return false;
    }
    return true;
  }

  /**
   * Update data on rule set List when : Active or deactive a rule set version.
   */
  private void updateRuleSetList(boolean isActive) {
    // check rule set on dataview
    checkSelectRuleSet();

    // In case, there is only one selected row on each dataview.
    int[] rowRuleSet = dataViewRuleSet.getSelectedRows();
    int[] rowRuleSetVersion = dataViewRuleSetVersion.getSelectedRows();
    if (rowRuleSet != null && rowRuleSet.length > 0) {
      // Get info of selected rule set version.
      Long ruleSetVersionId = null;
      Integer version = null;
      String desc = "";
      String alarm = "";

      if (isActive) {
        DataSet dsRulSet = dataViewRuleSetVersion.getModel().getDataSet();
        // If this version is active, must get other information of rule set.
        ruleSetVersionId =
            (Long) dsRulSet.getValue(rowRuleSetVersion[0],
                RuleSetVersionDTO.FIELD_RULESET_VERSION_ID);
        version =
            (Integer) dsRulSet.getValue(rowRuleSetVersion[0], RuleSetVersionDTO.FIELD_VERSION);
        desc =
            (String) dsRulSet.getValue(rowRuleSetVersion[0],
                RuleSetVersionDTO.FIELD_DESCRIPTION);
        alarm =
            (String) dsRulSet.getValue(rowRuleSetVersion[0],
                RuleSetVersionDTO.FIELD_ALARM_THRESHOLD);
      }

      // Set info of rule set version to rule set dataview.
      DataSet dsRuleSetVersion = dataViewRuleSet.getModel().getDataSet();
      dsRuleSetVersion.setValue(rowRuleSet[0], RuleSetDTO.ACTIVE_VERSION_ID, ruleSetVersionId);
      dsRuleSetVersion.setValue(rowRuleSet[0], RuleSetDTO.ACTIVE_VERSION_NUM, version);
      dsRuleSetVersion.setValue(rowRuleSet[0], RuleSetDTO.ACTIVE_VERSION_DESC, desc);
      dsRuleSetVersion.setValue(rowRuleSet[0], RuleSetDTO.ACTIVE_VERSION_ALARM, alarm);
    }
  }

  public void doBackToPage(WRequest request, Event event) {
    // clear message.
    clearErrorMessage();

    if (dataViewRuleSet != null && dataViewRuleSet.getModel().getDataSet() != null) {
      // check rule set on dataview
      checkSelectRuleSet();

      int[] rowRuleSet = dataViewRuleSet.getSelectedRows();

      String newRecord = request.getParameter(SCConstants.PARAMETER_NEW_RECORD);
      int rowIndex = -1;
      if (newRecord != null) {
        int currentPage = dataViewRuleSet.getCurrentPage();
        String selectedRows = buildSelectedRow(rowRuleSet);

        refeshRuleSetDataSet();
        // dataViewRuleSet.getModel().getDataSet().appendRows(1);
        // rowIndex = dataViewRuleSet.getModel().getDataSet().getRowCount();

        dataViewRuleSet.setSelectedRows(selectedRows);
        dataViewRuleSet.gotoPage(currentPage);
      } else {
        if (rowRuleSet.length > 0) {
          rowIndex = rowRuleSet[0];
        }
      }
      if (rowIndex > -1) {
        String ruleSetStr = request.getParameter(SCConstants.PARAMETER_RULE_SET_ID);
        if (ruleSetStr != null && !"null".equals(ruleSetStr)) {
          Long ruleSetId = Long.parseLong(ruleSetStr);
          BaseService baseServ = SCWebServiceFactory.getScBaseService();
          EntityManager entityManager =
              baseServ.getEntityManagerFactory().createEntityManager();
          try {
            RuleSet ruleSet =
                baseServ.queryByPrimaryKey(entityManager, RuleSet.class, ruleSetId);
            if (ruleSet != null) {
              List<RuleSet> list = new ArrayList<RuleSet>();
              list.add(ruleSet);
              List<RuleSetDTO> listDto = createRuleSetDTO(list);
              if (listDto != null && listDto.size() > 0) {
                bindRuleSetDtoToDataSet(listDto.get(0), rowIndex);
              }
            }
          } finally {
            baseServ.closeEntityManager(entityManager);
          }
        }
      }
    } else {
      // create a new dataview.
      doShow(request, event);
    }

    // check if dataview of rule set version is showing or not.
    if (dataViewRuleSetVersion != null
        && dataViewRuleSetVersion.getModel().getDataSet() != null) {
      int[] rowRuleSetVersion = dataViewRuleSetVersion.getSelectedRows();

      String newRecordVersion = request.getParameter(SCConstants.PARAMETER_NEW_RECORD_VERSION);
      int rowIndexVersion = -1;
      if (newRecordVersion != null) {
        int currentPage = dataViewRuleSetVersion.getCurrentPage();
        String selectedRows = buildSelectedRow(rowRuleSetVersion);

        showRuleSetVersion(request, event);
        // dataViewRuleSetVersion.getModel().getDataSet().appendRows(1);
        // rowIndexVersion =
        // dataViewRuleSetVersion.getModel().getDataSet().getRowCount();
        //
        dataViewRuleSetVersion.setSelectedRows(selectedRows);
        dataViewRuleSetVersion.gotoPage(currentPage);
      } else {
        if (rowRuleSetVersion.length > 0) {
          rowIndexVersion = rowRuleSetVersion[0];
        }
        if (rowIndexVersion > -1) {
          String ruleSetVersionStr =
              request.getParameter(SCConstants.PARAMETER_RULE_SET_VERSION_ID);
          if (ruleSetVersionStr != null && !"null".equals(ruleSetVersionStr)) {
            Long ruleSetVersionId = Long.parseLong(ruleSetVersionStr);
            BaseService baseServ = SCWebServiceFactory.getScBaseService();
            EntityManager entityManager =
                baseServ.getEntityManagerFactory().createEntityManager();
            try {
              RuleSetVersion ruleSetVersion =
                  baseServ.queryByPrimaryKey(entityManager, RuleSetVersion.class,
                      ruleSetVersionId);
              if (ruleSetVersion != null) {
                List<RuleSetVersion> ruleSetVersionList = new ArrayList<RuleSetVersion>();
                ruleSetVersionList.add(ruleSetVersion);
                List<RuleSetVersionDTO> listDto = createRuleSetVersionDTO(ruleSetVersionList);
                if (listDto != null && listDto.size() > 0) {
                  bindRuleSetVersionToDataSet(listDto.get(0), rowIndexVersion);
                }
              }
            } finally {
              baseServ.closeEntityManager(entityManager);
            }
          }
        }
      }
      // Correct name of selected rule set.
      if (selectedRuleSetId != null) {
        RuleSet ruleSet =
            SCWebServiceFactory.getScBaseService().queryByPrimaryKey(RuleSet.class,
                selectedRuleSetId);
        if (ruleSet != null) {
          selectedRuleSetName = ruleSet.getName();
        }
      }
    }

  }

  public void doExportRuleSet(WRequest request, Event event) {
    clearErrorMessage();
    long startTime = System.currentTimeMillis();
    int[] selectedRows = getDataViewRuleSet().getSelectedRows();
    if (selectedRows.length == 0) {
      errorCheckSelectedRecord = CommonUtils.getCommonBundleMessage("choose_least_one_record");
      return;
    }

    BaseService baseServ = SCWebServiceFactory.getScBaseService();
    EntityManager entityManager = baseServ.getEntityManagerFactory().createEntityManager();
    try {
      String fileName = "";
      StringBuilder trackingBuilder = new StringBuilder();
      TRuleSet[] arrTRuleSet = new TRuleSet[selectedRows.length];
      for (int i = 0; i < selectedRows.length; i++) {
        Long exportRuleSetId = getRuleSetId(selectedRows[i]);

        RuleSet ruleSet =
            baseServ.queryByPrimaryKey(entityManager, RuleSet.class, exportRuleSetId);
        TRuleSet ruleSetObj = RuleHelper.convertToObject(ruleSet);
        arrTRuleSet[i] = ruleSetObj;

        fileName = ruleSet.getName();
        trackingBuilder.append(fileName).append(";");
      }

      byte[] bytes = RuleHelper.toBytes(arrTRuleSet);
      ServletOutputStream ou = null;
      try {
        HttpServletResponse respone = request.getHttpResponse();
        respone.setHeader(HTTPCacheHeader.CACHE_CONTROL.getName(), "");
        respone.setHeader(HTTPCacheHeader.PRAGMA.getName(), "");
        respone.addHeader("Content-Disposition", "attachment; filename=\"" + fileName + ".bin\"");
        respone.setContentType("application/octet-stream");
        ou = request.getHttpResponse().getOutputStream();
        ou.write(bytes);
        ou.flush();
      } catch (Exception e) {
        LOGGER.error(e.getMessage(), e);
      } finally {
        if (ou != null) {
          try {
            ou.close();
          } catch (IOException e) {
          }
        }
        try {
          // Action log if there is deleted rule.
          String parameters = trackingBuilder.toString();
          if (parameters.length() > 0) {
            ActionTrackingEntity tracking = new ActionTrackingEntity();
            tracking.setAction("Export Rule Set");
            // remove last ';'
            tracking.setParameters(parameters.substring(0, parameters.length() - 1));
            tracking.setElapsedTime(System.currentTimeMillis() - startTime);
            trackAction(tracking);
          }
        } catch (Exception e) {
          LOGGER.debug(e.getMessage(), e);
        }
      }
    } finally {
      baseServ.closeEntityManager(entityManager);
    }
  }

  private void bindRuleSetDtoToDataSet(RuleSetDTO ruleSetDto, int row) {
    DataSet ds = dataViewRuleSet.getModel().getDataSet();
    for (int i = 0; i < DS_RULE_SET_COLUMNS.length; i++) {
      Method method =
          ReflecttionUtils.getGetMethodFromClass(DS_RULE_SET_COLUMNS[i], RuleSetDTO.class);
      if (method != null) {
        try {
          Object ob = method.invoke(ruleSetDto);
          ds.setValue(row, DS_RULE_SET_COLUMNS[i], ob);
        } catch (Exception e) {
          if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(e.getMessage(), e);
          }
        }
      }
    }
  }

  private void bindRuleSetVersionToDataSet(RuleSetVersionDTO ruleSetVersionDto, int row) {
    DataSet ds = dataViewRuleSetVersion.getModel().getDataSet();
    for (int i = 0; i < DS_RULE_SET_VERSION_COLUMNS.length; i++) {
      Method method =
          ReflecttionUtils.getGetMethodFromClass(DS_RULE_SET_VERSION_COLUMNS[i],
              RuleSetVersionDTO.class);
      if (method != null) {
        try {
          Object ob = method.invoke(ruleSetVersionDto);
          ds.setValue(row, DS_RULE_SET_VERSION_COLUMNS[i], ob);
        } catch (Exception e) {
          if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(e.getMessage(), e);
          }
        }
      }
    }
  }

  /**
   * Check on selected row of data view. This action keep current selected rule
   * set although user changed select box on GUI.
   */
  private void checkSelectRuleSet() {
    if (selectedRuleSetId != null) {
      int rowCount = getDataViewRuleSet().getModel().getDataSet().getRowCount();
      int row = 0;
      for (row = 1; row <= rowCount; row++) {
        Long ruleSetId =
            (Long) getDataViewRuleSet().getModel().getDataSet().getValue(row, "ruleSetId");
        if (selectedRuleSetId.longValue() == ruleSetId.longValue()) {
          break;
        }
      }
      if (1 < row && row <= rowCount) {
        String selectedRows = buildSelectedRow(new int[]{row });
        getDataViewRuleSet().setSelectedRows(selectedRows);
      }
    }
  }

  /**
   * Example of Java callback used to display boolean values as checkbox
   * 
   * @param request
   *          the current request
   * @param event
   *          the event
   * @return the formatted value
   */
  public String formatBooleanValue(WRequest request, DataViewEvent event) {
    Object value = event.getValue();
    boolean v = value == null ? false : Boolean.valueOf(value.toString()).booleanValue();

    String retVal = v ? Html.image(request.getImagePath("icons/icon_ok.gif"), "") : "";

    return retVal;
  }

  /**
   * Create list of RuleSetVersionDTO.
   * 
   * @param listRuleSetVersion
   * @return
   */
  private List<RuleSetVersionDTO> createRuleSetVersionDTO(
      List<RuleSetVersion> listRuleSetVersion) {
    List<RuleSetVersionDTO> listDTO = null;
    if (listRuleSetVersion != null && listRuleSetVersion.size() > 0) {
      listDTO = new ArrayList<RuleSetVersionDTO>();
      for (RuleSetVersion rsv : listRuleSetVersion) {
        RuleSetVersionDTO dto = new RuleSetVersionDTO();
        dto.setRuleSetVersionId(rsv.getRuleSetVersionId());
        dto.setRuleSetId(rsv.getRuleSetId());
        dto.setVersion(rsv.getVersion());
        dto.setStatus(rsv.getStatus());
        Timestamp time = rsv.getStatusUpdatedTime();
        if (time != null) {
          dto.setLastStatusDate(new Date(time.getTime()));
        }
        dto.setDescription(rsv.getDescription());
        if (rsv.getAlarmThreshold() != null) {
          dto.setAlarmThresholdStr(rsv.getAlarmThreshold().toString() + "%");
        }
        time = rsv.getUpdatedOn();
        if (time != null) {
          dto.setUpdatedOn(new Date(time.getTime()));
        }
        // set Mir criteria condition
        dto.createMirCriteria(rsv.getMirCriteria());
        listDTO.add(dto);
      }
    }
    return listDTO;
  }

  /**
   * @return the ruleSetDataSet
   */
  public DataSet getRuleSetDataSet() {
    return ruleSetDataSet;
  }

  /**
   * @param ruleSetDataSet
   *          the ruleSetDataSet to set
   */
  public void setRuleSetDataSet(DataSet ruleSetDataSet) {
    this.ruleSetDataSet = ruleSetDataSet;
  }

  /**
   * @return the ruleSetVerionDataSet
   */
  public DataSet getRuleSetVerionDataSet() {
    return ruleSetVerionDataSet;
  }

  /**
   * @param ruleSetVerionDataSet
   *          the ruleSetVerionDataSet to set
   */
  public void setRuleSetVerionDataSet(DataSet ruleSetVerionDataSet) {
    this.ruleSetVerionDataSet = ruleSetVerionDataSet;
  }

  /**
   * @return the errorCheckSelectedRecord
   */
  public String getErrorCheckSelectedRecord() {
    return errorCheckSelectedRecord;
  }

  /**
   * @return the showVersion
   */
  public boolean getShowVersion() {
    return showVersion;
  }

  /**
   * @return the isOwnersOfRuleSet
   */
  public boolean getIsOwnersOfRuleSet() {
    return isOwnersOfRuleSet;
  }

  /**
   * @param isOwnersOfRuleSet
   *          the isOwnersOfRuleSet to set
   */
  public void setIsOwnersOfRuleSet(boolean isOwnersOfRuleSet) {
    this.isOwnersOfRuleSet = isOwnersOfRuleSet;
  }

  /**
   * @return the errorCopyRuleSet
   */
  public String getErrorCopyRuleSet() {
    return errorCopyRuleSet;
  }

  /**
   * @return the selectedRuleSetName
   */
  public String getSelectedRuleSetName() {
    return selectedRuleSetName;
  }

  /**
   * @param selectedRuleSetName
   *          the selectedRuleSetName to set
   */
  public void setSelectedRuleSetName(String selectedRuleSetName) {
    this.selectedRuleSetName = selectedRuleSetName;
  }

  /**
   * @return the selectedRuleSetId
   */
  public Long getSelectedRuleSetId() {
    return selectedRuleSetId;
  }

  /**
   * @param selectedRuleSetId
   *          the selectedRuleSetId to set
   */
  public void setSelectedRuleSetId(Long selectedRuleSetId) {
    this.selectedRuleSetId = selectedRuleSetId;
  }

}
