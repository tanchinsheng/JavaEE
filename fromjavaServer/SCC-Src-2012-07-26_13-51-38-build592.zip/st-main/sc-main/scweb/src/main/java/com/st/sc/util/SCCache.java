/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.util;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

/**
 * The Class SCCache.
 */
public final class SCCache {

  /** The Constant INSTANCE. */
  private static final SCCache INSTANCE = new SCCache();

  /** The cache manager. */
  private CacheManager cacheManager;

  /** The Constant CACHE_NAME. */
  private static final String CACHE_NAME = "SCCache";

  /**
   * Instantiates a new sC cache.
   */
  private SCCache() {
    cacheManager = CacheManager.create();
  }

  /**
   * Gets the single instance of SCCache.
   * 
   * @return single instance of SCCache
   */
  public static SCCache getInstance() {
    return INSTANCE;
  }

  /**
   * Gets the value from cache.
   * 
   * @param key
   *          the key
   * @return the value from cache
   */
  public Object getValueFromCache(final String key) {
    final Cache scCache = cacheManager.getCache(CACHE_NAME);
    if (scCache != null) {
      final Element element = scCache.get(key);
      if (element != null) {
        return element.getObjectValue();
      }
    }
    return null;
  }

  /**
   * Put into cache.
   * 
   * @param key
   *          the key
   * @param value
   *          the value
   */
  public void putIntoCache(final String key, final Object value) {
    final Cache scCache = cacheManager.getCache(CACHE_NAME);
    if (value != null && scCache != null) {
      scCache.put(new Element(key, value));
    }
  }

  /**
   * Removes the from cache.
   * 
   * @param key
   *          the key
   */
  public void removeFromCache(final String key) {
    final Cache scCache = cacheManager.getCache(CACHE_NAME);
    if (scCache != null && key != null) {
      scCache.remove(key);
    }
  }

  /**
   * Shutdown.
   */
  public void shutdown() {
    CacheManager.getInstance().shutdown();
  }
}
