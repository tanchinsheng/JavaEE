/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 26, 2011 10:05:31 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.st.common.config.ConfigLoader;
import com.st.persistence.entity.SettingEntity;
import com.st.sc.common.CommonUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class SettingDTO {
  
  /*-------General Setting---------*/
  private Double defaultAlarmThreshold;
  private String plantCode;
  private Integer scanFileInterval;
  // Check box of liotroX must be boolean type, not Boolean.
  private boolean compress = true;
  private Integer maxNumFileNotify;
  private String umUrl;
  private Integer limitFailedValues;

  /*----Report Setting---------- */
  private Integer compliancyScoreRangeTo;
  private Integer onlineReportTime;
  private Integer maxRowDataView;

  /*----APCD Information---------- */
  private String apcdHost;
  private String apcdMailbox;
  private String apcdMbx;
  private Integer apcdPort;

  /*------------Email information-------------*/
  private String emailAdmin;
  private String emailFrom;
  private String emailSubject;
  private String emailHost;
  private Integer emailPort;
  private String emailUsername;
  private String emailPassword;
  private String emailProtocol;

  /**
   * Old encrypted password in DB, used to compare new password.
   */
  private String oldEmailPassword;
  /*-----PURGE CONFIG----------------------*/
  private String purgeStartTime;
  private Integer purgeIntervalTime;
  private String purgeIntervalUnit;
  private Integer purgeCompliancyResultExpiredTime;
  private Integer purgeParseFileStatusExpiredTime;
  private Integer purgeHistoryExpiredTime;
  private Integer purgeOfflineReportExpiredTime;

  public void initValues(Map<String, Object> mapValues) {
    if (mapValues == null) {
      return;
    }
    defaultAlarmThreshold = (Double) mapValues.get(ConfigLoader.DEFAULT_ALARM_THRESHOLD);
    plantCode = (String) mapValues.get(ConfigLoader.PLANT_CODE);
    scanFileInterval = getInteger(mapValues.get(ConfigLoader.KEY_INTERVAL_TIME));

    Boolean tempCompress = (Boolean) mapValues.get(ConfigLoader.COMPRESS_ARCHIVE);
    if (tempCompress != null) {
      compress = tempCompress.booleanValue();
    }

    maxNumFileNotify = getInteger(mapValues.get(ConfigLoader.KEY_MAX_SIZE_NOTIFY));
    limitFailedValues = getInteger(mapValues.get(ConfigLoader.LIMIT_FAIL_VALUES));

    umUrl = (String) mapValues.get(ConfigLoader.UM_URL);

    compliancyScoreRangeTo =
        getInteger(mapValues.get(ConfigLoader.MAX_NUM_OF_COMPLIANCY_SCORE_RANGE));
    onlineReportTime = getInteger(mapValues.get(ConfigLoader.ONLINE_REPORT_TIME));
    maxRowDataView = getInteger(mapValues.get(ConfigLoader.KEY_MAX_ROW_ON_DATAVIEW));

    // APCD Settings
    apcdHost = (String) mapValues.get(ConfigLoader.APCD_HOST);
    apcdMailbox = (String) mapValues.get(ConfigLoader.APCD_MAILBOX);
    apcdMbx = (String) mapValues.get(ConfigLoader.APCD_MBX);
    apcdPort = getInteger(mapValues.get(ConfigLoader.APCD_PORT));

    // Email setting
    emailFrom = (String) mapValues.get(ConfigLoader.KEY_EMAIL_FROM);
    emailAdmin = (String) mapValues.get(ConfigLoader.KEY_EMAIL_ADMIN);
    emailSubject = (String) mapValues.get(ConfigLoader.KEY_EMAIL_SUBJECT);
    emailHost = (String) mapValues.get(ConfigLoader.KEY_SMTP_HOST);
    emailPort = getInteger(mapValues.get(ConfigLoader.KEY_SMTP_PORT));
    emailUsername = (String) mapValues.get(ConfigLoader.KEY_SMTP_USERNAME);
    emailPassword = (String) mapValues.get(ConfigLoader.KEY_SMTP_PASSWORD);
    emailProtocol = (String) mapValues.get(ConfigLoader.KEY_SMTP_PROTOCOL);

    // PURGE CONFIG
    purgeIntervalTime = getInteger(mapValues.get(ConfigLoader.PURGE_INTERVAL_TIME));
    purgeIntervalUnit = (String) mapValues.get(ConfigLoader.PURGE_INTERVAL_UNIT);
    purgeStartTime = (String) mapValues.get(ConfigLoader.PURGE_START_TIME);
    purgeCompliancyResultExpiredTime =
        getInteger(mapValues.get(ConfigLoader.PURGE_COMPLIANCY_RESULT_EXPIRED_TIME));
    purgeParseFileStatusExpiredTime =
        getInteger(mapValues.get(ConfigLoader.PURGE_FILE_STS_EXPIRED_TIME));
    purgeHistoryExpiredTime =
        getInteger(mapValues.get(ConfigLoader.PURGE_CHANGE_HISTORY_EXPIRED_TIME));
    purgeOfflineReportExpiredTime =
        getInteger(mapValues.get(ConfigLoader.PURGE_OFFLINE_REPORT_EXPIRED_TIME));
  }

  private Integer getInteger(Object ob) {
    if (ob != null) {
      if (ob instanceof Double) {
        return ((Double) ob).intValue();
      }
      return Integer.valueOf(ob.toString());
    } else {
      return null;
    }
  }

  public List<SettingEntity> getCommonSettingList() {
    List<SettingEntity> list = new ArrayList<SettingEntity>();
    list.add(createDefaultAlarmTheshold());
    list.add(createScanFileInterval());
    list.add(createCompressArchive());
    list.add(createPlantCode());
    list.add(createMaxNumFileNotify());
    list.add(createLimitFailedValues());
    list.add(createUmUrl());
    // report configuration
    list.add(createNumberCompliancyTo());
    list.add(createOnlineReportTime());
    list.add(createMaxRowOnDataView());

    // apcd configuration
    list.add(createApcdHost());
    list.add(createApcdMaibox());
    list.add(createApcdMBX());
    list.add(createApcdPort());

    list.addAll(createEmailConfigs());
    return list;
  }

  public List<SettingEntity> getPurgeSettingList() {
    List<SettingEntity> list = new ArrayList<SettingEntity>();
    // purge configuration
    list.add(createPurgeInterval());
    list.add(createPurgeIntervalUnit());
    list.add(createPurgeStartTime());
    list.addAll(createPurgeSCDBExpiredTime());
    return list;
  }

  private SettingEntity createDefaultAlarmTheshold() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.DEFAULT_ALARM_THRESHOLD);
    if (defaultAlarmThreshold != null) {
      entity.setParaValue(defaultAlarmThreshold.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);
    entity.setDescription("Default alarm threshold");
    return entity;
  }

  private SettingEntity createPlantCode() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.PLANT_CODE);
    entity.setParaValue(plantCode);
    // varchar
    entity.setDataType(1);
    entity.setDescription("Plant code");
    return entity;
  }

  private SettingEntity createScanFileInterval() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.KEY_INTERVAL_TIME);
    if (scanFileInterval != null) {
      entity.setParaValue(scanFileInterval.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);
    entity
        .setDescription("Interval time of monitoring folder. Unit is second. This value is not reloaded.");
    return entity;
  }

  private SettingEntity createCompressArchive() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.COMPRESS_ARCHIVE);
    entity.setParaValue(String.valueOf(compress));
    // boolean
    entity.setDataType(3);
    entity.setDescription("Compress option when moving STDF file to archive folder.");
    return entity;
  }

  private SettingEntity createMaxNumFileNotify() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.KEY_MAX_SIZE_NOTIFY);
    if (maxNumFileNotify != null) {
      entity.setParaValue(maxNumFileNotify.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);
    entity.setDescription("Max number of files can be notified in one time, maximum is 50.");
    return entity;
  }

  private SettingEntity createLimitFailedValues() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.LIMIT_FAIL_VALUES);
    if (limitFailedValues != null) {
      entity.setParaValue(limitFailedValues.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);
    entity.setDescription("Limit number of failed values (empty for unlimited).");
    return entity;
  }

  private SettingEntity createUmUrl() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.UM_URL);
    entity.setParaValue(umUrl);
    // number
    entity.setDataType(1);
    entity.setDescription("User management url.");
    return entity;
  }

  private SettingEntity createNumberCompliancyTo() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.MAX_NUM_OF_COMPLIANCY_SCORE_RANGE);
    if (compliancyScoreRangeTo != null) {
      entity.setParaValue(compliancyScoreRangeTo.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);
    entity.setDescription("No. of compliancy score maximum.");
    return entity;
  }

  private SettingEntity createOnlineReportTime() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.ONLINE_REPORT_TIME);
    if (onlineReportTime != null) {
      entity.setParaValue(onlineReportTime.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);
    entity
        .setDescription("If user enter timing-range out of this value, system will generate offline report. Unit is day.");
    return entity;
  }

  private SettingEntity createMaxRowOnDataView() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.KEY_MAX_ROW_ON_DATAVIEW);
    if (maxRowDataView != null) {
      entity.setParaValue(maxRowDataView.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);
    entity
        .setDescription("To avoid out of memory, system just show a limited number of row to GUI.");
    return entity;
  }

  private SettingEntity createApcdHost() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.APCD_HOST);
    entity.setParaValue(apcdHost);
    // varchar
    entity.setDataType(1);
    entity.setDescription("Host to send alarm to APCD.");
    return entity;
  }

  private SettingEntity createApcdMaibox() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.APCD_MAILBOX);
    entity.setParaValue(apcdMailbox);
    // varchar
    entity.setDataType(1);
    entity.setDescription("Mail box to send alarm to APCD.");
    return entity;
  }

  private SettingEntity createApcdMBX() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.APCD_MBX);
    entity.setParaValue(apcdMbx);
    // varchar
    entity.setDataType(1);
    entity.setDescription("MBX name to send alarm to APCD.");
    return entity;
  }

  private SettingEntity createApcdPort() {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.APCD_PORT);
    if (apcdPort != null) {
      entity.setParaValue(apcdPort.toString());
    } else {
      entity.setParaValue(null);
    }
    // varchar
    entity.setDataType(0);
    entity.setDescription("Port to send alarm to APCD.");
    return entity;
  }

  private SettingEntity createPurgeInterval() {
    SettingEntity entity = new SettingEntity();
    entity.setDataType(0);
    entity.setDescription("Interval time for purging data.");
    entity.setParaCode(ConfigLoader.PURGE_INTERVAL_TIME);
    entity.setParaValue(String.valueOf(purgeIntervalTime));
    return entity;
  }

  private SettingEntity createPurgeIntervalUnit() {
    SettingEntity purgeIntervalTimeUnit = new SettingEntity();
    purgeIntervalTimeUnit.setDataType(1);
    purgeIntervalTimeUnit.setDescription("days/hours/minutes");
    purgeIntervalTimeUnit.setParaCode(ConfigLoader.PURGE_INTERVAL_UNIT);
    purgeIntervalTimeUnit.setParaValue(purgeIntervalUnit);
    return purgeIntervalTimeUnit;
  }

  private SettingEntity createPurgeStartTime() {
    SettingEntity entity = new SettingEntity();
    entity.setDataType(1);
    entity
        .setDescription("Time when Purge will run to delete data. This value is used only if unit is day.");
    entity.setParaCode(ConfigLoader.PURGE_START_TIME);
    entity.setParaValue(purgeStartTime);
    return entity;
  }

  private List<SettingEntity> createPurgeSCDBExpiredTime() {
    List<SettingEntity> list = new ArrayList<SettingEntity>();
    SettingEntity entity = new SettingEntity();
    entity.setDataType(0);
    entity.setDescription("Expired time for Compliancy Report.");
    entity.setParaCode(ConfigLoader.PURGE_COMPLIANCY_RESULT_EXPIRED_TIME);
    entity.setParaValue(String.valueOf(purgeCompliancyResultExpiredTime));
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(0);
    entity.setDescription("Expired time for STDF_FILE_STATUS table.");
    entity.setParaCode(ConfigLoader.PURGE_FILE_STS_EXPIRED_TIME);
    entity.setParaValue(String.valueOf(purgeParseFileStatusExpiredTime));
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(0);
    entity.setDescription("Expired time for CHANGE_HISTORY table.");
    entity.setParaCode(ConfigLoader.PURGE_CHANGE_HISTORY_EXPIRED_TIME);
    entity.setParaValue(String.valueOf(purgeHistoryExpiredTime));
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(0);
    entity.setDescription("Expired time for OFFLINE_REPORT table.");
    entity.setParaCode(ConfigLoader.PURGE_OFFLINE_REPORT_EXPIRED_TIME);
    entity.setParaValue(String.valueOf(purgeOfflineReportExpiredTime));
    list.add(entity);
    return list;
  }

  private List<SettingEntity> createEmailConfigs() {
    List<SettingEntity> list = new ArrayList<SettingEntity>();
    SettingEntity entity = new SettingEntity();
    entity.setDataType(1);
    entity.setDescription("Indicate system.");
    entity.setParaCode(ConfigLoader.KEY_EMAIL_FROM);
    entity.setParaValue(emailFrom);
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(1);
    entity.setDescription("Email of System Admin. System will send mail if any error.");
    entity.setParaCode(ConfigLoader.KEY_EMAIL_ADMIN);
    entity.setParaValue(emailAdmin);
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(1);
    entity.setDescription("Subject for all email related to system error.");
    entity.setParaCode(ConfigLoader.KEY_EMAIL_SUBJECT);
    entity.setParaValue(emailSubject);
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(1);
    entity.setDescription("Mail server.");
    entity.setParaCode(ConfigLoader.KEY_SMTP_HOST);
    entity.setParaValue(emailHost);
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(0);
    entity.setDescription("SMTP port.");
    entity.setParaCode(ConfigLoader.KEY_SMTP_PORT);
    if (emailPort != null) {
      entity.setParaValue(String.valueOf(emailPort));
    } else {
      entity.setParaValue(null);
    }
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(1);
    entity.setDescription("SMTP_USERNAME.");
    entity.setParaCode(ConfigLoader.KEY_SMTP_USERNAME);
    entity.setParaValue(emailUsername);
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(1);
    entity.setDescription("SMTP_PASSWORD.");
    entity.setParaCode(ConfigLoader.KEY_SMTP_PASSWORD);
    String encryptPass =
        CommonUtils.encryptPassword(emailPassword, "email configuration", oldEmailPassword);
    entity.setParaValue(encryptPass);
    //update value to show on GUI
    emailPassword = oldEmailPassword = encryptPass;
    list.add(entity);
    entity = new SettingEntity();
    entity.setDataType(1);
    entity.setDescription("SMTP or SMTPS.");
    entity.setParaCode(ConfigLoader.KEY_SMTP_PROTOCOL);
    entity.setParaValue(emailProtocol);
    list.add(entity);
    return list;
  }

  /**
   * @return the defaultAlarmThreshold
   */
  public Double getDefaultAlarmThreshold() {
    return defaultAlarmThreshold;
  }

  /**
   * @param defaultAlarmThreshold
   *          the defaultAlarmThreshold to set
   */
  public void setDefaultAlarmThreshold(Double defaultAlarmThreshold) {
    this.defaultAlarmThreshold = defaultAlarmThreshold;
  }

  /**
   * @return the plantCode
   */
  public String getPlantCode() {
    return plantCode;
  }

  /**
   * @param plantCode
   *          the plantCode to set
   */
  public void setPlantCode(String plantCode) {
    this.plantCode = plantCode;
  }

  /**
   * @return the scanFileInterval
   */
  public Integer getScanFileInterval() {
    return scanFileInterval;
  }

  /**
   * @param scanFileInterval
   *          the scanFileInterval to set
   */
  public void setScanFileInterval(Integer scanFileInterval) {
    this.scanFileInterval = scanFileInterval;
  }

  /**
   * @return the compress
   */
  public Boolean getCompress() {
    return compress;
  }

  /**
   * @param compress
   *          the compress to set
   */
  public void setCompress(Boolean compress) {
    this.compress = compress;
  }

  /**
   * @return the umUrl
   */
  public String getUmUrl() {
    return umUrl;
  }

  /**
   * @param umUrl
   *          the umUrl to set
   */
  public void setUmUrl(String umUrl) {
    this.umUrl = umUrl;
  }

  /**
   * @return the compliancyScoreRangeTo
   */
  public Integer getCompliancyScoreRangeTo() {
    return compliancyScoreRangeTo;
  }

  /**
   * @param compliancyScoreRangeTo
   *          the compliancyScoreRangeTo to set
   */
  public void setCompliancyScoreRangeTo(Integer compliancyScoreRangeTo) {
    this.compliancyScoreRangeTo = compliancyScoreRangeTo;
  }

  /**
   * @return the apcdHost
   */
  public String getApcdHost() {
    return apcdHost;
  }

  /**
   * @param apcdHost
   *          the apcdHost to set
   */
  public void setApcdHost(String apcdHost) {
    this.apcdHost = apcdHost;
  }

  /**
   * @return the apcdMailbox
   */
  public String getApcdMailbox() {
    return apcdMailbox;
  }

  /**
   * @param apcdMailbox
   *          the apcdMailbox to set
   */
  public void setApcdMailbox(String apcdMailbox) {
    this.apcdMailbox = apcdMailbox;
  }

  /**
   * @return the apcdMbx
   */
  public String getApcdMbx() {
    return apcdMbx;
  }

  /**
   * @param apcdMbx
   *          the apcdMbx to set
   */
  public void setApcdMbx(String apcdMbx) {
    this.apcdMbx = apcdMbx;
  }

  /**
   * @return the apcdPort
   */
  public Integer getApcdPort() {
    return apcdPort;
  }

  /**
   * @param apcdPort
   *          the apcdPort to set
   */
  public void setApcdPort(Integer apcdPort) {
    this.apcdPort = apcdPort;
  }

  /**
   * @return the maxNumFileNotify
   */
  public Integer getMaxNumFileNotify() {
    return maxNumFileNotify;
  }

  /**
   * @param maxNumFileNotify
   *          the maxNumFileNotify to set
   */
  public void setMaxNumFileNotify(Integer maxNumFileNotify) {
    this.maxNumFileNotify = maxNumFileNotify;
  }

  /**
   * @return the purgeStartTime
   */
  public String getPurgeStartTime() {
    return purgeStartTime;
  }

  /**
   * @param purgeStartTime
   *          the purgeStartTime to set
   */
  public void setPurgeStartTime(String purgeStartTime) {
    this.purgeStartTime = purgeStartTime;
  }

  /**
   * @return the purgeIntervalTime
   */
  public Integer getPurgeIntervalTime() {
    return purgeIntervalTime;
  }

  /**
   * @param purgeIntervalTime
   *          the purgeIntervalTime to set
   */
  public void setPurgeIntervalTime(Integer purgeIntervalTime) {
    this.purgeIntervalTime = purgeIntervalTime;
  }

  /**
   * @return the purgeIntervalUnit
   */
  public String getPurgeIntervalUnit() {
    return purgeIntervalUnit;
  }

  /**
   * @param purgeIntervalUnit
   *          the purgeIntervalUnit to set
   */
  public void setPurgeIntervalUnit(String purgeIntervalUnit) {
    this.purgeIntervalUnit = purgeIntervalUnit;
  }

  /**
   * @return the limitFailedValues
   */
  public Integer getLimitFailedValues() {
    return limitFailedValues;
  }

  /**
   * @param limitFailedValues
   *          the limitFailedValues to set
   */
  public void setLimitFailedValues(Integer limitFailedValues) {
    this.limitFailedValues = limitFailedValues;
  }

  /**
   * @param compress
   *          the compress to set
   */
  public void setCompress(boolean compress) {
    this.compress = compress;
  }

  /**
   * @param onlineReportTime
   *          the onlineReportTime to set
   */
  public void setOnlineReportTime(Integer onlineReportTime) {
    this.onlineReportTime = onlineReportTime;
  }

  /**
   * @return the onlineReportTime
   */
  public Integer getOnlineReportTime() {
    return onlineReportTime;
  }

  /**
   * @return the maxRowDataView
   */
  public Integer getMaxRowDataView() {
    return maxRowDataView;
  }

  /**
   * @param maxRowDataView
   *          the maxRowDataView to set
   */
  public void setMaxRowDataView(Integer maxRowDataView) {
    this.maxRowDataView = maxRowDataView;
  }

  /**
   * @return the emailAdmin
   */
  public String getEmailAdmin() {
    return emailAdmin;
  }

  /**
   * @param emailAdmin
   *          the emailAdmin to set
   */
  public void setEmailAdmin(String emailAdmin) {
    this.emailAdmin = emailAdmin;
  }

  /**
   * @return the emailFrom
   */
  public String getEmailFrom() {
    return emailFrom;
  }

  /**
   * @param emailFrom
   *          the emailFrom to set
   */
  public void setEmailFrom(String emailFrom) {
    this.emailFrom = emailFrom;
  }

  /**
   * @return the emailSubject
   */
  public String getEmailSubject() {
    return emailSubject;
  }

  /**
   * @param emailSubject
   *          the emailSubject to set
   */
  public void setEmailSubject(String emailSubject) {
    this.emailSubject = emailSubject;
  }

  /**
   * @return the emailHost
   */
  public String getEmailHost() {
    return emailHost;
  }

  /**
   * @param emailHost
   *          the emailHost to set
   */
  public void setEmailHost(String emailHost) {
    this.emailHost = emailHost;
  }

  /**
   * @return the emailPort
   */
  public Integer getEmailPort() {
    return emailPort;
  }

  /**
   * @param emailPort
   *          the emailPort to set
   */
  public void setEmailPort(Integer emailPort) {
    this.emailPort = emailPort;
  }

  /**
   * @return the emailUsername
   */
  public String getEmailUsername() {
    return emailUsername;
  }

  /**
   * @param emailUsername
   *          the emailUsername to set
   */
  public void setEmailUsername(String emailUsername) {
    this.emailUsername = emailUsername;
  }

  /**
   * @return the emailPassword
   */
  public String getEmailPassword() {
    return emailPassword;
  }

  /**
   * @param emailPassword
   *          the emailPassword to set
   */
  public void setEmailPassword(String emailPassword) {
    this.emailPassword = emailPassword;
  }

  /**
   * @return the emailProtocol
   */
  public String getEmailProtocol() {
    return emailProtocol;
  }

  /**
   * @param emailProtocol
   *          the emailProtocol to set
   */
  public void setEmailProtocol(String emailProtocol) {
    this.emailProtocol = emailProtocol;
  }

  /**
   * @return the purgeCompliancyResultExpiredTime
   */
  public Integer getPurgeCompliancyResultExpiredTime() {
    return purgeCompliancyResultExpiredTime;
  }

  /**
   * @param purgeCompliancyResultExpiredTime
   *          the purgeCompliancyResultExpiredTime to set
   */
  public void setPurgeCompliancyResultExpiredTime(Integer purgeCompliancyResultExpiredTime) {
    this.purgeCompliancyResultExpiredTime = purgeCompliancyResultExpiredTime;
  }

  /**
   * @return the purgeParseFileStatusExpiredTime
   */
  public Integer getPurgeParseFileStatusExpiredTime() {
    return purgeParseFileStatusExpiredTime;
  }

  /**
   * @param purgeParseFileStatusExpiredTime
   *          the purgeParseFileStatusExpiredTime to set
   */
  public void setPurgeParseFileStatusExpiredTime(Integer purgeParseFileStatusExpiredTime) {
    this.purgeParseFileStatusExpiredTime = purgeParseFileStatusExpiredTime;
  }

  /**
   * @return the purgeHistoryExpiredTime
   */
  public Integer getPurgeHistoryExpiredTime() {
    return purgeHistoryExpiredTime;
  }

  /**
   * @param purgeHistoryExpiredTime
   *          the purgeHistoryExpiredTime to set
   */
  public void setPurgeHistoryExpiredTime(Integer purgeHistoryExpiredTime) {
    this.purgeHistoryExpiredTime = purgeHistoryExpiredTime;
  }

  /**
   * @return the purgeOfflineReportExpiredTime
   */
  public Integer getPurgeOfflineReportExpiredTime() {
    return purgeOfflineReportExpiredTime;
  }

  /**
   * @param purgeOfflineReportExpiredTime
   *          the purgeOfflineReportExpiredTime to set
   */
  public void setPurgeOfflineReportExpiredTime(Integer purgeOfflineReportExpiredTime) {
    this.purgeOfflineReportExpiredTime = purgeOfflineReportExpiredTime;
  }

  /**
   * @param oldEmailPassword the oldEmailPassword to set
   */
  public void setOldEmailPassword(String oldEmailPassword) {
    this.oldEmailPassword = oldEmailPassword;
  }
  
}
