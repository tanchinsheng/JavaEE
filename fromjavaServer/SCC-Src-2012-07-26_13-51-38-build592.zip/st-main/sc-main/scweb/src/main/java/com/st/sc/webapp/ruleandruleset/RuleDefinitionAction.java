/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 3, 2011 8:55:28 PM - nhatvn - Initialize version
/********************************************************************************/

package com.st.sc.webapp.ruleandruleset;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;

import com.st.common.config.ConfigLoader;
import com.st.common.web.config.ConfigReloader;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleValue;
import com.st.sc.entity.RuleVersion;
import com.st.sc.entity.enums.RuleTypeEnum;
import com.st.sc.entity.enums.RuleValueKeyEnum;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.rulemanager.EntityExecutor;
import com.st.sc.rulemanager.QueryExecutor;
import com.st.sc.rulemanager.QueryStringExecutor;
import com.st.sc.rulemanager.RuleService;
import com.st.sc.rulemanager.rule.validation.expression.ExpressionProcessor;
import com.st.sc.rulemanager.rule.validation.expression.ExpressionUtil;
import com.st.sc.rulemanager.rule.validation.expression.exception.CompileException;
import com.st.sc.util.RuleSetComparison;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.util.recordloader.RecordLoader;
import com.st.sc.webapp.BaseAction;

/**
 * @author hoand
 */
public class RuleDefinitionAction extends BaseAction {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(RuleDefinitionAction.class);

  /* General */
  /**
   * Selected field of rule condition.
   */
  private String selectedField;
  private final String NOT_EMPTY = "Y";
  private final String EDIT_TYPE = "edit";
  private final String ADD_TYPE = "add";
  private final int NUM_OF_RULE_CONDITION = RuleTypeEnum.values().length + 1;
  private final int NUM_OF_AREA_DISPLAY = 6;
  /**
   * It is key to get value from request.
   */
  private final String INCREASE_VERSION_REQUEST_PARAMETER = "increaseVersion";
  private final String INCREASE_VERSION_TRUE = "true";
  /**
   * Map contains name of a rule condition and its variable which includes data
   * of rule condition. Key is name of rule condition , key is the name of
   * element in RuleTypeEnum. Value is a variable in this class, it is data to
   * be displayed in client web GUI.
   */
  private static Map<String, RuleConditionType> mapRuleConditionAndVariable =
      new HashMap<String, RuleConditionType>();

  /* ------- Special Rule Condition -------- */
  private RecordParameter specificValue;
  private RecordParameter referenceRecord;
  private RecordParameter existInGroup;
  private FieldParameter includeValues;
  private FieldParameter excludeValues;
  private FieldParameter fieldInRange;
  private FieldParameter fieldLengh;
  private RecordParameter uniqueField;
  private RecordParameter matchingField;
  private RecordParameter expressionField;

  /**
   * This stores information of rule and display on GUI.
   */
  private Rule rule = new Rule();
  /**
   * This stores information of rule version and display on GUI.
   */
  private RuleVersion ruleVersion = new RuleVersion();
  /**
   * The type of action : 'add' or 'edit'. It is used to separate add action and
   * edit action.
   */
  private String actionType;
  /**
   * The name of rule condition, also the name of element of RuleTypeEnum. It's
   * used as the value of radio button on web GUI. Consequently, we use this
   * value to check on radio button when edit.
   */
  private String ruleConditionName;
  private String ruleConditionParameters;
  /**
   * Name of rule sets which is using this rule.
   */
  private String usedBy;

  private String owners;
  /**
   * This is used to check if user is editing rule, system will disable some
   * element such as : record type.
   */
  private boolean isEditRule;
  /**
   * Check login user whether is owner of rule.
   */
  private boolean isOwnerOfRule = false;

  /**
   * Check login user whether is creator of rule.
   */
  private boolean isCreatorOfRule = false;

  /**
   * It used to distribute what rule condition will be displayed.
   */
  private List<String> ruleConditionDisplay = new ArrayList<String>();

  /**
   * It is used to display when view rule, no authorized to edit.
   */
  private List<String> areaDisplay = new ArrayList<String>(NUM_OF_AREA_DISPLAY);

  /**
   * It is used to determine update list when back to rule list page.
   */
  private boolean alreadyIncreaseVersion;
  private boolean alreadySave;

  private String confirmMessage;
  private List<RuleOwners> oldRuleOwners;

  /*
   * --------Begin Getter used to displayed value on web GUI, don't use
   * variable-------
   */
  public String[] getRecordTypes() {
    return RecordLoader.getRecordList();
  }

  public String[] getTargetRecordTypes() {
    String[] allRecords = RecordLoader.getRecordsHaveHeadNumSiteNum();
    // Check source record.
    // if source is one of (PTR, MPR, FTR), don't display it on target record.
    final String srcRecordType = rule.getRecordType();

    if (srcRecordType.equals("PTR") || srcRecordType.equals("MPR")
        || srcRecordType.equals("FTR")) {
      // Remove these record from source
      List<String> listTarget = new ArrayList<String>();
      for (String record : allRecords) {
        if (!record.equals("PTR") && !record.equals("MPR") && !record.equals("FTR")) {
          listTarget.add(record);
        }
      }
      return listTarget.toArray(new String[0]);
    }
    return allRecords;
  }

  public String[] getCompareOperator() {
    return new String[]{"=", ">=", ">", "<", "<=" };
  }

  public String[] getFieldTypes() {
    String selectRecord = rule.getRecordType();
    if (selectRecord == null) {
      if (getRecordTypes() != null) {
        selectRecord = getRecordTypes()[0];
      }
    }
    return RecordLoader.getFieldsOfRecord(selectRecord);
  }

  public String getCreatedBy() {
    return ruleVersion.getUpdatedBy();
  }

  public Integer getVersionOfRule() {
    return ruleVersion.getVersion();
  }

  public String getRuleOrigin() {
    return rule.getOrigin();
  }

  /*
   * --------End Getter used to displayed value on web GUI, don't use
   * variable-------
   */

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#afterPopulate(st.liotrox.WRequest)
   */
  @Override
  protected void afterPopulate(WRequest request) {
    // When submit to server, after populate data,
    // each element of list ruleConditionDisplay is appended with whitespace.
    // Must trim element of list.
    for (int i = 0; i < ruleConditionDisplay.size(); i++) {
      ruleConditionDisplay.set(i, ruleConditionDisplay.get(i).trim());
    }
    for (int i = 0; i < areaDisplay.size(); i++) {
      areaDisplay.set(i, areaDisplay.get(i).trim());
    }

    buildShowConfirmMessage();

    super.afterPopulate(request);
  }

  /**
   * Create map and some variables. Constructor
   */
  public RuleDefinitionAction() {
    // create variable
    createRuleConditionVariable();
    // create map of rule condition name and variable.
    createRuleConditionAndVariableMap();
  }

  private void createRuleConditionVariable() {
    specificValue =
        new RecordParameter(RuleTypeEnum.OCCURRENCE_RECORD.getValue(), new RuleValueKeyEnum[]{
            RuleValueKeyEnum.OCCURRENCE_RECORD_OPERATOR,
            RuleValueKeyEnum.OCCURRENCE_RECORD_COUNT });
    // Reference record
    referenceRecord =
        new RecordParameter(RuleTypeEnum.OCCURRENCE_TWO_RECORDS.getValue(),
            new RuleValueKeyEnum[]{RuleValueKeyEnum.OCCURRENCE_2_RECORD_OPERATOR,
                RuleValueKeyEnum.OCCURRENCE_2_RECORD_TYPE });
    // record exist in group
    existInGroup =
        new RecordParameter(RuleTypeEnum.MUST_IN_GROUP.getValue(),
            new RuleValueKeyEnum[]{RuleValueKeyEnum.EXIST_IN_GROUP });

    includeValues =
        new FieldParameter(RuleTypeEnum.VALUE_FIELD_IN_LIST.getValue(),
            new RuleValueKeyEnum[]{RuleValueKeyEnum.FIELD_NAME_IN_LIST });
    excludeValues =
        new FieldParameter(RuleTypeEnum.VALUE_FIELD_NOT_IN_LIST.getValue(),
            new RuleValueKeyEnum[]{RuleValueKeyEnum.FIELD_NAME_NOT_IN_LIST });
    fieldInRange =
        new FieldParameter(RuleTypeEnum.VALUE_IN_RANGE.getValue(), new RuleValueKeyEnum[]{
            RuleValueKeyEnum.FIELD_IN_RANGE_FROM, RuleValueKeyEnum.FIELD_IN_RANGE_TO });
    fieldLengh =
        new FieldParameter(RuleTypeEnum.CHECK_LENGTH_FIELD.getValue(), new RuleValueKeyEnum[]{
            RuleValueKeyEnum.FIELD_LENGTH_OPERATOR, RuleValueKeyEnum.FIELD_LENGTH_VALUE });
    uniqueField =
        new RecordParameter(RuleTypeEnum.CHECK_UNIQUENESS.getValue(),
            new RuleValueKeyEnum[]{RuleValueKeyEnum.FIELD_UNIQUE });
    matchingField =
        new RecordParameter(RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS.getValue(),
            new RuleValueKeyEnum[]{RuleValueKeyEnum.FIELD_MATCHING_SRC_RECORD,
                RuleValueKeyEnum.FIELD_MATCHING_SRC_FIELD,
                RuleValueKeyEnum.FIELD_MATCHING_TARGET_RECORD,
                RuleValueKeyEnum.FIELD_MATCHING_TARGET_FIELD });
    expressionField =
        new RecordParameter(RuleTypeEnum.EXPRESSION.getValue(),
            new RuleValueKeyEnum[]{RuleValueKeyEnum.EXPRESSION });
  }

  private void createRuleConditionAndVariableMap() {
    mapRuleConditionAndVariable.put(RuleTypeEnum.REQUIRED_RECORD.name(), new RecordParameter(
        RuleTypeEnum.REQUIRED_RECORD.getValue(), null));
    mapRuleConditionAndVariable.put(RuleTypeEnum.OCCURRENCE_RECORD.name(), specificValue);
    mapRuleConditionAndVariable.put(RuleTypeEnum.OCCURRENCE_TWO_RECORDS.name(),
        referenceRecord);
    mapRuleConditionAndVariable.put(RuleTypeEnum.NUMBER_OF_PCR.name(), new RecordParameter(
        RuleTypeEnum.NUMBER_OF_PCR.getValue(), null));

    mapRuleConditionAndVariable.put(RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP1.name(),
        new RecordParameter(RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP1.getValue(), null));
    mapRuleConditionAndVariable.put(RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP2.name(),
        new RecordParameter(RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP2.getValue(), null));
    mapRuleConditionAndVariable.put(RuleTypeEnum.NUMBER_OF_TEST_RECORD.name(),
        new RecordParameter(RuleTypeEnum.NUMBER_OF_TEST_RECORD.getValue(), null));
    mapRuleConditionAndVariable.put(RuleTypeEnum.MUST_IN_GROUP.name(), existInGroup);
    mapRuleConditionAndVariable.put(RuleTypeEnum.ORDER_TERADYNE.name(), new RecordParameter(
        RuleTypeEnum.ORDER_TERADYNE.getValue(), null));

    // Field condition
    mapRuleConditionAndVariable.put(RuleTypeEnum.REQUIRED_FIELD.name(), new FieldParameter(
        RuleTypeEnum.REQUIRED_FIELD.getValue(), null));
    // Rule for SDR field is not need parameters, we treat as RecordParameter
    mapRuleConditionAndVariable.put(RuleTypeEnum.NUMBER_OF_SDR.name(), new RecordParameter(
        RuleTypeEnum.NUMBER_OF_SDR.getValue(), null));
    mapRuleConditionAndVariable.put(RuleTypeEnum.VALUE_FIELD_IN_LIST.name(), includeValues);
    mapRuleConditionAndVariable
        .put(RuleTypeEnum.VALUE_FIELD_NOT_IN_LIST.name(), excludeValues);
    mapRuleConditionAndVariable.put(RuleTypeEnum.VALUE_IN_RANGE.name(), fieldInRange);
    mapRuleConditionAndVariable.put(RuleTypeEnum.CHECK_LENGTH_FIELD.name(), fieldLengh);
    // Rule VALIDATE_BIT7 on field is not need parameters, we treat as
    // RecordParameter
    mapRuleConditionAndVariable.put(RuleTypeEnum.VALIDATE_BIT7.name(), new RecordParameter(
        RuleTypeEnum.VALIDATE_BIT7.getValue(), null));
    mapRuleConditionAndVariable.put(RuleTypeEnum.CHECK_UNIQUENESS.name(), uniqueField);
    mapRuleConditionAndVariable.put(RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS.name(),
        matchingField);
    mapRuleConditionAndVariable.put(RuleTypeEnum.EXPRESSION.name(), expressionField);
  }

  private interface RuleConditionType {
    List<RuleValue> buildParameter();

    void seperateParameter(List<RuleValue> listParams);

    String createStringOfParamters();

    boolean compareParameter(String oldParam);
  }

  public class RecordParameter implements RuleConditionType {
    protected Integer ruleType;
    private RuleValueKeyEnum[] paramKeys;

    /**
     * Constructor
     * 
     * @param type
     */
    RecordParameter(int type, RuleValueKeyEnum[] paramKeys) {
      ruleType = type;
      this.paramKeys = paramKeys;

      // Init parameters
      if (paramKeys != null && paramKeys.length > 0) {
        for (int i = 0; i < paramKeys.length; i++) {
          listParams.add("");
        }
      }
    }

    protected List<String> listParams = new ArrayList<String>();

    public List<String> getListParams() {
      return listParams;
    }

    public void setlistParams(List<String> list) {
      listParams = list;
    }

    public List<RuleValue> buildParameter() {
      if (listParams.size() > 0) {
        List<RuleValue> list = new ArrayList<RuleValue>(listParams.size());
        for (int i = 0; i < listParams.size(); i++) {
          list.add(new RuleValue(paramKeys[i], listParams.get(i)));
        }
        return list;
      }
      return null;
    }

    public void seperateParameter(List<RuleValue> params) {
      if (params != null && listParams.size() > 0) {
        int numberParam = listParams.size();

        for (int i = 0; i < params.size(); i++) {
          RuleValue ruleValue = params.get(i);
          for (int j = 0; j < numberParam; j++) {
            if (ruleValue.getId().getRuleValueKey() == paramKeys[j]) {
              listParams.set(j, ruleValue.getParamValue());
              break;
            }
          }
        }

      }
    }

    public String createStringOfParamters() {
      StringBuilder builder = new StringBuilder();
      if (listParams != null && listParams.size() > 0) {
        for (String param : listParams) {
          builder.append(param).append(",");
        }
      }
      return builder.toString();
    }

    public boolean compareParameter(String oldParam) {
      String combineString = createStringOfParamters();
      return combineString.equals(oldParam);
    }

  }

  public class FieldParameter extends RecordParameter {

    private String fieldName;
    protected final RuleValueKeyEnum FIELD_NAME_KEY = RuleValueKeyEnum.FIELD_NAME;

    public void setFieldName(String field) {
      fieldName = field;
    }

    /**
     * Constructor
     * 
     * @param type
     * @param numberParams
     */
    FieldParameter(int type, RuleValueKeyEnum[] numberParams) {
      super(type, numberParams);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.st.sc.webapp.RuleDefinitionAction.RecordParameter#buildParameter()
     */
    @Override
    public List<RuleValue> buildParameter() {
      List<RuleValue> list = super.buildParameter();
      if (list == null) {
        list = new ArrayList<RuleValue>();
      }
      list.add(new RuleValue(FIELD_NAME_KEY, fieldName));
      return list;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.st.sc.webapp.RuleDefinitionAction.RecordParameter#seperateParameter(java.util.List)
     */
    @Override
    public void seperateParameter(List<RuleValue> params) {
      if (params != null && params.size() > 0) {
        for (RuleValue ruleValue : params) {
          if (ruleValue.getId().getRuleValueKey() == FIELD_NAME_KEY) {
            fieldName = ruleValue.getParamValue();
            break;
          }
        }
        super.seperateParameter(params);
      }
    }

    public String createStringOfParamters() {
      StringBuilder builder = new StringBuilder();
      builder.append(fieldName).append(",");
      builder.append(super.createStringOfParamters());
      return builder.toString();
    }
  }

  @Override
  protected void checkUserRole(WRequest request) {
    super.checkUserRole(request);
    if (!getIsManaged()) {
      isOwnerOfRule = false;
      isCreatorOfRule = false;
    }
  }

  public void doShow(WRequest request, Event event) {
    // Check role of user
    checkUserRole(request);
    // If page is refresh, action type is not null.
    // If page is called from Rule management, action type is got from
    // parameter.
    if (actionType == null) {
      actionType = request.getParameter("type");
      alreadySave = false;
      alreadyIncreaseVersion = false;
    }

    if (EDIT_TYPE.equals(actionType)) {
      // it use to disable some element.
      isEditRule = true;
      BaseService baseServ = SCWebServiceFactory.getScBaseService();
      // Edit only is called from another page with parameter.
      String ruleVersionIdStr = request.getParameter("ruleVersionId");
      Long ruleVersionId = Long.parseLong(ruleVersionIdStr);
      // Query rule version, and we can get rule and ruleValue list from rule
      // version by using fetch=LAZY.
      // Therefore, we must close EntityManager after fetching from ruleVersion.
      EntityManager entityManager = baseServ.getEntityManagerFactory().createEntityManager();
      ruleVersion =
          baseServ.queryByPrimaryKey(entityManager, RuleVersion.class, ruleVersionId);
      rule = ruleVersion.getRule();

      // Get rule condition type
      ruleConditionName = ruleVersion.getRuleType().name();
      // Get variable of this condition.
      RuleConditionType recordParam = mapRuleConditionAndVariable.get(ruleConditionName);
      // get rule values from rule vesion id.
      // use fetch attribute = LAZY of JPA
      List<RuleValue> listParams = ruleVersion.getRuleValueList();
      // Separate parameters from list of parameters. After separating, values
      // is show on GUI.
      recordParam.seperateParameter(listParams);
      if (recordParam instanceof FieldParameter) {
        selectedField = ((FieldParameter) recordParam).fieldName;
      }
      // store combine parameters on client to check increase version
      ruleConditionParameters = recordParam.createStringOfParamters();

      // Get rule sets which use this rule.
      usedBy = buildUsedByString();
      // Get owners list of this rule
      owners = buildOwnersString();
      // close entity manager after fetching data.
      baseServ.closeEntityManager(entityManager);

    }
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");
    if (ADD_TYPE.equals(actionType)) {
      if (getIsManaged()) {
        isOwnerOfRule = true;
        isCreatorOfRule = true;
      }
      // Add new rule, must initial some values.
      // When add new rule, the version of rule is 1.
      ruleVersion.setVersion(1);
      // get login user to be created user of rule.
      rule.setCreatedBy(loginUser);
      // init owners to display on client.
      owners = loginUser;
      ruleVersion.setUpdatedBy(loginUser);
      // Set default origin
      rule.setOrigin((String) ConfigReloader.reload(SCWebServiceFactory.getSettingService())
          .getValue(ConfigLoader.PLANT_CODE));
    }
    if (EDIT_TYPE.equals(actionType) && getIsManaged()) {
      // check login user whether is owner.
      isOwnerOfRule = checkIsOwner(loginUser);
      if (loginUser.equalsIgnoreCase(rule.getCreatedBy())) {
        isCreatorOfRule = true;
      }
    }
    manageDisplayRule();

    buildShowConfirmMessage();
  }

  private void manageDisplayRule() {
    if (isOwnerOfRule) {
      String recordType = rule.getRecordType();
      if (recordType == null) {
        // get first record in list
        recordType = getRecordTypes()[0];
      }
      ruleConditionDisplay = distributeRuleConditionByRecordType(recordType);
    } else {
      ruleConditionDisplay = distributeRuleConditionWhenNotOwnerOfRule();
    }
  }

  /**
   * Build the usedBy string to display on web GUI.
   * 
   * @return usedBy string.
   */
  private String buildUsedByString() {
    List<RuleSetVersion> list = ruleVersion.getRuleSetVersionList();
    if (list != null && list.size() > 0) {
      List<String> ruleSetNames = new ArrayList<String>();
      for (RuleSetVersion rsv : list) {
        if (!ruleSetNames.contains(rsv.getRuleSet().getName())) {
          ruleSetNames.add(rsv.getRuleSet().getName());
        }
      }
      StringBuilder builder = new StringBuilder();
      for (String name : ruleSetNames) {
        builder.append(name).append(SCConstants.STRING_CONNECTOR);
      }
      // Remove the last connector.
      if (builder.length() > 0) {
        builder.setLength(builder.length() - SCConstants.STRING_CONNECTOR.length());
      }
      return builder.toString();
    } else {
      return "";
    }
  }

  /**
   * Build string of owners of this rule.
   * 
   * @return string of owners.
   */
  private String buildOwnersString() {
    List<RuleOwners> list = rule.getUserRules();
    if (list != null && list.size() > 0) {
      StringBuilder usernameBuilder = new StringBuilder();
      for (RuleOwners user : list) {
        usernameBuilder.append(user.getId().getUserName())
            .append(SCConstants.STRING_CONNECTOR);
      }
      // Remove the last connector.
      if (usernameBuilder.length() > 0) {
        usernameBuilder.setLength(usernameBuilder.length()
            - SCConstants.STRING_CONNECTOR.length());
      }
      return usernameBuilder.toString();
    }
    return "";
  }

  /**
   * Check user whether is owner of rule.
   * 
   * @param userName
   *          user name need to check
   * @return true if it is owner of rule.
   */
  private boolean checkIsOwner(String userName) {
    List<RuleOwners> list = rule.getUserRules();
    if (list != null && list.size() > 0) {
      for (RuleOwners user : list) {
        if (userName.equalsIgnoreCase(user.getId().getUserName())) {
          return true;
        }
      }
    }
    return false;
  }

  public void doBack(WRequest request, Event event) {
    if (alreadySave) {
      boolean isNewRecordRule = false;
      if (ADD_TYPE.equals(actionType)) {
        isNewRecordRule = true;
      }
      redirectBackToRuleList(request, rule.getRuleId(), ruleVersion.getRuleVersionId(),
          isNewRecordRule, alreadyIncreaseVersion);
    } else {
      request.redirectTo(SCConstants.getContextPath() + SCConstants.RULE_LIST_PAGE_URL);
    }
  }

  private void buildShowConfirmMessage() {
    confirmMessage = "";
    // Check action type
    if (EDIT_TYPE.equals(actionType)) {
      BaseService base = SCWebServiceFactory.getScBaseService();
      EntityManager entityManager = base.getEntityManagerFactory().createEntityManager();
      try {
        RuleVersion ruleSetVersion =
            base.queryByPrimaryKey(entityManager, RuleVersion.class,
                ruleVersion.getRuleVersionId());
        if (ruleSetVersion != null) {
          List<RuleSetVersion> list = ruleSetVersion.getRuleSetVersionList();
          if (list != null && list.size() > 0) {
            StringBuilder builder = new StringBuilder();
            for (RuleSetVersion rv : list) {
              builder.append("[").append(rv.getRuleSet().getName()).append(",")
                  .append("Version=").append(rv.getVersion()).append("];");
            }
            // remove last ';'
            builder.setLength(builder.length() - 1);
            confirmMessage = CommonUtils.getRuleBundleMessage("confirm_edit_rule");
            confirmMessage = confirmMessage.replaceFirst("\\{\\}", builder.toString());
          }
        }
      } finally {
        base.closeEntityManager(entityManager);
      }
    }
  }

  private boolean checkExistRuleVersion(WRequest request, Long ruleVersionId) {
    BaseService base = SCWebServiceFactory.getScBaseService();
    RuleVersion ruleVersion = base.queryByPrimaryKey(RuleVersion.class, ruleVersionId);
    if (ruleVersion == null) {
      errorMessage = CommonUtils.getRuleBundleMessage("rule_version_was_deleted");
      return false;
    } else {
      oldRuleOwners = ruleVersion.getRule().getUserRules();
    }
    return true;
  }

  /**
   * Save information.
   * 
   * @param request
   * @param event
   */
  public void doSave(WRequest request, Event event) {
    boolean isEdit = false;
    boolean isAdd = false;
    Long startTime = System.currentTimeMillis();
    // Check action type
    if (EDIT_TYPE.equals(actionType)) {
      isEdit = true;
    }
    if (ADD_TYPE.equals(actionType)) {
      isAdd = true;
    }
    // Get flag to display rule condition. Must get at begin function.
    ruleConditionDisplay = distributeRuleConditionByRecordType(rule.getRecordType());

    // Check rule version whether is deleted when edit rule.
    if (isEdit && !checkExistRuleVersion(request, ruleVersion.getRuleVersionId())) {
      return;
    }
    String originRuleName = request.getParameter("origin_rule_name_h");
    if (isAdd || (isEdit && !originRuleName.equalsIgnoreCase(rule.getName()))) {
      boolean exist = checkExistRuleName(rule.getName());
      if (exist) {
        errorMessage = CommonUtils.getRuleBundleMessage("rule_name_exist");
        return;
      }
    }
    //check origin field: Plant code
    if (rule.getOrigin() == null || rule.getOrigin().length() == 0) {
      errorMessage = CommonUtils.getCommonBundleMessage("msg_input_plant_code");
      return;
    }

    // Get general information of a rule
    List<RuleValue> ruleValues = getSelectdRuleCondition(request);

    // validate Expression field
    String condition = request.getParameter("group1");
    if (condition != null && condition.equals(RuleTypeEnum.EXPRESSION.name())) {
      String validMsg = validateExpressionField(ruleValues.get(0).getParamValue());
      if (validMsg.length() > 0) {
        errorMessage = CommonUtils.getRuleBundleMessage("rule_expression_wrong");
        return;
      }
    }
    BaseService baseServ = SCWebServiceFactory.getScBaseService();
    if (isAdd) {
      // Get next ruleId from sequence
      Long ruleId = baseServ.getNextValueSequence(SCConstants.SEQ_RULE);
      rule.setRuleId(ruleId);

      // Get next ruleVersionId from sequence
      Long ruleVersionId = baseServ.getNextValueSequence(SCConstants.SEQ_RULE_VERSION);
      ruleVersion.setRuleVersionId(ruleVersionId);
    }
    ruleVersion.setRuleId(rule.getRuleId());
    // Set updated by for rule version
    // get login user to be updated user of rule.
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");
    ruleVersion.setUpdatedBy(loginUser);

    // Increase versions when edit rule
    // boolean increaseVersion = false;
    Long oldRuleVersionId = null;
    if (isEdit) {
      // I check increase version on client side with general information:
      // owners, logId, description.
      // I check rule condition on server side.
      // I put parameter to request to check increase version.
      String increase = request.getParameter(INCREASE_VERSION_REQUEST_PARAMETER);
      if (INCREASE_VERSION_TRUE.equals(increase)) {
        alreadyIncreaseVersion = true;
        oldRuleVersionId = ruleVersion.getRuleVersionId();
        // increase version of rule
        Integer maxVersion = new RuleService(baseServ).getMaxVersionOfRule(rule.getRuleId());
        if (maxVersion == null) {
          errorMessage = CommonUtils.getRuleBundleMessage("cannot_get_max_ruleversion");
          return;
        }
        ruleVersion.setVersion(maxVersion + 1);
        // Increase rule version id.
        Long ruleVersionId = baseServ.getNextValueSequence(SCConstants.SEQ_RULE_VERSION);
        ruleVersion.setRuleVersionId(ruleVersionId);
      }
    }
    String actionType = event.getParameter("saveType");
    // If edit and not increase version, check data changed or not.
    if (isEdit && oldRuleVersionId == null) {
      // check name and owners list.
      boolean changed = false;
      if (!originRuleName.equals(rule.getName())) {
        changed = true;
      }
      if (!changed) {
        String originOwners = request.getParameter("origin_owner_list_h");
        if (!originOwners.equals(owners)) {
          changed = true;
        }
      }
      if (!changed) {
        infoMessage = CommonUtils.getCommonBundleMessage("nothing_to_changed");

        if ("close".equals(actionType)) {
          // if no add new rule, just back and keep selection.
          redirectBackToRuleList(request, rule.getRuleId(), ruleVersion.getRuleVersionId(),
              false, alreadyIncreaseVersion);
        }
        return;
      }
    }
    // Set ruleVersionId for each RuleValue
    if (ruleValues != null && ruleValues.size() > 0) {
      for (RuleValue ruleValue : ruleValues) {
        ruleValue.getId().setRuleVersionId(ruleVersion.getRuleVersionId());
      }
    }
    // Save data to DB.
    int saveType;
    if (isAdd) {
      saveType = EntityExecutor.INSERT_ENTITY;
    } else {
      saveType = EntityExecutor.UPDATE_ENTITY;
    }
    // Get current time on DB.
    Timestamp currentTime = baseServ.getCurrentTime();
    // Update current time for entity
    rule.setUpdatedOn(currentTime);
    ruleVersion.setUpdatedOn(currentTime);

    // Create executors to execute all entities in one transaction.
    List<QueryExecutor> listExecutor = new ArrayList<QueryExecutor>();
    // If we edit on rule, must remove old parameters of rule before insert new
    // parameters.
    if (isEdit) {
      // Delete old RuleValue
      Map<String, Object> param = new HashMap<String, Object>();
      param.put("ruleVersionId", ruleVersion.getRuleVersionId());
      QueryStringExecutor queryExecutor =
          new QueryStringExecutor(QueryStringExecutor.NAMED_QUERY, RuleValue.DELETE_PARAMTERS,
              param);
      listExecutor.add(queryExecutor);

      // If we edit on rule, must remove old owners list of rule before insert
      // new
      // owners.
      // Delete old UserRule before update new owners.
      Map<String, Object> param2 = new HashMap<String, Object>();
      param2.put("ruleId", rule.getRuleId());
      QueryStringExecutor queryExecutor2 =
          new QueryStringExecutor(QueryStringExecutor.NAMED_QUERY, RuleOwners.DELETE_USERS,
              param2);
      listExecutor.add(queryExecutor2);
    }
    // Must call delete SQL before insert entities, to not be conflict entities
    // in
    // entity manager. The conflict occurred on entity fetched by 'EAGER'.
    // The conflict between entity fetched from DB and entity created on client.
    // The detail is conflict of RuleOwners.
    listExecutor.add(new EntityExecutor(saveType, rule));
    listExecutor.add(new EntityExecutor(saveType, ruleVersion));

    // Save list of rule parameters.
    if (ruleValues != null && ruleValues.size() > 0) {
      for (RuleValue value : ruleValues) {
        listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, value));
      }
    }
    // Update list of UserRule
    if (owners == null || owners.length() == 0) {
      owners = rule.getCreatedBy();
    } else {
      // check creator exist in list
      if (owners.indexOf(rule.getCreatedBy()) == -1) {
        owners = rule.getCreatedBy() + SCConstants.STRING_CONNECTOR + owners;
      }
    }
    List<RuleOwners> userList = getOwnersOfRule(owners, rule.getRuleId());
    for (RuleOwners userRule : userList) {
      listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, userRule));
    }
    // If updating doesn't increase version, Query to get rule set list of this
    // rule.
    // Cause: when insert rule version with list of rule sets is null,
    // Hibernate will remove all record in Rule_Of_RuleSet table.
    if (isEdit && oldRuleVersionId == null) {
      BaseService base = SCWebServiceFactory.getScBaseService();
      EntityManager entityManager = base.getEntityManagerFactory().createEntityManager();
      try {
        RuleVersion ruleSetVersion =
            base.queryByPrimaryKey(entityManager, RuleVersion.class,
                ruleVersion.getRuleVersionId());
        ruleVersion.setRuleSetVersionList(ruleSetVersion.getRuleSetVersionList());
      } finally {
        base.closeEntityManager(entityManager);
      }
    }
    try {
      baseServ.executeMultipleQuery(listExecutor);

      // Save action log.
      insertActionTracking(isEdit, originRuleName, oldRuleVersionId, userList,
          System.currentTimeMillis() - startTime);
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = CommonUtils.getRuleBundleMessage("error_when_save_rule");
      return;
    }
    // If successful, and save type is close , redirect to rule list page.
    alreadySave = true;
    if ("close".equals(actionType)) {
      if (isAdd) {
        // If add new rule, call doShow() to refesh page.
        String url = SCConstants.getContextPath() + SCConstants.RULE_LIST_SHOW_URL;
        request.redirectTo(url);
      } else {
        // if no add new rule, just back and keep selection.
        redirectBackToRuleList(request, rule.getRuleId(), ruleVersion.getRuleVersionId(),
            false, alreadyIncreaseVersion);
      }
    } else {
      if (isEdit) {
        infoMessage = CommonUtils.getRuleBundleMessage("rule_edit_successful");
        buildShowConfirmMessage();
      }
      // No close, continue to user create new rule
      if (isAdd) {
        actionType = ADD_TYPE;
        // Clear rule ,keep info of rule set version.
        rule = new Rule();
        doShow(request, event);
      }
    }
  }

  /**
   * Get selected rule condition from request.
   * 
   * @param request
   * @return list of RuleValue.
   */
  private List<RuleValue> getSelectdRuleCondition(WRequest request) {
    String condition = request.getParameter("group1");
    List<RuleValue> list = null;
    if (condition != null) {
      RuleConditionType ruleCondition = mapRuleConditionAndVariable.get(condition);
      // If condition is checked on fields, must set field value before building
      // parameters.
      if (ruleCondition instanceof FieldParameter) {
        ((FieldParameter) ruleCondition).fieldName = selectedField;
      }
      list = ruleCondition.buildParameter();

      // set rule condition type for version
      RuleTypeEnum ruleType =
          RuleTypeEnum.fromValue(((RecordParameter) ruleCondition).ruleType);
      ruleVersion.setRuleType(ruleType);

      if (EDIT_TYPE.equals(actionType)) {
        // Get variable to check increase version or not from client
        if (!INCREASE_VERSION_TRUE.equals(request
            .getParameter(INCREASE_VERSION_REQUEST_PARAMETER))) {
          // Check if condition change. If condition change, must increase
          // version.
          boolean increaseVersion = false;
          if (ruleType.name().equals(ruleConditionName)) {
            increaseVersion = !ruleCondition.compareParameter(ruleConditionParameters);
          } else {
            increaseVersion = true;
          }
          if (increaseVersion) {
            request.setParameter(INCREASE_VERSION_REQUEST_PARAMETER, INCREASE_VERSION_TRUE);
          }
        }
      }
      // set rule condition name to display check box after updated.
      // Update condition name and parameters.
      ruleConditionName = ruleType.name();
      ruleConditionParameters = ruleCondition.createStringOfParamters();
    }
    return list;
  }

  private String validateExpressionField(String expression) {
    try {
      ExpressionProcessor.compile(expression, ExpressionUtil.newContext());
    } catch (CompileException e) {
      if (LOGGER.isDebugEnabled()) {
        LOGGER.debug(e.getMessage(), e);
      }
      return e.getMessage();
    }
    return "";
  }

  /**
   * Get list of RuleOwners from owners string.
   * 
   * @param ownerList
   *          String of id of user.
   * @param ruleId
   * @return list of RuleOwners
   */
  private List<RuleOwners> getOwnersOfRule(String ownerList, Long ruleId) {
    if (ownerList == null || ownerList.length() == 0) {
      return null;
    }
    String[] splitList = ownerList.split(SCConstants.STRING_CONNECTOR);
    List<RuleOwners> userList = new ArrayList<RuleOwners>();
    for (String userName : splitList) {
      userList.add(new RuleOwners(userName, ruleId));
    }
    return userList;
  }

  /**
   * Tracking create/modify rule.
   * 
   * @param isEdit
   *          true if edit rule.
   * @param oldRuleName
   *          old rule name
   * @param oldVersion
   *          version before increasing.
   * @param newUsers
   *          list of new users
   * @param elapsedTime
   *          elapsed time of this action.
   */
  private void insertActionTracking(boolean isEdit, String oldRuleName, Long oldRuleVersionId,
      List<RuleOwners> newUsers, long elapsedTime) {
    StringBuilder changedParam = new StringBuilder();
    if (isEdit) {
      if (!oldRuleName.equalsIgnoreCase(rule.getName())) {
        changedParam.append("Rule Name: OldValue=").append(oldRuleName).append(", NewValue=")
            .append(rule.getName());
      }
      // Have increase version.
      if (oldRuleVersionId != null && !oldRuleVersionId.equals(ruleVersion.getRuleVersionId())) {
        RuleVersion oldRuleVersion =
            SCWebServiceFactory.getScBaseService().queryByPrimaryKey(RuleVersion.class,
                oldRuleVersionId);

        if (changedParam.length() > 0) {
          changedParam.append(",");
        }
        changedParam.append("Version: OldValue=").append(oldRuleVersion.getVersion())
            .append(", NewValue=").append(ruleVersion.getVersion());

        RuleSetComparison.differentRule(oldRuleVersion, ruleVersion, changedParam);
      }

      // compare 2 list owners
      boolean different = checkUsersDifferent(newUsers, oldRuleOwners);
      if (different) {
        if (changedParam.length() > 0) {
          changedParam.append(",");
        }
        changedParam.append("[Owners:");
        // old users
        for (RuleOwners oldOwner : oldRuleOwners) {
          changedParam.append(oldOwner.getId().getUserName()).append(",");
        }
        changedParam.append("->");
        // new owners
        for (RuleOwners newOwner : newUsers) {
          changedParam.append(newOwner.getId().getUserName()).append(",");
        }
        changedParam.append("]");
      }
    } else {
      changedParam.append("Rule Name:").append(rule.getName());
    }
    if (changedParam.length() > 0) {
      ActionTrackingEntity trackingEntity = new ActionTrackingEntity();
      if (isEdit) {
        trackingEntity.setAction("Modify Rule");
      } else {
        trackingEntity.setAction("Create Rule");
      }
      trackingEntity.setParameters(changedParam.toString());
      trackingEntity.setElapsedTime(elapsedTime);

      trackAction(trackingEntity);
    }
  }

  private boolean checkUsersDifferent(List<RuleOwners> newUsers, List<RuleOwners> oldUsers) {
    if (newUsers == null || newUsers.size() == 0) {
      if (oldUsers != null && oldUsers.size() > 0) {
        return true;
      }
    } else {
      if (oldUsers == null) {
        return true;
      }
    }
    if (newUsers.size() != oldUsers.size()) {
      return true;
    }
    boolean different = false;
    for (RuleOwners newOwner : newUsers) {
      boolean same = false;
      for (RuleOwners oldOwner : oldUsers) {
        if (newOwner.getId().getUserName().equalsIgnoreCase(oldOwner.getId().getUserName())) {
          same = true;
          break;
        }
      }
      if (!same) {
        different = true;
      }
    }
    return different;
  }

  /**
   * Check exist rule name.
   * 
   * @param ruleName
   *          name of rule.
   * @return true if rule name exist.
   */
  private boolean checkExistRuleName(String ruleName) {
    RuleService ruleSer = new RuleService(SCWebServiceFactory.getScBaseService());
    if (ruleSer.getRuleByName(ruleName) != null) {
      return true;
    }
    return false;
  }

  private void initFullAreaDisplay() {
    for (int i = 0; i < NUM_OF_AREA_DISPLAY; i++) {
      areaDisplay.add(NOT_EMPTY);
    }
  }

  private void buildAreaDisplayWhenNotOwnerOfRule() {
    RuleTypeEnum chooseCondition = RuleTypeEnum.valueOf(ruleConditionName);
    for (int i = 0; i < NUM_OF_AREA_DISPLAY; i++) {
      areaDisplay.add("");
    }
    // Display record
    if ((chooseCondition.getValue() >= RuleTypeEnum.REQUIRED_RECORD.getValue() && chooseCondition
        .getValue() <= RuleTypeEnum.ORDER_TERADYNE.getValue())
        || chooseCondition.getValue() == RuleTypeEnum.VALIDATE_BIT7.getValue()
        || chooseCondition.getValue() == RuleTypeEnum.NUMBER_OF_SDR.getValue()) {
      // Note: move condition : validate bit 7 to occurrence area.
      areaDisplay.set(0, NOT_EMPTY);
    } else {
      // Display field check
      if (chooseCondition.getValue() >= RuleTypeEnum.REQUIRED_FIELD.getValue()
          && chooseCondition.getValue() <= RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS
              .getValue()) {
        areaDisplay.set(1, NOT_EMPTY);

        if (chooseCondition.getValue() != RuleTypeEnum.CHECK_UNIQUENESS.getValue()
            && chooseCondition.getValue() != RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS
                .getValue()) {
          areaDisplay.set(2, NOT_EMPTY);
        } else {
          if (chooseCondition.getValue() == RuleTypeEnum.CHECK_UNIQUENESS.getValue()) {
            areaDisplay.set(3, NOT_EMPTY);
          }
          if (chooseCondition.getValue() == RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS
              .getValue()) {
            areaDisplay.set(4, NOT_EMPTY);
          }
        }
      }
      // Display expression
      if (chooseCondition.getValue() == RuleTypeEnum.EXPRESSION.getValue()) {
        areaDisplay.set(5, NOT_EMPTY);
      }
    }
  }

  /**
   * If user is not owner of rule, just display one condition of this rule. Do
   * not permit user edit.
   * 
   * @return
   */
  private List<String> distributeRuleConditionWhenNotOwnerOfRule() {
    List<String> list = new ArrayList<String>(NUM_OF_RULE_CONDITION);
    RuleTypeEnum chooseCondition = RuleTypeEnum.valueOf(ruleConditionName);
    for (int i = 0; i < NUM_OF_RULE_CONDITION; i++) {
      if (i == chooseCondition.getValue()) {
        list.add(NOT_EMPTY);
      } else {
        list.add("");
      }
    }
    buildAreaDisplayWhenNotOwnerOfRule();
    return list;
  }

  private List<String> distributeRuleConditionByRecordType(String recordType) {
    // Each element of list is presented for that rule condition will be showed
    // or not.
    // If element is empty, this condition will not be showed.
    // Otherwise, this condition will be showed.
    List<String> list = new ArrayList<String>(NUM_OF_RULE_CONDITION);
    for (int i = 0; i < NUM_OF_RULE_CONDITION; i++) {
      if (i == RuleTypeEnum.NUMBER_OF_PCR.getValue()
          || i == RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP1.getValue()
          || i == RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP2.getValue()
          || i == RuleTypeEnum.NUMBER_OF_TEST_RECORD.getValue()
          || i == RuleTypeEnum.NUMBER_OF_SDR.getValue()
          || i == RuleTypeEnum.VALIDATE_BIT7.getValue()
          || i == RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS.getValue()) {
        list.add("");
      } else {
        list.add(NOT_EMPTY);
      }
    }
    checkPCRCondition(list, recordType);
    checkHBR_SBRCondition(list, recordType);
    checkTSRCondition(list, recordType);
    checkSDRCondition(list, recordType);
    checkPTR_MPRCondition(list, recordType);
    checkCorrespondentCondition(list, recordType);

    initFullAreaDisplay();
    return list;
  }

  private void checkPCRCondition(List<String> list, String recordType) {
    if ("PCR".equals(recordType)) {
      // Just apply for PCR record.
      list.set(RuleTypeEnum.NUMBER_OF_PCR.getValue(), NOT_EMPTY);
    }
  }

  private void checkHBR_SBRCondition(List<String> list, String recordType) {
    if ("HBR".equals(recordType) || "SBR".equals(recordType)) {
      // Just apply for HBR,SBR record.
      list.set(RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP1.getValue(), NOT_EMPTY);
      list.set(RuleTypeEnum.NUMBER_OF_BIN_RECORD_OP2.getValue(), NOT_EMPTY);
    }
  }

  private void checkTSRCondition(List<String> list, String recordType) {
    if ("TSR".equals(recordType)) {
      // Just apply for TSR record.
      list.set(RuleTypeEnum.NUMBER_OF_TEST_RECORD.getValue(), NOT_EMPTY);
    }
  }

  private void checkSDRCondition(List<String> list, String recordType) {
    if ("SDR".equals(recordType)) {
      // Just apply for SDR record.
      list.set(RuleTypeEnum.NUMBER_OF_SDR.getValue(), NOT_EMPTY);
    }
  }

  private void checkPTR_MPRCondition(List<String> list, String recordType) {
    if ("PTR".equals(recordType) || "MPR".equals(recordType)) {
      // Just apply for HBR,SBR record.
      list.set(RuleTypeEnum.VALIDATE_BIT7.getValue(), NOT_EMPTY);
    }
  }

  private void checkCorrespondentCondition(List<String> list, String recordType) {
    String[] records = RecordLoader.getRecordsHaveHeadNumSiteNum();
    if (records != null) {
      for (String rc : records) {
        if (recordType.equals(rc)) {
          list.set(RuleTypeEnum.CORRESPONDENT_BETWEEN_RECORDS.getValue(), NOT_EMPTY);
          break;
        }
      }
    }
  }

  /**
   * @return the actionType
   */
  public String getActionType() {
    return actionType;
  }

  /**
   * @param actionType
   *          the actionType to set
   */
  public void setActionType(String actionType) {
    this.actionType = actionType;
  }

  /**
   * @return the ruleConditionName
   */
  public String getRuleConditionName() {
    return ruleConditionName;
  }

  /**
   * @param ruleConditionName
   *          the ruleConditionName to set
   */
  public void setRuleConditionName(String ruleConditionName) {
    this.ruleConditionName = ruleConditionName;
  }

  /**
   * @return the specificValue
   */
  public RecordParameter getSpecificValue() {
    return specificValue;
  }

  /**
   * @param specificValue
   *          the specificValue to set
   */
  public void setSpecificValue(RecordParameter specificValue) {
    this.specificValue = specificValue;
  }

  /**
   * @return the referenceRecord
   */
  public RecordParameter getReferenceRecord() {
    return referenceRecord;
  }

  /**
   * @param referenceRecord
   *          the referenceRecord to set
   */
  public void setReferenceRecord(RecordParameter referenceRecord) {
    this.referenceRecord = referenceRecord;
  }

  /**
   * @return the existInGroup
   */
  public RecordParameter getExistInGroup() {
    return existInGroup;
  }

  /**
   * @param existInGroup
   *          the existInGroup to set
   */
  public void setExistInGroup(RecordParameter existInGroup) {
    this.existInGroup = existInGroup;
  }

  /**
   * @return the includeValues
   */
  public FieldParameter getIncludeValues() {
    return includeValues;
  }

  /**
   * @param includeValues
   *          the includeValues to set
   */
  public void setIncludeValues(FieldParameter includeValues) {
    this.includeValues = includeValues;
  }

  /**
   * @return the excludeValues
   */
  public FieldParameter getExcludeValues() {
    return excludeValues;
  }

  /**
   * @param excludeValues
   *          the excludeValues to set
   */
  public void setExcludeValues(FieldParameter excludeValues) {
    this.excludeValues = excludeValues;
  }

  /**
   * @return the fieldInRange
   */
  public FieldParameter getFieldInRange() {
    return fieldInRange;
  }

  /**
   * @param fieldInRange
   *          the fieldInRange to set
   */
  public void setFieldInRange(FieldParameter fieldInRange) {
    this.fieldInRange = fieldInRange;
  }

  /**
   * @return the fieldLengh
   */
  public FieldParameter getFieldLengh() {
    return fieldLengh;
  }

  /**
   * @param fieldLengh
   *          the fieldLengh to set
   */
  public void setFieldLengh(FieldParameter fieldLengh) {
    this.fieldLengh = fieldLengh;
  }

  /**
   * @return the uniqueField
   */
  public RecordParameter getUniqueField() {
    return uniqueField;
  }

  /**
   * @param uniqueField
   *          the uniqueField to set
   */
  public void setUniqueField(RecordParameter uniqueField) {
    this.uniqueField = uniqueField;
  }

  /**
   * @return the matchingField
   */
  public RecordParameter getMatchingField() {
    return matchingField;
  }

  /**
   * @param matchingField
   *          the matchingField to set
   */
  public void setMatchingField(RecordParameter matchingField) {
    this.matchingField = matchingField;
  }

  /**
   * @return the expressionField
   */
  public RecordParameter getExpressionField() {
    return expressionField;
  }

  /**
   * @param expressionField
   *          the expressionField to set
   */
  public void setExpressionField(RecordParameter expressionField) {
    this.expressionField = expressionField;
  }

  /**
   * @return the selectedField
   */
  public String getSelectedField() {
    return selectedField;
  }

  /**
   * @param selectedField
   *          the selectedField to set
   */
  public void setSelectedField(String selectedField) {
    this.selectedField = selectedField;
  }

  /**
   * @return the rule
   */
  public Rule getRule() {
    return rule;
  }

  /**
   * @param rule
   *          the rule to set
   */
  public void setRule(Rule rule) {
    this.rule = rule;
  }

  /**
   * @return the ruleVersion
   */
  public RuleVersion getRuleVersion() {
    return ruleVersion;
  }

  /**
   * @param ruleVersion
   *          the ruleVersion to set
   */
  public void setRuleVersion(RuleVersion ruleVersion) {
    this.ruleVersion = ruleVersion;
  }

  /**
   * @return usedBy
   */
  public String getUsedBy() {
    return usedBy;
  }

  /**
   * @param usedBy
   *          the usedBy to set
   */
  public void setUsedBy(String usedBy) {
    this.usedBy = usedBy;
  }

  /**
   * @return the isEditRule
   */
  public boolean getIsEditRule() {
    return isEditRule;
  }

  /**
   * @return the ruleConditionDisplay
   */
  public List<String> getRuleConditionDisplay() {
    return ruleConditionDisplay;
  }

  public List<String> getAreaDisplay() {
    return areaDisplay;
  }

  /**
   * @param ruleConditionDisplay
   *          the ruleConditionDisplay to set
   */
  public void setRuleConditionDisplay(List<String> ruleConditionDisplay) {
    this.ruleConditionDisplay = ruleConditionDisplay;
  }

  /**
   * @param areaDisplay
   *          the areaDisplay to set
   */
  public void setAreaDisplay(List<String> areaDisplay) {
    this.areaDisplay = areaDisplay;
  }

  /**
   * @return the owners
   */
  public String getOwners() {
    return owners;
  }

  /**
   * @param owners
   *          the owners to set
   */
  public void setOwners(String owners) {
    this.owners = owners;
  }

  /**
   * @return the ruleConditionParameters
   */
  public String getRuleConditionParameters() {
    return ruleConditionParameters;
  }

  /**
   * @param ruleConditionParameters
   *          the ruleConditionParameters to set
   */
  public void setRuleConditionParameters(String ruleConditionParameters) {
    this.ruleConditionParameters = ruleConditionParameters;
  }

  /**
   * Get isOwnerOfRule
   * 
   * @return isOwnerOfRule
   */
  public boolean getIsOwnerOfRule() {
    return isOwnerOfRule;
  }

  public boolean getIsCreatorOfRule() {
    return isCreatorOfRule;
  }

  /**
   * @param isEditRule
   *          the isEditRule to set
   */
  public void setIsEditRule(boolean isEditRule) {
    this.isEditRule = isEditRule;
  }

  /**
   * @param isCreatorOfRule
   *          the isCreatorOfRule to set
   */
  public void setIsCreatorOfRule(boolean isCreatorOfRule) {
    this.isCreatorOfRule = isCreatorOfRule;
  }

  /**
   * @param isOwnerOfRule
   *          the isOwnerOfRule to set
   */
  public void setIsOwnerOfRule(boolean isOwnerOfRule) {
    this.isOwnerOfRule = isOwnerOfRule;
  }

  /**
   * @return the alreadyIncreaseVersion
   */
  public boolean getAlreadyIncreaseVersion() {
    return alreadyIncreaseVersion;
  }

  /**
   * @param alreadyIncreaseVersion
   *          the alreadyIncreaseVersion to set
   */
  public void setAlreadyIncreaseVersion(boolean alreadyIncreaseVersion) {
    this.alreadyIncreaseVersion = alreadyIncreaseVersion;
  }

  /**
   * @return the alreadySave
   */
  public boolean getAlreadySave() {
    return alreadySave;
  }

  /**
   * @param alreadySave
   *          the alreadySave to set
   */
  public void setAlreadySave(boolean alreadySave) {
    this.alreadySave = alreadySave;
  }

  /**
   * @return the confirmMessage
   */
  public String getConfirmMessage() {
    return confirmMessage;
  }

}
