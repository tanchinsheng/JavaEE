/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 28, 2011 6:46:13 PM - nguyensn - Initialize version
/********************************************************************************/
package com.st.sc.webapp;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.login.LoginUtil;
import st.liotrox.profile.UserProfile;

import com.st.common.DBUtil;
import com.st.common.exception.ServiceException;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.util.SCWebServiceFactory;
import com.st.um.entity.UserEntity;
import com.st.um.service.UserService;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ChangePasswordNC extends LoginAction {
  private static final Logger LOGGER = LoggerFactory.getLogger(ChangePasswordNC.class);

  private String currentPassword;
  private String newPassword;
  private String confirmPassword;
  private String errorMessage;

  /**
   * @return the errorMessage
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * @param errorMessage
   *          the errorMessage to set
   */
  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  /**
   * @return the currentPassword
   */
  public String getCurrentPassword() {
    WRequest request = WRequest.getCurrentInstance();
    UserProfile userProfile = request.getUserProfile();
    currentPassword = userProfile.getAttribute("liotrox.password");
    return currentPassword;
  }

  /**
   * @param currentPassword
   *          the currentPassword to set
   */
  public void setCurrentPassword(String currentPassword) {
    this.currentPassword = currentPassword;
  }

  /**
   * @return the newPassword
   */
  public String getNewPassword() {
    return newPassword;
  }

  /**
   * @param newPassword
   *          the newPassword to set
   */
  public void setNewPassword(String newPassword) {
    this.newPassword = newPassword;
  }

  /**
   * @return the confirmPassword
   */
  public String getConfirmPassword() {
    return confirmPassword;
  }

  /**
   * @param confirmPassword
   *          the confirmPassword to set
   */
  public void setConfirmPassword(String confirmPassword) {
    this.confirmPassword = confirmPassword;
  }

  private boolean validation() {
    boolean result = true;
    getCurrentPassword();
    if (newPassword == null || newPassword.equals("")) {
      errorMessage = CommonUtils.getLoginBundleMessage("scc_change_new_password_require");
      result = false;
    } else if (confirmPassword == null || confirmPassword.equals("")) {
      errorMessage = CommonUtils.getLoginBundleMessage("scc_change_confirm_password_require");
      result = false;
    } else if (newPassword.length() != newPassword.trim().length()) {
      errorMessage =
          CommonUtils.getLoginBundleMessage("scc_change_new_password_contain_blank");
      result = false;
    } else if (confirmPassword.length() != confirmPassword.trim().length()) {
      errorMessage =
          CommonUtils.getLoginBundleMessage("scc_change_confirm_password_contain_blank");
      result = false;
    } else if (!newPassword.equals(confirmPassword)) {
      errorMessage = CommonUtils.getLoginBundleMessage("scc_change_password_wrong_confirm");
      result = false;
    } else if (newPassword.equals(currentPassword)) {
      errorMessage = CommonUtils.getLoginBundleMessage("scc_change_confirm_no_change");
      result = false;
    }
    return result;
  }

  /**
   * Change password of the first login of user.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void changePassword(WRequest request, Event event) {
    try {
      LOGGER.debug("changePassword");
      if (!validation()) {
        return;
      }
      UserProfile up = request.getUserProfile();
      String username = up.getAttribute("liotrox.user");

      UserService userService = SCWebServiceFactory.getUserService();
      UserEntity user = userService.getUserByUserName(username);
      if (user != null) {
        String passwordHash = DBUtil.hashPassword(newPassword);
        Timestamp date = SCWebServiceFactory.getSCExecutor().getSysDate();
        user.setLastLoginDate(date);
        user.setPassword(passwordHash);
        // update DB
        userService.update(user);

        String roleName = user.getRoleName();
        setRole(roleName);

        up.setAttribute("liotrox.role", getRole());
        up.setAttribute("liotrox.roles", new String[]{getRole() });
        LoginUtil.bindUserProfile(request, up);

        request.redirectTo(SCConstants.getContextPath() + SCConstants.FILTERING_PAGE_URL);
      } else {
        errorMessage = CommonUtils.getLoginBundleMessage("user_already_deleted");
      }
    } catch (ServiceException e) {
      setErrorMessage(CommonUtils.getCommonBundleMessage(SCConstants.DB_COMMON_ERROR_KEY));
      LOGGER.error(e.getMessage(), e);
    }
  }
}
