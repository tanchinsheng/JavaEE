/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/* HISTORY */
// - 1.0.0 - Apr 21, 2011 3:30:00 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.common;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.WRequest;

import com.st.common.EncryptionUtils;

/**
 * The Class CommonUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class CommonUtils {

  private static final Logger LOG = LoggerFactory.getLogger(CommonUtils.class);
  
  /**
   * Instantiates a new common utils.
   */
  private CommonUtils() {
  }

  /**
   * Gets the hTTP param name.
   * 
   * @param cls
   *          the cls
   * @param fieldName
   *          the field name
   * @return the hTTP param name
   * @throws Exception
   *           the exception
   */
  public static String getHTTPParamName(final Class< ? > cls, final String fieldName)
      throws Exception {

    Field f = getField(cls, fieldName);
    if (f != null) {
      HTTPParamName anno = f.getAnnotation(HTTPParamName.class);
      if (anno != null) {
        return anno.name();
      } else {
        return f.getName();
      }
    }
    return null;
  }

  /**
   * Gets the hTTP param name.
   * 
   * @param cls
   *          the cls
   * @param field
   *          the field
   * @return the hTTP param name
   * @throws Exception
   *           the exception
   */
  public static String getHTTPParamName(final Class< ? > cls, Field field) throws Exception {

    if (field != null) {
      HTTPParamName anno = field.getAnnotation(HTTPParamName.class);
      if (anno != null) {
        return anno.name();
      } else {
        return field.getName();
      }
    }
    return null;
  }

  /**
   * Gets field of the cls.
   * 
   * @param cls
   *          the cls
   * @param fieldName
   *          the field name
   * @return Field
   */
  public static Field getField(Class< ? > cls, final String fieldName) {
    if (cls == null || fieldName == null) {
      return null;
    }
    while (cls != null) {
      try {
        Field f = cls.getDeclaredField(fieldName);
        if (f != null) {
          return f;
        }
      } catch (NoSuchFieldException e) {
        if (cls.getSuperclass() != null) {
          cls = cls.getSuperclass();
        } else {
          cls = null;
        }
      }
    }
    return null;
  }

  /**
   * Gets the sets the method.
   * 
   * @param cls
   *          the cls
   * @param field
   *          the field
   * @return the sets the method
   */
  public static Method getSetMethod(Class< ? > cls, Field field) {
    if (cls == null || field == null) {
      return null;
    }
    String methodName =
        "set" + field.getName().substring(0, 1).toUpperCase() + field.getName().substring(1);
    Method setMethod = null;
    try {
      setMethod = cls.getMethod(methodName, field.getType());
    } catch (SecurityException e) {
    } catch (NoSuchMethodException e) {
    }
    return setMethod;
  }

  /**
   * Get message from bundle.
   * 
   * @param bundleName
   *          name of bundle, ex: app/sc/rule_management
   * @param key
   *          key of message
   * @return message
   */
  public static String getBundleMessage(String bundleName, String key) {
    WRequest request = WRequest.getCurrentInstance();
    return request.getI18NMessage(bundleName, key);
  }

  /**
   * Gets message from bundle.
   * 
   * @param bundleName
   *          name of bundle, ex: app/sc/rule_management
   * @param key
   *          the key of message
   * @param params
   *          the parameter
   * @return the bundle message
   */
  public static String getBundleMessage(String bundleName, String key, Object[] params) {
    WRequest request = WRequest.getCurrentInstance();
    return request.getI18NMessage(bundleName, key, params);
  }

  /**
   * Get message from rule bundle 'app/sc/rule_management'.
   * 
   * @param key
   *          key of message
   * @return message
   */
  public static String getRuleBundleMessage(String key) {
    return getBundleMessage(SCConstants.BUNDLE_RULE_NAME, key);
  }

  /**
   * Get message from rule bundle 'app/sc/ruleset_management'.
   * 
   * @param key
   *          key of message
   * @return message
   */
  public static String getRuleSetBundleMessage(String key) {
    return getBundleMessage(SCConstants.BUNDLE_RULESET_NAME, key);
  }

  /**
   * Gets the report bundle message.
   * 
   * @param key
   *          the key
   * @return the report bundle message
   */
  public static String getReportBundleMessage(String key) {
    return getBundleMessage(SCConstants.BUNDLE_REPORT, key);
  }

  /**
   * Gets the report bundle message.
   * 
   * @param key
   *          the key
   * @param params
   *          the parameters
   * @return the report bundle message
   */
  public static String getReportBundleMessage(String key, Object[] params) {
    return getBundleMessage(SCConstants.BUNDLE_REPORT, key, params);
  }

  /**
   * Get message from common bundle 'app/sc/sc'.
   * 
   * @param key
   *          key of message
   * @return message
   */
  public static String getCommonBundleMessage(String key) {
    return getBundleMessage(SCConstants.BUNDLE_COMMON_NAME, key);
  }

  /**
   * Get message from common bundle 'app/sc/admin'.
   * 
   * @param key
   *          key of message
   * @return message
   */
  public static String getAdminBundleMessage(String key) {
    return getBundleMessage(SCConstants.BUNDLE_ADMIN, key);
  }

  /**
   * Get message from common bundle 'app/sc/admin'.
   * 
   * @param key
   *          the key
   * @param param
   *          the parameters
   * @return the admin bundle message
   */
  public static String getAdminBundleMessage(String key, Object[] param) {
    return getBundleMessage(SCConstants.BUNDLE_ADMIN, key, param);
  }

  /**
   * Get message from profile bundle 'app/sc/profile'.
   * 
   * @param key
   *          key of message
   * @return message
   */
  public static String getProfileBundleMessage(String key) {
    return getBundleMessage(SCConstants.BUNDLE_PROFILE, key);
  }

  /**
   * Get message from login bundle 'app/sc/login'.
   * 
   * @param key
   *          key of message
   * @return message
   */
  public static String getLoginBundleMessage(String key) {
    return getBundleMessage(SCConstants.BUNDLE_LOGIN_NAME, key);
  }

  /**
   * Round a double value to 2 decimal.
   * 
   * @param value
   *          the value
   * @return the double
   */
  public static double roundDouble(double value) {
    DecimalFormat format = new DecimalFormat("#.##");
    return Double.parseDouble(format.format(value));
  }

  public static List<Object[]> convertIntToObject(List<Integer[]> list) {
    if (list == null) {
      return null;
    }
    List<Object[]> result = new ArrayList<Object[]>();
    for (Integer[] valueList : list) {
      Object[] ls = new Object[valueList.length];
      for (int i = 0; i < valueList.length; i++) {
        ls[i] = valueList[i];
      }
      result.add(ls);
    }
    return result;
  }

  /**
   * Convert integer to hexa.
   * @param num
   * @return
   */
  public static String convertToHex(final int num) {
    String hex = Integer.toHexString(num);
    if (hex.length() == 1) {
      hex = "0" + hex;
    }
    return hex;
  }
  
  /**
   * Encrypt password.
   * 
   * @param password
   * @param errorMsg
   *          errorMsg message use to log when error.
   * @param oldEncryptedPass
   *          the old password which was already encrypted.
   * @return
   */
  public static String encryptPassword(final String password, final String errorMsg,
      final String oldEncryptedPass) {
    String encrypt = null;
    // decrypt password
    if (password != null && password.length() > 0) {
      if (!password.equals(oldEncryptedPass)) {
        try {
          encrypt = EncryptionUtils.encrypt(password);
        } catch (Exception e) {
          LOG.error("Cannot encrypt password of " + errorMsg, e);
        }
      } else {
        // password is origin password which was already encrypted.
        encrypt = password;
      }
    }
    return encrypt;
  }
}
