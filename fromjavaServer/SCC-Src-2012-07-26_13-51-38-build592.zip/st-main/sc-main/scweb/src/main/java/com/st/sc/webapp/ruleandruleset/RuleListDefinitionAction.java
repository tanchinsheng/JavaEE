package com.st.sc.webapp.ruleandruleset;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.RowList;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.db.DataSet;
import st.liotrox.db.DefaultDataSet;
import st.liotrox.template.element.control.DataViewElement;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.web.html.WriteHTML;

import com.st.persistence.entity.ActionTrackingEntity;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleSetOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleVersion;
import com.st.sc.entity.RulesOfRS;
import com.st.sc.entity.util.Util;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.rulemanager.EntityExecutor;
import com.st.sc.rulemanager.QueryExecutor;
import com.st.sc.rulemanager.QueryStringExecutor;
import com.st.sc.rulemanager.RuleService;
import com.st.sc.rulemanager.RuleSetService;
import com.st.sc.service.ReportService;
import com.st.sc.util.RuleSetComparison;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.RuleDTO;
import com.st.sc.web.data.RuleVersionDTO;

/**
 * The Class RulesetDefinitionPage.
 */
public class RuleListDefinitionAction extends RuleListOfRuleSetAction {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(RuleListDefinitionAction.class);

  /** The avail data view. */
  private DataView availDataView = null;

  /** The selected data view. */
  private DataView selectedDataView = null;

  /** The ds available rules. */
  private DataSet availableRuleDS;

  /** The ds selected rules. */
  private DataSet ruleListOfRuleSetDS;

  /** The avail rules. */
  private List<RuleDTO> availRules;

  /** The selected rules. */
  private List<RuleVersionDTO> selectedRules;

  /** The Constant DS_COLUMS_NAME. */
  private static final String[] DS_COLUMS_NAME_RIGHT = new String[]{"ruleId", "ruleVersionId",
      "ruleName", "recordType", "version", "description", "point", "weightageInString",
      "lastUpdate", "createdBy", "usedBy", "updatedBy", "origin", "owners", "logID" };

  private static final String[] DS_COLUMS_NAME_LEFT = new String[]{"ruleId", "ruleName",
      "ruleVersionList", "selectedIndex" };

  private static final String COMBOBOX_SELECT_NAME = "sc_cb_ruleversion";
  private static final String ADD_VALUE = "add";

  /**
   * These are used to handle back to rule set list.
   */
  private String callFromRuleSetDefinition = null;
  private String callFromShowRuleList = null;
  private boolean inCreaseRuleSetVersion;

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#beforeRender(st.liotrox.WRequest)
   */
  @Override
  protected void beforeRender(WRequest request) {
    // Add javacript function call in OnLoad(), to show error message if have.
    addOnLoadCode("checkAndShowErrorMesage();");

    // check role of user
    checkUserRole(request);
    super.beforeRender(request);
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#afterPopulate(st.liotrox.WRequest)
   */
  @Override
  protected void afterPopulate(WRequest request) {
    // This function is call when next,prev,last,first page of dataview.
    int[] selectedRows = getAvailDataView().getSelectedRows();
    if (selectedRows != null && selectedRows.length > 0) {
      for (int selectedRow : selectedRows) {
        // store selected index of rule version in selectbox of dataview.
        String indexStr = request.getParameter(COMBOBOX_SELECT_NAME + selectedRow);
        if (indexStr != null) {
          Integer indexCombobox = Integer.parseInt(indexStr);
          // Store index to dataset.
          getAvailDataView().getModel().getDataSet()
              .setValue(selectedRow, "selectedIndex", indexCombobox);
        }
      }
    }

    // clear error message.
    clearErrorMsg();
    super.afterPopulate(request);
  }

  private void clearSessionVariable() {
    ruleSetVersion = new RuleSetVersion();
    callFromRuleSetDefinition = null;
    callFromShowRuleList = null;
    inCreaseRuleSetVersion = false;
  }

  private void clearErrorMsg() {
    errorMessage = "";
    infoMessage = "";
    errorCheckSelectedRecord = "";
  }

  /**
   * Do show.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void doShow(final WRequest request, final Event event) {
    clearErrorMsg();
    try {
      // Parameter is passed from URL.
      String ruleSetVersionIdStr = request.getParameter("ruleSetVersionId");
      Long ruleSetVersionId = null;
      if (ruleSetVersionIdStr != null) {
        // clear session variable
        clearSessionVariable();

        ruleSetVersionId = Long.parseLong(ruleSetVersionIdStr);
        // Get parameter to determine whether page is called from rule set
        // condition page.
        callFromRuleSetDefinition =
            request.getParameter(SCConstants.PARAMETER_CALL_FROM_RULESET_DEFINITION);
        // Get parameter to determine whether page is called from show rule list
        // page.
        callFromShowRuleList =
            request.getParameter(SCConstants.PARAMETER_CALL_FROM_SHOW_RULE_LIST);

        // User is creating a rule set, and get ruleSetVersion from session.
        if (isAddingNewRuleSet()) {
          // get ruleSetVersion
          ruleSetVersion =
              (RuleSetVersion) request.getSession().getAttribute(
                  SCConstants.SESSION_KEY_RULESET_VERSION);
        }
      } else {
        // function doShow is called by another function in this class to
        // refresh page.
        if (ruleSetVersion.getRuleSetVersionId() != null) {
          ruleSetVersionId = ruleSetVersion.getRuleSetVersionId();
        }
      }
      // Check user is operator or admin or engineer.
      checkUserRole(request);
      if (isOwnersOfRuleSet) {
        // create data for 2 list view. And query data for ruleSetVersion
        // variable.
        createRuleDefinitionForm(ruleSetVersionId);
      }

      if (getIsManaged()) {
        // If page is called from rule set condition page, we don't need check
        // authorized
        if (isCallFromRuleSetDefinition()) {
          isOwnersOfRuleSet = true;
        } else {
          // get login user and check whether it is owners of rule set.
          isOwnersOfRuleSet =
              checkLoginUserIsOwnerRuleSet(request, ruleSetVersion.getRuleSet());
        }
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
  }

  private void createRuleDefinitionForm(Long ruleSetVersionId) throws Exception {
    // Get rule of this rule set version.
    selectedRules = createListRuleVersionDTO(ruleSetVersionId);
    ruleListOfRuleSetDS = new DefaultDataSet();
    createMatrixDataSetRuleVersionDto(ruleListOfRuleSetDS, selectedRules);
    selectedDataView = getSelectedDataView();
    selectedDataView.getModel().setDataSet(ruleListOfRuleSetDS);

    // Get all available rules
    createAvailableRuleDataView();

  }

  private void createAvailableRuleDataView() throws Exception {
    availRules = getAvailableRuleList();
    availableRuleDS = new DefaultDataSet();
    createMatrixDataSetRuleDto(availableRuleDS, availRules);
    availDataView = getAvailDataView();
    availDataView.getModel().setDataSet(availableRuleDS);
  }

  private void createMatrixDataSetRuleDto(DataSet dataSet, List<RuleDTO> listDto)
      throws Exception {
    dataSet.setColumnNames(DS_COLUMS_NAME_LEFT);
    if (listDto.size() > 0) {
      dataSet.loadFromMatrix(ReportService.buildMatrix(
          listDto.toArray(new RuleDTO[listDto.size()]), DS_COLUMS_NAME_LEFT));
    }
  }

  private void createMatrixDataSetRuleVersionDto(DataSet dataSet, List<RuleVersionDTO> listDto)
      throws Exception {
    dataSet.setColumnNames(DS_COLUMS_NAME_RIGHT);
    if (listDto.size() > 0) {
      dataSet.loadFromMatrix(ReportService.buildMatrix(
          listDto.toArray(new RuleVersionDTO[listDto.size()]), DS_COLUMS_NAME_RIGHT));
    }
  }

  /**
   * Gets the avail data view.
   * 
   * @return the avail data view
   */
  public DataView getAvailDataView() {
    if (availDataView == null) {
      DataViewElement dvElement = (DataViewElement) findControl("xcAvailableRuleDV");
      availDataView = dvElement.getDataView(WRequest.getCurrentInstance());
    }
    return availDataView;
  }

  /**
   * Gets the selected data view.
   * 
   * @return the selected data view
   */
  public DataView getSelectedDataView() {
    if (selectedDataView == null) {
      DataViewElement dvElement = (DataViewElement) findControl("xcSelectedRuleDV");
      selectedDataView = dvElement.getDataView(WRequest.getCurrentInstance());
    }
    return selectedDataView;
  }

  /**
   * Gets the available rule list.
   * 
   * @return the available rule list
   */
  private List<RuleDTO> getAvailableRuleList() {
    RuleService ruleServ = new RuleService(SCWebServiceFactory.getScBaseService());
    EntityManager entityManager =
        SCWebServiceFactory.getScEntityManagerFactory().createEntityManager();
    List<Rule> listRules = ruleServ.getAllRules(entityManager);
    List<RuleDTO> ruleDtoList = createListRuleDTO(listRules);
    SCWebServiceFactory.getScBaseService().closeEntityManager(entityManager);
    return ruleDtoList;
  }

  private RuleDTO createRuleDTO(Rule rule) {
    RuleDTO ruleDto = new RuleDTO();
    ruleDto.setRuleId(rule.getRuleId());
    ruleDto.setRuleName(rule.getName());
    List<RuleVersionDTO> ruleVersionList = createListRuleVersionDTO(rule);
    ruleDto.setRuleVersionList(ruleVersionList);
    return ruleDto;
  }

  private List<RuleDTO> createListRuleDTO(List<Rule> listRule) {
    List<RuleDTO> listDto = new ArrayList<RuleDTO>();
    if (listRule != null && listRule.size() > 0) {
      for (Rule rule : listRule) {
        RuleDTO dto = createRuleDTO(rule);
        listDto.add(dto);
      }
    }
    return listDto;
  }

  /**
   * Check need increase version or not.
   * 
   * @return
   */
  private boolean checkIncreaseVersion() {
    // Get current list of rule version of a rule set.
    RuleSetService ruleSetServ = new RuleSetService(SCWebServiceFactory.getScBaseService());
    // List<RuleSetVersion> listRuleSetVersions =
    // ruleSetServ.getVersions(ruleSetVersion.getRuleSetId());
    boolean increaseVersion = false;
    // get list rule of rule set.
    List<RulesOfRS> listRuleOfRS =
        ruleSetServ.getListRulesOfRS(ruleSetVersion.getRuleSetVersionId());
    if (listRuleOfRS == null || listRuleOfRS.size() == 0) {
      if (selectedRules != null && selectedRules.size() > 0) {
        increaseVersion = true;
      }
    } else {
      if (selectedRules == null || selectedRules.size() != listRuleOfRS.size()) {
        increaseVersion = true;
      } else {
        // selectedRules.size() == listRuleOfRS.size()
        boolean exist = false;
        for (RulesOfRS rulesOfRS : listRuleOfRS) {
          Long ruleVersionId = rulesOfRS.getId().getRuleVersionId();
          exist = false;
          for (RuleVersionDTO dto : selectedRules) {
            if (ruleVersionId.equals(dto.getRuleVersionId())) {
              exist = true;
              break;
            }
          }
          if (!exist) {
            increaseVersion = true;
            break;
          }
        }
      }
    }
    return increaseVersion;
  }

  public void updateNoClose(final WRequest request, final Event event) {
    clearErrorMsg();
    // If edit rule list, must check whether rule set version was deleted.
    if ((!isAddingNewRuleSet() || inCreaseRuleSetVersion)
        && !checkExistRuleSetVersion(request, ruleSetVersion.getRuleSetVersionId())) {
      return;
    }
    String errorMsg = checkSelectedRulesExist();
    if (errorMsg.length() > 0) {
      errorCheckSelectedRecord = errorMsg;
      return;
    }
    boolean tempIncrease = update(request, event);
    if (tempIncrease) {
      // If it increase version first time, dont't reset it if next time don't
      // increase version.
      inCreaseRuleSetVersion = tempIncrease;
    }
  }

  public void updateClose(final WRequest request, final Event event) {
    clearErrorMsg();
    // If edit rule list, must check whether rule set version was deleted.
    if ((!isAddingNewRuleSet() || inCreaseRuleSetVersion)
        && !checkExistRuleSetVersion(request, ruleSetVersion.getRuleSetVersionId())) {
      return;
    }
    String errorMsg = checkSelectedRulesExist();
    if (errorMsg.length() > 0) {
      errorCheckSelectedRecord = errorMsg;
      return;
    }
    boolean tempIncrease = update(request, event);
    if (tempIncrease) {
      // If it increase version first time, dont't reset it if next time don't
      // increase version.
      inCreaseRuleSetVersion = tempIncrease;
    }
    // close and redirect to rule set list.
    redirectPage(request);
  }

  public void doCancel(final WRequest request, final Event event) {
    // clear rule set version in session
    request.getSession().setAttribute(SCConstants.SESSION_KEY_RULESET_VERSION, null);
    redirectPage(request);
  }

  private void redirectPage(final WRequest request) {
    if (isCallFromShowRuleList()) {
      redirectToShowRuleListPage(request, ruleSetVersion.getRuleSetVersionId());
    } else {
      boolean isAdd = isAddingNewRuleSet();
      redirectBackToRuleSetList(request, ruleSetVersion.getRuleSet().getRuleSetId(),
          ruleSetVersion.getRuleSetVersionId(), isAdd, inCreaseRuleSetVersion);
    }
  }

  /**
   * Update data to DB.
   * 
   * @param request
   * @param event
   * @return true if increase version of rule set.
   */
  public boolean update(final WRequest request, final Event event) {
    long startTime = System.currentTimeMillis();
    // Check whether page is call from rule set condition page.
    RuleSetVersion sessionRuleSetVersion = null;
    boolean alreadyIncreaseVersion = false;
    if (isCallFromRuleSetDefinition()) {
      sessionRuleSetVersion =
          (RuleSetVersion) request.getSession().getAttribute(
              SCConstants.SESSION_KEY_RULESET_VERSION);
      // Must check different null, because: after the first time update, then i
      // clear session.
      if (sessionRuleSetVersion != null) {
        // It is the first time update, variable in session # null.
        // If this is add new rule set, we get ruleSetVersion from session in
        // doShow() function.
        // At here, don't get ruleSetVersion again.
        if (isAddingNewRuleSet()) {
          alreadyIncreaseVersion = true;
          // when add new, on dowShow() function, we already assigned to
          // ruleSetVersin from session.
        } else {
          // compare id of rule set version in session and current page.
          // If they are different, the version was increased in rule set
          // condition page,
          // at here, we don't need increase version again.
          if (!sessionRuleSetVersion.getRuleSetVersionId().equals(
              ruleSetVersion.getRuleSetVersionId())) {
            alreadyIncreaseVersion = true;
          }
          // assign rule set version in session to current rule set version.
          ruleSetVersion = sessionRuleSetVersion;
        }
      }
    }

    // If object stored in session which did not increase version, we check rule
    // list to increase version.
    boolean increaseVersion = false;
    if (!alreadyIncreaseVersion) {
      increaseVersion = checkIncreaseVersion();
    }
    // If we did not increase version before,must increase version here.
    if (increaseVersion) {
      // increase version of rule
      Integer maxVersion =
          new RuleSetService(SCWebServiceFactory.getScBaseService())
              .getMaxVersionOfRuleSet(ruleSetVersion.getRuleSet().getRuleSetId());
      if (maxVersion == null) {
        errorMessage = CommonUtils.getRuleSetBundleMessage("cannot_get_max_rulesetversion");
        return false;
      }
      ruleSetVersion.setVersion(maxVersion + 1);
      ruleSetVersion.setStatus(false);
      // Increase rule set version id.
      Long newRuleSetVersionId =
          SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET_VERSION);
      ruleSetVersion.setRuleSetVersionId(newRuleSetVersionId);

      if (Util.countMirCriteria(ruleSetVersion.getMirCriteria()) == 0) {
        ruleSetVersion.setMirCriteria(null);
      } else {
        // Update MIRCriterial
        ruleSetVersion.getMirCriteria().setRuleSetVersionId(newRuleSetVersionId);
        ruleSetVersion.getMirCriteria().setRuleSetVersion(ruleSetVersion);
      }
    }
    // Begin insert data.
    List<QueryExecutor> listExecutor = new ArrayList<QueryExecutor>();

    // Page is called from rule set definition.
    if (sessionRuleSetVersion != null) {
      boolean needSaveDB = false;
      if (alreadyIncreaseVersion || increaseVersion) {
        needSaveDB = true;
      } else {
        // Not increase version, must check name and owners whether are changed.
        RuleSetVersion dbRuleSetVersion =
            SCWebServiceFactory.getScBaseService().queryByPrimaryKey(RuleSetVersion.class,
                ruleSetVersion.getRuleSetVersionId());
        needSaveDB = checkChangedNotIncreaseVersion(dbRuleSetVersion, ruleSetVersion);
        if (!needSaveDB) {
          infoMessage = CommonUtils.getCommonBundleMessage("nothing_to_changed");
          return false;
        }
      }
      if (needSaveDB) {
        // If we edit, must remove old owners list of rule before insert new
        // owners.
        if (!isAddingNewRuleSet()) {
          Map<String, Object> param = new HashMap<String, Object>();
          param.put("ruleSetId", ruleSetVersion.getRuleSet().getRuleSetId());
          QueryStringExecutor queryExecutor =
              new QueryStringExecutor(QueryStringExecutor.NAMED_QUERY,
                  RuleSetOwners.DELETE_USERS, param);
          listExecutor.add(queryExecutor);
        }
        // Get current time on DB.
        Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
        ruleSetVersion.setUpdatedOn(currentTime);
        ruleSetVersion.getRuleSet().setUpdatedOn(currentTime);
        if (isAddingNewRuleSet()) {
          ruleSetVersion.setStatusUpdatedTime(currentTime);
        }
        // Save data to DB.
        int saveType;
        if (alreadyIncreaseVersion && isAddingNewRuleSet()) {
          saveType = EntityExecutor.INSERT_ENTITY;
        } else {
          saveType = EntityExecutor.UPDATE_ENTITY;
        }
        // Update rule set and its version
        listExecutor.add(new EntityExecutor(saveType, ruleSetVersion.getRuleSet()));
        int saveTypeVersion;
        if (alreadyIncreaseVersion || increaseVersion) {
          saveTypeVersion = EntityExecutor.INSERT_ENTITY;
        } else {
          saveTypeVersion = EntityExecutor.UPDATE_ENTITY;
        }
        listExecutor.add(new EntityExecutor(saveTypeVersion, ruleSetVersion));

        for (RuleSetOwners userRuleset : ruleSetVersion.getRuleSet().getUserRuleSets()) {
          listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, userRuleset));
        }
        // Empty list of users of rule set to update not be exception.
        ruleSetVersion.getRuleSet().setUserRuleSets(null);

        // Insert rules of rule set version when increase version.
        if (alreadyIncreaseVersion || increaseVersion) {
          for (RuleVersionDTO dto : selectedRules) {
            listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, new RulesOfRS(
                dto.getRuleVersionId(), ruleSetVersion.getRuleSetVersionId())));
          }
        }
        try {
          SCWebServiceFactory.getScBaseService().executeMultipleQuery(listExecutor);

          // Action log for create rule set
          if (alreadyIncreaseVersion && isAddingNewRuleSet()) {
            actionTrackingRuleList("Create Rule Set", ruleSetVersion.getRuleSet().getName(),
                System.currentTimeMillis() - startTime);
          } else {
            actionTrackingRuleList("Modify Rule Set", ruleSetVersion.getRuleSet().getName(),
                System.currentTimeMillis() - startTime);
          }
        } catch (Exception e) {
          LOGGER.error(e.getMessage(), e);
          errorMessage = CommonUtils.getRuleSetBundleMessage("error_when_save_ruleset");
        }
      }
    } else {
      // just edit rules of rule set
      if (increaseVersion) {
        Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
        ruleSetVersion.setUpdatedOn(currentTime);

        listExecutor.add(new EntityExecutor(QueryExecutor.UPDATE_ENTITY, ruleSetVersion));

        for (RuleVersionDTO dto : selectedRules) {
          listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, new RulesOfRS(dto
              .getRuleVersionId(), ruleSetVersion.getRuleSetVersionId())));
        }
        try {
          SCWebServiceFactory.getScBaseService().executeMultipleQuery(listExecutor);

          actionTrackingRuleList("Edit Rule List Of Rule Set", ruleSetVersion.getRuleSet()
              .getName(), System.currentTimeMillis() - startTime);
        } catch (Exception e) {
          LOGGER.error(e.getMessage(), e);
          errorMessage =
              CommonUtils.getRuleSetBundleMessage("there_error_when_add_rule_to_ruleset");
        }
      } else {
        infoMessage = CommonUtils.getCommonBundleMessage("nothing_to_changed");
      }
    }
    // 2 message is empty, must assign info.
    if ((infoMessage == null || "".equals(infoMessage))
        && (errorMessage == null || "".equals(errorMessage))) {
      infoMessage = CommonUtils.getRuleSetBundleMessage("update_rule_list_successful");
    }
    // clear rule set version in session
    if (sessionRuleSetVersion != null) {
      request.getSession().setAttribute(SCConstants.SESSION_KEY_RULESET_VERSION, null);
    }
    return (alreadyIncreaseVersion || increaseVersion);
  }

  private boolean isCallFromRuleSetDefinition() {
    if (callFromRuleSetDefinition != null && callFromRuleSetDefinition.indexOf("true") > -1) {
      return true;
    }
    return false;
  }

  private boolean isAddingNewRuleSet() {
    if (callFromRuleSetDefinition != null && callFromRuleSetDefinition.indexOf(ADD_VALUE) > -1) {
      return true;
    }
    return false;
  }

  private boolean isCallFromShowRuleList() {
    if ("true".equals(callFromShowRuleList)) {
      return true;
    }
    return false;
  }

  private void actionTrackingRuleList(final String actionName, final String ruleSetName,
      long elapsedTime) {
    try {
      ActionTrackingEntity trackingEntity = new ActionTrackingEntity();
      trackingEntity.setAction(actionName);
      trackingEntity.setParameters("Rule Set Name:" + ruleSetName);
      trackingEntity.setElapsedTime(elapsedTime);

      trackAction(trackingEntity);
    } catch (Exception e) {
      LOGGER.debug(e.getMessage(), e);
    }
  }

  /**
   * Compare 2 versions when fields which cause to increase version are same.
   * 
   * @param oldVersion
   * @param newVersion
   * @return
   */
  private boolean checkChangedNotIncreaseVersion(RuleSetVersion oldVersion,
      RuleSetVersion newVersion) {
    if (!oldVersion.getRuleSet().getName().equalsIgnoreCase(newVersion.getRuleSet().getName())) {
      return true;
    }
    // compare 2 list owners
    boolean different =
        RuleSetComparison.isUserListDifferent(newVersion.getRuleSet().getUserRuleSets(),
            oldVersion.getRuleSet().getUserRuleSets());
    return different;
  }

  /**
   * Check rule version exist or not, because it may be deleted by other users.
   * 
   * @return
   */
  private String checkSelectedRulesExist() {
    StringBuilder builder = new StringBuilder();
    BaseService base = SCWebServiceFactory.getScBaseService();

    for (RuleVersionDTO rv : selectedRules) {
      RuleVersion ruleVersion =
          base.queryByPrimaryKey(RuleVersion.class, rv.getRuleVersionId());
      if (ruleVersion == null) {
        builder.append("[").append(rv.getRuleName()).append(",Version=")
            .append(rv.getVersion()).append("];");
      }
    }
    if (builder.length() > 0) {
      String errorDelete = CommonUtils.getRuleBundleMessage("many_rule_was_deleted");
      // Remove last ';'
      builder.setLength(builder.length() - 1);
      return errorDelete + builder.toString();
    }
    return builder.toString();
  }

  /**
   * Submit page.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void leftToRight(final WRequest request, final Event event) {
    clearErrorMsg();

    availDataView = getAvailDataView();
    selectedDataView = getSelectedDataView();
    int[] moveRows = availDataView.getSelectedRows();
    if (moveRows == null || moveRows.length == 0) {
      errorCheckSelectedRecord = CommonUtils.getCommonBundleMessage("choose_least_one_record");
      return;
    }
    // String errMsg = validate();
    // if (errMsg.length() == 0) {
    try {
      moveLeftToRight(request, availRules, availDataView, selectedRules, selectedDataView,
          moveRows);
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
    // } else {
    // LOGGER.error(errMsg);
    // errorMessage = errMsg;
    // }
  }

  /**
   * Right to left.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void rightToLeft(final WRequest request, final Event event) {
    clearErrorMsg();

    availDataView = getAvailDataView();
    selectedDataView = getSelectedDataView();
    int[] moveRows = selectedDataView.getSelectedRows();
    if (moveRows == null || moveRows.length == 0) {
      errorCheckSelectedRecord = CommonUtils.getCommonBundleMessage("choose_least_one_record");
      return;
    }
    try {
      moveRightToLeft(selectedRules, selectedDataView, availRules, availDataView, moveRows);
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
  }

  /**
   * Reset as first states.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void reset(final WRequest request, final Event event) {
    clearErrorMsg();

    // If edit rule list, must check whether rule set version was deleted.
    if ((!isAddingNewRuleSet() || inCreaseRuleSetVersion)
        && !checkExistRuleSetVersion(request, ruleSetVersion.getRuleSetVersionId())) {
      return;
    }
    try {
      selectedRules = createListRuleVersionDTO(ruleSetVersion.getRuleSetVersionId());
      ruleListOfRuleSetDS = new DefaultDataSet();
      createMatrixDataSetRuleVersionDto(ruleListOfRuleSetDS, selectedRules);
      selectedDataView = getSelectedDataView();
      selectedDataView.getModel().setDataSet(ruleListOfRuleSetDS);

      createAvailableRuleDataView();
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
  }

  /**
   * Moves rows from srcDataView to destDataView.
   * 
   * @param srcList
   *          the src list
   * @param srcDataView
   *          the src data view
   * @param destList
   *          the dest list
   * @param destDataView
   *          the dest data view
   * @param moveRows
   *          the move rows
   * @throws Exception
   *           the exception
   */
  private void moveLeftToRight(WRequest request, final List<RuleDTO> srcList,
      final DataView srcDataView, final List<RuleVersionDTO> destList,
      final DataView destDataView, final int[] moveRows) throws Exception {
    if (moveRows.length == 0) {
      return;
    }

    RowList srcRows = srcDataView.getModel().getRows();
    RowList destRows = destDataView.getModel().getRows();

    if (srcRows.getCount() == 0 || srcRows.getCount() < moveRows.length) {
      return;
    }

    DataSet srcDS = srcDataView.getModel().getDataSet();
    DataSet destDS = destDataView.getModel().getDataSet();

    if (destDS == null) {
      destDS = new DefaultDataSet();
      destDataView.getModel().setDataSet(destDS);
    }

    for (int row : moveRows) {
      Long ruleId = (Long) srcDS.getValue(row, "ruleId");
      RuleVersionDTO bean = getEnityOfLeftControl(request, row, srcList, ruleId);
      // add row to right control
      if (bean != null) {
        int i = 0;
        for (; i < destList.size(); i++) {
          if (destList.get(i).getRuleId().equals(bean.getRuleId())) {
            // replace version
            destList.set(i, bean);
            break;
          }
        }
        if (i == destList.size()) {
          destList.add(bean);
        }
      }
    }

    // srcDS.clear();
    destDS.clear();
    // srcRows.clear();
    destRows.clear();

    // update data for dataviews
    // createMatrixDataSetRuleDto(srcDS, srcList);
    createMatrixDataSetRuleVersionDto(destDS, destList);
    // srcDataView.getModel().setDataSet(srcDS);
    destDataView.getModel().setDataSet(destDS);

    // clear dataview states
    // srcDataView.clearState();
    destDataView.clearState();
  }

  private void moveRightToLeft(final List<RuleVersionDTO> srcList, final DataView srcDataView,
      final List<RuleDTO> destList, final DataView destDataView, final int[] moveRows)
      throws Exception {
    if (moveRows.length == 0) {
      return;
    }

    RowList srcRows = srcDataView.getModel().getRows();
    // RowList destRows = destDataView.getModel().getRows();

    if (srcRows.getCount() == 0 || srcRows.getCount() < moveRows.length) {
      return;
    }

    DataSet srcDS = srcDataView.getModel().getDataSet();
    DataSet destDS = destDataView.getModel().getDataSet();

    if (destDS == null) {
      destDS = new DefaultDataSet();
      destDataView.getModel().setDataSet(destDS);
    }

    for (int row : moveRows) {
      Long ruleVerionId = (Long) srcDS.getValue(row, "ruleVersionId");
      RuleDTO bean = getAndRemoveEntityOfRightControl(srcList, ruleVerionId);
      // setVersionsListForRuleDTO(bean);
      // if (bean != null) {
      // destList.add(bean);
      // }
    }

    srcDS.clear();
    // destDS.clear();
    srcRows.clear();
    // destRows.clear();

    // update data for dataviews
    createMatrixDataSetRuleVersionDto(srcDS, srcList);
    // createMatrixDataSetRuleDto(destDS, destList);

    srcDataView.getModel().setDataSet(srcDS);
    // destDataView.getModel().setDataSet(destDS);

    // clear dataview states
    srcDataView.clearState();
    // destDataView.clearState();

  }

  private void setVersionsListForRuleDTO(RuleDTO ruleDto) {
    RuleService ruleServ = new RuleService(SCWebServiceFactory.getScBaseService());
    List<RuleVersion> ruleVersionList = ruleServ.getAllVersionOfRule(ruleDto.getRuleId());
    // Create rule entity to create list of RuleVersionDTO.
    Rule rule = new Rule();
    rule.setRuleId(ruleDto.getRuleId());
    rule.setName(ruleDto.getRuleName());
    rule.setRuleVersions(ruleVersionList);
    // set rule set list of rule version List is null,
    // to not lazy load when create RuleVersionDTO.
    if (ruleVersionList != null && ruleVersionList.size() > 0) {
      for (RuleVersion ruleVersion : ruleVersionList) {
        ruleVersion.setRuleSetVersionList(null);
      }
    }
    List<RuleVersionDTO> ruleVersionDtoList = createListRuleVersionDTO(rule);
    ruleDto.setRuleVersionList(ruleVersionDtoList);
  }

  /**
   * Generate combobox of rule versions.
   * 
   * @param request
   * @param event
   * @return
   */
  public String generateComboboxVersion(WRequest request, DataViewEvent event) {
    List<RuleVersionDTO> ruleVersionList = (List<RuleVersionDTO>) event.getValue();
    FastStringBuffer html = new FastStringBuffer();
    WriteHTML.Select.selectStartWithAttrs(html);
    WriteHTML.Select.name(html, COMBOBOX_SELECT_NAME + event.getRow());
    WriteHTML.Select.style(html, "width:100px");
    WriteHTML.Select.closeTag(html);
    if (ruleVersionList != null && ruleVersionList.size() > 0) {
      Integer selectedIndex =
          (Integer) getAvailDataView().getModel().getDataSet()
              .getValue(event.getRow(), "selectedIndex");
      for (int i = 0; i < ruleVersionList.size(); i++) {
        String optionText =
            ruleVersionList.get(i).getVersion() + " - " + ruleVersionList.get(i).getPoint();
        boolean selected = false;
        if (selectedIndex != null && selectedIndex == i) {
          selected = true;
        }
        WriteHTML.Select.option(html, optionText, String.valueOf(i), selected, true);
      }
    }
    WriteHTML.Select.selectEnd(html);
    WriteHTML.Table.cellEnd(html);

    return html.toString();
  }

  /**
   * Gets the and remove entity of right control.
   * 
   * @param beans
   *          the beans
   * @param id
   *          the id
   * @return entity of RuleDTO, which contains ruleId and rule name.
   */
  private RuleDTO getAndRemoveEntityOfRightControl(final List<RuleVersionDTO> beans,
      final Long id) {
    if (beans == null || beans.size() == 0 || id == null) {
      return null;
    }
    for (int i = 0; i < beans.size(); i++) {
      if (id.equals(beans.get(i).getRuleVersionId())) {
        RuleDTO dto = new RuleDTO();
        dto.setRuleId(beans.get(i).getRuleId());
        dto.setRuleName(beans.get(i).getRuleName());
        beans.remove(i);
        return dto;
      }
    }
    return null;
  }

  /**
   * Get RuleVersionDTO selected from users to add it to right control. And
   * remove it from dtoList.
   * 
   * @param request
   * @param selectedRow
   * @param dtoList
   * @param ruleId
   * @return
   */
  private RuleVersionDTO getEnityOfLeftControl(WRequest request, int selectedRow,
      List<RuleDTO> dtoList, Long ruleId) {
    RuleVersionDTO ruleVersion = null;
    if (dtoList != null && dtoList.size() > 0) {
      // Get index from dataset.
      String indexStr = request.getParameter(COMBOBOX_SELECT_NAME + selectedRow);
      Integer indexCombobox = null;
      if (indexStr != null) {
        indexCombobox = Integer.parseInt(indexStr);
        // Store index to dataset.
        getAvailDataView().getModel().getDataSet()
            .setValue(selectedRow, "selectedIndex", indexCombobox);
      } else {
        indexCombobox =
            (Integer) getAvailDataView().getModel().getDataSet()
                .getValue(selectedRow, "selectedIndex");
      }
      for (int i = 0; i < dtoList.size(); i++) {
        if (ruleId.equals(dtoList.get(i).getRuleId())) {
          ruleVersion = dtoList.get(i).getRuleVersionList().get(indexCombobox);
          break;
        }
      }
    }
    return ruleVersion;
  }

  /**
   * Gets the available rule ds.
   * 
   * @return the available rule ds
   */
  public DataSet getAvailableRuleDS() {
    return availableRuleDS;
  }

  /**
   * Gets the rule list of rule set ds.
   * 
   * @return the rule list of rule set ds
   */
  public DataSet getRuleListOfRuleSetDS() {
    return ruleListOfRuleSetDS;
  }

  /**
   * @return the callFromRuleSetDefinition
   */
  public String getCallFromRuleSetDefinition() {
    return callFromRuleSetDefinition;
  }

  /**
   * @param callFromRuleSetDefinition
   *          the callFromRuleSetDefinition to set
   */
  public void setCallFromRuleSetDefinition(String callFromRuleSetDefinition) {
    this.callFromRuleSetDefinition = callFromRuleSetDefinition;
  }

  /**
   * @return the callFromShowRuleList
   */
  public String getCallFromShowRuleList() {
    return callFromShowRuleList;
  }

  /**
   * @param callFromShowRuleList
   *          the callFromShowRuleList to set
   */
  public void setCallFromShowRuleList(String callFromShowRuleList) {
    this.callFromShowRuleList = callFromShowRuleList;
  }

}
