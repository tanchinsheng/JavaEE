/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 2:37:08 PM - nhatvn - Initialize version
/********************************************************************************/
package st.liotrox.template.element.control;

import st.liotrox.WRequest;
import st.liotrox.page.WPage;
import st.liotrox.template.DynamicElement;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.web.html.HtmlCalendar;
import st.liotrox.web.html.JavaScriptAPI;
import st.liotrox.web.html.WriteHTML;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class DateControlUtils {

  /**
   * The parameter of validation javascript function.
   */
  private static final String VALIDATION_PARAMETER = "validationGroup";

  public static void writeDateControl(WPage page, WRequest request, FastStringBuffer fs,
      String controlName, String controlValue, String classCss, String format, String label) {
    // Write content of to date text box.
    WriteHTML.Input.inputStartWithAttrs(fs);
    WriteHTML.Input.typeText(fs);
    WriteHTML.Input.name(fs, controlName);
    WriteHTML.Input.value(fs, controlValue);
    if (classCss != null && classCss.length() > 0) {
      WriteHTML.Input.attribute(fs, "class", classCss);
    }
    //If netscape browser, we decrease size of text box
    if(request.is_NS_Browser()){
      WriteHTML.Input.attribute(fs, "size", 10);
    }
    WriteHTML.Input.closeTag(fs);
    WriteHTML.Input.inputEnd(fs);
    CustomElement.writeNewLine(fs);
    // Conent of to calendar
    writeCalendar(page, request, fs, controlName, format);
    CustomElement.writeNewLine(fs);
    // Write span to display error icon
    writeErrorIcon(request, fs, controlName);
    CustomElement.writeNewLine(fs);

    // write javascript validate date
    CustomElement.writeStartScript(fs);
    writeValidationJavaScript(page, request, fs, controlName, format, label);
    CustomElement.writeEndScript(fs);
  }

  /**
   * Get the function call with the function name parameter.
   * 
   * @param functionName
   *          name of function which is called.
   * @return
   */
  private static String getValidateCode(String functionName) {
    StringBuilder builder = new StringBuilder();
    String ifClause = "if (!LX.Ajax) ";
    builder.append(ifClause).append(functionName).append("(").append(VALIDATION_PARAMETER)
        .append("); \n");
    return builder.toString();
  }

  /**
   * Write the content of calendar.
   * 
   * @param request
   * @param fs
   * @param controlName
   *          the name of text box which is showed calendar.
   */
  private static void writeCalendar(WPage page, WRequest request, FastStringBuffer fs,
      String controlName, String format) {

    String localFormat =
        request.getI18NMessage(DynamicElement.BUNDLE_NAME, "calendar_format_" + format, null);

    FastStringBuffer alterText =
        new FastStringBuffer(request.getI18NMessage(DynamicElement.BUNDLE_NAME,
            "control_TextBox_openCalendarTooltip", new Object[]{localFormat }));

    HtmlCalendar.writeCalendar(request, fs, null, controlName, page, format,
        alterText.toString(), null);
  }

  /**
   * Write the javascript function to validate the date of textbox.
   * 
   * @param request
   * @param fsb
   * @param controlName
   *          name of textbox
   * @param format
   *          format of date. Ex: MM-dd-yyyy, MM/dd/yyyy, ...
   * @param label
   *          label text
   */
  private static void writeValidationJavaScript(WPage page, WRequest request,
      FastStringBuffer fsb, String controlName, String format, String label) {
    String localFormat =
        request.getI18NMessage(DynamicElement.BUNDLE_NAME, "calendar_format_" + format, null);

    String validDateStr =
        request.getI18NMessage(DynamicElement.BUNDLE_NAME,
            "control_TextBox_invalidDateFormatMsg", new Object[]{label, localFormat });
    String functionName = controlName + "Validate";
    fsb.append("\n function ").append(functionName).append("(").append(VALIDATION_PARAMETER)
        .append(") { \n");
    JavaScriptAPI.writeValidateInputDate(fsb, controlName, null, null, format, false, null,
        true, validDateStr, null, null, null, null, null, true, null);
    fsb.append("} \n");

    // Add validate function call in doLiotroValidation()
    page.addJavascriptValidateCode(getValidateCode(functionName));

  }

  /**
   * Write span to display error icon when validate date.
   * 
   * @param request
   * @param fsb
   * @param controlName
   *          name of text box
   */
  private static void writeErrorIcon(WRequest request, FastStringBuffer fsb, String controlName) {
    fsb.append("<SPAN id=\"").append(controlName).append("span\" STYLE=\"")
        .append(request.is_NS_Browser() ? "position:relative; " : "")
        .append("visibility:hidden;").append("\"><IMG BORDER=0 ID=\"").append(controlName)
        .append("img\" SRC=\"").append(request.getImagePath("icons/icon_alert.gif"))
        .append("\" ></SPAN>");
  }
}
