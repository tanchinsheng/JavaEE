/**
 * 
 */
package st.liotrox.template.element.control;

import st.liotrox.WRequest;
import st.liotrox.template.ControlElement;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.web.html.WriteHTML;

/**
 * @author nhatvn
 */
public abstract class CustomElement extends ControlElement {
  protected static final String ATTRIBUTE_LABEL = "label";
  protected static final String ATTRIBUTE_LABEL_LENGTH = "labelLength";
  
  protected static final String ATTRIBUTE_CLASS = "class";

  /**
   * Get the label content of element.
   * 
   * @param request
   */
  protected String getLabel(WRequest request) {
    String label = resolveAttributeAsString(request, ATTRIBUTE_LABEL);
    return label;
  }

  /**
   * Get label length attribute.
   * 
   * @param request
   */
  protected int getLabelLength(WRequest request) {
    String label = resolveAttributeAsString(request, ATTRIBUTE_LABEL_LENGTH);
    int length = 0;
    try {
      length = Integer.parseInt(label);
    } catch (Exception e) {
      length = 100;
    }
    return length;
  }
  /**
   * Get name of element.
   * 
   * @param request
   * @return
   */
  protected String getElementName(WRequest request) {
    String name = resolveAttributeAsString(request, ATTRIBUTE_NAME);
    return name;
  }

  /**
   * Get class attribute of element.
   * 
   * @param request
   * @return
   */
  protected String getClassCss(WRequest request) {
    String name = resolveAttributeAsString(request, ATTRIBUTE_CLASS);
    return name;
  }

  public static void writeLabel(FastStringBuffer fs, String label) {
    // write label.
    if (label != null) {
      fs.append(label);
//      int numberWhiteSpace = labelLength - label.length();
//      if (numberWhiteSpace > 0) {
//        for (int i = 0; i < numberWhiteSpace; i++) {
//          writeWhiteSpace(fs);
//        }
//      } else {
//        writeWhiteSpace(fs);
//      }
    }
  }

  public static void writeRadio(FastStringBuffer fs, String radioName, String value,
      String checkedValue, String mouseDownEvent) {
    // Write radio button.
    WriteHTML.Input.inputStartWithAttrs(fs);
    WriteHTML.Input.typeRadio(fs);
    WriteHTML.Input.name(fs, radioName);
    WriteHTML.Input.value(fs, value);
    if (value != null && value.equals(checkedValue)) {
      WriteHTML.Input.checked(fs);
    }
    if (mouseDownEvent != null && mouseDownEvent.length() > 0) {
      WriteHTML.Input.onMouseDown(fs, mouseDownEvent);
    }
    WriteHTML.Input.closeTag(fs);
    WriteHTML.Input.inputEnd(fs);

  }

  public static void writeTextBox(FastStringBuffer fs, String textboxName, String value) {
    // write text box
    WriteHTML.Input.inputStartWithAttrs(fs);
    WriteHTML.Input.typeText(fs);
    WriteHTML.Input.name(fs, textboxName);
    WriteHTML.Input.value(fs, value);
    // If netscape browser, we decrease size of text box
    if (WRequest.getCurrentInstance().is_NS_Browser()) {
      WriteHTML.Input.attribute(fs, "size", 10);
    }
    WriteHTML.Input.closeTag(fs);
    WriteHTML.Input.inputEnd(fs);
  }

  public static void writeTextBox(FastStringBuffer fs, String textboxName, String value, int maxLength) {
    // write text box
    WriteHTML.Input.inputStartWithAttrs(fs);
    WriteHTML.Input.typeText(fs);
    WriteHTML.Input.name(fs, textboxName);
    WriteHTML.Input.value(fs, value);
    // If netscape browser, we decrease size of text box
    if (WRequest.getCurrentInstance().is_NS_Browser()) {
      WriteHTML.Input.attribute(fs, "size", 10);
    }
    WriteHTML.Input.maxSize(fs, maxLength);
    WriteHTML.Input.closeTag(fs);
    WriteHTML.Input.inputEnd(fs);
  }

  public static void writeTableStartWithLabelLength(FastStringBuffer fs, int labelLength) {
    WriteHTML.Table.tableStart(fs);
    WriteHTML.Table.rowStart(fs);
    if (labelLength > 0) {
      WriteHTML.Table.cellStartWithAttrs(fs);
      WriteHTML.Table.attribute(fs, "width", labelLength);
      WriteHTML.Table.closeTag(fs);
    } else {
      WriteHTML.Table.cellStart(fs);
    }
  }
  public static void writeTableClose(FastStringBuffer fs){
    //End row
    WriteHTML.Table.rowEnd(fs);
    WriteHTML.Table.tableEnd(fs);
  }
  /**
   * Write new line character.
   * 
   * @param fs
   */
  public static void writeNewLine(FastStringBuffer fs) {
    fs.append("\n");
  }

  /**
   * Write white space between HTML elements.
   * 
   * @param fs
   */
  public static void writeWhiteSpace(FastStringBuffer fs) {
    fs.append("&nbsp;");
  }

  /**
   * Write start of script tag.
   * 
   * @param fs
   */
  public static void writeStartScript(FastStringBuffer fs) {
    fs.append("<script type='text/javascript'>");
  }

  /**
   * Write end of script tag.
   * 
   * @param fs
   */
  public static void writeEndScript(FastStringBuffer fs) {
    fs.append("</script>");
  }
}
