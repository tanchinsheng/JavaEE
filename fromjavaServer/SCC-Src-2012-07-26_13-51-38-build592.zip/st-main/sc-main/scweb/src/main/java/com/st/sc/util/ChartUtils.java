/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - Nov 15, 2011 1:34:56 PM - duytv - Initialize version
/******************************************************************************/
package com.st.sc.util;

import java.awt.Color;
import java.util.Random;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.data.category.CategoryDataset;

/**
 * The Class ChartUtils.
 */
public final class ChartUtils {

  private static final Color BACKGROUND_COLOR = Color.decode("#F0F0F0");
  /** The Constant COLORS. */
  private static final Color[] COLORS = new Color[]{new Color(255, 128, 128),
      new Color(176, 176, 0), new Color(0, 185, 185), new Color(255, 128, 192),
      new Color(0, 255, 0), new Color(255, 0, 0), new Color(128, 128, 192),
      new Color(128, 64, 64), new Color(255, 128, 64), new Color(0, 64, 128),
      new Color(128, 128, 255), new Color(128, 0, 64), new Color(255, 0, 128),
      new Color(255, 128, 0), new Color(0, 128, 64), new Color(0, 0, 255),
      new Color(0, 0, 160), new Color(128, 0, 128), new Color(128, 0, 255),
      new Color(64, 0, 0), new Color(128, 64, 0), new Color(0, 64, 0), new Color(0, 64, 64),
      new Color(0, 0, 128), new Color(64, 0, 64), new Color(64, 0, 128),
      new Color(128, 128, 0), new Color(128, 128, 128), new Color(64, 128, 128),
      new Color(192, 192, 192), new Color(64, 0, 64) };

  /**
   * Gets color from index.
   * 
   * @param index
   * @return the color
   */
  public static Color getColor(final int index) {
    if (index < COLORS.length) {
      return COLORS[index];
    } else {
      return new Color(new Random().nextInt(256), new Random().nextInt(256),
          new Random().nextInt(256));
    }
  }

  /**
   * Instantiates a new chart utils.
   */
  private ChartUtils() {
  }

  /**
   * Creates clustered bar chart.
   * 
   * @param dataset
   *          the dataset
   * @param chartTitle
   *          the chart title
   * @return the jfree chart
   */
  public static JFreeChart createClusteredBarChart(final CategoryDataset dataset,
      final String chartTitle, final String yAxisTitle, final Color[] colors) {

    // create the chart...
    final JFreeChart chart = ChartFactory.createBarChart(chartTitle, "", // domain
                                                                         // axis
                                                                         // label
        yAxisTitle, // range axis label
        dataset, // data
        PlotOrientation.VERTICAL, // orientation
        false, // include legend
        true, // tooltips?
        false // URLs?
        );

    final CategoryPlot plot = (CategoryPlot) chart.getPlot();
    // set the range axis to display integers only.
    final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
    // rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    // set max Y axis = max value * 0.1
    rangeAxis.setUpperMargin(0.1f);

    final CategoryAxis domainAxis = plot.getDomainAxis();
    final int numCategory = dataset.getColumnCount();
    final int numSeries = dataset.getRowCount();
    setMarginForDomainAxis(domainAxis, numCategory * numSeries);

    BarRenderer br = (BarRenderer) plot.getRenderer();
    br.setItemMargin(0.0);
    br.setMaximumBarWidth(0.25);
    // to display value on top of column:
    // + must implement CategoryItemLabelGenerator.
    // + setSeriesItemLabelsVisible(series,true).
    CustomLabelGenerator customGenerator = new CustomLabelGenerator();

    for (int i = 0; i < colors.length; i++) {
      // set color bar chart
      br.setSeriesPaint(i, colors[i]);
      // display value on top of column
      br.setSeriesItemLabelGenerator(i, customGenerator);
      br.setSeriesItemLabelsVisible(i, true);
    }
    plot.setBackgroundPaint(BACKGROUND_COLOR);
    return chart;
  }

  private static class CustomLabelGenerator implements CategoryItemLabelGenerator {
    /**
     * Display value on the top of bar chart. {@inheritDoc}
     * 
     * @see org.jfree.chart.labels.CategoryItemLabelGenerator#generateLabel(org.jfree.data.category.CategoryDataset,
     *      int, int)
     */
    public String generateLabel(CategoryDataset arg0, int arg1, int arg2) {
      return arg0.getValue(arg1, arg2) + "";
    }

    public String generateRowLabel(CategoryDataset arg0, int arg1) {
      return null;
    }

    public String generateColumnLabel(CategoryDataset arg0, int arg1) {
      return null;
    }
  }

  /**
   * Create stacked bar chart.
   * 
   * @param dataset
   *          the dataset
   * @param chartTitle
   *          the chart title
   * @return the j free chart
   */
  public static JFreeChart createStackedBarChart(final CategoryDataset dataset,
      final String chartTitle, final String yAxisTitle, final Color[] colors, boolean is100Stack) {

    final JFreeChart chart = ChartFactory.createStackedBarChart(chartTitle, "", // domain
                                                                                // axis
                                                                                // label
        yAxisTitle, // range axis label
        dataset, // data
        PlotOrientation.VERTICAL, // the plot orientation
        false, // legend
        true, // tooltips
        false // urls
        );

    final CategoryPlot plot = (CategoryPlot) chart.getPlot();
    final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
    rangeAxis.setUpperMargin(0.05);

    final CategoryAxis domainAxis = plot.getDomainAxis();
    int numCategory = dataset.getColumnCount();
    setMarginForDomainAxis(domainAxis, numCategory);

    final StackedBarRenderer renderer = (StackedBarRenderer) plot.getRenderer();
    if (is100Stack) {
      // draw 100 stack chart
      renderer.setRenderAsPercentages(true);
    }
    renderer.setMaximumBarWidth(0.25);
    // set color bar chart
    for (int i = 0; i < colors.length; i++) {
      renderer.setSeriesPaint(i, colors[i]);
    }
    plot.setBackgroundPaint(BACKGROUND_COLOR);
    return chart;
  }

  public static JFreeChart createLineChart(final CategoryDataset dataset,
      final String chartTitle, final String yAxisTitle, final Color[] colors) {

    // create the chart...
    final JFreeChart chart = ChartFactory.createLineChart(chartTitle, // chart
                                                                      // title
        "", // x axis label
        yAxisTitle, // y axis label
        dataset, // data
        PlotOrientation.VERTICAL, // orientation
        false, // include legend
        true, // tooltips
        false // urls
        );

    // NOW DO SOME OPTIONAL CUSTOMISATION OF THE CHART...
    // final StandardLegend legend = (StandardLegend) chart.getLegend();
    // legend.setDisplaySeriesShapes(true);
    // legend.setShapeScaleX(1.5);
    // legend.setShapeScaleY(1.5);
    // legend.setDisplaySeriesLines(true);
    final CategoryPlot plot = (CategoryPlot) chart.getPlot();

    final CategoryAxis domainAxis = plot.getDomainAxis();
    int numCategory = dataset.getColumnCount();
    setMarginForDomainAxis(domainAxis, numCategory);

    // customise the range axis...
    final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
    rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    rangeAxis.setAutoRangeIncludesZero(false);

    // set color bar chart
    for (int i = 0; i < colors.length; i++) {
      plot.getRenderer().setSeriesPaint(i, colors[i]);
    }
    plot.setBackgroundPaint(BACKGROUND_COLOR);

    // customise the renderer...
    // final LineAndShapeRenderer renderer = (LineAndShapeRenderer)
    // plot.getRenderer();
    // renderer.setSeriesStroke(0, new BasicStroke(2.0f,
    // BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
    // new float[] { 10.0f, 6.0f }, 0.0f));
    // renderer.setSeriesStroke(1, new BasicStroke(2.0f,
    // BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
    // new float[] { 6.0f, 6.0f }, 0.0f));
    // renderer.setSeriesStroke(2, new BasicStroke(2.0f,
    // BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1.0f,
    // new float[] { 2.0f, 6.0f }, 0.0f));
    // OPTIONAL CUSTOMISATION COMPLETED.

    return chart;
  }

  private static void setMarginForDomainAxis(final CategoryAxis domainAxis,
      final int numCategory) {
    if (numCategory == 1) {
      domainAxis.setLowerMargin(0.3f);
      domainAxis.setUpperMargin(0.3f);
    } else {
      int ratio = (numCategory - 1) / 10 + 1;
      domainAxis.setLowerMargin(0.05f / ratio);
      domainAxis.setUpperMargin(0.05f / ratio);
    }
    //set number line label of category
    domainAxis.setMaximumCategoryLabelLines(3);
  }

}
