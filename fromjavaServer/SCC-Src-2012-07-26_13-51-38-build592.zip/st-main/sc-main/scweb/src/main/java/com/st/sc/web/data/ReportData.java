/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 20, 2012 10:31:19 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.st.sc.common.SCConstants;
import com.st.sc.webapp.reports.BaseReportSetting;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class ReportData implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = -3871512849861419319L;
  private String[] columnLabels;
  private int[] columnLabelIndex;
  private String[] rowLabels;
  private int[] rowLabelIndex;

  private Object[][] tableData;

  /*---Data used for Draw Chart---*/
  private BaseReportSetting setting;
  
  public ReportData() {

  }

  public ReportData(final String[] columnLabels, final int[] columnLabelIndex,
      final String[] rowLabels, final int[] rowLabelIndex, final Object[][] data) {
    this.columnLabels = columnLabels;
    this.rowLabels = rowLabels;
    this.columnLabelIndex = columnLabelIndex;
    this.rowLabelIndex = rowLabelIndex;

    tableData = data;
  }

  public int countNumberColumn() {
    if (!haveColumnGroup()) {
      return columnLabels.length;
    }
    int sum = countElement(columnLabels, columnLabelIndex);
    return sum;
  }

  public int countNumberRow() {
    if (!haveRowGroup()) {
      return rowLabels.length;
    }
    int sum = countElement(rowLabels, rowLabelIndex);
    return sum;
  }

  private int countElement(final String[] labels, final int[] indexs) {
    int sum = 0;
    if (labels != null && indexs != null) {
      for (int i = 0; i < indexs.length - 1; i++) {
        sum += indexs[i + 1] - indexs[i] - 1;
      }
      int lastIndex = indexs[indexs.length - 1];
      sum += labels.length - lastIndex - 1;
    }
    return sum;
  }

  public String[] buildCombineRowLabels() {
    String[] combineNames = null;
    if (!haveRowGroup()) {
      combineNames = getLabelsWithNullValue(rowLabels);
    } else {
      combineNames = buildCombineLabels(rowLabels, rowLabelIndex);
    }
    return combineNames;
  }

  public String[] buildCombineColumnLabels() {
    String[] combineNames = null;
    if (!haveColumnGroup()) {
      combineNames = getLabelsWithNullValue(columnLabels);
    } else {
      combineNames = buildCombineLabels(columnLabels, columnLabelIndex);
    }
    return combineNames;
  }

  private String[] buildCombineLabels(final String[] labels, final int[] labelIndexs) {
    List<String> series = new ArrayList<String>();
    int numberIndex = labelIndexs.length;
    int startIndex = 0;
    int endIndex = 0;
    String groupName = "";
    for (int i = 0; i < numberIndex; i++) {
      startIndex = labelIndexs[i];
      if (i < numberIndex - 1) {
        endIndex = labelIndexs[i + 1];
      } else {
        endIndex = labels.length;
      }
      groupName = labels[startIndex];
      if (groupName == null) {
        groupName = SCConstants.NA_VALUE;
      }
      for (int j = startIndex + 1; j < endIndex; j++) {
        if (labels[j] == null) {
          series.add(groupName + ";" + SCConstants.NA_VALUE);
        } else {
          series.add(groupName + ";" + labels[j]);
        }
      }
    }
    return series.toArray(new String[0]);
  }

  private String[] getLabelsWithNullValue(String[] values) {
    if (values == null) {
      return null;
    }
    String[] newValues = new String[values.length];
    for (int i = 0; i < values.length; i++) {
      if (values[i] == null) {
        newValues[i] = SCConstants.NA_VALUE;
      } else {
        newValues[i] = values[i];
      }
    }
    return newValues;
  }

  public boolean haveColumnGroup() {
    if (columnLabels != null && columnLabelIndex != null) {
      if (columnLabels.length == columnLabelIndex.length) {
        return false;
      }
    }
    return true;
  }

  public boolean haveRowGroup() {
    if (rowLabels != null && rowLabelIndex != null) {
      if (rowLabels.length == rowLabelIndex.length) {
        return false;
      }
    }
    return true;
  }

  public static String[] parseMapToArray(Map<String, List<String>> mapGroup, int[] indexs) {
    int i = 0;
    ArrayList<String> arrays = new ArrayList<String>();
    List<String> ls = null;
    int startIndex = i;
    for (String group : mapGroup.keySet()) {
      indexs[i++] = startIndex++;
      // add name of group
      arrays.add(group);
      ls = mapGroup.get(group);
      if (ls != null) {
        // add each element of group
        arrays.addAll(ls);
        startIndex += ls.size();
      }
    }
    return arrays.toArray(new String[0]);
  }

  public Integer[] getColumnValues(int columnIndex) {
    if (columnIndex < 0) {
      return null;
    }
    if (tableData != null) {
      int numberFirstColum = 1;
      if (haveRowGroup()) {
        numberFirstColum = 2;
      }
      final int colIdx = columnIndex + numberFirstColum;
      Integer[] values = new Integer[tableData.length];
      for (int i = 0; i < values.length; i++) {
        values[i] = (Integer) tableData[i][colIdx];
      }
      return values;
    } else {
      return null;
    }
  }

  public void updateColumValues(int columnIndex, Object[] values) {
    if (tableData != null) {
      int numberFirstColum = 1;
      if (haveRowGroup()) {
        numberFirstColum = 2;
      }
      final int colIdx = columnIndex + numberFirstColum;
      for (int i = 0; i < tableData.length; i++) {
        tableData[i][colIdx] = values[i];
      }
    }
  }

  /**
   * @return the tableData
   */
  public Object[][] getTableData() {
    return tableData;
  }

  /**
   * @param tableData
   *          the tableData to set
   */
  public void setTableData(Object[][] tableData) {
    this.tableData = tableData;
  }

  /**
   * @return the columnLabels
   */
  public String[] getColumnLabels() {
    return columnLabels;
  }

  /**
   * @param columnLabels
   *          the columnLabels to set
   */
  public void setColumnLabels(String[] columnLabels) {
    this.columnLabels = columnLabels;
  }

  /**
   * @return the columnLabelIndex
   */
  public int[] getColumnLabelIndex() {
    return columnLabelIndex;
  }

  /**
   * @param columnLabelIndex
   *          the columnLabelIndex to set
   */
  public void setColumnLabelIndex(int[] columnLabelIndex) {
    this.columnLabelIndex = columnLabelIndex;
  }

  /**
   * @return the rowLabels
   */
  public String[] getRowLabels() {
    return rowLabels;
  }

  /**
   * @param rowLabels
   *          the rowLabels to set
   */
  public void setRowLabels(String[] rowLabels) {
    this.rowLabels = rowLabels;
  }

  /**
   * @return the rowLabelIndex
   */
  public int[] getRowLabelIndex() {
    return rowLabelIndex;
  }

  /**
   * @param rowLabelIndex
   *          the rowLabelIndex to set
   */
  public void setRowLabelIndex(int[] rowLabelIndex) {
    this.rowLabelIndex = rowLabelIndex;
  }

  /**
   * @return the setting
   */
  public BaseReportSetting getSetting() {
    return setting;
  }

  /**
   * @param setting the setting to set
   */
  public void setSetting(BaseReportSetting setting) {
    this.setting = setting;
  }
      
}
