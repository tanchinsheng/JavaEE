/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 12, 2012 11:30:36 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.ruleandruleset;

import static org.apache.commons.io.FileUtils.deleteDirectory;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.config.ConfigLoader;
import com.st.common.exception.SccException;
import com.st.common.fileaccess.FileAccessFactory;
import com.st.common.fileaccess.SccFileAccess;
import com.st.common.web.config.ConfigReloader;
import com.st.common.web.util.ServletUtils;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.CompliancyResult;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleVersion;
import com.st.sc.rulemanager.RuleService;
import com.st.sc.rulemanager.rule.validation.FileValidation;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.webapp.BaseAction;
import com.st.scc.common.utils.ConvertUtils;
import com.st.scc.common.utils.FileUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class RuleSetValidationResultAction extends BaseAction {

  private static final Logger LOGGER = LoggerFactory
      .getLogger(RuleSetValidationResultAction.class);

  public void doShow(WRequest request, Event event) {
    String stdfPathFile = ServletUtils.decodeUrlParam(request.getParameter("stdfFilePath"));
    RuleSetVersion requestRSV =
        (RuleSetVersion) request.getSession().getAttribute(
            SCConstants.KEY_RULESET_VALIDATION_VERSION);
    if (requestRSV == null) {
      errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");
      return;
    }
    // check again rule set version whether has been deleted.
    RuleService ruleService = new RuleService(SCWebServiceFactory.getScBaseService());
    final RuleSetVersion ruleSetVersion = ruleService.loadRuleVersions(requestRSV);
    List<RuleVersion> ruleVersions = null;
    if (ruleSetVersion != null) {
      ruleVersions = ruleSetVersion.getRuleVersions();
    } else {
      errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");
      return;
    }
    if (ruleVersions == null || ruleVersions.size() == 0) {
      errorMessage = CommonUtils.getRuleSetBundleMessage("validate_ruleset_must_have_rule");
      return;
    }

    String stdfType = ServletUtils.decodeUrlParam(request.getParameter("type"));
    String filePath = stdfPathFile;
    FileTypeEnum fileType = FileTypeEnum.fromValue(stdfType);
    if (fileType != null && fileType != FileTypeEnum.NFS) {
      String stdfHost = ServletUtils.decodeUrlParam(request.getParameter("host"));
      String stdfPort = ServletUtils.decodeUrlParam(request.getParameter("port"));
      String stdfUser = ServletUtils.decodeUrlParam(request.getParameter("username"));
      String stdfPass = ServletUtils.decodeUrlParam(request.getParameter("password"));
      FileInfo fileInfo = new FileInfo(stdfPathFile, "/", 0);
      fileInfo.setFileType(fileType);
      fileInfo.setHost(stdfHost);
      fileInfo.setPassWord(stdfPass);
      fileInfo.setPort(ConvertUtils.getInt(stdfPort));
      fileInfo.setUserName(stdfUser);
      SccFileAccess fileAccess = FileAccessFactory.create(fileInfo);
      if (fileAccess != null) {
        File dlFile =
            fileAccess.download(SCConstants.ROOT_FULL_DETAIL + File.separator
                + FileUtils.getFileName(stdfPathFile));
        if (dlFile != null) {
          filePath = dlFile.getAbsolutePath();
        }
      }
    }

    String sessionId = request.getSession().getId();
    validateRuleSet(filePath, sessionId, requestRSV, ruleVersions);
  }

  private void validateRuleSet(String stdfPathFile, String sessionId,
      RuleSetVersion ruleSetVersion, List<RuleVersion> ruleVersions) {
    final File file = new File(stdfPathFile);
    final FileValidation fileValidation = new FileValidation();
    fileValidation.setSessionId(sessionId);
    fileValidation.setFile(file);
    final Number limitFailedNum =
        (Number) ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getValue(
            ConfigLoader.LIMIT_FAIL_VALUES, ConfigLoader.DEFAULT_LIMIT_FAIL_VALUES);
    if (limitFailedNum != null) {
      fileValidation.setLimitFailValue(Integer.valueOf(limitFailedNum.intValue()));
    }

    String ruleSetName = ruleSetVersion.getRuleSet().getName();
    Integer rsVersion = ruleSetVersion.getVersion();
    try {
      fileValidation.validate(SCConstants.ROOT_FULL_DETAIL, ruleSetName, rsVersion,
          ruleVersions);
    } catch (final SccException e) {
      errorMessage = "Fail to validate file, error detail:" + e.getMessage();
      LOGGER.error(e.getMessage(), e);
      return;
    }

    final RuleValidationDetail[] details = fileValidation.getDetails();
    final CompliancyResult result = fileValidation.getResult();
    final String fileUUID = fileValidation.getFileUUID();

    if (details != null) {
      WRequest
          .getCurrentInstance()
          .getSession()
          .setAttribute(SCConstants.KEY_RULESET_VALIDATION_DETAIL + result.getFileId(),
              details);
    }
    if (result != null) {
      StringBuilder url =
          new StringBuilder(SCConstants.getContextPath() +
              "/app/path/pages/sc/reports/fullDetailReportRuleSetValidation.generateFullDetailReportFromValidateRuleSet?");
      // fileId is null, don't pass fileId to URL.
      url.append("fileName=").append(ServletUtils.encodeUrlParam(result.getFileName()));
      url.append("&finalCompliancyScore=").append(
          ServletUtils.encodeUrlParam(CommonUtils.roundDouble(result.getCompliancyScore())));
      url.append("&checkingTime=").append(
          ServletUtils.encodeUrlParam(result.getCheckingTime()));
      url.append("&involvedRuleSet=").append(ServletUtils.encodeUrlParam(ruleSetName));
      url.append("&version=").append(rsVersion);
      // Root folder of STDF to test.
      url.append("&specifiedFailedValuesFolder=").append(
          ServletUtils.encodeUrlParam(SCConstants.ROOT_FULL_DETAIL));
      // store sessionId
      url.append("&sessionId=").append(sessionId);
      // keep file UUID
      url.append("&fileuuid=").append(fileUUID);

      WRequest.getCurrentInstance().redirectTo(url.toString());
    } else {
      errorMessage = "Finished validation, but there is no result.";
    }
  }

  public static void deleteTempFailedValuesFolder() {
    File f = new File(SCConstants.ROOT_FULL_DETAIL);
    try {
      deleteDirectory(f);
    } catch (IOException e) {
      LOGGER.error(e.getMessage(), e);
    }
  }

  public static void deleteTempFailedValuesFolder(String sessionId) {
    File f = new File(SCConstants.ROOT_FULL_DETAIL + File.separator + sessionId);
    try {
      deleteDirectory(f);
    } catch (IOException e) {
      LOGGER.error(e.getMessage(), e);
    }
  }

}
