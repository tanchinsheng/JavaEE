/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 20, 2012 5:17:07 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp;

import java.net.MalformedURLException;
import java.net.URL;

import st.liotrox.Event;
import st.liotrox.WRequest;

import com.st.common.config.ConfigLoader;
import com.st.common.web.config.ConfigReloader;
import com.st.sc.util.SCWebServiceFactory;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class NavigatorAction extends BaseAction {

  /**
   * Handle when user click "User management" link.
   * 
   * @param request
   * @param event
   */
  public void doShowUserManagement(WRequest request, Event event) {
    final String umUrl =
        (String) ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getValue(
            ConfigLoader.UM_URL);
    if (umUrl != null) {
      if (checkUrlFormat(umUrl)) {
        request.redirectTo(umUrl);
      } else {
        errorMessage = "Format of UM URL is not correct. The URL = " + umUrl;
      }
    } else {
      errorMessage = "UM URL is not found.";
    }
  }

  private boolean checkUrlFormat(String url) {
    try {
      URL u = new URL(url);
    } catch (MalformedURLException e) {
      return false;
    }
    return true;
  }

}
