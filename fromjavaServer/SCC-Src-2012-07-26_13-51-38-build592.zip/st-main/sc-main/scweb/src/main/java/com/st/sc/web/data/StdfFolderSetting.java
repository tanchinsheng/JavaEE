/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 26, 2011 10:14:53 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.st.common.config.ConfigLoader;
import com.st.persistence.entity.SettingEntity;
import com.st.sc.common.CommonUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class StdfFolderSetting {
  
  public static final String STDF_TYPE = "STDF";
  public static final String STDF_ARCHIVE_TYPE = "STDF_ARCHIVE";
  public static final String STDF_ERROR_TYPE = "STDF_ERROR";
  public static final String FAIL_VALUES_FOLDER_TYPE = "FAIL_VALUES";

  private String folderPath;
  private Integer folderDepth;
  private String folderType;
  private String fileType;
  private String host;
  private String username;
  private String password;
  private Integer port;
  private Integer expiredTimePurge;


  /**
   * Old encrypted password in DB, used to compare new password.
   */
  private String oldEncryptedPassword;
  
  /**
   * Initialize value of fields.
   * 
   * @param mapValues
   *          contains setting values.
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   */
  public void initValues(Map<String, Object> mapValues, String stdfType) {
    if (mapValues == null) {
      return;
    }
    if (STDF_TYPE.equals(stdfType)) {
      initStdfValues(mapValues);
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      initStdfArchiveValues(mapValues);
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      initStdfErrorValues(mapValues);
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      initFailValuesFolder(mapValues);
    }
  }

  private void initStdfValues(Map<String, Object> mapValues) {
    folderPath = (String) mapValues.get(ConfigLoader.STDF_FOLDER);
    folderType = (String) mapValues.get(ConfigLoader.STDF_FOLDER_TYPE);
    fileType = (String) mapValues.get(ConfigLoader.STDF_FILE_TYPE);
    if (fileType == null) {
      fileType = ".Z;.std*";
    }
    host = (String) mapValues.get(ConfigLoader.STDF_FILE_SERVER);
    username = (String) mapValues.get(ConfigLoader.STDF_USER_NAME);
    password = (String) mapValues.get(ConfigLoader.STDF_PASSWORD);
    port = getInteger(mapValues.get(ConfigLoader.STDF_PORT));

    folderDepth = getInteger(mapValues.get(ConfigLoader.STDF_DEPTH_FOLDER));
  }
 
  
  private Integer getInteger(Object ob) {
    if (ob != null) {
      if (ob instanceof Double) {
        return ((Double) ob).intValue();
      }
      return Integer.valueOf(ob.toString());
    } else {
      return null;
    }
  }

  private void initStdfArchiveValues(Map<String, Object> mapValues) {
    folderPath = (String) mapValues.get(ConfigLoader.STDF_ARCHIVE_FOLDER);
    folderType = (String) mapValues.get(ConfigLoader.STDF_ARCHIVE_FOLDER_TYPE);
    fileType = (String) mapValues.get(ConfigLoader.STDF_ARCHIVE_FILE_TYPE);
    if (fileType == null) {
      fileType = ".Z;.std*";
    }
    host = (String) mapValues.get(ConfigLoader.STDF_ARCHIVE_FILE_SERVER);
    username = (String) mapValues.get(ConfigLoader.STDF_ARCHIVE_USER_NAME);
    password = (String) mapValues.get(ConfigLoader.STDF_ARCHIVE_PASSWORD);
    port = getInteger(mapValues.get(ConfigLoader.STDF_ARCHIVE_PORT));

    // used for purge
    folderDepth = getInteger(mapValues.get(ConfigLoader.STDF_ARCHIVE_DEPTH_FOLDER));
    expiredTimePurge = getInteger(mapValues.get(ConfigLoader.STDF_ARCHIVE_EXPIRED_TIME));
  }

  private void initStdfErrorValues(Map<String, Object> mapValues) {
    folderPath = (String) mapValues.get(ConfigLoader.STDF_ERROR_FOLDER);
    folderType = (String) mapValues.get(ConfigLoader.STDF_ERROR_FOLDER_TYPE);
    fileType = (String) mapValues.get(ConfigLoader.STDF_ERROR_FILE_TYPE);
    if (fileType == null) {
      fileType = ".Z;.std*";
    }
    host = (String) mapValues.get(ConfigLoader.STDF_ERROR_FILE_SERVER);
    username = (String) mapValues.get(ConfigLoader.STDF_ERROR_USER_NAME);
    password = (String) mapValues.get(ConfigLoader.STDF_ERROR_PASSWORD);
    port = getInteger(mapValues.get(ConfigLoader.STDF_ERROR_PORT));

  }

  private void initFailValuesFolder(Map<String, Object> mapValues) {
    folderPath = (String) mapValues.get(ConfigLoader.FAIL_VALUES_FOLDER);
    folderType = (String) mapValues.get(ConfigLoader.FAIL_VALUES_FOLDER_TYPE);
    fileType = (String) mapValues.get(ConfigLoader.FAIL_VALUES_FILE_TYPE);
    if (fileType == null) {
      fileType = "*.*";
    }
    host = (String) mapValues.get(ConfigLoader.FAIL_VALUES_FILE_SERVER);
    username = (String) mapValues.get(ConfigLoader.FAIL_VALUES_USER_NAME);
    password = (String) mapValues.get(ConfigLoader.FAIL_VALUES_PASSWORD);
    
    port = getInteger(mapValues.get(ConfigLoader.FAIL_VALUES_PORT));

    // used for purge
    folderDepth = getInteger(mapValues.get(ConfigLoader.FAIL_VALUES_DEPTH_FOLDER));
    expiredTimePurge = getInteger(mapValues.get(ConfigLoader.FAIL_VALUES_EXPIRED_TIME));
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  public List<SettingEntity> getCommonSettingList(String stdfType) {
    List<SettingEntity> list = new ArrayList<SettingEntity>();
    list.add(createFolderPath(stdfType));
    list.add(createFolderType(stdfType));
    list.add(createFileType(stdfType));
    list.add(createHost(stdfType));
    list.add(createUsername(stdfType));
    list.add(createPassword(stdfType));
    list.add(createPort(stdfType));

    // folder depth used for STDF folder.
    if (STDF_TYPE.equals(stdfType)) {
      SettingEntity e = createFolderDepth(stdfType);
      if (e != null) {
        list.add(e);
      }
    }
    return list;
  }

  public List<SettingEntity> getPurgeSettingList(String stdfType) {
    List<SettingEntity> list = new ArrayList<SettingEntity>();
    // purge
    SettingEntity e = createFolderDepth(stdfType);
    if (e != null) {
      list.add(e);
    }
    e = createExpiredTime(stdfType);
    if (e != null) {
      list.add(e);
    }
    return list;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createFolderPath(String stdfType) {
    SettingEntity entity = new SettingEntity();
    if (STDF_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_FOLDER);
      entity.setDescription("Path for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_FOLDER);
      entity.setDescription("Path for STDF archive folder.");
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ERROR_FOLDER);
      entity.setDescription("Path for STDF error folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.FAIL_VALUES_FOLDER);
      entity.setDescription("Path for fail values folder.");
    }
    entity.setParaValue(folderPath);
    // var char
    entity.setDataType(1);

    return entity;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createFolderDepth(String stdfType) {
    SettingEntity entity = null;
    // Error folder is not purged, don't have folder depth configuration.
    if (STDF_TYPE.equals(stdfType)) {
      entity = new SettingEntity();
      entity.setParaCode(ConfigLoader.STDF_DEPTH_FOLDER);
      entity.setDescription("Depth folder to get new files for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity = new SettingEntity();
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_DEPTH_FOLDER);
      entity.setDescription("Depth folder to get new files for STDF archive folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity = new SettingEntity();
      entity.setParaCode(ConfigLoader.FAIL_VALUES_DEPTH_FOLDER);
      entity.setDescription("Depth folder to get new files for fail values folder.");
    }
    if (entity != null) {
      entity.setParaValue(folderDepth.toString());
      // number
      entity.setDataType(0);
    }
    return entity;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createFolderType(String stdfType) {
    SettingEntity entity = new SettingEntity();
    if (STDF_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_FOLDER_TYPE);
      entity.setDescription("Folder type for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_FOLDER_TYPE);
      entity.setDescription("Folder type for STDF archive folder.");
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ERROR_FOLDER_TYPE);
      entity.setDescription("Folder type for STDF error folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.FAIL_VALUES_FOLDER_TYPE);
      entity.setDescription("Folder type for fail values folder.");
    }
    entity.setParaValue(folderType);
    // var char
    entity.setDataType(1);

    return entity;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createFileType(String stdfType) {
    SettingEntity entity = new SettingEntity();
    if (STDF_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_FILE_TYPE);
      entity.setDescription("File type for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_FILE_TYPE);
      entity.setDescription("File type for STDF archive folder.");
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ERROR_FILE_TYPE);
      entity.setDescription("File type for STDF error folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.FAIL_VALUES_FILE_TYPE);
      entity.setDescription("File type for fail values folder.");
    }
    entity.setParaValue(fileType);
    // var char
    entity.setDataType(1);

    return entity;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createHost(String stdfType) {
    SettingEntity entity = new SettingEntity();
    if (STDF_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_FILE_SERVER);
      entity.setDescription("File server for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_FILE_SERVER);
      entity.setDescription("File server for STDF archive folder.");
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ERROR_FILE_SERVER);
      entity.setDescription("File server for STDF error folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.FAIL_VALUES_FILE_SERVER);
      entity.setDescription("File server for fail values folder.");
    }
    entity.setParaValue(host);
    // var char
    entity.setDataType(1);

    return entity;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createUsername(String stdfType) {
    SettingEntity entity = new SettingEntity();
    if (STDF_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_USER_NAME);
      entity.setDescription("Username to access file server for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_USER_NAME);
      entity.setDescription("Username to access file server for STDF archive folder.");
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ERROR_USER_NAME);
      entity.setDescription("Username to access file server for STDF error folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.FAIL_VALUES_USER_NAME);
      entity.setDescription("Username to access file server for failed values folder.");
    }
    entity.setParaValue(username);
    // var char
    entity.setDataType(1);

    return entity;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createPassword(String stdfType) {
    SettingEntity entity = new SettingEntity();
    if (STDF_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_PASSWORD);
      entity.setDescription("Password to access file server for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_PASSWORD);
      entity.setDescription("Password to access file server for STDF archive folder.");
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ERROR_PASSWORD);
      entity.setDescription("Password to access file server for STDF error folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.FAIL_VALUES_PASSWORD);
      entity.setDescription("Password to access file server for failed values folder.");
    }
    String encryptPass = CommonUtils.encryptPassword(password, stdfType, oldEncryptedPassword);
    entity.setParaValue(encryptPass);
    // update value to show on GUI
    password = oldEncryptedPassword = encryptPass;
    // var char
    entity.setDataType(1);

    return entity;
  }

  /**
   * @param stdfType
   *          one of values of StdfFolderSetting : STDF_TYPE, STDF_ARCHIVE_TYPE,
   *          STDF_ERROR_TYPE.
   * @return
   */
  private SettingEntity createPort(String stdfType) {
    SettingEntity entity = new SettingEntity();
    if (STDF_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_PORT);
      entity.setDescription("Port to access file server for STDF folder.");
    } else if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_PORT);
      entity.setDescription("Port to access file server for STDF archive folder.");
    } else if (STDF_ERROR_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.STDF_ERROR_PORT);
      entity.setDescription("Port to access file server for STDF error folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity.setParaCode(ConfigLoader.FAIL_VALUES_PORT);
      entity.setDescription("Port to access file server for failed values folder.");
    }
    if (port != null) {
      entity.setParaValue(port.toString());
    } else {
      entity.setParaValue(null);
    }
    // number
    entity.setDataType(0);

    return entity;
  }

  private SettingEntity createExpiredTime(String stdfType) {
    SettingEntity entity = null;
    if (STDF_ARCHIVE_TYPE.equals(stdfType)) {
      entity = new SettingEntity();
      entity.setParaCode(ConfigLoader.STDF_ARCHIVE_EXPIRED_TIME);
      entity.setDescription("Expired time is used for purging STDF archive folder.");
    } else if (FAIL_VALUES_FOLDER_TYPE.equals(stdfType)) {
      entity = new SettingEntity();
      entity.setParaCode(ConfigLoader.FAIL_VALUES_EXPIRED_TIME);
      entity.setDescription("Expired time is used for purging failed values folder.");
    }
    if (entity != null) {
      if (expiredTimePurge != null) {
        entity.setParaValue(expiredTimePurge.toString());
      } else {
        entity.setParaValue(null);
      }
      // number
      entity.setDataType(0);
    }
    return entity;
  }

  /**
   * @return the folderPath
   */
  public String getFolderPath() {
    return folderPath;
  }

  /**
   * @param folderPath
   *          the folderPath to set
   */
  public void setFolderPath(String folderPath) {
    this.folderPath = folderPath;
  }

  /**
   * @return the folderType
   */
  public String getFolderType() {
    return folderType;
  }

  /**
   * @param folderType
   *          the folderType to set
   */
  public void setFolderType(String folderType) {
    this.folderType = folderType;
  }

  /**
   * @return the fileType
   */
  public String getFileType() {
    return fileType;
  }

  /**
   * @param fileType
   *          the fileType to set
   */
  public void setFileType(String fileType) {
    this.fileType = fileType;
  }

  /**
   * @return the host
   */
  public String getHost() {
    return host;
  }

  /**
   * @param host
   *          the host to set
   */
  public void setHost(String host) {
    this.host = host;
  }

  /**
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * @param username
   *          the username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @param password
   *          the password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * @return the port
   */
  public Integer getPort() {
    return port;
  }

  /**
   * @param port
   *          the port to set
   */
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   * @return the folderDepth
   */
  public Integer getFolderDepth() {
    return folderDepth;
  }

  /**
   * @param folderDepth
   *          the folderDepth to set
   */
  public void setFolderDepth(Integer folderDepth) {
    this.folderDepth = folderDepth;
  }

  /**
   * @return the expiredTimePurge
   */
  public Integer getExpiredTimePurge() {
    return expiredTimePurge;
  }

  /**
   * @param expiredTimePurge
   *          the expiredTimePurge to set
   */
  public void setExpiredTimePurge(Integer expiredTimePurge) {
    this.expiredTimePurge = expiredTimePurge;
  }

  /**
   * @param oldEncryptedPassword the oldEncryptedPassword to set
   */
  public void setOldEncryptedPassword(String oldEncryptedPassword) {
    this.oldEncryptedPassword = oldEncryptedPassword;
  }
  
}
