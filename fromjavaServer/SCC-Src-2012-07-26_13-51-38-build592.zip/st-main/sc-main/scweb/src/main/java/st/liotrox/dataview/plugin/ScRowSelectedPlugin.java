/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 16, 2011 4:47:29 PM - nhatvn - Initialize version
/********************************************************************************/
package st.liotrox.dataview.plugin;

import st.liotrox.WRequest;
import st.liotrox.dataview.AbstractRowRenderer;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.Row;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.web.html.WriteHTML;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ScRowSelectedPlugin extends RowSelectorPlugin {

  protected String hiddenField;

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.plugin.RowSelectorPlugin#writeColumnCell(st.liotrox.WRequest,
   *      st.liotrox.util.FastStringBuffer,
   *      st.liotrox.dataview.event.DataViewEvent)
   */
  @Override
  public void writeColumnCell(WRequest request, FastStringBuffer fsb, DataViewEvent event) {
    // Write <TD>
    WriteHTML.Table.cellStartWithAttrs(fsb).attribute(fsb, "align", getAlign()).closeTag(fsb);

    DataView dataView = event.getDataView();
    Row row = dataView.getModel().getRows().get(event.getRow());
    DataView.RenderedRowInterval interval = dataView.getRenderedRowInterval();
    // get hidden fields
    if (hiddenField != null && hiddenField.length() > 0) {
      String[] hiddenFieldList = hiddenField.split(",");
      for (String field : hiddenFieldList) {
        WriteHTML.Input.inputStartWithAttrs(fsb).typeHidden(fsb);

        fsb.append(" name = \"").append(dataView.getName()).append("_").append(field)
            .append(event.getRow()).append("_h\" ");
        // get value from dataset.
        Object fieldValue = dataView.getModel().getDataSet().getValue(event.getRow(), field);
        WriteHTML.Input.value(fsb, fieldValue.toString()).closeTag(fsb);
      }
    }

    WriteHTML.Input.inputStartWithAttrs(fsb).typeCheckBox(fsb);

    fsb.append(" name = \"").append(dataView.getName()).append("_rSel").append(event.getRow())
        .append("\" ");
    if (row.isSelected())
      WriteHTML.Input.checked(fsb);

    fsb.append(" ROWID = \"");
    AbstractRowRenderer.writeRowID(fsb, dataView, row);
    fsb.append("\" ");

    fsb.append(" onclick = \"").append("DVHandleSelect(this,")
        .append(getClientSideHighlight()).append(",'").append(dataView.getName())
        .append("', ").append(interval.getFirstRow()).append(',')
        .append(interval.getLastRow()).append(",'");

    AbstractRowRenderer.writeRowID(fsb, dataView, row);
    fsb.append("',").append(event.getRow());
    if (this.onClick != null)
      fsb.append(",'").append(this.onClick).append("'");
    fsb.append(")\" ");

    WriteHTML.Input.closeTag(fsb);

    WriteHTML.Table.cellEnd(fsb);
  }

  /**
   * @return the hiddenField
   */
  public String getHiddenField() {
    return hiddenField;
  }

  /**
   * @param hiddenField
   *          the hiddenField to set
   */
  public void setHiddenField(String hiddenField) {
    this.hiddenField = hiddenField;
  }

}
