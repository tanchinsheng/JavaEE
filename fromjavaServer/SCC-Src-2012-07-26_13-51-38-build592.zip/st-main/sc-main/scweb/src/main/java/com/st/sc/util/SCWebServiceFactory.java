/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 2, 2011 6:38:32 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.util;

import java.util.Map;

import javax.persistence.EntityManagerFactory;

import com.st.common.config.ConfigLoader;
import com.st.persistence.DatabaseConstants;
import com.st.persistence.SQLExecutor;
import com.st.persistence.SQLExecutorJpaImpl;
import com.st.persistence.service.SettingService;
import com.st.persistence.util.EntityManagerUtils;
import com.st.sc.rulemanager.BaseService;
import com.st.scc.common.utils.PropertiesUtil;
import com.st.um.service.UserService;

/**
 * The Class ScServiceUtil.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class SCWebServiceFactory {

  /** The Constant SC_FACTORY. */
  private static EntityManagerFactory entityManagerFactory;

  private static EntityManagerFactory umEntityManagerFactory;

  /** The Constant SC_SERVICE. */
  private static BaseService scService;

  /** The user service. */
  private static UserService userService;

  /** The Constant SC_EXECUTOR. */
  private static SQLExecutor scExecutor;

  /** The setting service. */
  private static SettingService settingService;

  /** The UM setting service. */
  private static SettingService umSettingService;

  /**
   * Gets the SC base service.
   * 
   * @return the SC base service
   */
  public static BaseService getScBaseService() {
    if (scService == null) {
      synchronized (SCWebServiceFactory.class) {
        if (scService == null) {
          scService = new BaseService(getScEntityManagerFactory());
        }
      }
    }
    return scService;
  }

  /**
   * Gets the sc entity manager factory.
   * 
   * @return the sc entity manager factory
   */
  public static EntityManagerFactory getScEntityManagerFactory() {
    if (entityManagerFactory == null) {
      synchronized (SCWebServiceFactory.class) {
        if (entityManagerFactory == null) {
          final Map<String, String> properties =
              PropertiesUtil.loadFromXML(ConfigLoader.getInstance().getFile(
                  DatabaseConstants.SC_DB_XML));
          entityManagerFactory =
              EntityManagerUtils.getEntityManagerFactory(DatabaseConstants.SC_DB_UNIT_NAME,
                  properties);
        }
      }
    }
    return entityManagerFactory;
  }

  public static EntityManagerFactory getUmEntityManagerFactory() {
    if (umEntityManagerFactory == null) {
      synchronized (SCWebServiceFactory.class) {
        if (umEntityManagerFactory == null) {
          final Map<String, String> properties =
              PropertiesUtil.loadFromXML(ConfigLoader.getInstance().getFile(
                  DatabaseConstants.UM_DB_XML));
          umEntityManagerFactory =
              EntityManagerUtils.getEntityManagerFactory(DatabaseConstants.UM_DB_UNIT_NAME,
                  properties);
        }
      }
    }
    return umEntityManagerFactory;
  }

  /**
   * Gets the sC executor.
   * 
   * @return the sC executor
   */
  public static SQLExecutor getSCExecutor() {
    if (scExecutor == null) {
      synchronized (SCWebServiceFactory.class) {
        if (scExecutor == null) {
          scExecutor = new SQLExecutorJpaImpl(getScEntityManagerFactory());
        }
      }
    }
    return scExecutor;
  }

  /**
   * Gets the user service.
   * 
   * @return the user service
   */
  public static UserService getUserService() {
    if (userService == null) {
      synchronized (SCWebServiceFactory.class) {
        if (userService == null) {
          userService = new UserService(getUmEntityManagerFactory());
        }
      }
    }
    return userService;
  }

  public static SettingService getUmSettingService() {
    if (umSettingService == null) {
      synchronized (SCWebServiceFactory.class) {
        if (umSettingService == null) {
          umSettingService = new SettingService(getUmEntityManagerFactory());
        }
      }
    }
    return umSettingService;
  }

  /**
   * Gets the setting service.
   * 
   * @return the setting service
   */
  public static SettingService getSettingService() {
    if (settingService == null) {
      synchronized (SCWebServiceFactory.class) {
        if (settingService == null) {
          settingService = new SettingService(getScEntityManagerFactory());
        }
      }
    }
    return settingService;
  }

  /**
   * Instantiates a new SC service utility.
   */
  private SCWebServiceFactory() {
  }

}
