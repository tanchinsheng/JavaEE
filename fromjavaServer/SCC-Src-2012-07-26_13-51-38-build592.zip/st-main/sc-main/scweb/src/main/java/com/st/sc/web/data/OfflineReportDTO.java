/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 25, 2012 5:04:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.util.Date;

import com.st.sc.entity.OfflineReportEntity;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class OfflineReportDTO {

  private Long offlineReportId;

  /** The checking time. */
  private String checkingTime;

  /** The error message. */
  private String errorMessage;

  /** The mir start t. */
  private String mirStartT;

  /** The mrr finish t. */
  private String mrrFinishT;

  /** The owners. */
  private String owners;

  /** The report name. */
  private String reportName;

  /** The report time. */
  private Date reportTime;

  /** The report type. */
  private String reportType;

  /** The status. */
  private String status;

  public OfflineReportDTO(final OfflineReportEntity entity) {
    offlineReportId = entity.getOfflineReportId();
    reportName = entity.getReportName();
    reportType = entity.getReportType();
    if (entity.getReportTime() != null) {
      reportTime = new Date(entity.getReportTime().getTime());
    }
    checkingTime = entity.getCheckingTime();
    mirStartT = entity.getMirStartT();
    mrrFinishT = entity.getMrrFinishT();
    errorMessage = entity.getErrorMessage();
    status = entity.getStatus();
    owners = entity.getOwners();
  }

  /**
   * @return the offlineReportId
   */
  public Long getOfflineReportId() {
    return offlineReportId;
  }

  /**
   * @param offlineReportId
   *          the offlineReportId to set
   */
  public void setOfflineReportId(Long offlineReportId) {
    this.offlineReportId = offlineReportId;
  }

  /**
   * @return the checkingTime
   */
  public String getCheckingTime() {
    return checkingTime;
  }

  /**
   * @param checkingTime
   *          the checkingTime to set
   */
  public void setCheckingTime(String checkingTime) {
    this.checkingTime = checkingTime;
  }

  /**
   * @return the errorMessage
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * @param errorMessage
   *          the errorMessage to set
   */
  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  /**
   * @return the mirStartT
   */
  public String getMirStartT() {
    return mirStartT;
  }

  /**
   * @param mirStartT
   *          the mirStartT to set
   */
  public void setMirStartT(String mirStartT) {
    this.mirStartT = mirStartT;
  }

  /**
   * @return the mrrFinishT
   */
  public String getMrrFinishT() {
    return mrrFinishT;
  }

  /**
   * @param mrrFinishT
   *          the mrrFinishT to set
   */
  public void setMrrFinishT(String mrrFinishT) {
    this.mrrFinishT = mrrFinishT;
  }

  /**
   * @return the owners
   */
  public String getOwners() {
    return owners;
  }

  /**
   * @param owners
   *          the owners to set
   */
  public void setOwners(String owners) {
    this.owners = owners;
  }

  /**
   * @return the reportName
   */
  public String getReportName() {
    return reportName;
  }

  /**
   * @param reportName
   *          the reportName to set
   */
  public void setReportName(String reportName) {
    this.reportName = reportName;
  }

  /**
   * @return the reportTime
   */
  public Date getReportTime() {
    return reportTime;
  }

  /**
   * @param reportTime
   *          the reportTime to set
   */
  public void setReportTime(Date reportTime) {
    this.reportTime = reportTime;
  }

  /**
   * @return the reportType
   */
  public String getReportType() {
    return reportType;
  }

  /**
   * @param reportType
   *          the reportType to set
   */
  public void setReportType(String reportType) {
    this.reportType = reportType;
  }

  /**
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * @param status
   *          the status to set
   */
  public void setStatus(String status) {
    this.status = status;
  }

}
