/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 13, 2012 2:46:04 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.profile.UserProfile;

import com.st.common.DBUtil;
import com.st.common.exception.SccException;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.util.SCWebServiceFactory;
import com.st.um.entity.UserEntity;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class UserInformation extends BaseAction {

  private static final Logger LOGGER = LoggerFactory.getLogger(UserInformation.class);

  /**
   * Instantiates a new user information.
   */
  public UserInformation() {
  }

  public void setUserInfo(UserEntity user) {
    if (user == null) {
      return;
    }
    email = user.getEmail();
    phone = user.getPhone();
    organization = user.getOrganization();
    fullName = user.getFullName();
    userType = user.getUserType().getValue();
    priority = user.getProfilesPriority();
  }

  public void refresh(WRequest request, Event event) {
    show(request, event);
  }

  /**
   * Show user information.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void show(WRequest request, Event event) {

    UserProfile up = request.getUserProfile();
    if (up == null) {
      errorMessage =
          CommonUtils.getProfileBundleMessage("scc_profile_user_profile_does_not_found_error");
      return;
    }

    userName = up.getAttribute("liotrox.user");

    UserEntity user = null;
    try {
      user = SCWebServiceFactory.getUserService().getUserByUserName(userName);
    } catch (SccException e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = CommonUtils.getCommonBundleMessage(SCConstants.DB_COMMON_ERROR_KEY);
    }

    if (user == null) {
      errorMessage =
          CommonUtils.getProfileBundleMessage("scc_profile_user_does_not_found_error");
      return;
    }
    role = up.getRole();
    setUserInfo(user);
  }

  /**
   * validate two element. if both value is null or equals return true, else
   * return false.
   * 
   * @param previousValue
   * @param newValue
   * @return
   */
  private boolean validationElement(String previousValue, String newValue) {
    boolean result = false;
    if ((previousValue == null || previousValue.equals(""))
        && (newValue == null || newValue.equals(""))) {
      result = true;
    } else if (previousValue != null && newValue != null && previousValue.equals(newValue)) {
      result = true;
    }
    return result;
  }

  /**
   * validation in user if the user info is changed or not.
   * 
   * @param user
   * @return
   */
  private boolean validationInput(UserEntity user, StringBuilder builder) {
    if (user == null) {
      return false;
    }
    boolean result = true;
    boolean isSame;
    // validation email
    isSame = validationElement(user.getEmail(), email);
    result = isSame;
    // Tracking for email
    if (!isSame) {
      builder.append("[Email: Old value=").append(user.getEmail()).append(", New value=")
          .append(email).append("],");
    }
    isSame = validationElement(user.getFullName(), fullName);
    result = result && isSame;
    // Tracking for full name
    if (!isSame) {
      builder.append("[Full Name: Old value=").append(user.getFullName())
          .append(", New value=").append(fullName).append("],");
    }
    isSame = validationElement(user.getPhone(), phone);
    result = result && isSame;
    // Tracking for phone
    if (!isSame) {
      builder.append("[Phone: Old value=").append(user.getPhone()).append(", New value=")
          .append(phone).append("],");
    }

    isSame = validationElement(user.getProfilesPriority(), priority);
    result = result && isSame;
    // Tracking for email
    if (!isSame) {
      builder.append("[Profile Priority: Old value=").append(user.getProfilesPriority())
          .append(", New value=").append(priority).append("],");
    }

    isSame = validationElement(user.getOrganization(), organization);
    result = result && isSame;
    // Tracking for organization.
    if (!isSame) {
      builder.append("[Organization: Old value=").append(user.getOrganization())
          .append(", New value=").append(organization).append("],");
    }

    result = result && (currentPassword == null || currentPassword.equals(""));
    return result;
  }

  /**
   * Change user infomation.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void change(WRequest request, Event event) {
    long startTime = System.currentTimeMillis();
    isShowPassword = false;
    UserProfile up = request.getUserProfile();
    userName = up.getAttribute("liotrox.user");
    role = up.getRole();

    UserEntity user = null;
    try {
      user = SCWebServiceFactory.getUserService().getUserByUserName(userName);
    } catch (SccException e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = CommonUtils.getCommonBundleMessage(SCConstants.DB_COMMON_ERROR_KEY);
      return;
    }
    if (user == null) {
      errorMessage = CommonUtils.getProfileBundleMessage("user_already_deleted");
      return;
    }
    email = request.getHttpRequest().getParameter("email");
    phone = request.getHttpRequest().getParameter("phone");
    organization = request.getHttpRequest().getParameter("organization");
    fullName = request.getHttpRequest().getParameter("fullName");
    currentPassword = request.getHttpRequest().getParameter("currentPassword");
    priority = request.getHttpRequest().getParameter("priority");
    newPassword = request.getHttpRequest().getParameter("newPassword");
    confirmPassword = request.getHttpRequest().getParameter("confirmPassword");
    StringBuilder paramTracking = new StringBuilder();
    boolean validateUserInfo = validationInput(user, paramTracking);
    if (validateUserInfo) {
      if (currentPassword != null && !currentPassword.equals("")) {
        isShowPassword = true;
      }
      errorMessage = CommonUtils.getCommonBundleMessage("nothing_to_changed");
      return;
    }
    user.setEmail(email);
    user.setFullName(fullName);
    user.setOrganization(organization);
    user.setPhone(phone);
    if (priority != null) {
      user.setProfilesPriority(priority);
    }
    if (currentPassword != null && currentPassword != "") {
      isShowPassword = true;
      if (currentPassword != null
          && !DBUtil.hashPassword(currentPassword).equals(user.getPassword())) {
        errorMessage =
            CommonUtils.getProfileBundleMessage("scc_profile_change_confirm_wrong_password");
        return;
      } else {
        if (newPassword != null) {
          user.setPassword(DBUtil.hashPassword(newPassword));
        } else {
          errorMessage =
              CommonUtils.getProfileBundleMessage("scc_profile_change_new_password_require");
          return;
        }
      }
    }

    try {
      SCWebServiceFactory.getUserService().update(user);
    } catch (SccException e) {
      successUpdate = false;
      LOGGER.error(e.getMessage(), e);
      errorMessage = CommonUtils.getCommonBundleMessage(SCConstants.DB_COMMON_ERROR_KEY);
      return;
    }

    setUserInfo(user);
    successUpdate = true;
    // Create ActionTracking object and add to service.
    ActionTrackingEntity trackingEntity = new ActionTrackingEntity();
    trackingEntity.setAction("Modify User Information");
    trackingEntity.setParameters(paramTracking.toString());
    trackingEntity.setElapsedTime(System.currentTimeMillis() - startTime);

    trackAction(trackingEntity);
    return;
  }

  /** The password. */
  private String currentPassword;

  private String newPassword;

  private String confirmPassword;

  /** The user name. */
  private String userName;

  /** The phone. */
  private String phone;

  /** The email. */
  private String email;

  /** The organization. */
  private String organization;

  /** The first name. */
  private String fullName;

  /** The role. */
  private String role;

  /** The error message. */
  private String errorMessage;

  /** The success update. */
  private boolean successUpdate;

  private int userType;

  private String priority;

  private boolean isShowPassword;

  public boolean getIsShowPassword() {
    return isShowPassword;
  }

  public String getPriority() {
    return priority;
  }

  public void setPriority(String priority) {
    this.priority = priority;
  }

  public int getUserType() {
    return userType;
  }

  public void setUserType(int userType) {
    this.userType = userType;
  }

  public boolean isSuccessUpdate() {
    return successUpdate;
  }

  public void setSuccessUpdate(boolean successUpdate) {
    this.successUpdate = successUpdate;
  }

  /**
   * Gets the error message.
   * 
   * @return the error message
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * Sets the error message.
   * 
   * @param errorMessage
   *          the new error message
   */
  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  /**
   * Gets the role.
   * 
   * @return the role
   */
  public String getRole() {
    return role;
  }

  /**
   * Sets the role.
   * 
   * @param role
   *          the new role
   */
  public void setRole(String role) {
    this.role = role;
  }

  /**
   * Gets the phone.
   * 
   * @return the phone
   */
  public String getPhone() {
    return phone;
  }

  /**
   * Sets the phone.
   * 
   * @param phone
   *          the new phone
   */
  public void setPhone(String phone) {
    this.phone = phone;
  }

  /**
   * Gets the email.
   * 
   * @return the email
   */
  public String getEmail() {
    return email;
  }

  /**
   * Sets the email.
   * 
   * @param email
   *          the new email
   */
  public void setEmail(String email) {
    this.email = email;
  }

  /**
   * Gets the organization.
   * 
   * @return the organization
   */
  public String getOrganization() {
    return organization;
  }

  /**
   * Sets the organization.
   * 
   * @param organization
   *          the new organization
   */
  public void setOrganization(String organization) {
    this.organization = organization;
  }

  /**
   * Gets the first name.
   * 
   * @return the first name
   */
  public String getFullName() {
    return fullName;
  }

  /**
   * Sets the first name.
   * 
   * @param firstName
   *          the new first name
   */
  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  /**
   * Gets the user name.
   * 
   * @return the user name
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Sets the user name.
   * 
   * @param userName
   *          the new user name
   */
  public void setUserName(String userName) {
    this.userName = userName;
  }

  /** The last login. */
  private Timestamp lastLogin;

  /**
   * @return the currentPassword
   */
  public String getCurrentPassword() {
    return currentPassword;
  }

  /**
   * Gets the password.
   * 
   * @return the password
   */
  public String getNewPassword() {
    return newPassword;
  }

  /**
   * Gets the password.
   * 
   * @return the password
   */
  public String getConfirmPassword() {
    return confirmPassword;
  }

  /**
   * Gets the last login.
   * 
   * @return the last login
   */
  public Timestamp getLastLogin() {
    return lastLogin;
  }

  /**
   * Sets the last login.
   * 
   * @param lastLogin
   *          the new last login
   */
  public void setLastLogin(Timestamp lastLogin) {
    this.lastLogin = lastLogin;
  }

  /**
   * Sets the password.
   * 
   * @param password
   *          the new password
   */
  public void setPassword(String password) {
    this.currentPassword = password;
  }
}
