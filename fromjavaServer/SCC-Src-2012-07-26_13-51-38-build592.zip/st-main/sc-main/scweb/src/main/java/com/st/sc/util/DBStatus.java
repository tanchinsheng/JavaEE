/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 18, 2011 4:41:23 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.ConfigLoader;
import com.st.persistence.DatabaseConstants;
import com.st.scc.common.utils.PropertiesUtil;

/**
 * The Class DBStatus.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class DBStatus {

  /**
   * The Class DBInfo.
   */
  private static class DBInfo {

    /** The driver. */
    private String driver;

    /** The url. */
    private String url;

    /** The user name. */
    private String userName;

    /** The password. */
    private String password;

    /**
     * Gets the driver.
     * 
     * @return the driver
     */
    public String getDriver() {
      return driver;
    }

    /**
     * Gets the password.
     * 
     * @return the password
     */
    public String getPassword() {
      return password;
    }

    /**
     * Gets the url.
     * 
     * @return the url
     */
    public String getUrl() {
      return url;
    }

    /**
     * Gets the user name.
     * 
     * @return the user name
     */
    public String getUserName() {
      return userName;
    }

    /**
     * Sets the driver.
     * 
     * @param driver
     *          the new driver
     */
    public void setDriver(final String driver) {
      this.driver = driver;
    }

    /**
     * Sets the password.
     * 
     * @param password
     *          the new password
     */
    public void setPassword(final String password) {
      this.password = password;
    }

    /**
     * Sets the url.
     * 
     * @param url
     *          the new url
     */
    public void setUrl(final String url) {
      this.url = url;
    }

    /**
     * Sets the user name.
     * 
     * @param userName
     *          the new user name
     */
    public void setUserName(final String userName) {
      this.userName = userName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
      return "DBInfo [driver=" + driver + ", url=" + url + ", userName=" + userName
          + ", password=******]";
    }
  }

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(DBStatus.class);

  /** The Constant INSTANCE. */
  private static final DBStatus INSTANCE = new DBStatus();

  /**
   * Gets unique instance of this class.
   * 
   * @return DBStatus
   */
  public static DBStatus getInstance() {
    return INSTANCE;
  }

  /**
   * Gets database information from configuration file.
   * 
   * @return DBInfo
   */
  private static DBInfo getSCDBInfo() {
    final Map<String, String> properties =
        PropertiesUtil.loadFromXML(ConfigLoader.getInstance().getFile(
            DatabaseConstants.SC_DB_XML));
    final DBInfo dbInfo = new DBInfo();
    for (final String key : properties.keySet()) {
      if ("hibernate.connection.url".equals(key)) {
        dbInfo.setUrl(properties.get(key));
      }
      if ("hibernate.connection.username".equals(key)) {
        dbInfo.setUserName(properties.get(key));
      }
      if ("hibernate.connection.password".equals(key)) {
        dbInfo.setPassword(properties.get(key));
      }
      if ("hibernate.connection.driver_class".equals(key)) {
        dbInfo.setDriver(properties.get(key));
      }
    }
    return dbInfo;
  }

  /** The sc db info. */
  private DBInfo scDBInfo;

  /**
   * Private constructor for singleton Constructor.
   */
  private DBStatus() {
    try {
      scDBInfo = getSCDBInfo();
    } catch (final Exception ex) {
      LOGGER.error("Load db config file error", ex);
    }
  }

  /**
   * Gets connection status of SCC DB.
   * 
   * @return true if connect OK, otherwise false
   */
  public boolean getSConnectionStatus() {
    Connection conn = null;
    try {
      Class.forName(scDBInfo.getDriver());
      conn =
          DriverManager.getConnection(scDBInfo.getUrl(), scDBInfo.getUserName(),
              scDBInfo.getPassword());
      return true;
    } catch (final Exception e) {
      LOGGER.error("SC database connection error: " + e.getMessage());
    } finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (final SQLException e) {
          // ignore exception if close error.
        }
      }
    }
    return false;
  }

  @Override
  public String toString() {
    return "DBStatus [scDBInfo=" + scDBInfo + "]";
  }

}
