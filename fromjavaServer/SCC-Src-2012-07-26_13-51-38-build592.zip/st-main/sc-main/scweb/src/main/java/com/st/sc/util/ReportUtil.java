/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 28, 2012 6:11:06 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.util;

import javax.servlet.http.HttpSession;

import st.liotrox.WRequest;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All rights reserved.
 *
 */
public class ReportUtil {
  /**
   * Gets the view name.
   * 
   * @return the view name
   */
  public static String getViewName() {
    return getViewName(WRequest.getCurrentInstance().getSession());
  }

  /**
   * Gets the view name.
   * 
   * @param session
   *          the session
   * @return the view name
   */
  public static String getViewName(final HttpSession session) {
    String viewName = "V_TMP_" + session.getId();

    if (viewName.length() > 30) {
      viewName = viewName.substring(0, 30);
    }
    return viewName.toUpperCase();
  }
}
