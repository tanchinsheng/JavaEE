/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 21, 2011 11:29:30 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.db.DataSet;
import st.liotrox.template.element.control.TabbedPanelElement;

import com.st.common.config.ConfigLoader;
import com.st.common.web.config.ConfigReloader;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.persistence.entity.SettingEntity;
import com.st.persistence.service.JPABaseService;
import com.st.persistence.service.SettingService;
import com.st.sc.common.CommonUtils;
import com.st.sc.rulemanager.EntityExecutor;
import com.st.sc.rulemanager.QueryExecutor;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.ActionTrackingDTO;
import com.st.sc.web.data.SettingDTO;
import com.st.sc.web.data.StdfFolderSetting;
import com.st.scc.common.utils.DataValidation;
import com.st.scc.common.utils.StringUtil;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class AdminAction extends BaseAction {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(AdminAction.class);

  private SettingDTO settingDto = new SettingDTO();
  private StdfFolderSetting stdfFolder = new StdfFolderSetting();
  private StdfFolderSetting stdfArchiveFolder = new StdfFolderSetting();
  private StdfFolderSetting stdfErrorFolder = new StdfFolderSetting();
  private StdfFolderSetting failValuesFolder = new StdfFolderSetting();

  private DataSet changeHistoryDataSet;
  private DataView changeHistoryDV;

  public String[] getFolderTypeList() {
    return new String[]{"NFS", "FTP", "SFTP" };
  }

  private final String DAY_UNIT = "days";

  public String[] getPurgeUnits() {
    return new String[]{DAY_UNIT, "hours", "minutes" };
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#handleAction(st.liotrox.WRequest,
   *      st.liotrox.Event)
   */
  @Override
  public void handleAction(WRequest request, Event event) throws Throwable {
    // This is called when you click on each tab.
    super.handleAction(request, event);
    boolean getNewData = false;
    // handle change tab event
    // handle click on admin menu : click amdin.lxp
    String eventBkmParams = event.getParameter("LX_BKM_EVT");
    if (eventBkmParams == null || eventBkmParams.contains("changeTab")) {
      getNewData = true;
    }

    if (getNewData) {
      TabbedPanelElement mainTabPanel = (TabbedPanelElement) findControl("mainTabPanel");
      String selectedTabName = mainTabPanel.getSelectedTab();
      if ("changeHistory".equals(selectedTabName)) {
        doShowChangeHistory(request, event);
      }
      if ("applicationParameters".equals(selectedTabName)
          || "purgeConfig".equals(selectedTabName)) {
        doShowConfiguration(request, event);
      }
    }
  }

  private void clearErrorMsg() {
    infoMessage = "";
    errorMessage = "";
  }

  public void doShowConfiguration(WRequest request, Event event) {
    clearErrorMsg();
    SettingService setting = new SettingService();
    setting.setEntityManagerFactory(SCWebServiceFactory.getScEntityManagerFactory());

    Map<String, Object> mapValues = setting.loadAll();
    settingDto.initValues(mapValues);
    stdfFolder.initValues(mapValues, StdfFolderSetting.STDF_TYPE);
    stdfArchiveFolder.initValues(mapValues, StdfFolderSetting.STDF_ARCHIVE_TYPE);
    stdfErrorFolder.initValues(mapValues, StdfFolderSetting.STDF_ERROR_TYPE);
    failValuesFolder.initValues(mapValues, StdfFolderSetting.FAIL_VALUES_FOLDER_TYPE);
  }

  private boolean validateData() {
    boolean valid = false;
    // validate URL
    valid = DataValidation.checkGoodUrl(settingDto.getUmUrl());
    if (!valid) {
      errorMessage += CommonUtils.getAdminBundleMessage("msg_url_not_correct_format");
    }
    // validate Email
    String emailFrom = settingDto.getEmailFrom();
    if (emailFrom != null && emailFrom.length() > 0) {
      valid = DataValidation.checkGoodMail(emailFrom);
      if (!valid) {
        errorMessage +=
            CommonUtils.getAdminBundleMessage("msg_email_not_correct_format",
                new Object[]{"Email From" });
      }
    }
    String emailAdmin = settingDto.getEmailAdmin();
    if (emailAdmin != null && emailAdmin.length() > 0) {
      List<String> invalidEmails = new ArrayList<String>();
      emailAdmin = emailAdmin.replaceAll(";", ",");
      String[] strings = StringUtil.split(emailAdmin, ",");
      for (String string : strings) {
        if (!DataValidation.checkGoodMail(string)) {
          invalidEmails.add(string);
        }
      }
      valid = invalidEmails.size() == 0;
      if (!valid) {
        errorMessage +=
            CommonUtils.getAdminBundleMessage("msg_email_not_correct_format",
                new Object[]{invalidEmails.toString() });
      }
    }
    if (errorMessage.length() > 0) {
      return false;
    }
    return true;
  }

  public void doSave(WRequest request, Event event) {
    clearErrorMsg();
    long startTime = System.currentTimeMillis();
    if (!validateData()) {
      return;
    }
    // Check data whether is changed
    String changedStr = createChangedString();
    if (changedStr.length() == 0) {
      infoMessage = CommonUtils.getCommonBundleMessage("nothing_to_changed");
      return;
    }
    List<SettingEntity> list1 = settingDto.getCommonSettingList();
    List<SettingEntity> list2 = stdfFolder.getCommonSettingList(StdfFolderSetting.STDF_TYPE);
    list1.addAll(list2);
    list2 = stdfArchiveFolder.getCommonSettingList(StdfFolderSetting.STDF_ARCHIVE_TYPE);
    list1.addAll(list2);
    list2 = stdfErrorFolder.getCommonSettingList(StdfFolderSetting.STDF_ERROR_TYPE);
    list1.addAll(list2);
    list2 = failValuesFolder.getCommonSettingList(StdfFolderSetting.FAIL_VALUES_FOLDER_TYPE);
    list1.addAll(list2);

    // save data
    boolean success = saveSettings(list1);
    if (success) {
      // create action log.
      ActionTrackingEntity trackingEntity = new ActionTrackingEntity();
      trackingEntity.setAction("Modify Setting");
      trackingEntity.setParameters(changedStr);
      trackingEntity.setElapsedTime(System.currentTimeMillis() - startTime);

      trackAction(trackingEntity);
    }
  }

  /**
   * Save purge settings.
   * 
   * @param request
   * @param event
   */
  public void doSavePurgeConfig(WRequest request, Event event) {
    clearErrorMsg();
    long startTime = System.currentTimeMillis();
    // Check data whether is changed
    String changedStr = createPurgeChangedString();
    if (changedStr.length() == 0) {
      infoMessage = CommonUtils.getCommonBundleMessage("nothing_to_changed");
      return;
    }
    List<SettingEntity> list1 = settingDto.getPurgeSettingList();
    List<SettingEntity> list2 =
        stdfArchiveFolder.getPurgeSettingList(StdfFolderSetting.STDF_ARCHIVE_TYPE);
    list1.addAll(list2);
    list2 = failValuesFolder.getPurgeSettingList(StdfFolderSetting.FAIL_VALUES_FOLDER_TYPE);
    list1.addAll(list2);

    // save data
    boolean success = saveSettings(list1);
    if (success) {
      // create action log.
      ActionTrackingEntity trackingEntity = new ActionTrackingEntity();
      trackingEntity.setAction("Modify Purge Setting");
      trackingEntity.setParameters(changedStr);
      trackingEntity.setElapsedTime(System.currentTimeMillis() - startTime);

      trackAction(trackingEntity);
    }
  }

  private SettingEntity createChangedSetting(long time) {
    SettingEntity entity = new SettingEntity();
    entity.setParaCode(ConfigLoader.KEY_CONFIG_TIME);
    entity.setParaValue(String.valueOf(time));
    // varchar
    entity.setDataType(1);
    entity.setDescription("Reload configuration when this time is changed.");
    return entity;
  }

  private boolean saveSettings(List<SettingEntity> settingList) {
    if (settingList == null || settingList.size() == 0) {
      return false;
    }
    List<QueryExecutor> listQuery = new ArrayList<QueryExecutor>();
    Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
    String loginUser =
        WRequest.getCurrentInstance().getUserProfile().getAttribute("liotrox.user");
    for (SettingEntity setting : settingList) {
      setting.setUpdatedBy(loginUser);
      setting.setUpdatedOn(currentTime);
      listQuery.add(new EntityExecutor(QueryExecutor.UPDATE_ENTITY, setting));
    }
    SettingEntity changedEntity = createChangedSetting(currentTime.getTime());
    changedEntity.setUpdatedBy(loginUser);
    changedEntity.setUpdatedOn(currentTime);
    listQuery.add(new EntityExecutor(QueryExecutor.UPDATE_ENTITY, changedEntity));

    try {
      SCWebServiceFactory.getScBaseService().executeMultipleQuery(listQuery);

      infoMessage = CommonUtils.getAdminBundleMessage("update_successful");

      // Reload configuration
      final Map<String, Object> map = SCWebServiceFactory.getSettingService().loadAll();
      ConfigLoader.getInstance().reload(map, null);
    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
      errorMessage = CommonUtils.getAdminBundleMessage("error_saving_setting");
      return false;
    }
    return true;
  }

  private String createChangedString() {
    SettingService setting = SCWebServiceFactory.getSettingService();

    Map<String, Object> mapValues = setting.loadAll();
    SettingDTO oldSetting = new SettingDTO();
    oldSetting.initValues(mapValues);
    settingDto.setOldEmailPassword(oldSetting.getEmailPassword());
    
    // STDF folder
    StdfFolderSetting oldStdfFolder = new StdfFolderSetting();
    oldStdfFolder.initValues(mapValues, StdfFolderSetting.STDF_TYPE);
    stdfFolder.setOldEncryptedPassword(oldStdfFolder.getPassword());
    // STDF archive folder
    StdfFolderSetting oldStdfArchiveFolder = new StdfFolderSetting();
    oldStdfArchiveFolder.initValues(mapValues, StdfFolderSetting.STDF_ARCHIVE_TYPE);
    stdfArchiveFolder.setOldEncryptedPassword(oldStdfArchiveFolder.getPassword());
    // STDF error folder
    StdfFolderSetting oldStdfErrorFolder = new StdfFolderSetting();
    oldStdfErrorFolder.initValues(mapValues, StdfFolderSetting.STDF_ERROR_TYPE);
    stdfErrorFolder.setOldEncryptedPassword(oldStdfErrorFolder.getPassword());
    // Fail values
    StdfFolderSetting oldFailValuesFolder = new StdfFolderSetting();
    oldFailValuesFolder.initValues(mapValues, StdfFolderSetting.FAIL_VALUES_FOLDER_TYPE);
    failValuesFolder.setOldEncryptedPassword(oldFailValuesFolder.getPassword());

    StringBuilder builder = new StringBuilder();
    createChangedValuesOfGeneralSetting(oldSetting, builder);
    // STDF
    createChangedValuesOfStdfFolder(oldStdfFolder, stdfFolder, "STDF", builder);
    // STDF archive
    createChangedValuesOfStdfFolder(oldStdfArchiveFolder, stdfArchiveFolder, "STDF Archive",
        builder);
    // STDF error
    createChangedValuesOfStdfFolder(oldStdfErrorFolder, stdfErrorFolder, "STDF Error", builder);

    // Fail values folder.
    createChangedValuesOfStdfFolder(oldFailValuesFolder, failValuesFolder, "Failed Values",
        builder);
    return builder.toString();
  }

  private void createChangedValuesOfGeneralSetting(SettingDTO oldSetting, StringBuilder builder) {
    final String connector = ";";
    if (!settingDto.getDefaultAlarmThreshold().equals(oldSetting.getDefaultAlarmThreshold())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Default AlarmThreshold: OldValue=")
          .append(oldSetting.getDefaultAlarmThreshold()).append(", NewValue=")
          .append(settingDto.getDefaultAlarmThreshold());
    }
    if (!settingDto.getScanFileInterval().equals(oldSetting.getScanFileInterval())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Scan Interval Time: OldValue=").append(oldSetting.getScanFileInterval())
          .append(", NewValue=").append(settingDto.getScanFileInterval());
    }
    if (!settingDto.getPlantCode().equals(oldSetting.getPlantCode())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Plant Code: OldValue=").append(oldSetting.getPlantCode())
          .append(", NewValue=").append(settingDto.getPlantCode());
    }
    if (!settingDto.getCompress().equals(oldSetting.getCompress())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Compress: OldValue=").append(oldSetting.getCompress())
          .append(", NewValue=").append(settingDto.getCompress());
    }
    if (!settingDto.getMaxNumFileNotify().equals(oldSetting.getMaxNumFileNotify())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Max number of files notified: OldValue=")
          .append(oldSetting.getMaxNumFileNotify()).append(", NewValue=")
          .append(settingDto.getMaxNumFileNotify());
    }
    if (!settingDto.getLimitFailedValues().equals(oldSetting.getLimitFailedValues())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Limit number of failed value: OldValue=")
          .append(oldSetting.getLimitFailedValues()).append(", NewValue=")
          .append(settingDto.getLimitFailedValues());
    }
    if (!settingDto.getUmUrl().equals(oldSetting.getUmUrl())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("UM Url: OldValue=").append(oldSetting.getUmUrl()).append(", NewValue=")
          .append(settingDto.getUmUrl());
    }
    if (!settingDto.getCompliancyScoreRangeTo().equals(oldSetting.getCompliancyScoreRangeTo())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Max number of compliancy score: OldValue=")
          .append(oldSetting.getCompliancyScoreRangeTo()).append(", NewValue=")
          .append(settingDto.getCompliancyScoreRangeTo());
    }
    if (checkDifferrent(settingDto.getOnlineReportTime(), oldSetting.getOnlineReportTime())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("The offline report time range, unit is day: OldValue=")
          .append(oldSetting.getOnlineReportTime()).append(", NewValue=")
          .append(settingDto.getOnlineReportTime());
    }
    if (checkDifferrent(settingDto.getMaxRowDataView(), oldSetting.getMaxRowDataView())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("The max row on dataview: OldValue=")
          .append(oldSetting.getMaxRowDataView()).append(", NewValue=")
          .append(settingDto.getMaxRowDataView());
    }
    if (checkDifferrent(settingDto.getApcdHost(), oldSetting.getApcdHost())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("APCD Host: OldValue=").append(oldSetting.getApcdHost())
          .append(", NewValue=").append(settingDto.getApcdHost());
    }
    if (!settingDto.getApcdPort().equals(oldSetting.getApcdPort())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("APCD Port: OldValue=").append(oldSetting.getApcdPort())
          .append(", NewValue=").append(settingDto.getApcdPort());
    }
    if (!settingDto.getApcdMailbox().equals(oldSetting.getApcdMailbox())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("APCD Mailbox: OldValue=").append(oldSetting.getApcdMailbox())
          .append(", NewValue=").append(settingDto.getApcdMailbox());
    }
    if (!settingDto.getApcdMbx().equals(oldSetting.getApcdMbx())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("APCD Mbx: OldValue=").append(oldSetting.getApcdMbx())
          .append(", NewValue=").append(settingDto.getApcdMbx());
    }

    // Email setting
    createChangedValuesOfEmailSetting(oldSetting, builder);
  }

  private void createChangedValuesOfEmailSetting(SettingDTO oldSetting, StringBuilder builder) {
    final String connector = ";";
    if (checkDifferrent(settingDto.getEmailFrom(), oldSetting.getEmailFrom())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email From: OldValue=").append(oldSetting.getEmailFrom())
          .append(", NewValue=").append(settingDto.getEmailFrom());
    }
    if (checkDifferrent(settingDto.getEmailAdmin(), oldSetting.getEmailAdmin())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email Admin: OldValue=").append(oldSetting.getEmailAdmin())
          .append(", NewValue=").append(settingDto.getEmailAdmin());
    }
    if (checkDifferrent(settingDto.getEmailSubject(), oldSetting.getEmailSubject())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email Subject: OldValue=").append(oldSetting.getEmailSubject())
          .append(", NewValue=").append(settingDto.getEmailSubject());
    }
    if (checkDifferrent(settingDto.getEmailHost(), oldSetting.getEmailHost())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email Host: OldValue=").append(oldSetting.getEmailHost())
          .append(", NewValue=").append(settingDto.getEmailHost());
    }
    if (checkDifferrent(settingDto.getEmailPort(), oldSetting.getEmailPort())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email Port: OldValue=").append(oldSetting.getEmailPort())
          .append(", NewValue=").append(settingDto.getEmailPort());
    }
    if (checkDifferrent(settingDto.getEmailUsername(), oldSetting.getEmailUsername())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email User name: OldValue=").append(oldSetting.getEmailUsername())
          .append(", NewValue=").append(settingDto.getEmailUsername());
    }
    if (checkDifferrent(settingDto.getEmailPassword(), oldSetting.getEmailPassword())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email Password: OldValue=").append(oldSetting.getEmailPassword())
          .append(", NewValue=").append(settingDto.getEmailPassword());
    }
    if (checkDifferrent(settingDto.getEmailProtocol(), oldSetting.getEmailProtocol())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Email Protocol: OldValue=").append(oldSetting.getEmailProtocol())
          .append(", NewValue=").append(settingDto.getEmailProtocol());
    }
  }

  private void createChangedValuesOfStdfFolder(StdfFolderSetting oldSetting,
      StdfFolderSetting newSetting, String stdftype, StringBuilder builder) {
    final String connector = ";";
    if (!newSetting.getFolderPath().equals(oldSetting.getFolderPath())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append(stdftype).append(" Folder Path: OldValue=")
          .append(oldSetting.getFolderPath()).append(", NewValue=")
          .append(newSetting.getFolderPath());
    }
    if (newSetting.getFolderDepth() != null
        && !newSetting.getFolderDepth().equals(oldSetting.getFolderDepth())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append(stdftype).append(" Folder Depth: OldValue=")
          .append(oldSetting.getFolderDepth()).append(", NewValue=")
          .append(newSetting.getFolderDepth());
    }
    if (!newSetting.getFolderType().equals(oldSetting.getFolderType())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append(stdftype).append(" Folder Type: OldValue=")
          .append(oldSetting.getFolderType()).append(", NewValue=")
          .append(newSetting.getFolderType());
    }
    if (!newSetting.getFileType().equals(oldSetting.getFileType())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append(stdftype).append(" File Type: OldValue=")
          .append(oldSetting.getFileType()).append(", NewValue=")
          .append(newSetting.getFileType());
    }
    if ("FTP".equals(newSetting.getFolderType()) || "SFTP".equals(newSetting.getFolderType())) {
      if (!newSetting.getHost().equals(oldSetting.getHost())) {
        if (builder.length() > 0) {
          builder.append(connector);
        }
        builder.append(stdftype).append(" Host: OldValue=").append(oldSetting.getHost())
            .append(", NewValue=").append(newSetting.getHost());
      }
      if (!newSetting.getPort().equals(oldSetting.getPort())) {
        if (builder.length() > 0) {
          builder.append(connector);
        }
        builder.append(stdftype).append(" Port: OldValue=").append(oldSetting.getPort())
            .append(", NewValue=").append(newSetting.getPort());
      }
      if (!newSetting.getUsername().equals(oldSetting.getUsername())) {
        if (builder.length() > 0) {
          builder.append(connector);
        }
        builder.append(stdftype).append(" User name: OldValue=")
            .append(oldSetting.getUsername()).append(", NewValue=")
            .append(newSetting.getUsername());
      }
      if (!newSetting.getPassword().equals(oldSetting.getPassword())) {
        if (builder.length() > 0) {
          builder.append(connector);
        }
        builder.append(stdftype).append(" Password: OldValue=")
            .append(oldSetting.getPassword()).append(", NewValue=")
            .append(newSetting.getPassword());
      }
    }
  }

  private String createPurgeChangedString() {
    SettingService setting = SCWebServiceFactory.getSettingService();

    Map<String, Object> mapValues = setting.loadAll();
    SettingDTO oldSetting = new SettingDTO();
    oldSetting.initValues(mapValues);

    StdfFolderSetting oldStdfArchiveFolder = new StdfFolderSetting();
    oldStdfArchiveFolder.initValues(mapValues, StdfFolderSetting.STDF_ARCHIVE_TYPE);

    StdfFolderSetting oldFailValuesFolder = new StdfFolderSetting();
    oldFailValuesFolder.initValues(mapValues, StdfFolderSetting.FAIL_VALUES_FOLDER_TYPE);

    StringBuilder builder = new StringBuilder();
    createChangedValuesOfPurgeSetting(oldSetting, builder);

    // STDF archive
    createChangedValuesPurgeOfStdfFolder(oldStdfArchiveFolder, stdfArchiveFolder,
        "STDF Archive", builder);

    // Fail values folder.
    createChangedValuesPurgeOfStdfFolder(oldFailValuesFolder, failValuesFolder,
        "Failed Values", builder);
    return builder.toString();
  }

  private void createChangedValuesOfPurgeSetting(SettingDTO oldSetting, StringBuilder builder) {
    final String connector = ";";
    if (checkDifferrent(settingDto.getPurgeIntervalTime(), oldSetting.getPurgeIntervalTime())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Purge Interval Time: OldValue=")
          .append(oldSetting.getPurgeIntervalTime()).append(", NewValue=")
          .append(settingDto.getPurgeIntervalTime());
    }
    if (checkDifferrent(settingDto.getPurgeIntervalUnit(), oldSetting.getPurgeIntervalUnit())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Purge Interval Time Unit: OldValue=")
          .append(oldSetting.getPurgeIntervalUnit()).append(", NewValue=")
          .append(settingDto.getPurgeIntervalUnit());
    }
    if (DAY_UNIT.equals(settingDto.getPurgeIntervalUnit())) {
      if (!settingDto.getPurgeStartTime().equals(oldSetting.getPurgeStartTime())) {
        if (builder.length() > 0) {
          builder.append(connector);
        }
        builder.append("Purge Start Time: OldValue=").append(oldSetting.getPurgeStartTime())
            .append(", NewValue=").append(settingDto.getPurgeStartTime());
      }
    }

    if (checkDifferrent(settingDto.getPurgeCompliancyResultExpiredTime(),
        oldSetting.getPurgeCompliancyResultExpiredTime())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Purge Compliancy_Result Expired Time: OldValue=")
          .append(oldSetting.getPurgeCompliancyResultExpiredTime()).append(", NewValue=")
          .append(settingDto.getPurgeCompliancyResultExpiredTime());
    }
    if (checkDifferrent(settingDto.getPurgeParseFileStatusExpiredTime(),
        oldSetting.getPurgeParseFileStatusExpiredTime())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Purge STDF_FILE_STATUS Expired Time: OldValue=")
          .append(oldSetting.getPurgeParseFileStatusExpiredTime()).append(", NewValue=")
          .append(settingDto.getPurgeParseFileStatusExpiredTime());
    }
    if (checkDifferrent(settingDto.getPurgeHistoryExpiredTime(),
        oldSetting.getPurgeHistoryExpiredTime())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Purge CHANGE_HISTORY Expired Time: OldValue=")
          .append(oldSetting.getPurgeHistoryExpiredTime()).append(", NewValue=")
          .append(settingDto.getPurgeHistoryExpiredTime());
    }
    if (checkDifferrent(settingDto.getPurgeOfflineReportExpiredTime(),
        oldSetting.getPurgeOfflineReportExpiredTime())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append("Purge OFFLINE_REPORT Expired Time: OldValue=")
          .append(oldSetting.getPurgeOfflineReportExpiredTime()).append(", NewValue=")
          .append(settingDto.getPurgeOfflineReportExpiredTime());
    }
  }

  private void createChangedValuesPurgeOfStdfFolder(StdfFolderSetting oldSetting,
      StdfFolderSetting newSetting, String stdftype, StringBuilder builder) {
    final String connector = ";";
    if (newSetting.getFolderDepth() != null
        && !newSetting.getFolderDepth().equals(oldSetting.getFolderDepth())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append(stdftype).append(" Folder Depth: OldValue=")
          .append(oldSetting.getFolderDepth()).append(", NewValue=")
          .append(newSetting.getFolderDepth());
    }
    if (!newSetting.getExpiredTimePurge().equals(oldSetting.getExpiredTimePurge())) {
      if (builder.length() > 0) {
        builder.append(connector);
      }
      builder.append(stdftype).append(" Folder Expired Time: OldValue=")
          .append(oldSetting.getExpiredTimePurge()).append(", NewValue=")
          .append(newSetting.getExpiredTimePurge());
    }

  }

  public void doShowChangeHistory(WRequest request, Event event) {
    final JPABaseService<ActionTrackingEntity> service =
        new JPABaseService<ActionTrackingEntity>();
    service.setEntityManagerFactory(SCWebServiceFactory.getScEntityManagerFactory());

    final Number maxRow =
        (Number) ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getValue(
            ConfigLoader.KEY_MAX_ROW_ON_DATAVIEW);
    int maxResult = -1;
    if (maxRow != null) {
      maxResult = maxRow.intValue();
    }
    int size = 0;

    final List<ActionTrackingEntity> list =
        service.queryList(ActionTrackingEntity.SELECT_ALL_ORDER_BY_ID, null, -1, maxResult);
    if (list != null && list.size() > 0) {
      List<ActionTrackingDTO> dtos = new ArrayList<ActionTrackingDTO>(list.size());
      for (ActionTrackingEntity e : list) {
        if (e != null) {
          dtos.add(new ActionTrackingDTO(e));
        }
      }
      size = dtos.size();
      changeHistoryDataSet = createDataSet(dtos);
    }
    getChangeHistoryDataView().getModel().setDataSet(changeHistoryDataSet);
    if (maxResult != -1 && size >= maxResult) {
      final String value =
          "<span style=\"color: navy; font-weight: bold;\">"
              + CommonUtils.getAdminBundleMessage("msg_show_num_lastest_records_history",
                  new Object[]{size }) + "</span>";
      getChangeHistoryDataView().setHeader(value);
    } else {
      getChangeHistoryDataView().setHeader(null);
    }
  }

  private DataView getChangeHistoryDataView() {
    if (changeHistoryDV == null) {
      changeHistoryDV = getDataViewFromRequest("changeHistoryDataView");
    }
    return changeHistoryDV;
  }

  /**
   * Check 2 object differrent.
   * 
   * @param ob1
   * @param ob2
   * @return true if different
   */
  private boolean checkDifferrent(Object ob1, Object ob2) {
    // change empty string to null.
    // Because values submitted from client is empty, in DB is null.
    if (ob1 instanceof String && ob1 != null && ((String) ob1).length() == 0) {
      ob1 = null;
    }
    if (ob2 instanceof String && ob2 != null && ((String) ob2).length() == 0) {
      ob2 = null;
    }
    if ((ob1 == null && ob2 != null) || (ob1 != null && !ob1.equals(ob2))) {
      return true;
    }
    return false;
  }

  /**
   * @return the settingDto
   */
  public SettingDTO getSettingDto() {
    return settingDto;
  }

  /**
   * @param settingDto
   *          the settingDto to set
   */
  public void setSettingDto(SettingDTO settingDto) {
    this.settingDto = settingDto;
  }

  /**
   * @return the stdfFolder
   */
  public StdfFolderSetting getStdfFolder() {
    return stdfFolder;
  }

  /**
   * @param stdfFolder
   *          the stdfFolder to set
   */
  public void setStdfFolder(StdfFolderSetting stdfFolder) {
    this.stdfFolder = stdfFolder;
  }

  /**
   * @return the stdfArchiveFolder
   */
  public StdfFolderSetting getStdfArchiveFolder() {
    return stdfArchiveFolder;
  }

  /**
   * @param stdfArchiveFolder
   *          the stdfArchiveFolder to set
   */
  public void setStdfArchiveFolder(StdfFolderSetting stdfArchiveFolder) {
    this.stdfArchiveFolder = stdfArchiveFolder;
  }

  /**
   * @return the stdfErrorFolder
   */
  public StdfFolderSetting getStdfErrorFolder() {
    return stdfErrorFolder;
  }

  /**
   * @param stdfErrorFolder
   *          the stdfErrorFolder to set
   */
  public void setStdfErrorFolder(StdfFolderSetting stdfErrorFolder) {
    this.stdfErrorFolder = stdfErrorFolder;
  }

  /**
   * @return the changeHistoryDataSet
   */
  public DataSet getChangeHistoryDataSet() {
    return changeHistoryDataSet;
  }

  /**
   * @param changeHistoryDataSet
   *          the changeHistoryDataSet to set
   */
  public void setChangeHistoryDataSet(DataSet changeHistoryDataSet) {
    this.changeHistoryDataSet = changeHistoryDataSet;
  }

  /**
   * @return the failValuesFolder
   */
  public StdfFolderSetting getFailValuesFolder() {
    return failValuesFolder;
  }

  /**
   * @param failValuesFolder
   *          the failValuesFolder to set
   */
  public void setFailValuesFolder(StdfFolderSetting failValuesFolder) {
    this.failValuesFolder = failValuesFolder;
  }

}
