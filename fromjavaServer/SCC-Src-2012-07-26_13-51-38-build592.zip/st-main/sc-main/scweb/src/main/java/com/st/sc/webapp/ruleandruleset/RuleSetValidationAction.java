/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Dec 6, 2011 10:51:16 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.ruleandruleset;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.db.DataSet;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.fileaccess.FileScanner;
import com.st.common.fileaccess.FileScannerFactory;
import com.st.common.web.util.ServletUtils;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.FileDTO;
import com.st.sc.webapp.BaseAction;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleSetValidationAction extends BaseAction {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(RuleSetValidationAction.class);

  private DataSet scanedFileDataSet;
  private DataView fileDV;
  private RuleSetVersion ruleSetVersion = new RuleSetVersion();

  private String scanFolder;
  private String scanFolderType;

  private String host;
  private String username;
  private String password;
  private int port;
  /**
   * Flag indicate beginning of validation, show popup dialog.
   */
  private Boolean beginValidate;
  private String selectedStdf;

  private static final int MAX_DEEPTH_FOLDER = 0;
  private static final int MAX_NUM_FILES = 10000;

  public String[] getFolderTypeList() {
    return new String[]{"NFS", "FTP", "SFTP" };
  }

  public void doShow(WRequest request, Event event) {
    clearErrorMsg();

    String ruleSetVersionStr = request.getParameter(SCConstants.PARAMETER_RULE_SET_VERSION_ID);
    if (ruleSetVersionStr != null) {
      ruleSetVersion =
          SCWebServiceFactory.getScBaseService().queryByPrimaryKey(RuleSetVersion.class,
              Long.parseLong(ruleSetVersionStr));
    }
    if (ruleSetVersion == null) {
      errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");
    }
  }

  public DataView getDataView() {
    if (fileDV == null) {
      fileDV = getDataViewFromRequest("scanedFileDataView");
    }
    return fileDV;
  }

  private void clearErrorMsg() {
    errorMessage = "";
    beginValidate = Boolean.FALSE;
  }

  private List<FileInfo> scanFiles() {
    FileTypeEnum fileType = FileTypeEnum.fromValue(scanFolderType);
    FileScanner scanner = FileScannerFactory.create(fileType, host, username, password, port);
    if (scanner != null) {
      scanner.setMonitorFolder(scanFolder);
      List<String> patterns = new ArrayList<String>();
      patterns.add("\\.Z");
      patterns.add("\\.std[f]?"); // . it means any character
      scanner.setFilePatternList(patterns);
      return scanner.scan(scanFolder, MAX_DEEPTH_FOLDER, MAX_NUM_FILES);
    } else {
      errorMessage =
          CommonUtils.getBundleMessage(SCConstants.BUNDLE_VALIDATE_RULESET_NAME,
              "error_scan_files");
      return null;
    }
  }

  private List<FileDTO> createFileDTO(List<FileInfo> listFileInfo) {
    List<FileDTO> listDto = new ArrayList<FileDTO>();
    if (listFileInfo != null && listFileInfo.size() > 0) {
      int fileTypeIndex;
      for (FileInfo fileInfo : listFileInfo) {
        FileDTO dto = new FileDTO();
        dto.setFileName(fileInfo.getPathRootToFile());
        dto.setSize(fileInfo.getSize());
        dto.setModifiedTime(new Date(fileInfo.getLastModified()));
        // get tails of file
        fileTypeIndex = fileInfo.getPathRootToFile().indexOf(".");
        if (fileTypeIndex > -1) {
          dto.setFileType(fileInfo.getPathRootToFile().substring(fileTypeIndex + 1));
        }
        listDto.add(dto);
      }
    }
    return listDto;
  }

  public void doScanFiles(WRequest request, Event event) {
    clearErrorMsg();

    List<FileInfo> fileInfos = scanFiles();
    List<FileDTO> dtoList = createFileDTO(fileInfos);
    scanedFileDataSet = createDataSet(dtoList);
    getDataView().getModel().setDataSet(scanedFileDataSet);
  }

  public void doValidateRuleSetVersion(WRequest request, Event event) {
    clearErrorMsg();

    int[] selectedRows = getDataView().getSelectedRows();
    if (selectedRows.length != 1) {
      errorMessage = CommonUtils.getCommonBundleMessage("choose_one_record");
    } else {
      // validate data.
      String fileName =
          (String) getDataView().getModel().getDataSet().getValue(selectedRows[0], "fileName");

      if (!scanFolder.endsWith(File.separator)) {
        selectedStdf = scanFolder + File.separator + fileName;
      } else {
        selectedStdf = scanFolder + fileName;
      }
      LOG.info("Validation STDF file = " + selectedStdf);
      beginValidate = Boolean.TRUE;
      storeParametersToValidate(request);
    }
  }

  private void storeParametersToValidate(WRequest request) {
    // User may click validate different files at for each click, cannot store
    // file name in session.
    selectedStdf = ServletUtils.encodeUrlParam(selectedStdf);
    // rule set can store in session, it is get at
    // RuleSetValidationResultAction.doShow
    request.getSession().setAttribute(SCConstants.KEY_RULESET_VALIDATION_VERSION,
        ruleSetVersion);
  }

  /**
   * @return the scanFolder
   */
  public String getScanFolder() {
    return scanFolder;
  }

  /**
   * @param scanFolder
   *          the scanFolder to set
   */
  public void setScanFolder(String scanFolder) {
    this.scanFolder = scanFolder;
  }

  /**
   * @return the scanFolderType
   */
  public String getScanFolderType() {
    return scanFolderType;
  }

  /**
   * @param scanFolderType
   *          the scanFolderType to set
   */
  public void setScanFolderType(String scanFolderType) {
    this.scanFolderType = scanFolderType;
  }

  /**
   * @return the scanedFileDataSet
   */
  public DataSet getScanedFileDataSet() {
    return scanedFileDataSet;
  }

  /**
   * @return the ruleSetVersion
   */
  public RuleSetVersion getRuleSetVersion() {
    return ruleSetVersion;
  }

  /**
   * @param ruleSetVersion
   *          the ruleSetVersion to set
   */
  public void setRuleSetVersion(RuleSetVersion ruleSetVersion) {
    this.ruleSetVersion = ruleSetVersion;
  }

  /**
   * @return the host
   */
  public String getHost() {
    return host;
  }

  /**
   * @param host
   *          the host to set
   */
  public void setHost(String host) {
    this.host = host;
  }

  /**
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * @param username
   *          the username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @param password
   *          the password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * @return the port
   */
  public int getPort() {
    return port;
  }

  /**
   * @param port
   *          the port to set
   */
  public void setPort(int port) {
    this.port = port;
  }

  /**
   * @return the beginValidate
   */
  public Boolean getBeginValidate() {
    return beginValidate;
  }
  /**
   * Need setter to set this variable from client.
   * @param value
   */
  public void setBeginValidate(Boolean value) {
    beginValidate = value;
  }
  
  /**
   * @return the selectedStdf
   */
  public String getSelectedStdf() {
    return selectedStdf;
  }
  
}
