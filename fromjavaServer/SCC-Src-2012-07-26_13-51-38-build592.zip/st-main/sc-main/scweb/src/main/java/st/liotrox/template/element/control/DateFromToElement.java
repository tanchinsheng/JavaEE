/**
 * 
 */
package st.liotrox.template.element.control;

import st.liotrox.LIOTROX;
import st.liotrox.WRequest;
import st.liotrox.template.TemplateException;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.web.html.WriteHTML;

import com.st.sc.common.CommonUtils;

/**
 * @author nhatvn
 */
public class DateFromToElement extends CustomElement {

  private static final String ATTRIBUTE_FROM_DATE = "fromDate";
  private static final String ATTRIBUTE_TO_DATE = "toDate";
  private static final String ATTRIBUTE_FORMAT = "format";
  private static final String ATTRIBUTE_RADIO_NAME = "radioName";
  private static final String ATTRIBUTE_RADIO_VALUE = "radioValue";
  private static final String ATTRIBUTE_CHECKED_VALUE = "checkedValue";
  private static final String ATTRIBUTE_RADIO_MOUSE_DOWN = "radioMousedown";

  public void validate() throws TemplateException {
    super.validate();
    StringBuilder builder = new StringBuilder();
    String fromDate = getAttribute(ATTRIBUTE_FROM_DATE);
    if (fromDate == null) {
      builder.append("Must specify 'fromDate' attribute.");
    }
    String todate = getAttribute(ATTRIBUTE_TO_DATE);
    if (todate == null) {
      builder.append("Must specify 'toDate' attribute.");
    }
    String radioName = getAttribute(ATTRIBUTE_RADIO_NAME);
    if (radioName == null) {
      builder.append("Must specify 'radioName' attribute, it is name of radio.");
    }
    if (builder.length() > 0) {
      raiseException(builder.toString());
    }
  }

  @Override
  public void writeContent(final WRequest request, final FastStringBuffer fs) {
    String label = getLabel(request);
    String name = getName(request);
    String format = resolveAttributeAsString(request, ATTRIBUTE_FORMAT);
    if (format == null) {
      format = LIOTROX.getApplication().getApplicationSettings().getDateFormat();
    }
    String classCss = getClassCss(request);
    String radioName = resolveAttributeAsString(request, ATTRIBUTE_RADIO_NAME);
    String radioMouseDown = resolveAttributeAsString(request, ATTRIBUTE_RADIO_MOUSE_DOWN);
    String radioValue = resolveAttributeAsString(request, ATTRIBUTE_RADIO_VALUE);
    String checkedValue = resolveAttributeAsString(request, ATTRIBUTE_CHECKED_VALUE);
    int labelLength = getLabelLength(request);
    //Start table
    writeTableStartWithLabelLength(fs, labelLength);
    // write label.
    writeLabel(fs, label);
    WriteHTML.Table.cellEnd(fs);
    
    WriteHTML.Table.cellStart(fs);
    // Write radio button.
    writeRadio(fs, radioName, radioValue, checkedValue, radioMouseDown);

    fs.append(CommonUtils.getCommonBundleMessage("report_from_lb"));
    writeWhiteSpace(fs);
    String fromName = name + "From";
    String from = resolveAttributeAsString(request, ATTRIBUTE_FROM_DATE);
    DateControlUtils.writeDateControl(getPage(), request, fs, fromName, from, classCss,
        format, label + " From");
    WriteHTML.Table.cellEnd(fs);
    
    WriteHTML.Table.cellStart(fs);
    // write to element
    fs.append(CommonUtils.getCommonBundleMessage("report_to_lb"));
    writeWhiteSpace(fs);
    String toName = name + "To";
    String to = resolveAttributeAsString(request, ATTRIBUTE_TO_DATE);
    DateControlUtils.writeDateControl(getPage(), request, fs, toName, to, classCss, format,
        label + " To");
    WriteHTML.Table.cellEnd(fs);
    
    //End table
    writeTableClose(fs);
  }

}
