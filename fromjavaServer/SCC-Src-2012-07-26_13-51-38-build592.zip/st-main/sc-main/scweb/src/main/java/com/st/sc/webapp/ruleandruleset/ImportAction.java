/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 16, 2012 2:07:49 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.ruleandruleset;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.template.element.control.UploadItem;

import com.st.persistence.entity.ActionTrackingEntity;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleOwners;
import com.st.sc.entity.RuleSet;
import com.st.sc.entity.RuleSetOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleValue;
import com.st.sc.entity.RuleVersion;
import com.st.sc.entity.RulesOfRS;
import com.st.sc.entity.util.Util;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.rulemanager.EntityExecutor;
import com.st.sc.rulemanager.QueryExecutor;
import com.st.sc.rulemanager.RuleService;
import com.st.sc.rulemanager.RuleSetService;
import com.st.sc.rulemanager.serialization.rule.TRule;
import com.st.sc.rulemanager.serialization.rule.TRuleSet;
import com.st.sc.rulemanager.util.RuleHelper;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.webapp.BaseAction;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class ImportAction extends BaseAction {

  private static final Logger LOGGER = LoggerFactory.getLogger(ImportAction.class);

  private UploadItem infoUpload = null;
  private String importType;
  private static final String RULE_SET_TYPE = "RuleSet";
  private static final String RULE_TYPE = "Rule";
  private static final String ADDED_SUFFIX = "_1";
  /**
   * Key is used to store in session.
   */
  private static final String IMPORTED_RULE_SET_KEY = "IMPORTED_RULE_SET_KEY";
  private static final String IMPORTED_RULES_OF_RULE_SET_KEY =
      "IMPORTED_RULES_OF_RULE_SET_KEY";
  private static final String IMPORTED_RULES_KEY = "IMPORTED_RULES_KEY";
  private static final String RULE_SET_UPLOADED_FILE_NAME_KEY =
      "RULE_SET_UPLOADED_FILE_NAME_KEY";
  private static final String RULE_UPLOADED_FILE_NAME_KEY = "RULE_UPLOADED_FILE_NAME_KEY";

  /**
   * Error message in case: a user which is not Admin import a ruleset with all
   * MIR fields empty.
   */
  private String errorImportRuleSetHaveEmptyMIR;
  /**
   * The time to read file, store to tracking action log.
   */
  private long readFileTime;
  /**
   * This flag used to specify when hide the import button, stop import here.
   */
  private boolean stopImport;

  /**
   * List contains old names and new names of rule set which exists in DB.
   */
  private List<NameDTO> existedRuleSetNameList = new ArrayList<ImportAction.NameDTO>();

  /**
   * List contains old names and new names of rule which exists in DB.
   */
  private List<NameDTO> existedRuleNameList = new ArrayList<ImportAction.NameDTO>();

  /**
   * Return uploaded file name.
   * 
   * @return uploaded file name.
   */
  public String getFileName() {
    WRequest currentRequest = WRequest.getCurrentInstance();
    if (infoUpload == null) {
      String fileName = null;
      if (isImportRuleSet()) {
        fileName =
            (String) currentRequest.getSession().getAttribute(RULE_SET_UPLOADED_FILE_NAME_KEY);
      }
      if (isImportRule()) {
        fileName =
            (String) currentRequest.getSession().getAttribute(RULE_UPLOADED_FILE_NAME_KEY);
      }
      if (fileName == null) {
        return "No file is uploaded";
      } else {
        return fileName;
      }
    }
    String fileName = infoUpload.getFileName();
    // store file name in session.
    if (isImportRuleSet()) {
      currentRequest.getSession().setAttribute(RULE_SET_UPLOADED_FILE_NAME_KEY, fileName);
    }
    if (isImportRule()) {
      currentRequest.getSession().setAttribute(RULE_UPLOADED_FILE_NAME_KEY, fileName);
    }
    return fileName;
  }

  public Integer getNumberExistRuleSetName() {
    if (existedRuleSetNameList == null || existedRuleSetNameList.size() == 0) {
      return null;
    }
    return existedRuleSetNameList.size();
  }

  public Integer getNumberExistRuleName() {
    if (existedRuleNameList == null || existedRuleNameList.size() == 0) {
      return null;
    }
    return existedRuleNameList.size();
  }

  /**
   * Return uploaded file content as string.
   * 
   * @return uploaded file content as string.
   */
  public byte[] getContentFile() {
    byte[] bytes = new byte[0];
    InputStream in = null;
    String path = infoUpload.getFile().getAbsolutePath();
    File f = new File(path);
    try {
      ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
      byte[] buff = new byte[8192];
      in = new BufferedInputStream(new FileInputStream(f));
      int len = 0;
      while ((len = in.read(buff)) != -1) {
        byteStream.write(buff, 0, len);
      }
      byteStream.flush();
      bytes = byteStream.toByteArray();
      byteStream.close();
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    } finally {
      if (in != null) {
        try {
          in.close();
        } catch (IOException e) {
          LOGGER.error(e.getMessage(), e);
        }
      }
      // delete temp uploaded file
      f.delete();
    }
    return bytes;
  }

  private void clearErrorMsg() {
    existedRuleNameList = new ArrayList<ImportAction.NameDTO>();
    existedRuleSetNameList = new ArrayList<ImportAction.NameDTO>();
    errorMessage = infoMessage = "";
    stopImport = false;
  }

  private void clearRuleSetSession(WRequest request) {
    if (isImportRuleSet()) {
      request.getSession().removeAttribute(IMPORTED_RULE_SET_KEY);
      request.getSession().removeAttribute(IMPORTED_RULES_OF_RULE_SET_KEY);
      request.getSession().removeAttribute(RULE_SET_UPLOADED_FILE_NAME_KEY);
    }
  }

  private void clearRuleSession(WRequest request) {
    if (isImportRule()) {
      request.getSession().removeAttribute(IMPORTED_RULES_KEY);
      request.getSession().removeAttribute(RULE_UPLOADED_FILE_NAME_KEY);
    }
  }

  public void doShow(WRequest request, Event event) {
    importType = request.getParameter("importtype");
    // just clear this message when do show.
    errorImportRuleSetHaveEmptyMIR = "";
    clearErrorMsg();
    // clear data in session
    clearRuleSetSession(request);
    clearRuleSession(request);
  }

  public void doImportData(WRequest request, Event event) {
    clearErrorMsg();
    doImportRuleSet(request);
    doImportRule(request);
  }

  private void doImportRuleSet(WRequest request) {
    if (isImportRuleSet()) {
      // click first time to upload.
      if (infoUpload != null) {
        boolean success = readRuleSetFromFile(request);
        if (!success) {
          return;
        }
        List<RuleSet> ruleSetList =
            (List<RuleSet>) request.getSession().getAttribute(IMPORTED_RULE_SET_KEY);
        if (ruleSetList != null && ruleSetList.size() == 0) {
          // No rule set to be import
          // This case occurred when user is not Admin and all Rule set version
          // have all MIR empty.
          errorMessage = errorImportRuleSetHaveEmptyMIR;
          stopImport = true;
          return;
        }
        // check rule set name whether exist
        checkNameOfRuleSetAndRule(ruleSetList);

        // If existed rule sets and rules list is empty,
        // all rules and rule sets are inputed new values.
        if ((existedRuleSetNameList == null || existedRuleSetNameList.size() == 0)
            && (existedRuleNameList == null || existedRuleNameList.size() == 0)) {
          insertRuleSets(ruleSetList);
        }
      } else {
        // After generating GUI to input new rule set and rule name, submit
        // data.
        List<RuleSet> ruleSetList =
            (List<RuleSet>) request.getSession().getAttribute(IMPORTED_RULE_SET_KEY);
        if (ruleSetList == null) {
          // No file is uploaded.
          return;
        }
        // get values inputed from request.
        getDataFromRequest(request);

        fillInputedNameToRuleSet(ruleSetList);
        // get import rule list from session
        List<Rule> ruleList =
            (List<Rule>) WRequest.getCurrentInstance().getSession()
                .getAttribute(IMPORTED_RULES_OF_RULE_SET_KEY);
        fillInputedNameToRule(ruleList);
        // If existed rule sets and rules list is empty,
        // all rules and rule sets are inputed new values.
        if ((existedRuleSetNameList == null || existedRuleSetNameList.size() == 0)
            && (existedRuleNameList == null || existedRuleNameList.size() == 0)) {
          insertRuleSets(ruleSetList);
        } else {
          errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_name_exist_input_again");
        }
      }
    }
  }

  private void doImportRule(WRequest request) {
    if (isImportRule()) {
      // click first time to upload.
      if (infoUpload != null) {
        boolean success = readRuleFromFile(request);
        if (!success) {
          return;
        }
        List<Rule> ruleList =
            (List<Rule>) request.getSession().getAttribute(IMPORTED_RULES_KEY);
        // check rule name whether exist in DB.
        checkNameOfRules(ruleList);

        if (existedRuleNameList == null || existedRuleNameList.size() == 0) {
          insertRules(ruleList);
        }
      } else {
        // After generating GUI to input new rule set and rule name, submit
        // data.
        // get import rule list from session
        List<Rule> ruleList =
            (List<Rule>) request.getSession().getAttribute(IMPORTED_RULES_KEY);
        if (ruleList == null) {
          // No file is uploaded.
          return;
        }
        getDataFromRequest(request);

        fillInputedNameToRule(ruleList);
        // If existed rule sets and rules list is empty,
        // all rules and rule sets are inputed new values.
        if (existedRuleNameList == null || existedRuleNameList.size() == 0) {
          insertRules(ruleList);
        } else {
          errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_name_exist_input_again");
        }
      }
    }
  }

  private boolean readRuleSetFromFile(WRequest request) {
    long startTime = System.currentTimeMillis();
    byte[] data = getContentFile();
    if (data == null) {
      errorMessage = "There is a error when reading file.";
      return false;
    }
    try {
      TRuleSet[] ruleSetObjects = RuleHelper.toRuleSetArray(data);
      if (ruleSetObjects != null && ruleSetObjects.length > 0) {
        List<RuleSet> ruleSetList = new ArrayList<RuleSet>();
        List<RuleSetVersion> ruleSetVesionList = null;
        String role = request.getUserProfile().getAttribute("liotrox.role");
        boolean isNotAdmin = false;
        if (!"admin".equals(role)) {
          isNotAdmin = true;
        }
        for (TRuleSet tRuleSet : ruleSetObjects) {
          RuleSet ruleSet = RuleHelper.convertToEntity(tRuleSet);
          if (ruleSet != null) {
            // Check role of user, if user is not administrator and rule set
            // version have no MIR criteria, do not permit import.
            if (isNotAdmin) {
              // check on each version of rule set.
              ruleSetVesionList = new ArrayList<RuleSetVersion>();
              for (RuleSetVersion rsv : ruleSet.getRuleSetVersions()) {
                if (Util.countMirCriteria(rsv.getMirCriteria()) > 0) {
                  ruleSetVesionList.add(rsv);
                }
              }
              if (ruleSetVesionList.size() < ruleSet.getRuleSetVersions().size()) {
                errorImportRuleSetHaveEmptyMIR =
                    CommonUtils.getRuleSetBundleMessage("rule_set_mir_empty_cannot_import");
              }
              // add version of rule set which have MIR criteria.
              if (ruleSetVesionList.size() > 0) {
                ruleSet.setRuleSetVersions(ruleSetVesionList);
                ruleSetList.add(ruleSet);
              }

            } else {
              ruleSetList.add(ruleSet);
            }
          } else {
            String errorMsg = "Cannot convert entity from TRuleSet to RuleSet.";
            LOGGER.error(errorMsg);
            errorMessage = errorMsg;
            return false;
          }
        }
        // STORE OBJECT TO SESSION
        request.getSession().setAttribute(IMPORTED_RULE_SET_KEY, ruleSetList);
      } else {
        errorMessage = "Error when serializing data. File format might be wrong.";
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = "Error when serializing data. File format might be wrong.";
    }
    if (errorMessage != null && errorMessage.length() > 0) {
      return false;
    }
    readFileTime = System.currentTimeMillis() - startTime;
    return true;
  }

  private boolean readRuleFromFile(WRequest request) {
    long startTime = System.currentTimeMillis();
    byte[] data = getContentFile();
    if (data == null) {
      errorMessage = "There is a error when reading file.";
      return false;
    }
    try {
      TRule[] ruleObjects = RuleHelper.toRuleArray(data);
      if (ruleObjects != null && ruleObjects.length > 0) {
        List<Rule> ruleList = new ArrayList<Rule>();
        for (TRule tRule : ruleObjects) {
          Rule rule = RuleHelper.convertToEntity(tRule);
          if (rule != null) {
            ruleList.add(rule);
          } else {
            String errorMsg = "Cannot convert entity from TRule to Rule.";
            LOGGER.error(errorMsg);
            errorMessage = errorMsg;
            return false;
          }
        }
        // STORE OBJECT TO SESSION
        request.getSession().setAttribute(IMPORTED_RULES_KEY, ruleList);
      } else {
        errorMessage = "Error when serializing data. File format might be wrong.";
      }
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = "Error when serializing data. File format might be wrong.";
    }
    if (errorMessage != null && errorMessage.length() > 0) {
      return false;
    }
    readFileTime = System.currentTimeMillis() - startTime;
    return true;
  }

  /**
   * Check name of rule set and rule whether exists in DB.
   * 
   * @param ruleSetList
   */
  private void checkNameOfRuleSetAndRule(List<RuleSet> ruleSetList) {
    if (ruleSetList == null || ruleSetList.size() == 0) {
      return;
    }
    BaseService baseServ = SCWebServiceFactory.getScBaseService();
    RuleSetService ruleSetServ = new RuleSetService(baseServ);
    RuleService ruleServ = new RuleService(baseServ);
    List<Rule> importRuleList = new ArrayList<Rule>();
    long tempId = 1;
    for (RuleSet ruleSet : ruleSetList) {
      // check ruleSet name whether existed.
      RuleSet queryRuleSet = ruleSetServ.getRuleSetByName(ruleSet.getName());
      if (queryRuleSet != null) {
        existedRuleSetNameList.add(new NameDTO(ruleSet.getName(), ruleSet.getName()
            + ADDED_SUFFIX));
      }
      for (RuleSetVersion rsv : ruleSet.getRuleSetVersions()) {
        if (rsv.getRuleVersions() != null) {
          for (RuleVersion ruleVersion : rsv.getRuleVersions()) {
            Rule tmpRule =
                checkRuleExistInList(importRuleList, ruleVersion.getRule().getName());
            if (tmpRule == null) {
              // rule is not in list, must clear rule version list.
              ruleVersion.getRule().setRuleVersions(new ArrayList<RuleVersion>());
              ruleVersion.getRule().getRuleVersions().add(ruleVersion);
              // add this rule to rule list.
              importRuleList.add(ruleVersion.getRule());
              // create an unique id (not id in DB) to identify this rule when
              // import.
              ruleVersion.getRule().setRuleId(tempId++);
            } else {
              if (checkRuleVersionExistInList(tmpRule.getRuleVersions(),
                  ruleVersion.getVersion()) == null) {
                if (tmpRule.getRuleVersions() == null) {
                  tmpRule.setRuleVersions(new ArrayList<RuleVersion>());
                }
                tmpRule.getRuleVersions().add(ruleVersion);
              }
              // update references of rule version to this rule
              ruleVersion.setRule(tmpRule);
            }
            // check name of rule whether exists.
            Rule queryRule = ruleServ.getRuleByName(ruleVersion.getRule().getName());
            if (queryRule != null) {
              // name exists, must rename it.
              // add rule name to list which will be used to generate GUI to
              // input new rule name.
              if (!checkRuleNameExist(existedRuleNameList, ruleVersion.getRule().getName())) {
                existedRuleNameList.add(new NameDTO(ruleVersion.getRule().getName(),
                    ruleVersion.getRule().getName() + ADDED_SUFFIX));
              }
            }
          }
        }
      }
    }
    if (importRuleList.size() > 0) {
      WRequest.getCurrentInstance().getSession()
          .setAttribute(IMPORTED_RULES_OF_RULE_SET_KEY, importRuleList);
    }
  }

  /**
   * Insert data to DB.
   * 
   * @param ruleSetList
   */
  /**
   * @param ruleSetList
   */
  private void insertRuleSets(List<RuleSet> ruleSetList) {
    if (ruleSetList == null || ruleSetList.size() == 0) {
      return;
    }
    long startTime = System.currentTimeMillis();
    // get login user to be updated user of rule set.
    String loginUser =
        WRequest.getCurrentInstance().getUserProfile().getAttribute("liotrox.user");
    // Get imported rules which is filtered and stored in session.
    List<Rule> importRuleList =
        (List<Rule>) WRequest.getCurrentInstance().getSession()
            .getAttribute(IMPORTED_RULES_OF_RULE_SET_KEY);

    // generate ID in DB of rules
    List<Long> idList = new ArrayList<Long>(importRuleList.size());
    for (int i = 0; i < importRuleList.size(); i++) {
      // init data for list
      idList.add(0L);
    }

    for (Rule rule : importRuleList) {
      // get new rule id.
      Long newRuleId = SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE);
      // id of rule which is set when check name of rule (in function
      // checkNameOfRuleSetAndRule() )
      // is used as index of array, it is from 1.
      idList.set(rule.getRuleId().intValue() - 1, newRuleId);

      // generate ID in DB of rule version.
      for (RuleVersion ruleVersion : rule.getRuleVersions()) {
        // get new rule version id.
        Long newRuleVersionId =
            SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_VERSION);
        ruleVersion.setRuleVersionId(newRuleVersionId);

        ruleVersion.setRuleId(newRuleId);
        ruleVersion.setUpdatedBy(loginUser);

        // update ruleversion id for rule value list
        for (RuleValue ruleValue : ruleVersion.getRuleValueList()) {
          ruleValue.setRuleVersion(ruleVersion);
          ruleValue.getId().setRuleVersionId(newRuleVersionId);
        }
      }
      // update rule set id for rule set owners
      List<RuleOwners> owners = rule.getUserRules();
      if (owners == null) {
        owners = new ArrayList<RuleOwners>();
      }
      boolean ownerExist = false;
      for (RuleOwners ruleOwner : owners) {
        ruleOwner.getId().setRuleId(newRuleId);
        if (ruleOwner.getId().getUserName().equalsIgnoreCase(loginUser)) {
          ownerExist = true;
        }
      }
      if (!ownerExist) {
        owners.add(new RuleOwners(loginUser, newRuleId));
      }
    }
    StringBuilder trackingBuilder = new StringBuilder();
    List<RulesOfRS> listRulesOfRuleSet = new ArrayList<RulesOfRS>();
    for (RuleSet ruleSet : ruleSetList) {
      // get new rule set id.
      Long newRuleSetId =
          SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET);
      ruleSet.setRuleSetId(newRuleSetId);
      for (RuleSetVersion rsv : ruleSet.getRuleSetVersions()) {
        rsv.getRuleSet().setRuleSetId(newRuleSetId);
        rsv.setRuleSetId(newRuleSetId);
        // get new rule set version id.
        Long newRuleSetVersionId =
            SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET_VERSION);
        rsv.setRuleSetVersionId(newRuleSetVersionId);
        if (Util.countMirCriteria(rsv.getMirCriteria()) > 0) {
          rsv.getMirCriteria().setRuleSetVersionId(newRuleSetVersionId);
        } else {
          rsv.setMirCriteria(null);
        }
        rsv.setUpdatedBy(loginUser);

        if (rsv.getRuleVersions() != null) {
          for (RuleVersion ruleVersion : rsv.getRuleVersions()) {
            // use unique ID (not id in DB) to identify what rule.
            Rule tmpRule =
                checkRuleExistInList(importRuleList, ruleVersion.getRule().getRuleId());
            // get version in list
            RuleVersion tempRuleVer =
                checkRuleVersionExistInList(tmpRule.getRuleVersions(),
                    ruleVersion.getVersion());

            listRulesOfRuleSet.add(new RulesOfRS(tempRuleVer.getRuleVersionId(),
                newRuleSetVersionId));
          }
        }
      }
      // update rule set id for rule set owners
      List<RuleSetOwners> owners = ruleSet.getUserRuleSets();
      if (owners == null) {
        owners = new ArrayList<RuleSetOwners>();
      }
      boolean ownerExist = false;
      for (RuleSetOwners ruleSetOwner : owners) {
        ruleSetOwner.getId().setRuleSetId(newRuleSetId);
        if (ruleSetOwner.getId().getUserName().equalsIgnoreCase(loginUser)) {
          ownerExist = true;
        }
      }
      if (!ownerExist) {
        owners.add(new RuleSetOwners(loginUser, newRuleSetId));
      }
      trackingBuilder.append("Rule Set=").append(ruleSet.getName()).append(";");
    }

    // update ID in DB to rule
    for (Rule rule : importRuleList) {
      Long ruleIdDB = idList.get(rule.getRuleId().intValue() - 1);
      // update ID of DB to rule
      rule.setRuleId(ruleIdDB);
    }

    // Get current time on DB.
    Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
    // list to insert data to DB.
    List<QueryExecutor> listExecutor = new ArrayList<QueryExecutor>();
    int saveType = EntityExecutor.INSERT_ENTITY;
    for (Rule rule : importRuleList) {
      rule.setUpdatedOn(currentTime);
      listExecutor.add(new EntityExecutor(saveType, rule));
      for (RuleVersion ruleVer : rule.getRuleVersions()) {
        ruleVer.setUpdatedOn(currentTime);
        listExecutor.add(new EntityExecutor(saveType, ruleVer));

        for (RuleValue ruleValue : ruleVer.getRuleValueList()) {
          listExecutor.add(new EntityExecutor(saveType, ruleValue));
        }
      }
      List<RuleOwners> owners = rule.getUserRules();
      for (RuleOwners ruleOwners : owners) {
        listExecutor.add(new EntityExecutor(saveType, ruleOwners));
      }
      // clear owners list of rule to not be exception when insert.
      rule.setUserRules(null);
      trackingBuilder.append("Rule=").append(rule.getName()).append(";");
    }
    for (RuleSet ruleSet : ruleSetList) {
      ruleSet.setUpdatedOn(currentTime);
      listExecutor.add(new EntityExecutor(saveType, ruleSet));
      for (RuleSetVersion rsv : ruleSet.getRuleSetVersions()) {
        rsv.setUpdatedOn(currentTime);
        listExecutor.add(new EntityExecutor(saveType, rsv));
        // update reference to rule set, to not be exception when insert.
        rsv.setRuleSet(ruleSet);
        if (Util.countMirCriteria(rsv.getMirCriteria()) > 0) {
          rsv.getMirCriteria().setRuleSetVersion(rsv);
        }
      }
      List<RuleSetOwners> owners = ruleSet.getUserRuleSets();
      for (RuleSetOwners ruleSetOwner : owners) {
        listExecutor.add(new EntityExecutor(saveType, ruleSetOwner));
      }
      // clear owners list of rule to not be exception when insert.
      ruleSet.setUserRuleSets(null);
    }

    for (RulesOfRS ruleOfRuleSet : listRulesOfRuleSet) {
      listExecutor.add(new EntityExecutor(saveType, ruleOfRuleSet));
    }

    try {
      SCWebServiceFactory.getScBaseService().executeMultipleQuery(listExecutor);

      try {
        // Action log if there is deleted rule.
        String parameters = trackingBuilder.toString();
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Import Rule Set");
          // remove last ';'
          tracking.setParameters(parameters.substring(0, parameters.length() - 1));
          tracking.setElapsedTime(System.currentTimeMillis() - startTime + readFileTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }

      clearRuleSetSession(WRequest.getCurrentInstance());
      if (errorImportRuleSetHaveEmptyMIR.length() == 0) {
        infoMessage = CommonUtils.getRuleSetBundleMessage("rule_set_import_success");
      } else {
        errorMessage = errorImportRuleSetHaveEmptyMIR;
      }
      stopImport = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = CommonUtils.getRuleSetBundleMessage("error_when_save_ruleset");
      return;
    }
  }

  private void fillInputedNameToRuleSet(List<RuleSet> ruleSetList) {
    if (existedRuleSetNameList != null && existedRuleSetNameList.size() > 0) {
      RuleSetService ruleSetServ = new RuleSetService(SCWebServiceFactory.getScBaseService());
      for (Iterator<NameDTO> iterator = existedRuleSetNameList.iterator(); iterator.hasNext();) {
        NameDTO nameDto = iterator.next();
        if (nameDto.getNewName() != null
            && ruleSetServ.getRuleSetByName(nameDto.getNewName()) == null) {
          // new name does not exist
          for (RuleSet ruleSet : ruleSetList) {
            if (ruleSet.getName().equalsIgnoreCase(nameDto.getOldName())) {
              ruleSet.setName(nameDto.getNewName());
              break;
            }
          }
          iterator.remove();
        }
      }
    }
  }

  private void fillInputedNameToRule(List<Rule> ruleList) {
    if (existedRuleNameList != null && existedRuleNameList.size() > 0) {
      RuleService ruleServ = new RuleService(SCWebServiceFactory.getScBaseService());
      for (Iterator<NameDTO> iterator = existedRuleNameList.iterator(); iterator.hasNext();) {
        NameDTO nameDto = iterator.next();
        if (nameDto.getNewName() != null
            && ruleServ.getRuleByName(nameDto.getNewName()) == null) {
          // new name does not exist
          for (Rule rule : ruleList) {
            if (rule.getName().equalsIgnoreCase(nameDto.getOldName())) {
              rule.setName(nameDto.getNewName());
              break;
            }
          }
          iterator.remove();
        }
      }
    }
  }

  private void getDataFromRequest(WRequest request) {
    String numberRuleSetStr = request.getParameter("numberExistRuleSet");
    if (numberRuleSetStr != null) {
      int numberRuleSet = Integer.parseInt(numberRuleSetStr);
      existedRuleSetNameList = new ArrayList<ImportAction.NameDTO>();
      for (int i = 0; i < numberRuleSet; i++) {
        String oldVal = request.getParameter("oldRuleSet" + i);
        String newVal = request.getParameter("newRuleSet" + i);
        existedRuleSetNameList.add(new NameDTO(oldVal, newVal));
      }
    }
    String numberRuleStr = request.getParameter("numberExistRule");
    if (numberRuleStr != null) {
      int numberRule = Integer.parseInt(numberRuleStr);
      existedRuleNameList = new ArrayList<ImportAction.NameDTO>();
      for (int i = 0; i < numberRule; i++) {
        String oldVal = request.getParameter("oldRule" + i);
        String newVal = request.getParameter("newRule" + i);
        existedRuleNameList.add(new NameDTO(oldVal, newVal));
      }
    }
  }

  /**
   * Check name of rules whether exists.
   * 
   * @param ruleList
   */
  private void checkNameOfRules(List<Rule> ruleList) {
    if (ruleList == null || ruleList.size() == 0) {
      return;
    }
    BaseService baseServ = SCWebServiceFactory.getScBaseService();
    RuleService ruleServ = new RuleService(baseServ);
    for (Rule rule : ruleList) {
      // check name of rule whether exists.
      Rule queryRule = ruleServ.getRuleByName(rule.getName());
      if (queryRule != null) {
        // name exists, must rename it.
        // add rule name to list which will be used to generate GUI to
        // input new rule name.
        if (!checkRuleNameExist(existedRuleNameList, rule.getName())) {
          existedRuleNameList.add(new NameDTO(rule.getName(), rule.getName() + ADDED_SUFFIX));
        }
      }
    }
  }

  private void insertRules(List<Rule> ruleList) {
    if (ruleList == null || ruleList.size() == 0) {
      return;
    }
    long startTime = System.currentTimeMillis();
    // get login user to be updated user of rule set.
    String loginUser =
        WRequest.getCurrentInstance().getUserProfile().getAttribute("liotrox.user");

    for (Rule rule : ruleList) {
      // get new rule id.
      Long newRuleId = SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE);
      rule.setRuleId(newRuleId);

      // generate ID in DB of rule version.
      for (RuleVersion ruleVersion : rule.getRuleVersions()) {
        // get new rule version id.
        Long newRuleVersionId =
            SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_VERSION);
        ruleVersion.setRuleVersionId(newRuleVersionId);

        ruleVersion.setRuleId(newRuleId);
        ruleVersion.setUpdatedBy(loginUser);

        // update ruleversion id for rule value list
        for (RuleValue ruleValue : ruleVersion.getRuleValueList()) {
          ruleValue.setRuleVersion(ruleVersion);
          ruleValue.getId().setRuleVersionId(newRuleVersionId);
        }
      }
      // update rule set id for rule set owners
      List<RuleOwners> owners = rule.getUserRules();
      if (owners == null) {
        owners = new ArrayList<RuleOwners>();
      }
      boolean ownerExist = false;
      for (RuleOwners ruleOwner : owners) {
        ruleOwner.getId().setRuleId(newRuleId);
        if (ruleOwner.getId().getUserName().equalsIgnoreCase(loginUser)) {
          ownerExist = true;
        }
      }
      if (!ownerExist) {
        owners.add(new RuleOwners(loginUser, newRuleId));
      }
    }

    // Get current time on DB.
    Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
    // list to insert data to DB.
    List<QueryExecutor> listExecutor = new ArrayList<QueryExecutor>();
    int saveType = EntityExecutor.INSERT_ENTITY;
    StringBuilder trackingBuilder = new StringBuilder();
    for (Rule rule : ruleList) {
      rule.setUpdatedOn(currentTime);
      listExecutor.add(new EntityExecutor(saveType, rule));
      for (RuleVersion ruleVer : rule.getRuleVersions()) {
        ruleVer.setUpdatedOn(currentTime);
        listExecutor.add(new EntityExecutor(saveType, ruleVer));

        for (RuleValue ruleValue : ruleVer.getRuleValueList()) {
          listExecutor.add(new EntityExecutor(saveType, ruleValue));
        }
      }
      List<RuleOwners> owners = rule.getUserRules();
      for (RuleOwners ruleOwners : owners) {
        listExecutor.add(new EntityExecutor(saveType, ruleOwners));
      }
      // clear owners list of rule to not be exception when insert.
      rule.setUserRules(null);
      trackingBuilder.append(rule.getName()).append(";");
    }

    try {
      SCWebServiceFactory.getScBaseService().executeMultipleQuery(listExecutor);

      try {
        // Action log if there is deleted rule.
        String parameters = trackingBuilder.toString();
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Import Rule");
          // remove last ';'
          tracking.setParameters(parameters.substring(0, parameters.length() - 1));
          tracking.setElapsedTime(System.currentTimeMillis() - startTime + readFileTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }

      clearRuleSession(WRequest.getCurrentInstance());
      infoMessage = CommonUtils.getRuleBundleMessage("rule_import_success");
      stopImport = true;
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      errorMessage = CommonUtils.getRuleBundleMessage("error_when_save_rule");
      return;
    }
  }

  private Rule checkRuleExistInList(List<Rule> ruleList, String ruleName) {
    if (ruleList == null || ruleList.size() == 0) {
      return null;
    }
    for (Rule rule : ruleList) {
      if (rule.getName().equalsIgnoreCase(ruleName)) {
        return rule;
      }
    }
    return null;
  }

  private Rule checkRuleExistInList(List<Rule> ruleList, long id) {
    if (ruleList == null || ruleList.size() == 0) {
      return null;
    }
    for (Rule rule : ruleList) {
      if (rule.getRuleId() == id) {
        return rule;
      }
    }
    return null;
  }

  private RuleVersion checkRuleVersionExistInList(List<RuleVersion> ruleVersionList,
      Integer version) {
    if (ruleVersionList == null || ruleVersionList.size() == 0) {
      return null;
    }
    for (RuleVersion ruleVersion : ruleVersionList) {
      if (ruleVersion.getVersion().intValue() == version.intValue()) {
        return ruleVersion;
      }
    }
    return null;
  }

  public class NameDTO {
    private String oldName;

    /**
     * @return the oldName
     */
    public String getOldName() {
      return oldName;
    }

    /**
     * @param oldName
     *          the oldName to set
     */
    public void setOldName(String oldName) {
      this.oldName = oldName;
    }

    /**
     * @return the newName
     */
    public String getNewName() {
      return newName;
    }

    /**
     * @param newName
     *          the newName to set
     */
    public void setNewName(String newName) {
      this.newName = newName;
    }

    private String newName;

    public NameDTO(String oldName) {
      this.oldName = oldName;
    }

    public NameDTO(String oldName, String newName) {
      this.oldName = oldName;
      this.newName = newName;
    }
  }

  private boolean checkRuleNameExist(List<NameDTO> nameList, String name) {
    if (nameList == null || nameList.size() == 0) {
      return false;
    }
    for (NameDTO nameDTO : nameList) {
      if (nameDTO.getOldName().equalsIgnoreCase(name)) {
        return true;
      }
    }
    return false;
  }

  private boolean isImportRuleSet() {
    if (RULE_SET_TYPE.equals(importType)) {
      return true;
    }
    return false;
  }

  private boolean isImportRule() {
    if (RULE_TYPE.equals(importType)) {
      return true;
    }
    return false;
  }

  /**
   * Return upload file information. If no file is uploaded the current value is
   * null.
   * 
   * @return the upload information (file name and file description)
   */
  public UploadItem getInfoUpload() {
    return this.infoUpload;
  }

  /**
   * Set the Upload information (file name, and file descriptor)
   * 
   * @param info
   *          st.liotrox.template.element.control.UploadItem
   */
  public void setInfoUpload(UploadItem info) {
    this.infoUpload = info;
  }

  /**
   * @return the importType
   */
  public String getImportType() {
    return importType;
  }

  /**
   * @param importType
   *          the importType to set
   */
  public void setImportType(String importType) {
    this.importType = importType;
  }

  /**
   * @return the existedRuleSetNameList
   */
  public List<NameDTO> getExistedRuleSetNameList() {
    return existedRuleSetNameList;
  }

  /**
   * @return the existedRuleNameList
   */
  public List<NameDTO> getExistedRuleNameList() {
    return existedRuleNameList;
  }

  /**
   * @return the stopImport
   */
  public boolean getStopImport() {
    return stopImport;
  }

  /**
   * @return the errorImportRuleSetHaveEmptyMIR
   */
  public String getErrorImportRuleSetHaveEmptyMIR() {
    return errorImportRuleSetHaveEmptyMIR;
  }

  public void setErrorImportRuleSetHaveEmptyMIR(String message) {
    errorImportRuleSetHaveEmptyMIR = message;
  }

  /**
   * @return the readFileTime
   */
  public long getReadFileTime() {
    return readFileTime;
  }

  /**
   * @param readFileTime
   *          the readFileTime to set
   */
  public void setReadFileTime(long readFileTime) {
    this.readFileTime = readFileTime;
  }

}
