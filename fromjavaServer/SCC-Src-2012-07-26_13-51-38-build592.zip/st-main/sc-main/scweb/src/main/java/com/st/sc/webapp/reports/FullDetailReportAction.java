/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import java.io.IOException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.db.DataSet;
import st.liotrox.db.DefaultDataSet;
import st.liotrox.template.element.control.DataViewElement;
import st.liotrox.util.Encode;
import st.liotrox.web.html.Table;

import com.st.common.web.util.CSVExporter;
import com.st.common.web.util.ServletUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.CompliancyResultBinary;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.sc.service.ReportService;
import com.st.sc.webapp.BaseAction;
import com.st.scc.common.utils.ConvertUtils;
import com.st.scc.common.utils.DateUtils;

/**
 * The Class FullDetailReportAction.
 */
public class FullDetailReportAction extends BaseAction {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(FullDetailReportAction.class);

  /** The Constant RESULT_PASSED. */
  private static final String RESULT_PASSED = "PASSED";

  /** The data view. */
  private DataView dataView;

  /** The dataset. */
  private DataSet dataset;

  /** The file name. */
  private String fileName;

  private String fileId;

  /** The final compliancy score. */
  private String finalCompliancyScore;

  /** The checking time. */
  private String checkingTime;

  /** The involved rule set. */
  private String involvedRuleSet;

  /** The version. */
  private String version;

  private RuleValidationDetail[] ruleValidationDetailArr;

  private String originalPage;

  /*----------------------Begin Variables used for Rule Set Validation---------------*/
  /**
   * A specified fail value folder path. It is used for rule set validation.
   */
  private String specifiedFailedValuesFolder;
  /**
   * It is used to view failed value detail.
   */
  private String sessionId;

  /** The file UUID. */
  private String fileUUID;
  /*----------------------End Variables used for Rule Set Validation---------------*/

  private static final int TEXT_WIDTH = 80;

  /**
   * Back to original page.
   * 
   * @param request
   * @param event
   */
  public void back(final WRequest request, final Event event) {
    if (originalPage != null) {
      request.redirectTo(originalPage);
    }
  }

  /**
   * Before populate.
   * 
   * @param request
   *          the request {@inheritDoc}
   * @see st.liotrox.page.WPage#beforePopulate(st.liotrox.WRequest)
   */
  @Override
  public void beforePopulate(final WRequest request) {
    // Get DataView object
    dataView = getDataView();
  }

  /**
   * This method is invoked by the framework BEFORE rendering the page.
   * 
   * @param request
   *          the request
   */
  @Override
  public void beforeRender(final WRequest request) {
    // Get DataView object
    dataView = getDataView();
  }

  /**
   * Export CSV.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void export(final WRequest request, final Event event) {
    request.getHttpResponse().setContentType("text/csv");
    final String dateStr = DateUtils.dateToString(new Date(), "yyyyMMdd_HHmmss");
    request.getHttpResponse().setHeader("Content-Disposition",
        "filename=data_" + dateStr + " .csv");

    try {
      final StringBuilder sb = new StringBuilder();
      sb.append("Report").append(CSVExporter.CSV_SEPARATOR).append("Full Detail Report\n");
      sb.append("STDF file name").append(CSVExporter.CSV_SEPARATOR).append(fileName)
          .append("\n");
      sb.append("Final Compliancy Score").append(CSVExporter.CSV_SEPARATOR)
          .append(finalCompliancyScore).append("\n");
      sb.append("Involved Rule Set").append(CSVExporter.CSV_SEPARATOR).append(involvedRuleSet)
          .append("\n");
      sb.append("Version").append(CSVExporter.CSV_SEPARATOR).append(version).append("\n");
      sb.append("The Checking Time").append(CSVExporter.CSV_SEPARATOR).append(checkingTime)
          .append("\n");
      sb.append("\n");
      request.getOutputStream().write(sb.toString().getBytes());

      CSVExporter.writeCSV(dataView, request.getOutputStream());
      request.closeOutput();
    } catch (final IOException e) {
      LOGGER.error(e.getMessage(), e);
    }

    request.setPagePath(null);
  }

  /**
   * Format text.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String formatDataViewText(final WRequest request, final DataViewEvent event) {
    return adjustText(event.getValue(), TEXT_WIDTH);
  }

  /**
   * Format rule name.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String formatRuleName(final WRequest request, final DataViewEvent event) {
    return adjustText(event.getValue(), 210);
  }

  /**
   * Process select prober event.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void generateFullDetailReport(final WRequest request, final Event event) {
    LOGGER.debug("Begin FullDetailReportAction.generateFullDetailReport()");
    // get original page to back action
    originalPage = ServletUtils.decodeUrlParam(request.getParameter("originalPage"));

    try {
      fileId = request.getParameter("fileId");
      fileName = request.getParameter("fileName");
      finalCompliancyScore = request.getParameter("finalCompliancyScore");
      checkingTime = request.getParameter("checkingTime");
      involvedRuleSet = request.getParameter("involvedRuleSet");
      version = request.getParameter("version");
      // not specified the fail value folder, it is only used by rule set
      // validation.
      specifiedFailedValuesFolder = null;
      if (LOGGER.isDebugEnabled()) {
        LOGGER.debug("Generate full detail report: fileName=" + fileName + "; fileId="
            + fileId + "; finalCompliancyScore=" + finalCompliancyScore + "; checkingTime="
            + checkingTime + "; involvedRuleSet=" + involvedRuleSet + "; version=" + version);
      }

      // de-serialize blob data to get data set
      final ReportService service = new ReportService();
      final CompliancyResultBinary binary =
          service.getData(ConvertUtils.getLongObject(fileId));

      byte[] detailResult = null;
      if (binary != null) {
        detailResult = binary.getDetailResult();
      }
      ruleValidationDetailArr = service.deSerialize(detailResult);
      if (ruleValidationDetailArr == null) {
        return;
      }

      LOGGER.info("De-serialize result (size): " + ruleValidationDetailArr.length);

      dataset = new DefaultDataSet();
      dataset.setColumnNames(ReportService.FULL_DETAIL_COLUMNS);
      if (ruleValidationDetailArr.length > 0) {
        final Object[][] matrix = service.buildFullDetailMatrix(ruleValidationDetailArr);
        dataset.loadFromMatrix(matrix);
        if (dataView != null) {
          dataView.getModel().setDataSet(dataset);
        }
      }
    } catch (final Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
    LOGGER.debug("End FullDetailReportAction.generateFullDetailReport()");
  }

  public void generateFullDetailReportFromValidateRuleSet(final WRequest request,
      final Event event) {
    LOGGER.debug("Begin FullDetailReportAction.generateFullDetailReportFromValidateRuleSet()");
    // don't show back button.
    originalPage = null;
    try {
      fileId = request.getParameter("fileId");
      fileName = ServletUtils.decodeUrlParam(request.getParameter("fileName"));
      finalCompliancyScore =
          ServletUtils.decodeUrlParam(request.getParameter("finalCompliancyScore"));
      checkingTime = ServletUtils.decodeUrlParam(request.getParameter("checkingTime"));
      involvedRuleSet = ServletUtils.decodeUrlParam(request.getParameter("involvedRuleSet"));
      version = request.getParameter("version");
      // this url is encoded when redirect to this page.
      // It is not used here. I continue redirect to DetailFailuresAction.
      // Don't decode this url here.
      specifiedFailedValuesFolder = request.getParameter("specifiedFailedValuesFolder");
      sessionId = request.getParameter("sessionId");
      fileUUID = request.getParameter("fileuuid");

      if (LOGGER.isDebugEnabled()) {
        LOGGER.debug("Rule set validation, generate full detail report: fileName=" + fileName + "; fileId="
            + fileId + "; finalCompliancyScore=" + finalCompliancyScore + "; checkingTime="
            + checkingTime + "; involvedRuleSet=" + involvedRuleSet + "; version=" + version);
      }

      // de-serialize blob data to get data set
      ruleValidationDetailArr =
          (RuleValidationDetail[]) request.getSession().getAttribute(
              SCConstants.KEY_RULESET_VALIDATION_DETAIL + fileId);
      if (ruleValidationDetailArr == null) {
        return;
      }

      dataset = new DefaultDataSet();
      dataset.setColumnNames(ReportService.FULL_DETAIL_COLUMNS);
      if (ruleValidationDetailArr.length > 0) {
        final Object[][] matrix =
            new ReportService().buildFullDetailMatrix(ruleValidationDetailArr);
        dataset.loadFromMatrix(matrix);
        if (dataView != null) {
          dataView.getModel().setDataSet(dataset);
        }
      }
    } catch (final Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
    LOGGER.debug("End FullDetailReportAction.generateFullDetailReportFromValidateRuleSet()");
  }

  /**
   * Gets the checking time.
   * 
   * @return the checking time
   */
  public String getCheckingTime() {
    return checkingTime;
  }

  /**
   * Load a dataset from database.
   * 
   * @return the loaded DataSet
   */
  public DataSet getDataSet() {
    return dataset;
  }

  /**
   * Get the DataView.
   * 
   * @return the DataView
   */
  public DataView getDataView() {
    if (dataView == null) {
      final DataViewElement dvElement = (DataViewElement) findControl("datasetDataView");
      if (dvElement != null) {
        dataView = dvElement.getDataView(WRequest.getCurrentInstance());
      }
    }
    return dataView;
  }

  public String getFileId() {
    return fileId;
  }

  /**
   * Gets the file name.
   * 
   * @return the file name
   */
  public String getFileName() {
    return fileName;
  }

  /**
   * Gets the file UUID.
   * 
   * @return the file UUID
   */
  public String getFileUUID() {
    return fileUUID;
  }

  /**
   * Gets the final compliancy score.
   * 
   * @return the final compliancy score
   */
  public String getFinalCompliancyScore() {
    return finalCompliancyScore;
  }

  /**
   * Gets the involved rule set.
   * 
   * @return the involved rule set
   */
  public String getInvolvedRuleSet() {
    return involvedRuleSet;
  }

  /**
   * @return the originalPage
   */
  public String getOriginalPage() {
    return originalPage;
  }

  public RuleValidationDetail[] getRuleValidationDetailArr() {
    return ruleValidationDetailArr;
  }

  /**
   * @return the sessionId
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * @return the specifiedFailedValuesFolder
   */
  public String getSpecifiedFailedValuesFolder() {
    return specifiedFailedValuesFolder;
  }

  /**
   * Gets the version.
   * 
   * @return the version
   */
  public String getVersion() {
    return version;
  }

  /**
   * Example of Java callback used to create the dataview header.
   * 
   * @param request
   *          the current request
   * @param event
   *          the event
   * @return the header
   */
  public String headerCallback(final WRequest request, final Event event) {
    final Table t = new Table(0);
    t.width("100%").style("border:1px solid navy");
    t.newRow();
    t.cell("<h2>The Full Detail Report</h2>").alignCenter().alignMiddle();
    return Encode.encodeForHTML(t.toString());
  }

  /**
   * Java callback returning NULL.
   * 
   * @param request
   *          the current request
   * @param event
   *          the event
   * @return always NULL
   */
  public String nullCallback(final WRequest request, final DataViewEvent event) {
    return null;
  }

  /**
   * Open detail failure.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String openDetailFailure(final WRequest request, final DataViewEvent event) {
    final Object value = event.getValue();
    final int row = event.getRow();
    String resultStr =
        (String) getDataView().getModel().getDataSet().getValue(row, "resultStr");
    if (resultStr == null) {
      resultStr = "";
    }
    String failedValue =
        (String) getDataView().getModel().getDataSet().getValue(row, "failedValue");
    if (failedValue == null) {
      failedValue = "";
    }
    if (RESULT_PASSED.equals(resultStr.toUpperCase())) {
      return "";
    }
    if (failedValue.length() > 0) {
      // print failedValue with cell width is 150
      return adjustText(failedValue, 150);
    }

    return "<a onclick=\"openDetailFailure(" + row
        + ")\" href=\"javascript: void(0)\" >...</a>";
  }

  /**
   * Sets the checking time.
   * 
   * @param checkingTime
   *          the new checking time
   */
  public void setCheckingTime(final String checkingTime) {
    this.checkingTime = checkingTime;
  }

  /**
   * Sets the file name.
   * 
   * @param fileName
   *          the new file name
   */
  public void setFileName(final String fileName) {
    this.fileName = fileName;
  }

  /**
   * Sets the final compliancy score.
   * 
   * @param finalCompliancyScore
   *          the new final compliancy score
   */
  public void setFinalCompliancyScore(final String finalCompliancyScore) {
    this.finalCompliancyScore = finalCompliancyScore;
  }

  /**
   * Sets the involved rule set.
   * 
   * @param involvedRuleSet
   *          the new involved rule set
   */
  public void setInvolvedRuleSet(final String involvedRuleSet) {
    this.involvedRuleSet = involvedRuleSet;
  }

  /**
   * Sets the version.
   * 
   * @param version
   *          the new version
   */
  public void setVersion(final String version) {
    this.version = version;
  }
}
