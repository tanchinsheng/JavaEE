/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 3, 2011 8:55:28 PM - nhatvn - Initialize version
/********************************************************************************/

package com.st.sc.webapp.ruleandruleset;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.db.DataSet;

import com.st.common.web.filter.HTTPCacheHeader;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.persistence.util.ReflecttionUtils;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleVersion;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.rulemanager.RuleService;
import com.st.sc.rulemanager.serialization.rule.TRule;
import com.st.sc.rulemanager.util.RuleHelper;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.RuleVersionDTO;
import com.st.sc.webapp.BaseAction;

public class RuleManagementAction extends BaseAction {
  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(RuleManagementAction.class);

  private DataView ruleDataView = null;
  private DataSet ruleDataSet = null;

  private DataView ruleVersionDataView = null;
  private DataSet ruleVersionDataSet = null;

  private String editErrorMessage;
  private final String CONNECTOR = ";";

  private boolean showVersion;
  private boolean isOwnerRule;

  private final String[] DS_RULE_COLUMNS = new String[]{"ruleId", "ruleName", "recordType",
      "createdBy", "owners", "origin" };

  private final String[] DS_RULE_VERSION_COLUMNS = new String[]{"ruleId", "ruleVersionId",
      "version", "description", "point", "usedBy", "logID", "lastUpdate", "updatedBy" };

  private String selectedRuleName;
  private Long selectedRuleId;

  /**
   * This is called any when before rendering page. {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#beforeRender(st.liotrox.WRequest)
   */
  @Override
  protected void beforeRender(WRequest request) {
    // Add javacript function call in OnLoad(), to show error message if have.
    addOnLoadCode("checkAndShowErrorMesage();");

    checkUserRole(request);
    super.beforeRender(request);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.webapp.BaseAction#checkUserRole(st.liotrox.WRequest)
   */
  @Override
  protected void checkUserRole(WRequest request) {
    super.checkUserRole(request);

    if (!getIsManaged()) {
      isOwnerRule = false;
    }
  }

  protected void beforePopulate(WRequest request) {
    getRuleDataView();

    clearMessage();
    super.beforePopulate(request);
  }

  private void clearMessage() {
    editErrorMessage = "";
    errorMessage = "";
    infoMessage = "";
  }

  public void doShow(WRequest request, Event event) {
    clearMessage();
    showVersion = false;
    refeshRuleDataView(request);
  }

  private void refeshRuleDataView(WRequest request) {
    // get and set data set for dataview before display.
    createRuleAndRuleVersionDataSet();

    int currentPage = getRuleDataView().getCurrentPage();
    if (currentPage > 0) {
      getRuleDataView().gotoPage(currentPage);
    }

    checkUserRole(request);
  }

  /**
   * Gets the data set.
   * 
   * @return the data set
   */
  private void createRuleAndRuleVersionDataSet() {
    RuleService ser = new RuleService(SCWebServiceFactory.getScBaseService());
    EntityManager entityManager =
        SCWebServiceFactory.getScBaseService().getEntityManagerFactory().createEntityManager();
    List<Rule> ruleList = ser.getAllRules(entityManager);
    // Create Rule DTO list to display on Rule Dataview.
    List<RuleVersionDTO> ruleListDto = createListRuleDTO(ruleList);
    SCWebServiceFactory.getScBaseService().closeEntityManager(entityManager);
    // Convert to dataset
    ruleDataSet = createDataSet(ruleListDto);
    getRuleDataView().getModel().setDataSet(ruleDataSet);

  }

  private List<RuleVersionDTO> createListRuleDTO(List<Rule> ruleList) {
    List<RuleVersionDTO> listDto = new ArrayList<RuleVersionDTO>();
    if (ruleList != null && ruleList.size() > 0) {
      for (Rule rule : ruleList) {
        RuleVersionDTO dto = createRuleVersionDTO(rule);
        listDto.add(dto);
      }
    }
    return listDto;
  }

  public void showRuleVersion(WRequest request, Event event) {
    clearMessage();
    refeshRuleVersionDataView(request);
  }

  private void refeshRuleVersionDataView(WRequest request) {
    int[] selectedRows = getRuleDataView().getSelectedRows();
    if (selectedRows.length != 1) {
      editErrorMessage = CommonUtils.getCommonBundleMessage("choose_one_record");
    } else {
      showVersion = true;
      selectedRuleId =
          (Long) getRuleDataView().getModel().getDataSet().getValue(selectedRows[0], "ruleId");
      // get rule name to display on gui.
      selectedRuleName =
          (String) getRuleDataView().getModel().getDataSet()
              .getValue(selectedRows[0], "ruleName");

      BaseService base = SCWebServiceFactory.getScBaseService();
      EntityManager entityManager = base.getEntityManagerFactory().createEntityManager();
      Rule rule = base.queryByPrimaryKey(entityManager, Rule.class, selectedRuleId);
      if (rule == null) {
        editErrorMessage = CommonUtils.getRuleBundleMessage("rule_was_deleted");
        refeshRuleDataView(request);
        showVersion = false;
        return;
      }
      List<RuleVersionDTO> ruleVersionDTOs = createListRuleVersionDTO(rule);
      base.closeEntityManager(entityManager);
      ruleVersionDataSet = createDataSet(ruleVersionDTOs);
      getRuleVersionDataView().getModel().setDataSet(ruleVersionDataSet);

      // check owners to authorize
      checkUserRole(request);
      if (getIsManaged()) {
        isOwnerRule = checkLoginUserIsOwnerRule(request, rule);
      }
    }
  }

  public void doDeleteRule(WRequest request, Event event) {
    clearMessage();
    long startTime = System.currentTimeMillis();
    int[] selectedRows = getRuleDataView().getSelectedRows();
    if (selectedRows.length == 0) {
      editErrorMessage = CommonUtils.getCommonBundleMessage("choose_least_one_record");
      return;
    } else {
      BaseService baseServ = SCWebServiceFactory.getScBaseService();
      EntityManager entityManager = baseServ.getEntityManagerFactory().createEntityManager();
      DataSet ds = getRuleDataView().getModel().getDataSet();

      // Build error message to show on GUI.
      StringBuilder errorBuilder1 = new StringBuilder();
      StringBuilder errorBuilder2 = new StringBuilder();
      StringBuilder errorBuilder3 = new StringBuilder();
      final String errorMsgUsedByRuleSet =
          CommonUtils.getRuleBundleMessage("cannot_delete_rule_usedbyruleset");
      final String errorDelete = CommonUtils.getRuleBundleMessage("error_when_delete");
      final String errorOwners = CommonUtils.getRuleBundleMessage("user_not_owner_rule");
      errorBuilder1.append(errorMsgUsedByRuleSet);
      errorBuilder2.append(errorDelete);
      errorBuilder3.append(errorOwners);
      StringBuilder trackingBuilder = new StringBuilder();
      Rule rule = null;
      Long ruleId = null;
      List<RuleVersion> ruleVersions = null;
      for (int i = 0; i < selectedRows.length; i++) {
        entityManager = baseServ.getEntityManagerFactory().createEntityManager();
        ruleId = (Long) ds.getValue(selectedRows[i], "ruleId");
        rule = baseServ.queryByPrimaryKey(entityManager, Rule.class, ruleId);
        if (rule != null) {
          // Check authorize of user, just owners of rule which can delete rule.
          boolean isOwner = checkLoginUserIsOwnerRule(request, rule);
          if (isOwner) {
            ruleVersions = rule.getRuleVersions();
            if (ruleVersions != null) {
              boolean isUsedByRuleSet = false;
              for (RuleVersion ruleVersion : ruleVersions) {
                if (ruleVersion.getRuleSetVersionList().size() > 0) {
                  appendErrorMsg(errorBuilder1, ruleVersion);
                  isUsedByRuleSet = true;
                  break;
                }
              }
              if (!isUsedByRuleSet) {
                // delete rule version and its parameters
                try {
                  baseServ.deleteEntity(entityManager, rule);
                  trackingBuilder.append(rule.getName()).append(";");
                } catch (Exception e) {
                  LOGGER.error(e.getMessage(), e);
                  errorBuilder2.append(rule.getName()).append(CONNECTOR);
                }
              }
            }
          } else {
            errorBuilder3.append(rule.getName()).append(CONNECTOR);
          }
        }
        // Close entity manager
        baseServ.closeEntityManager(entityManager);
      }
      try {
        // Action log if there is deleted rule.
        String parameters = trackingBuilder.toString();
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Delete Rule");
          // remove last ';'
          tracking.setParameters(parameters.substring(0, parameters.length() - 1));
          tracking.setElapsedTime(System.currentTimeMillis() - startTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }
      if (errorBuilder1.length() > errorMsgUsedByRuleSet.length()
          || errorBuilder2.length() > errorDelete.length()
          || errorBuilder3.length() > errorOwners.length()) {
        if (errorBuilder1.length() > errorMsgUsedByRuleSet.length()) {
          combineErrorMsg(errorBuilder1);
        }
        // Have error when delete
        if (errorBuilder2.length() > errorDelete.length()) {
          combineErrorMsg(errorBuilder2);
        }
        // no authorized user
        if (errorBuilder3.length() > errorOwners.length()) {
          combineErrorMsg(errorBuilder3);
        }
      } else {
        infoMessage = CommonUtils.getRuleBundleMessage("delete_rule_successfully");
      }
      // refesh data.
      refeshRuleDataView(request);
      showVersion = false;
    }
  }

  /**
   * Export one or multiple rules.
   * 
   * @param request
   * @param event
   */
  public void doExportRules(WRequest request, Event event) {
    clearMessage();
    long startTime = System.currentTimeMillis();
    int[] selectedRows = getRuleDataView().getSelectedRows();
    if (selectedRows.length == 0) {
      editErrorMessage = CommonUtils.getCommonBundleMessage("choose_least_one_record");
      return;
    }

    BaseService baseServ = SCWebServiceFactory.getScBaseService();
    EntityManager entityManager = baseServ.getEntityManagerFactory().createEntityManager();
    try {
      String fileName = "";
      StringBuilder trackingBuilder = new StringBuilder();
      TRule[] arrTRule = new TRule[selectedRows.length];
      DataSet ds = getRuleDataView().getModel().getDataSet();
      for (int i = 0; i < selectedRows.length; i++) {
        Long ruleId = (Long) ds.getValue(selectedRows[i], "ruleId");

        Rule rule = baseServ.queryByPrimaryKey(entityManager, Rule.class, ruleId);
        TRule ruleObj = RuleHelper.convertToObject(rule);
        arrTRule[i] = ruleObj;

        fileName = rule.getName();
        trackingBuilder.append(fileName).append(";");
      }

      byte[] bytes = RuleHelper.toBytes(arrTRule);
      ServletOutputStream ou = null;
      try {
        HttpServletResponse respone = request.getHttpResponse();
        respone.setHeader(HTTPCacheHeader.CACHE_CONTROL.getName(), "");
        respone.setHeader(HTTPCacheHeader.PRAGMA.getName(), "");       
        respone.addHeader("Content-Disposition", "attachment; filename=\"" + fileName + ".bin\"");
        respone.setContentType("application/octet-stream");
        ou = request.getHttpResponse().getOutputStream();
        ou.write(bytes);
        ou.flush();
      } catch (Exception e) {
        LOGGER.error(e.getMessage(), e);
      } finally {
        if (ou != null) {
          try {
            ou.close();
          } catch (IOException e) {
          }
        }
        try {
          // Action log if there is deleted rule.
          String parameters = trackingBuilder.toString();
          if (parameters.length() > 0) {
            ActionTrackingEntity tracking = new ActionTrackingEntity();
            tracking.setAction("Export Rule");
            // remove last ';'
            tracking.setParameters(parameters.substring(0, parameters.length() - 1));
            tracking.setElapsedTime(System.currentTimeMillis() - startTime);
            trackAction(tracking);
          }
        } catch (Exception e) {
          LOGGER.debug(e.getMessage(), e);
        }
      }
    } finally {
      baseServ.closeEntityManager(entityManager);
    }
  }

  /**
   * Do edit rule version.
   * 
   * @param request
   * @param event
   */
  public void doEdit(WRequest request, Event event) {
    clearMessage();
    int[] selectedRows = getRuleVersionDataView().getSelectedRows();
    if (selectedRows.length != 1) {
      editErrorMessage = CommonUtils.getCommonBundleMessage("choose_one_record");
    } else {
      Long ruleVersionId =
          (Long) getRuleVersionDataView().getModel().getDataSet()
              .getValue(selectedRows[0], "ruleVersionId");

      // Check whether rule is deleted.
      if (!checkExistRuleVersion(request, ruleVersionId)) {
        return;
      }

      String url =
          SCConstants.getContextPath() + SCConstants.RULE_DEFINITION_URL
              + ".doShow?type=edit&ruleVersionId=" + ruleVersionId;
      request.redirectTo(url);
    }
  }

  private boolean checkExistRuleVersion(WRequest request, Long ruleVersionId) {
    BaseService base = SCWebServiceFactory.getScBaseService();
    RuleVersion ruleVersion = base.queryByPrimaryKey(RuleVersion.class, ruleVersionId);
    if (ruleVersion == null) {
      editErrorMessage = CommonUtils.getRuleBundleMessage("rule_version_was_deleted");

      doRefeshRuleVersionNoClearMsg(request);
      return false;
    }
    return true;
  }

  public void doRefeshRuleVersion(WRequest request, Event event) {
    // check rule on dataview
    checkSelectRule();

    showRuleVersion(request, event);
  }

  private void doRefeshRuleVersionNoClearMsg(WRequest request) {
    // check rule on dataview
    checkSelectRule();

    refeshRuleVersionDataView(request);
  }

  /**
   * Do delete rule.
   * 
   * @param request
   * @param event
   */
  public void doDeleteRuleVersion(WRequest request, Event event) {
    clearMessage();
    long startTime = System.currentTimeMillis();
    int[] selectedRows = getRuleVersionDataView().getSelectedRows();
    if (selectedRows.length == 0) {
      editErrorMessage = CommonUtils.getCommonBundleMessage("choose_least_one_record");
      return;
    } else {
      BaseService baseServ = SCWebServiceFactory.getScBaseService();
      RuleService ruleServ = new RuleService(baseServ);
      EntityManager entityManager = baseServ.getEntityManagerFactory().createEntityManager();
      // Build error message to show on GUI.
      StringBuilder errorBuilder1 = new StringBuilder();
      StringBuilder errorBuilder2 = new StringBuilder();
      final String errorMsgUsedByRuleSet =
          CommonUtils.getRuleBundleMessage("cannot_delete_rule_usedbyruleset");
      final String errorDelete = CommonUtils.getRuleBundleMessage("error_when_delete");

      errorBuilder1.append(errorMsgUsedByRuleSet);
      errorBuilder2.append(errorDelete);
      StringBuilder trackingBuilder = new StringBuilder();
      DataSet ds = getRuleVersionDataView().getModel().getDataSet();
      Long ruleId = null;
      for (int i = 0; i < selectedRows.length; i++) {
        Long ruleVersionId = (Long) ds.getValue(selectedRows[i], "ruleVersionId");
        RuleVersion ruleVersion =
            baseServ.queryByPrimaryKey(entityManager, RuleVersion.class, ruleVersionId);
        if (ruleVersion != null) {
          ruleId = ruleVersion.getRuleId();
          // This rule version is not used by any RuleSet. We can delete it.
          if (ruleVersion.getRuleSetVersionList().size() == 0) {
            // delete rule version and its parameters
            try {
              baseServ.deleteEntity(entityManager, ruleVersion);
              if (trackingBuilder.length() == 0) {
                trackingBuilder.append("Rule Name: " + selectedRuleName).append(". Version=");
              }
              trackingBuilder.append(ruleVersion.getVersion()).append(";");
            } catch (Exception e) {
              LOGGER.error(e.getMessage(), e);
              appendErrorMsg(errorBuilder2, ruleVersion);
            }
          } else {
            // This rule version is used by some RuleSet. We cannot delete it.
            // The rule set version will be showed on error message.
            appendErrorMsg(errorBuilder1, ruleVersion);
          }
        }
      }
      Long count = 1L; // count != 0 to after delete, refesh page.
      if (ruleId != null) {
        count = ruleServ.countVersionOfRule(ruleId);
        // Check if rule doesn't have any versions, remove this rule.
        if (count == 0) {
          try {
            baseServ.deleteEntity(Rule.class, ruleId);
          } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
            errorMessage +=
                SCConstants.NEW_LINE
                    + CommonUtils.getRuleBundleMessage("error_delete_rule_and_version");
          }
        }
      }
      if (errorBuilder1.length() > errorMsgUsedByRuleSet.length()
          || errorBuilder2.length() > errorDelete.length()) {
        if (errorBuilder1.length() > errorMsgUsedByRuleSet.length()) {
          combineErrorMsg(errorBuilder1);
        }
        // Have error when delete
        if (errorBuilder2.length() > errorDelete.length()) {
          combineErrorMsg(errorBuilder2);
        }
      } else {
        infoMessage = CommonUtils.getRuleBundleMessage("delete_rule_successfully");
      }
      // Close entity manager
      baseServ.closeEntityManager(entityManager);

      try {
        // Action log if there is deleted rule set version.
        String parameters = trackingBuilder.toString();
        if (parameters.length() > 0) {
          ActionTrackingEntity tracking = new ActionTrackingEntity();
          tracking.setAction("Delete Rule Version");
          // remove last ';'
          tracking.setParameters(parameters.substring(0, parameters.length() - 1));
          tracking.setElapsedTime(System.currentTimeMillis() - startTime);
          trackAction(tracking);
        }
      } catch (Exception e) {
        LOGGER.debug(e.getMessage(), e);
      }
      // Refesh page
      if (count == 0) {
        refeshRuleDataView(request);
        showVersion = false;
      } else {
        doRefeshRuleVersionNoClearMsg(request);
      }
    }
  }

  private void appendErrorMsg(StringBuilder builder, RuleVersion ruleVersion) {
    builder.append("[").append(ruleVersion.getRule().getName()).append(",").append("Version=")
        .append(ruleVersion.getVersion());
    builder.append("]").append(CONNECTOR);
  }

  private void combineErrorMsg(StringBuilder builder) {
    // remove last connector character ';'
    builder.setLength(builder.length() - CONNECTOR.length());
    if (errorMessage.length() > 0) {
      errorMessage += SCConstants.NEW_LINE;
    }
    errorMessage += builder.toString();
  }

  private DataView getRuleDataView() {
    if (ruleDataView == null) {
      ruleDataView = getDataViewFromRequest("ruleDataView");
    }
    return ruleDataView;
  }

  private DataView getRuleVersionDataView() {
    if (ruleVersionDataView == null) {
      ruleVersionDataView = getDataViewFromRequest("ruleVersionDataView");
    }
    return ruleVersionDataView;
  }

  public void doBackToPage(WRequest request, Event event) {
    // clear message.
    errorMessage = infoMessage = "";

    if (getRuleDataView() != null && getRuleDataView().getModel().getDataSet() != null) {
      // check rule on dataview
      checkSelectRule();

      int[] rowsRule = getRuleDataView().getSelectedRows();

      String newRecord = request.getParameter(SCConstants.PARAMETER_NEW_RECORD);
      int rowIndex = -1;
      if (newRecord != null) {
        int currentPage = getRuleDataView().getCurrentPage();
        String selectedRows = buildSelectedRow(rowsRule);

        doShow(request, event);
        // getRuleDataView().getModel().getDataSet().appendRows(1);
        // rowIndex = getRuleDataView().getModel().getDataSet().getRowCount();
        //
        // If have new row, must focus on page of new row
        getRuleDataView().setSelectedRows(selectedRows);
        getRuleDataView().gotoPage(currentPage);
      } else {
        if (rowsRule.length > 0) {
          rowIndex = rowsRule[0];
        }

        if (rowIndex > -1) {
          String ruleIdStr = request.getParameter(SCConstants.PARAMETER_RULE_ID);
          if (ruleIdStr != null && !"null".equals(ruleIdStr)) {
            Long ruleId = Long.parseLong(ruleIdStr);
            BaseService baseServ = SCWebServiceFactory.getScBaseService();
            EntityManager entityManager =
                baseServ.getEntityManagerFactory().createEntityManager();
            try {
              Rule rule = baseServ.queryByPrimaryKey(entityManager, Rule.class, ruleId);
              if (rule != null) {
                RuleVersionDTO dto = createRuleVersionDTO(rule);
                bindRuleDtoToDataSet(dto, rowIndex);
              }
            } finally {
              baseServ.closeEntityManager(entityManager);
            }
          }
        }
      }
    } else {
      // create a new dataview.
      doShow(request, event);
    }

    // check if dataview of rule set version is showing or not.
    if (getRuleVersionDataView() != null
        && getRuleVersionDataView().getModel().getDataSet() != null) {
      int[] rowRuleVersion = getRuleVersionDataView().getSelectedRows();

      String newRecordVersion = request.getParameter(SCConstants.PARAMETER_NEW_RECORD_VERSION);
      int rowIndexVersion = -1;
      if (newRecordVersion != null) {
        int currentPage = getRuleVersionDataView().getCurrentPage();
        String selectedRows = buildSelectedRow(rowRuleVersion);

        showRuleVersion(request, event);
        // getRuleVersionDataView().getModel().getDataSet().appendRows(1);
        // rowIndexVersion =
        // getRuleVersionDataView().getModel().getDataSet().getRowCount();

        // If have new row, must focus on page of new row
        getRuleVersionDataView().setSelectedRows(selectedRows);
        getRuleVersionDataView().gotoPage(currentPage);
      } else {
        if (rowRuleVersion.length > 0) {
          rowIndexVersion = rowRuleVersion[0];
        }

        if (rowIndexVersion > -1) {
          String ruleVersionStr = request.getParameter(SCConstants.PARAMETER_RULE_VERSION_ID);
          if (ruleVersionStr != null && !"null".equals(ruleVersionStr)) {
            Long ruleVersionId = Long.parseLong(ruleVersionStr);
            BaseService baseServ = SCWebServiceFactory.getScBaseService();
            EntityManager entityManager =
                baseServ.getEntityManagerFactory().createEntityManager();
            try {
              RuleVersion ruleVersion =
                  baseServ.queryByPrimaryKey(entityManager, RuleVersion.class, ruleVersionId);
              if (ruleVersion != null) {
                RuleVersionDTO dto = new RuleVersionDTO();
                dto.setRuleId(ruleVersion.getRuleId());
                updateDataRuleVersionDTO(dto, ruleVersion);
                bindRuleVersionToDataSet(dto, rowIndexVersion);
              }
            } finally {
              baseServ.closeEntityManager(entityManager);
            }
          }
        }
      }

      // Correct name of selected rule.
      if (selectedRuleId != null) {
        Rule rule =
            SCWebServiceFactory.getScBaseService().queryByPrimaryKey(Rule.class,
                selectedRuleId);
        if (rule != null) {
          selectedRuleName = rule.getName();
        }
      }
    }

  }

  private void bindRuleDtoToDataSet(RuleVersionDTO ruleDto, int row) {
    DataSet ds = getRuleDataView().getModel().getDataSet();
    for (int i = 0; i < DS_RULE_COLUMNS.length; i++) {
      Method method =
          ReflecttionUtils.getGetMethodFromClass(DS_RULE_COLUMNS[i], RuleVersionDTO.class);
      if (method != null) {
        try {
          Object ob = method.invoke(ruleDto);
          ds.setValue(row, DS_RULE_COLUMNS[i], ob);
        } catch (Exception e) {
          if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(e.getMessage(), e);
          }
        }
      }
    }
  }

  private void bindRuleVersionToDataSet(RuleVersionDTO ruleVersionDto, int row) {
    DataSet ds = getRuleVersionDataView().getModel().getDataSet();
    for (int i = 0; i < DS_RULE_VERSION_COLUMNS.length; i++) {
      Method method =
          ReflecttionUtils.getGetMethodFromClass(DS_RULE_VERSION_COLUMNS[i],
              RuleVersionDTO.class);
      if (method != null) {
        try {
          Object ob = method.invoke(ruleVersionDto);
          ds.setValue(row, DS_RULE_VERSION_COLUMNS[i], ob);
        } catch (Exception e) {
          if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(e.getMessage(), e);
          }
        }
      }
    }
  }

  /**
   * Check on selected row of data view. This action keep current selected rule
   * although user changed select box on GUI.
   */
  private void checkSelectRule() {
    if (selectedRuleId != null) {
      int rowCount = getRuleDataView().getModel().getDataSet().getRowCount();
      int row = 0;
      for (row = 1; row <= rowCount; row++) {
        Long ruleId = (Long) getRuleDataView().getModel().getDataSet().getValue(row, "ruleId");
        if (selectedRuleId.longValue() == ruleId.longValue()) {
          break;
        }
      }
      if (1 < row && row <= rowCount) {
        String selectedRows = buildSelectedRow(new int[]{row });
        getRuleDataView().setSelectedRows(selectedRows);
      }
    }
  }

  public String getEditErrorMessage() {
    return editErrorMessage;
  }

  public void setEditErrorMessage(String editErrorMessage) {
    this.editErrorMessage = editErrorMessage;
  }

  /**
   * @return the ruleDataSet
   */
  public DataSet getRuleVersionDataSet() {
    return ruleVersionDataSet;
  }

  /**
   * @return the ruleDataSet
   */
  public DataSet getRuleDataSet() {
    return ruleDataSet;
  }

  /**
   * @return the showVersion
   */
  public boolean getShowVersion() {
    return showVersion;
  }

  /**
   * @param showVersion
   *          the showVersion to set
   */
  public void setShowVersion(boolean showVersion) {
    this.showVersion = showVersion;
  }

  /**
   * @return the isOwnerRule
   */
  public boolean getIsOwnerRule() {
    return isOwnerRule;
  }

  /**
   * @param isOwnerRule
   *          the isOwnerRule to set
   */
  public void setOwnerRule(boolean isOwnerRule) {
    this.isOwnerRule = isOwnerRule;
  }

  /**
   * @return the selectedRuleName
   */
  public String getSelectedRuleName() {
    return selectedRuleName;
  }

  /**
   * @param selectedRuleName
   *          the selectedRuleName to set
   */
  public void setSelectedRuleName(String selectedRuleName) {
    this.selectedRuleName = selectedRuleName;
  }

  /**
   * @return the selectedRuleId
   */
  public Long getSelectedRuleId() {
    return selectedRuleId;
  }

  /**
   * @param selectedRuleId
   *          the selectedRuleId to set
   */
  public void setSelectedRuleId(Long selectedRuleId) {
    this.selectedRuleId = selectedRuleId;
  }

}
