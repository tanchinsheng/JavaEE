/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 2:21:02 PM - nhatvn - Initialize version
/********************************************************************************/
package st.liotrox.template.element.control;

import st.liotrox.LIOTROX;
import st.liotrox.WRequest;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.web.html.WriteHTML;

import com.st.sc.common.CommonUtils;
import com.st.scc.common.utils.ConvertUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class DateSinceElement extends CustomElement {

  private static final String ATTRIBUTE_RADIO_NAME = "radioName";
  private static final String ATTRIBUTE_RADIO_VALUE = "radioValue";
  private static final String ATTRIBUTE_CHECKED_VALUE = "checkedValue";
  private static final String ATTRIBUTE_RADIO_MOUSE_DOWN = "radioMousedown";
  
  private static final String ATTRIBUTE_LABEL1 = "label1";
  private static final String ATTRIBUTE_LABEL2 = "label2";
  private static final String ATTRIBUTE_TEXTBOX_VALUE = "textboxValue";
  private static final String ATTRIBUTE_TEXTBOX_MAX_LENGTH = "textboxMaxLength";
  private static final String ATTRIBUTE_DATE_VALUE = "dateValue";
  private static final String ATTRIBUTE_FORMAT = "format";

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.template.DynamicElement#writeContent(st.liotrox.WRequest,
   *      st.liotrox.util.FastStringBuffer)
   */
  @Override
  public void writeContent(final WRequest request, final FastStringBuffer fs) {
    String radioName = resolveAttributeAsString(request, ATTRIBUTE_RADIO_NAME);
    String radioValue = resolveAttributeAsString(request, ATTRIBUTE_RADIO_VALUE);
    String checkedValue = resolveAttributeAsString(request, ATTRIBUTE_CHECKED_VALUE);
    String radioMouseDown = resolveAttributeAsString(request, ATTRIBUTE_RADIO_MOUSE_DOWN);
    
    String label1 = resolveAttributeAsString(request, ATTRIBUTE_LABEL1);
    if (label1 == null){
      label1 = CommonUtils.getCommonBundleMessage("report_last_lb") ;
    }
    String label2 = resolveAttributeAsString(request, ATTRIBUTE_LABEL2);
    if (label2 == null){
      label2 = CommonUtils.getCommonBundleMessage("report_since_lb");
    }
    String name = getName(request);
    String textboxValue = resolveAttributeAsString(request, ATTRIBUTE_TEXTBOX_VALUE);
    String textboxMaxLengthVal = resolveAttributeAsString(request, ATTRIBUTE_TEXTBOX_MAX_LENGTH);
    Integer textboxMaxLength= ConvertUtils.getInteger(textboxMaxLengthVal);
    String dateValue = resolveAttributeAsString(request, ATTRIBUTE_DATE_VALUE);
    String format = resolveAttributeAsString(request, ATTRIBUTE_FORMAT);
    if (format == null) {
      format = LIOTROX.getApplication().getApplicationSettings().getDateFormat();
    }
    String classCss = getClassCss(request);

    //Start table
    writeTableStartWithLabelLength(fs, 0);
    // Write radio button.
    writeRadio(fs, radioName, radioValue, checkedValue, radioMouseDown);

    writeWhiteSpace(fs);
    writeWhiteSpace(fs);
    
    writeLabel(fs, label1);
    WriteHTML.Table.cellEnd(fs);
    
    writeNewLine(fs);
    
    // write text box
    WriteHTML.Table.cellStart(fs);
    if (textboxMaxLength != null) {
      writeTextBox(fs, name + "Last", textboxValue, textboxMaxLength.intValue());
    } else {
      writeTextBox(fs, name + "Last", textboxValue);
    }
    WriteHTML.Table.cellEnd(fs);
    //write label.
    WriteHTML.Table.cellStart(fs);
    writeLabel(fs, label2);
    WriteHTML.Table.cellEnd(fs);
    
    writeNewLine(fs);
    
    // write date element
    WriteHTML.Table.cellStart(fs);
    DateControlUtils.writeDateControl(getPage(), request, fs, name + "Since",
        dateValue, classCss, format, label2);
    WriteHTML.Table.cellEnd(fs);
    
    //close table
    writeTableClose(fs);
  }

}
