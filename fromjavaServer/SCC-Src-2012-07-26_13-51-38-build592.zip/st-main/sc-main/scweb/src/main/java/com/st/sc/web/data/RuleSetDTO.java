/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 3, 2011 8:55:28 PM - nhatvn - Initialize version
/********************************************************************************/

package com.st.sc.web.data;

import java.util.Date;

public class RuleSetDTO {
  public static final String ACTIVE_VERSION_ID = "activeVersionId";
  public static final String ACTIVE_VERSION_NUM = "activeVersionNum";
  public static final String ACTIVE_VERSION_ALARM = "alarmThesholdStr";
  public static final String ACTIVE_VERSION_DESC = "description";
  public static final String ACTIVE_VERSION_LASTUPDATE = "lastUpdate";
  
  /*---------Rule set info -------*/
  private Long ruleSetId;
  private String name;
  private String owners;
  private String origin;
  private Date lastUpdate;

  /*---------Active Rule set version info -------*/
  private Long activeVersionId;
  private Integer activeVersionNum;
  private Double alarmTheshold;
  private String alarmThesholdStr;
  private String description;

  /**
   * @return the alarmThesholdStr
   */
  public String getAlarmThesholdStr() {
    if (alarmTheshold != null) {
      alarmThesholdStr = alarmTheshold.toString() + "%";
    }
    return alarmThesholdStr;
  }

  
  /**
   * @return the origin
   */
  public String getOrigin() {
    return origin;
  }


  /**
   * @param origin the origin to set
   */
  public void setOrigin(String origin) {
    this.origin = origin;
  }


  /**
   * @return the ruleSetId
   */
  public Long getRuleSetId() {
    return ruleSetId;
  }

  /**
   * @param ruleSetId
   *          the ruleSetId to set
   */
  public void setRuleSetId(Long ruleSetId) {
    this.ruleSetId = ruleSetId;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name
   *          the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @return the owners
   */
  public String getOwners() {
    return owners;
  }

  /**
   * @param owners
   *          the owners to set
   */
  public void setOwners(String owners) {
    this.owners = owners;
  }

  /**
   * @return the lastUpdate
   */
  public Date getLastUpdate() {
    return lastUpdate;
  }

  /**
   * @param lastUpdate
   *          the lastUpdate to set
   */
  public void setLastUpdate(Date lastUpdate) {
    this.lastUpdate = lastUpdate;
  }

  /**
   * @return the activeVersionId
   */
  public Long getActiveVersionId() {
    return activeVersionId;
  }

  /**
   * @param activeVersionId
   *          the activeVersionId to set
   */
  public void setActiveVersionId(Long activeVersionId) {
    this.activeVersionId = activeVersionId;
  }

  /**
   * @return the activeVersionNum
   */
  public Integer getActiveVersionNum() {
    return activeVersionNum;
  }

  /**
   * @param activeVersionNum
   *          the activeVersionNum to set
   */
  public void setActiveVersionNum(Integer activeVersionNum) {
    this.activeVersionNum = activeVersionNum;
  }

  /**
   * @return the alarmTheshold
   */
  public Double getAlarmTheshold() {
    return alarmTheshold;
  }

  /**
   * @param alarmTheshold
   *          the alarmTheshold to set
   */
  public void setAlarmTheshold(Double alarmTheshold) {
    this.alarmTheshold = alarmTheshold;
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * @param description
   *          the description to set
   */
  public void setDescription(String description) {
    this.description = description;
  }
  
}
