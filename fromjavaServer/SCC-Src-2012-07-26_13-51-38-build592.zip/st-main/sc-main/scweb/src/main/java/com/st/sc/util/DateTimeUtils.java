/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 23, 2012 3:24:03 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class DateTimeUtils {

  /** The Constant CONNECTOR_WEEK. */
  public static final String CONNECTOR_WEEK = ";";

  /** The Constant MILI_SECONDS_OF_DAY. */
  private static final long MILI_SECONDS_OF_DAY = 24 * 60 * 60 * 1000;

  /** The Constant MILI_SECONDS_OF_WEEK. */
  private static final long MILI_SECONDS_OF_WEEK = 6 * MILI_SECONDS_OF_DAY;

  /**
   * Days diff.
   * 
   * @param date1
   *          the date1
   * @param date2
   *          the date2
   * @return the int
   */
  public static int daysDiff(final Date date1, final Date date2) {
    final Calendar cal = Calendar.getInstance();
    cal.setTime(date1);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    final long time1 = cal.getTimeInMillis();
    cal.setTime(date2);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    final long time2 = cal.getTimeInMillis();
    final long sub = Math.abs(time2 - time1);
    final long day = sub / MILI_SECONDS_OF_DAY;
    return (int) day;
  }

  /**
   * Gets the date after x days.
   * 
   * @param date
   *          the date
   * @param numOfDays
   *          the number of days
   * @return the date after x days
   */
  public static Date getDateAfterXDays(final Date date, final int numOfDays) {
    Date nextDate = null;
    if (date != null) {
      final Calendar calendar = Calendar.getInstance();
      calendar.setTime(date);
      calendar.add(Calendar.DAY_OF_YEAR, numOfDays);
      nextDate = calendar.getTime();
    }
    return nextDate;
  }

  /**
   * Gets the date time from date.
   * 
   * @param date
   *          the date
   * @return the date time from date
   */
  private static DateTime getDateTimeFromDate(final Date date) {
    final Calendar cal = Calendar.getInstance();
    cal.setTimeInMillis(date.getTime());
    final DateTime dt =
        new DateTime(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
    return dt;
  }

  /**
   * Gets the first day from week number.
   * 
   * @param weekNum
   *          the week num
   * @param year
   *          the year
   * @return the first day from week number
   */
  public static Date getFirstDayFromWeekNumber(final int weekNum, final int year) {
    final DateTime t =
        new DateTime().withWeekyear(year).withWeekOfWeekyear(weekNum).withDayOfWeek(1);

    // ISO 8601 week start from Monday, scc/sc week start from Sunday
    return new Date(t.getMillis() - MILI_SECONDS_OF_DAY);
  }

  /**
   * Gets the last day from week number.
   * 
   * @param weekNum
   *          the week num
   * @param year
   *          the year
   * @return the last day from week number
   */
  public static Date getLastDayFromWeekNumber(final int weekNum, final int year) {
    final Calendar calendar = Calendar.getInstance();
    calendar.setTimeInMillis(getFirstDayFromWeekNumber(weekNum, year).getTime());
    // last date of week = first day of week + 6
    return new Date(calendar.getTimeInMillis() + MILI_SECONDS_OF_WEEK);
  }

  /**
   * Gets the next date.
   * 
   * @param date
   *          the date
   * @return the next date
   */
  public static Date getNextDate(final Date date) {
    return getDateAfterXDays(date, 1);
  }

  /**
   * Gets the start date 00:00:00.
   * 
   * @param date
   *          the date
   * @return the start date
   */
  public static Date getStartDate(final Date date) {
    Date startDate = null;
    if (date != null) {
      final Calendar calendar = Calendar.getInstance();
      calendar.setTime(date);
      calendar.set(Calendar.HOUR_OF_DAY, 0);
      calendar.set(Calendar.MINUTE, 0);
      calendar.set(Calendar.SECOND, 0);
      calendar.set(Calendar.MILLISECOND, 0);
      startDate = calendar.getTime();
    }
    return startDate;
  }

  /**
   * Gets the end date.
   * 
   * @param date
   *          the date
   * @return the end date
   */
  public static Date getEndDate(final Date date) {
    Date startDate = null;
    if (date != null) {
      final Calendar calendar = Calendar.getInstance();
      calendar.setTime(date);
      calendar.set(Calendar.HOUR_OF_DAY, 23);
      calendar.set(Calendar.MINUTE, 59);
      calendar.set(Calendar.SECOND, 59);
      calendar.set(Calendar.MILLISECOND, 0);
      startDate = calendar.getTime();
    }
    return startDate;
  }

  /**
   * Gets the week number.
   * 
   * @param date
   *          the date
   * @return (week number, week year), for example 15;2011
   */
  public static String getWeekNumber(final Date date) {
    DateTime dt = getDateTimeFromDate(date);
    // this API: week start from Monday. But sc/scc requires week start from
    // Sunday.
    // Therefore, if this date is Sunday, we must increase week number.
    if (dt.getDayOfWeek() == 7) {
      // increase to next date
      final long mili = dt.getMillis() + MILI_SECONDS_OF_DAY;
      dt = new DateTime(mili);
    }
    return dt.getWeekOfWeekyear() + CONNECTOR_WEEK + dt.getWeekyear();
  }

  /**
   * Gets the week numbers.
   * 
   * @param startDate
   *          the start date
   * @param endDate
   *          the end date
   * @return the week numbers
   */
  public static String[] getWeekNumbers(final Date startDate, final Date endDate) {
    final Calendar start = Calendar.getInstance();
    start.setTimeInMillis(startDate.getTime());
    start.set(Calendar.HOUR_OF_DAY, 0);
    start.set(Calendar.MINUTE, 0);

    final Calendar end = Calendar.getInstance();
    end.setTimeInMillis(endDate.getTime());
    end.set(Calendar.HOUR_OF_DAY, 23);
    end.set(Calendar.MINUTE, 59);

    long startMili = start.getTimeInMillis();
    final long endMili = end.getTimeInMillis();

    final List<String> listWeek = new ArrayList<String>();

    final Calendar tmp = Calendar.getInstance();
    while (startMili < endMili) {
      tmp.setTimeInMillis(startMili);
      String weekNum = getWeekNumber(tmp.getTime());
      if (!listWeek.contains(weekNum)) {
        listWeek.add(weekNum);
      }
      tmp.add(Calendar.DATE, 7);
      if (tmp.getTimeInMillis() > endMili) {
        tmp.setTimeInMillis(endMili);
        weekNum = getWeekNumber(tmp.getTime());
        if (!listWeek.contains(weekNum)) {
          listWeek.add(weekNum);
        }
        break;
      } else {
        startMili = tmp.getTimeInMillis();
      }
    }
    return listWeek.toArray(new String[listWeek.size()]);
  }
}
