/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 28, 2011 6:10:52 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.ruleandruleset;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import com.st.sc.common.CommonUtils;
import com.st.sc.entity.Rule;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RuleVersion;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.RuleVersionDTO;
import com.st.sc.webapp.BaseAction;
import com.st.scc.common.utils.StringUtil;

import st.liotrox.WRequest;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RuleListOfRuleSetAction extends BaseAction {

  /** The rule set version. */
  protected RuleSetVersion ruleSetVersion = new RuleSetVersion();

  protected boolean isOwnersOfRuleSet = true;

  protected String errorCheckSelectedRecord;

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.webapp.BaseAction#checkUserRole(st.liotrox.WRequest)
   */
  @Override
  protected void checkUserRole(WRequest request) {
    super.checkUserRole(request);
    if (!getIsManaged()) {
      isOwnersOfRuleSet = false;
    }
  }

  /**
   * Create data set for rule list of rule set version.
   * 
   * @param ruleSetVersionId
   * @return list of RuleVersionDTO. Note: must not return null.
   */
  public List<RuleVersionDTO> createListRuleVersionDTO(final Long ruleSetVersionId) {
    BaseService base = new BaseService(SCWebServiceFactory.getScEntityManagerFactory());
    EntityManager entityManager = base.getEntityManagerFactory().createEntityManager();
    List<RuleVersionDTO> listDto = new ArrayList<RuleVersionDTO>();
    try {
      RuleSetVersion tempRuleSetVersion =
          base.queryByPrimaryKey(entityManager, RuleSetVersion.class, ruleSetVersionId);
      // Note: If tempRuleSetVersion is null, don't assign it to ruleSetVersion
      // global variable. Because, if you assign to ruleSetVersion, current data
      // of ruleSetVersion
      // will be lost.
      // (In case: rule set is created, but not save yet. this page is called
      // from create rule set page)
      if (tempRuleSetVersion != null) {
        ruleSetVersion = tempRuleSetVersion;
      } else {
        // Check if it is null, create empty object, prevent NullPointer
        // exception.
        if (ruleSetVersion == null) {
          ruleSetVersion = new RuleSetVersion();
        }
        return listDto;
      }
      List<RuleVersion> ruleVersionList = ruleSetVersion.getRuleVersions();
      if (ruleVersionList != null && ruleVersionList.size() > 0) {
        Long totalPoint = 0L;
        for (RuleVersion ruleVersion : ruleVersionList) {
          RuleVersionDTO dto = new RuleVersionDTO();
          copyDataToDTO(dto, ruleVersion);
          copyDataToDTO(dto, ruleVersion.getRule());
          totalPoint += ruleVersion.getPoint();
          listDto.add(dto);
        }
        // Calculate weightage of rule.
        // Weightage = point /total point.
        double rate;
        double totalRate = 0;
        for (int i = 0; i < listDto.size() - 1; i++) {
          rate = (double) listDto.get(i).getPoint() / (double) totalPoint * 100;
          rate = CommonUtils.roundDouble(rate);
          listDto.get(i).setWeightageInString(rate + "%");
          totalRate += rate;
        }
        rate = 100 - totalRate;
        rate = CommonUtils.roundDouble(rate);
        listDto.get(listDto.size() - 1).setWeightageInString(rate + "%");
      }
    } finally {
      base.closeEntityManager(entityManager);
    }
    return listDto;
  }

  /**
   * Copy data to dto.
   * 
   * @param dto
   *          the dto
   * @param rv
   *          the rv
   */
  private void copyDataToDTO(final RuleVersionDTO dto, final RuleVersion rv) {
    dto.setRuleVersionId(rv.getRuleVersionId());
    dto.setDescription(rv.getDescription());
    dto.setVersion(rv.getVersion());
    dto.setPoint(rv.getPoint());
    dto.setLogID(StringUtil.getEmptyIfNull(rv.getLogId()));
    final Timestamp timestamp = rv.getUpdatedOn();
    if (timestamp != null) {
      dto.setLastUpdate(new Date(timestamp.getTime()));
    }
  }

  /**
   * Copy data to dto.
   * 
   * @param dto
   *          the dto
   * @param rule
   *          the rule
   */
  private void copyDataToDTO(final RuleVersionDTO dto, final Rule rule) {
    dto.setRuleId(rule.getRuleId());
    dto.setRuleName(rule.getName());
    dto.setRecordType(rule.getRecordType());
    dto.setCreatedBy(rule.getCreatedBy());
    dto.setOrigin(rule.getOrigin());
  }

  protected boolean checkExistRuleSetVersion(WRequest request, Long ruleSetVersionId) {
    BaseService base = SCWebServiceFactory.getScBaseService();
    RuleSetVersion ruleSetVersion =
        base.queryByPrimaryKey(RuleSetVersion.class, ruleSetVersionId);
    if (ruleSetVersion == null) {
      errorCheckSelectedRecord =
          CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");
      return false;
    }
    return true;
  }

  /**
   * @return the isOwnersOfRuleSet
   */
  public boolean getIsOwnersOfRuleSet() {
    return isOwnersOfRuleSet;
  }

  /**
   * @param isOwnersOfRuleSet
   *          the isOwnersOfRuleSet to set
   */
  public void setIsOwnersOfRuleSet(boolean isOwnersOfRuleSet) {
    this.isOwnersOfRuleSet = isOwnersOfRuleSet;
  }

  /**
   * @return the ruleSetVersion
   */
  public RuleSetVersion getRuleSetVersion() {
    return ruleSetVersion;
  }

  /**
   * @param ruleSetVersion
   *          the ruleSetVersion to set
   */
  public void setRuleSetVersion(RuleSetVersion ruleSetVersion) {
    this.ruleSetVersion = ruleSetVersion;
  }

  /**
   * @return the errorCheckSelectedRecord
   */
  public String getErrorCheckSelectedRecord() {
    return errorCheckSelectedRecord;
  }

}
