/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 2:37:08 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import st.liotrox.WRequest;

import com.st.common.web.LiotroxContants;
import com.st.common.web.util.DBFunctionConverter;
import com.st.persistence.SQLExecutor;
import com.st.persistence.util.Encoder;
import com.st.sc.common.CommonUtils;
import com.st.sc.util.DateTimeUtils;
import com.st.sc.util.SCWebServiceFactory;
import com.st.scc.common.utils.ConvertUtils;
import com.st.scc.common.utils.DateUtils;

/**
 * The Class FilterConditionInfo.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class FilterConditionInfo {

  private static final String DEFAULT_SINCE = "1";

  /**
   * Builds the from to condition.
   * 
   * @param columnName
   *          the column name
   * @param startTime
   *          the from value
   * @param endTime
   *          the to value
   * @return the string
   */
  public static String buildFromTo(final String columnName, final Date startTime,
      final Date endTime) {
    final StringBuilder condtion = new StringBuilder();
    if (startTime != null) {
      condtion.append(" AND ").append(columnName).append(" >= ")
          .append(DBFunctionConverter.getInstance().dateToString(startTime));
    }
    if (endTime != null) {
      condtion.append(" AND ").append(columnName).append(" <= ");
      condtion.append(DBFunctionConverter.getInstance().dateToString(endTime));
    }
    return condtion.toString();
  }

  /** The checked time from. */
  private String checkedTimeFrom;

  /** The checked time to. */
  private String checkedTimeTo;

  /** The checked time2 last. */
  private String checkedTime2Last;

  /** The checked time2 since. */
  private String checkedTime2Since;

  /** The checked time radio. */
  private String checkedTimeRadio;

  /** The mir start t from. */
  private String mirStartTFrom;

  /** The mir start t to. */
  private String mirStartTTo;

  /** The mir start t2 last. */
  private String mirStartT2Last;

  /** The mir start t2 since. */
  private String mirStartT2Since;

  /** The mir start t radio. */
  private String mirStartTRadio;

  /** The mir finish t from. */
  private String mirFinishTFrom;

  /** The mir finish t to. */
  private String mirFinishTTo;

  /** The mir finish t2 last. */
  private String mirFinishT2Last;

  /** The mir finish t2 since. */
  private String mirFinishT2Since;

  /** The mir finish t radio. */
  private String mirFinishTRadio;

  /** The part type value. */
  private String partTypeValue;

  /** The flow id value. */
  private String flowIdValue;

  /** The job name value. */
  private String jobNameValue;

  /** The dsgn rev value. */
  private String dsgnRevValue;

  /** The tstr type value. */
  private String tstrTypeValue;

  /** The job rev value. */
  private String jobRevValue;

  /** The mod code value. */
  private String modCodeValue;

  /** The exec typ value. */
  private String execTypValue;

  /** The spec nam value. */
  private String specNamValue;

  /** The cmod code value. */
  private String cmodCodeValue;

  /** The exec ver value. */
  private String execVerValue;

  /** The spec ver value. */
  private String specVerValue;

  /** The oper frq value. */
  private String operFrqValue;

  /** The proc id value. */
  private String procIdValue;

  /** The supr nam value. */
  private String suprNamValue;

  /** The compliancy score value. */
  private String compliancyScoreValue;

  /** The rule set value. */
  private String ruleSetValue;

  /** The rule set ver value. */
  private String ruleSetVerValue;

  /** The stdf file name value. */
  private String stdfFileNameValue;

  /** The part type op. */
  private String partTypeOp;

  /** The flow id op. */
  private String flowIdOp;

  /** The job name op. */
  private String jobNameOp;

  /** The dsgn rev op. */
  private String dsgnRevOp;

  /** The tstr type op. */
  private String tstrTypeOp;

  /** The job rev op. */
  private String jobRevOp;

  /** The mod code op. */
  private String modCodeOp;

  /** The exec typ op. */
  private String execTypOp;

  /** The spec nam op. */
  private String specNamOp;

  /** The cmod code op. */
  private String cmodCodeOp;

  /** The exec ver op. */
  private String execVerOp;

  /** The spec ver op. */
  private String specVerOp;

  /** The oper frq op. */
  private String operFrqOp;

  /** The proc id op. */
  private String procIdOp;

  /** The supr nam op. */
  private String suprNamOp;

  /** The compliancy score op. */
  private String compliancyScoreOp;

  /** The rule set op. */
  private String ruleSetOp;

  /** The rule set ver op. */
  private String ruleSetVerOp;

  /** The stdf file name op. */
  private String stdfFileNameOp;

  public FilterConditionInfo() {
    initDefaultValues();
  }

  /**
   * Builds the last since condition.
   * 
   * @param columnName
   *          the column name
   * @param startTime
   *          the start time
   * @param endTime
   *          the end time
   * @return the string
   */
  private String buildLastSince(final String columnName, final Date startTime,
      final Date endTime) {
    final StringBuilder condtion = new StringBuilder();
    if (startTime != null) {
      condtion.append(" AND ").append(columnName).append(" >= ")
          .append(DBFunctionConverter.getInstance().dateToString(startTime));
    }
    if (endTime != null) {
      condtion.append(" AND ").append(columnName).append(" < ")
          .append(DBFunctionConverter.getInstance().dateToString(endTime));
    }
    return condtion.toString();
  }

  /**
   * Builds the sql where.
   * 
   * @param params
   *          the params
   * @return the string
   * @throws ParseException
   *           the parse exception
   */
  public String buildSQLWhere(final Map<String, Object> params) throws ParseException {
    Date startTime = null;
    Date endTime = null;
    final StringBuilder where = new StringBuilder();
    if ("1".equals(checkedTimeRadio)) {
      startTime =
          DateTimeUtils.getStartDate(DateUtils.strToDate(checkedTimeFrom,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      endTime =
          DateTimeUtils.getEndDate(DateUtils.strToDate(checkedTimeTo,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      final String con = buildFromTo("CHECKING_TIME", startTime, endTime);
      if (con != null && con.length() > 0) {
        where.append(con);
      }
    } else if ("2".equals(checkedTimeRadio)) {
      final int lastDay = ConvertUtils.getInt(checkedTime2Last);
      final Date sinceDate =
          DateTimeUtils.getStartDate(DateUtils.strToDate(checkedTime2Since,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      endTime = DateTimeUtils.getNextDate(sinceDate);
      startTime = DateTimeUtils.getDateAfterXDays(sinceDate, -lastDay + 1);
      final String con = buildLastSince("CHECKING_TIME", startTime, endTime);
      if (con != null && con.length() > 0) {
        where.append(con);
      }
    }

    if ("1".equals(mirStartTRadio)) {
      startTime =
          DateTimeUtils.getStartDate(DateUtils.strToDate(mirStartTFrom,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      endTime =
          DateTimeUtils.getEndDate(DateUtils.strToDate(mirStartTTo,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      final String con = buildFromTo("MIR_START_T", startTime, endTime);
      if (con != null && con.length() > 0) {
        where.append(con);
      }
    } else if ("2".equals(mirStartTRadio)) {
      final int lastDay = ConvertUtils.getInt(mirStartT2Last);
      final Date sinceDate =
          DateTimeUtils.getEndDate(DateUtils.strToDate(mirStartT2Since,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      endTime = DateTimeUtils.getNextDate(sinceDate);
      startTime = DateTimeUtils.getDateAfterXDays(sinceDate, -lastDay + 1);
      final String con = buildLastSince("MIR_START_T", startTime, endTime);
      if (con != null && con.length() > 0) {
        where.append(con);
      }
    }

    if ("1".equals(mirFinishTRadio)) {
      startTime =
          DateTimeUtils.getStartDate(DateUtils.strToDate(mirFinishTFrom,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      endTime =
          DateTimeUtils.getStartDate(DateUtils.strToDate(mirFinishTTo,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      final String con = buildFromTo("MRR_FINISH_T", startTime, endTime);
      if (con != null && con.length() > 0) {
        where.append(con);
      }
    } else if ("2".equals(mirFinishTRadio)) {
      final int lastDay = ConvertUtils.getInt(mirFinishT2Last);
      final Date sinceDate =
          DateTimeUtils.getStartDate(DateUtils.strToDate(mirFinishT2Since,
              LiotroxContants.DEFAULT_DATE_FORMAT));
      endTime = DateTimeUtils.getNextDate(sinceDate);
      startTime = DateTimeUtils.getDateAfterXDays(sinceDate, -lastDay + 1);
      final String conn = buildLastSince("MRR_FINISH_T", startTime, endTime);
      where.append(conn);
    }

    if (compliancyScoreValue != null && compliancyScoreValue.length() > 0) {
      final String tmpVal = compliancyScoreValue.replace("~", ",").trim();
      final String[] fromto = tmpVal.split(",");
      final Double from = ConvertUtils.getDoubleObject(fromto[0]);
      Double to = null;
      if (fromto.length == 1) {
        to = 100.0;
      } else {
        to = ConvertUtils.getDoubleObject(fromto[1]);
      }
      if ("=".equals(compliancyScoreOp) || ">".equals(compliancyScoreOp)
          || "<".equals(compliancyScoreOp) || ">=".equals(compliancyScoreOp)
          || "<=".equals(compliancyScoreOp)) {
        where.append(" AND COMPLIANCY_SCORE ").append(compliancyScoreOp).append(" ")
            .append(from);
      } else {
        where.append(" AND COMPLIANCY_SCORE >= ").append(from)
            .append(" AND COMPLIANCY_SCORE <= ").append(to);
      }
    }

    updateSQL("RULE_SET_NAME", ruleSetValue, ruleSetOp, where, params);
    updateSQL("RULE_SET_VER", ruleSetVerValue, ruleSetVerOp, where, params);
    updateSQL("MIR_PART_TYP", partTypeValue, partTypeOp, where, params);
    updateSQL("MIR_DSGN_REV", dsgnRevValue, dsgnRevOp, where, params);
    updateSQL("MIR_CMOD_COD", cmodCodeValue, cmodCodeOp, where, params);
    updateSQL("MIR_OPER_FRQ", operFrqValue, operFrqOp, where, params);
    updateSQL("MIR_FLOW_ID", flowIdValue, flowIdOp, where, params);
    updateSQL("MIR_TSTR_TYP", tstrTypeValue, tstrTypeOp, where, params);
    updateSQL("MIR_EXEC_TYP", execTypValue, execTypOp, where, params);
    updateSQL("MIR_EXEC_VER", execVerValue, execVerOp, where, params);
    updateSQL("MIR_JOB_NAM", jobNameValue, jobNameOp, where, params);
    updateSQL("MIR_JOB_REV", jobRevValue, jobRevOp, where, params);
    updateSQL("MIR_SPEC_NAM", specNamValue, specNamOp, where, params);
    updateSQL("MIR_SPEC_VER", specVerValue, specVerOp, where, params);
    updateSQL("MIR_PROC_ID", procIdValue, procIdOp, where, params);
    updateSQL("MIR_SUPR_NAM", suprNamValue, suprNamOp, where, params);
    updateSQL("MIR_MODE_COD", modCodeValue, modCodeOp, where, params);
    updateSQLnoEncode("FILE_NAME", stdfFileNameValue, stdfFileNameOp, where, params);

    return where.toString();
  }

  /**
   * Fill value.
   * 
   * @param request
   *          the request
   * @throws Exception
   *           the exception
   */
  public void fillValue(final WRequest request) throws Exception {
    final Field[] fields = this.getClass().getDeclaredFields();
    Method setMethod = null;
    for (final Field f : fields) {
      setMethod = CommonUtils.getSetMethod(this.getClass(), f);
      if (setMethod != null) {
        setMethod.invoke(this,
            request.getParameter(CommonUtils.getHTTPParamName(this.getClass(), f)));
      }
    }
  }

  /**
   * Gets the checked time2 last.
   * 
   * @return the checked time2 last
   */
  public String getCheckedTime2Last() {
    return checkedTime2Last;
  }

  /**
   * Gets the checked time2 since.
   * 
   * @return the checked time2 since
   */
  public String getCheckedTime2Since() {
    return checkedTime2Since;
  }

  /**
   * Gets the checked time from.
   * 
   * @return the checked time from
   */
  public String getCheckedTimeFrom() {
    return checkedTimeFrom;
  }

  /**
   * Gets the checked time radio.
   * 
   * @return the checked time radio
   */
  public String getCheckedTimeRadio() {
    return checkedTimeRadio;
  }

  /**
   * Gets the checked time to.
   * 
   * @return the checked time to
   */
  public String getCheckedTimeTo() {
    return checkedTimeTo;
  }

  /**
   * Gets the cmod code op.
   * 
   * @return the cmod code op
   */
  public String getCmodCodeOp() {
    return cmodCodeOp;
  }

  /**
   * Gets the cmod code value.
   * 
   * @return the cmod code value
   */
  public String getCmodCodeValue() {
    return cmodCodeValue;
  }

  /**
   * Gets the compliancy score op.
   * 
   * @return the compliancy score op
   */
  public String getCompliancyScoreOp() {
    return compliancyScoreOp;
  }

  /**
   * Gets the compliancy score value.
   * 
   * @return the compliancy score value
   */
  public String getCompliancyScoreValue() {
    return compliancyScoreValue;
  }

  private String getDefaultDate() {
    return DateUtils.dateToString(new Date(), LiotroxContants.DEFAULT_DATE_FORMAT);
  }

  /**
   * Gets the dsgn rev op.
   * 
   * @return the dsgn rev op
   */
  public String getDsgnRevOp() {
    return dsgnRevOp;
  }

  /**
   * Gets the dsgn rev value.
   * 
   * @return the dsgn rev value
   */
  public String getDsgnRevValue() {
    return dsgnRevValue;
  }

  /**
   * Gets the exec typ op.
   * 
   * @return the exec typ op
   */
  public String getExecTypOp() {
    return execTypOp;
  }

  /**
   * Gets the exec typ value.
   * 
   * @return the exec typ value
   */
  public String getExecTypValue() {
    return execTypValue;
  }

  /**
   * Gets the exec ver op.
   * 
   * @return the exec ver op
   */
  public String getExecVerOp() {
    return execVerOp;
  }

  /**
   * Gets the exec ver value.
   * 
   * @return the exec ver value
   */
  public String getExecVerValue() {
    return execVerValue;
  }

  /**
   * Gets the flow id op.
   * 
   * @return the flow id op
   */
  public String getFlowIdOp() {
    return flowIdOp;
  }

  /**
   * Gets the flow id value.
   * 
   * @return the flow id value
   */
  public String getFlowIdValue() {
    return flowIdValue;
  }

  /**
   * Gets the job name op.
   * 
   * @return the job name op
   */
  public String getJobNameOp() {
    return jobNameOp;
  }

  /**
   * Gets the job name value.
   * 
   * @return the job name value
   */
  public String getJobNameValue() {
    return jobNameValue;
  }

  /**
   * Gets the job rev op.
   * 
   * @return the job rev op
   */
  public String getJobRevOp() {
    return jobRevOp;
  }

  /**
   * Gets the job rev value.
   * 
   * @return the job rev value
   */
  public String getJobRevValue() {
    return jobRevValue;
  }

  /**
   * Gets the mir finish t2 last.
   * 
   * @return the mir finish t2 last
   */
  public String getMirFinishT2Last() {
    return mirFinishT2Last;
  }

  /**
   * Gets the mir finish t2 since.
   * 
   * @return the mir finish t2 since
   */
  public String getMirFinishT2Since() {
    return mirFinishT2Since;
  }

  /**
   * Gets the mir finish t from.
   * 
   * @return the mir finish t from
   */
  public String getMirFinishTFrom() {
    return mirFinishTFrom;
  }

  /**
   * Gets the mir finish t radio.
   * 
   * @return the mir finish t radio
   */
  public String getMirFinishTRadio() {
    return mirFinishTRadio;
  }

  /**
   * Gets the mir finish t to.
   * 
   * @return the mir finish t to
   */
  public String getMirFinishTTo() {
    return mirFinishTTo;
  }

  /**
   * Gets the mir start t2 last.
   * 
   * @return the mir start t2 last
   */
  public String getMirStartT2Last() {
    return mirStartT2Last;
  }

  /**
   * Gets the mir start t2 since.
   * 
   * @return the mir start t2 since
   */
  public String getMirStartT2Since() {
    return mirStartT2Since;
  }

  /**
   * Gets the mir start t from.
   * 
   * @return the mir start t from
   */
  public String getMirStartTFrom() {
    return mirStartTFrom;
  }

  /**
   * Gets the mir start t radio.
   * 
   * @return the mir start t radio
   */
  public String getMirStartTRadio() {
    return mirStartTRadio;
  }

  /**
   * Gets the mir start t to.
   * 
   * @return the mir start t to
   */
  public String getMirStartTTo() {
    return mirStartTTo;
  }

  /**
   * Gets the mod code op.
   * 
   * @return the mod code op
   */
  public String getModCodeOp() {
    return modCodeOp;
  }

  /**
   * Gets the mod code value.
   * 
   * @return the mod code value
   */
  public String getModCodeValue() {
    return modCodeValue;
  }

  /**
   * Gets the oper frq op.
   * 
   * @return the oper frq op
   */
  public String getOperFrqOp() {
    return operFrqOp;
  }

  /**
   * Gets the oper frq value.
   * 
   * @return the oper frq value
   */
  public String getOperFrqValue() {
    return operFrqValue;
  }

  /**
   * Gets the part type op.
   * 
   * @return the part type op
   */
  public String getPartTypeOp() {
    return partTypeOp;
  }

  /**
   * Gets the part type value.
   * 
   * @return the part type value
   */
  public String getPartTypeValue() {
    return partTypeValue;
  }

  /**
   * Gets the proc id op.
   * 
   * @return the proc id op
   */
  public String getProcIdOp() {
    return procIdOp;
  }

  /**
   * Gets the proc id value.
   * 
   * @return the proc id value
   */
  public String getProcIdValue() {
    return procIdValue;
  }

  /**
   * Gets the rule set op.
   * 
   * @return the rule set op
   */
  public String getRuleSetOp() {
    return ruleSetOp;
  }

  /**
   * Gets the rule set value.
   * 
   * @return the rule set value
   */
  public String getRuleSetValue() {
    return ruleSetValue;
  }

  /**
   * Gets the rule set ver op.
   * 
   * @return the rule set ver op
   */
  public String getRuleSetVerOp() {
    return ruleSetVerOp;
  }

  /**
   * Gets the rule set ver value.
   * 
   * @return the rule set ver value
   */
  public String getRuleSetVerValue() {
    return ruleSetVerValue;
  }

  /**
   * Gets the spec nam op.
   * 
   * @return the spec nam op
   */
  public String getSpecNamOp() {
    return specNamOp;
  }

  /**
   * Gets the spec nam value.
   * 
   * @return the spec nam value
   */
  public String getSpecNamValue() {
    return specNamValue;
  }

  /**
   * Gets the spec ver op.
   * 
   * @return the spec ver op
   */
  public String getSpecVerOp() {
    return specVerOp;
  }

  /**
   * Gets the spec ver value.
   * 
   * @return the spec ver value
   */
  public String getSpecVerValue() {
    return specVerValue;
  }

  /**
   * Gets the stdf file name op.
   * 
   * @return the stdf file name op
   */
  public String getStdfFileNameOp() {
    return stdfFileNameOp;
  }

  /**
   * Gets the stdf file name value.
   * 
   * @return the stdf file name value
   */
  public String getStdfFileNameValue() {
    return stdfFileNameValue;
  }

  /**
   * Gets the supr nam op.
   * 
   * @return the supr nam op
   */
  public String getSuprNamOp() {
    return suprNamOp;
  }

  /**
   * Gets the supr nam value.
   * 
   * @return the supr nam value
   */
  public String getSuprNamValue() {
    return suprNamValue;
  }

  /**
   * Gets the tstr type op.
   * 
   * @return the tstr type op
   */
  public String getTstrTypeOp() {
    return tstrTypeOp;
  }

  /**
   * Gets the tstr type value.
   * 
   * @return the tstr type value
   */
  public String getTstrTypeValue() {
    return tstrTypeValue;
  }

  private void initDefaultValues() {
    checkedTimeFrom = getDefaultDate();
    checkedTimeTo = getDefaultDate();
    checkedTime2Last = DEFAULT_SINCE;
    checkedTime2Since = getDefaultDate();
    mirStartTFrom = getDefaultDate();
    mirStartTTo = getDefaultDate();
    mirStartT2Last = DEFAULT_SINCE;
    mirStartT2Since = getDefaultDate();
    mirFinishTFrom = getDefaultDate();
    mirFinishTTo = getDefaultDate();
    mirFinishT2Last = DEFAULT_SINCE;
    mirFinishT2Since = getDefaultDate();
    checkedTimeRadio = "1";
  }

  /**
   * Reset.
   */
  public void reset() {
    checkedTimeFrom = null;
    checkedTimeTo = null;
    checkedTime2Last = null;
    checkedTime2Since = null;
    checkedTimeRadio = null;
    mirStartTFrom = null;
    mirStartTTo = null;
    mirStartT2Last = null;
    mirStartT2Since = null;
    mirStartTRadio = null;
    mirFinishTFrom = null;
    mirFinishTTo = null;
    mirFinishT2Last = null;
    mirFinishT2Since = null;
    mirFinishTRadio = null;
    partTypeValue = null;
    flowIdValue = null;
    jobNameValue = null;
    dsgnRevValue = null;
    tstrTypeValue = null;
    jobRevValue = null;
    modCodeValue = null;
    execTypValue = null;
    specNamValue = null;
    cmodCodeValue = null;
    execVerValue = null;
    specVerValue = null;
    operFrqValue = null;
    procIdValue = null;
    suprNamValue = null;
    compliancyScoreValue = null;
    ruleSetValue = null;
    ruleSetVerValue = null;
    stdfFileNameValue = null;
    partTypeOp = null;
    flowIdOp = null;
    jobNameOp = null;
    dsgnRevOp = null;
    tstrTypeOp = null;
    jobRevOp = null;
    modCodeOp = null;
    execTypOp = null;
    specNamOp = null;
    cmodCodeOp = null;
    execVerOp = null;
    specVerOp = null;
    operFrqOp = null;
    procIdOp = null;
    suprNamOp = null;
    compliancyScoreOp = null;
    ruleSetOp = null;
    ruleSetVerOp = null;
    stdfFileNameOp = null;
  }

  /**
   * Sets the checked time2 last.
   * 
   * @param checkedTime2Last
   *          the new checked time2 last
   */
  public void setCheckedTime2Last(final String checkedTime2Last) {
    this.checkedTime2Last = checkedTime2Last;
  }

  /**
   * Sets the checked time2 since.
   * 
   * @param checkedTime2Since
   *          the new checked time2 since
   */
  public void setCheckedTime2Since(final String checkedTime2Since) {
    this.checkedTime2Since = checkedTime2Since;
  }

  /**
   * Sets the checked time from.
   * 
   * @param checkedTimeFrom
   *          the new checked time from
   */
  public void setCheckedTimeFrom(final String checkedTimeFrom) {
    this.checkedTimeFrom = checkedTimeFrom;
  }

  /**
   * Sets the checked time radio.
   * 
   * @param checkedTimeRadio
   *          the new checked time radio
   */
  public void setCheckedTimeRadio(final String checkedTimeRadio) {
    this.checkedTimeRadio = checkedTimeRadio;
  }

  /**
   * Sets the checked time to.
   * 
   * @param checkedTimeTo
   *          the new checked time to
   */
  public void setCheckedTimeTo(final String checkedTimeTo) {
    this.checkedTimeTo = checkedTimeTo;
  }

  /**
   * Sets the cmod code op.
   * 
   * @param cmodCodeOp
   *          the new cmod code op
   */
  public void setCmodCodeOp(final String cmodCodeOp) {
    this.cmodCodeOp = cmodCodeOp;
  }

  /**
   * Sets the cmod code value.
   * 
   * @param cmodCodeValue
   *          the new cmod code value
   */
  public void setCmodCodeValue(final String cmodCodeValue) {
    this.cmodCodeValue = cmodCodeValue;
  }

  /**
   * Sets the compliancy score op.
   * 
   * @param compliancyScoreOp
   *          the new compliancy score op
   */
  public void setCompliancyScoreOp(final String compliancyScoreOp) {
    this.compliancyScoreOp = compliancyScoreOp;
  }

  /**
   * Sets the compliancy score value.
   * 
   * @param compliancyScoreValue
   *          the new compliancy score value
   */
  public void setCompliancyScoreValue(final String compliancyScoreValue) {
    this.compliancyScoreValue = compliancyScoreValue;
  }

  /**
   * Sets the dsgn rev op.
   * 
   * @param dsgnRevOp
   *          the new dsgn rev op
   */
  public void setDsgnRevOp(final String dsgnRevOp) {
    this.dsgnRevOp = dsgnRevOp;
  }

  /**
   * Sets the dsgn rev value.
   * 
   * @param dsgnRevValue
   *          the new dsgn rev value
   */
  public void setDsgnRevValue(final String dsgnRevValue) {
    this.dsgnRevValue = dsgnRevValue;
  }

  /**
   * Sets the exec typ op.
   * 
   * @param execTypOp
   *          the new exec typ op
   */
  public void setExecTypOp(final String execTypOp) {
    this.execTypOp = execTypOp;
  }

  /**
   * Sets the exec typ value.
   * 
   * @param execTypValue
   *          the new exec typ value
   */
  public void setExecTypValue(final String execTypValue) {
    this.execTypValue = execTypValue;
  }

  /**
   * Sets the exec ver op.
   * 
   * @param execVerOp
   *          the new exec ver op
   */
  public void setExecVerOp(final String execVerOp) {
    this.execVerOp = execVerOp;
  }

  /**
   * Sets the exec ver value.
   * 
   * @param execVerValue
   *          the new exec ver value
   */
  public void setExecVerValue(final String execVerValue) {
    this.execVerValue = execVerValue;
  }

  /**
   * Sets the flow id op.
   * 
   * @param flowIdOp
   *          the new flow id op
   */
  public void setFlowIdOp(final String flowIdOp) {
    this.flowIdOp = flowIdOp;
  }

  /**
   * Sets the flow id value.
   * 
   * @param flowIdValue
   *          the new flow id value
   */
  public void setFlowIdValue(final String flowIdValue) {
    this.flowIdValue = flowIdValue;
  }

  /**
   * Sets the job name op.
   * 
   * @param jobNameOp
   *          the new job name op
   */
  public void setJobNameOp(final String jobNameOp) {
    this.jobNameOp = jobNameOp;
  }

  /**
   * Sets the job name value.
   * 
   * @param jobNameValue
   *          the new job name value
   */
  public void setJobNameValue(final String jobNameValue) {
    this.jobNameValue = jobNameValue;
  }

  /**
   * Sets the job rev op.
   * 
   * @param jobRevOp
   *          the new job rev op
   */
  public void setJobRevOp(final String jobRevOp) {
    this.jobRevOp = jobRevOp;
  }

  /**
   * Sets the job rev value.
   * 
   * @param jobRevValue
   *          the new job rev value
   */
  public void setJobRevValue(final String jobRevValue) {
    this.jobRevValue = jobRevValue;
  }

  /**
   * Sets the mir finish t2 last.
   * 
   * @param mirFinishT2Last
   *          the new mir finish t2 last
   */
  public void setMirFinishT2Last(final String mirFinishT2Last) {
    this.mirFinishT2Last = mirFinishT2Last;
  }

  /**
   * Sets the mir finish t2 since.
   * 
   * @param mirFinishT2Since
   *          the new mir finish t2 since
   */
  public void setMirFinishT2Since(final String mirFinishT2Since) {
    this.mirFinishT2Since = mirFinishT2Since;
  }

  /**
   * Sets the mir finish t from.
   * 
   * @param mirFinishTFrom
   *          the new mir finish t from
   */
  public void setMirFinishTFrom(final String mirFinishTFrom) {
    this.mirFinishTFrom = mirFinishTFrom;
  }

  /**
   * Sets the mir finish t radio.
   * 
   * @param mirFinishTRadio
   *          the new mir finish t radio
   */
  public void setMirFinishTRadio(final String mirFinishTRadio) {
    this.mirFinishTRadio = mirFinishTRadio;
  }

  /**
   * Sets the mir finish t to.
   * 
   * @param mirFinishTTo
   *          the new mir finish t to
   */
  public void setMirFinishTTo(final String mirFinishTTo) {
    this.mirFinishTTo = mirFinishTTo;
  }

  /**
   * Sets the mir start t2 last.
   * 
   * @param mirStartT2Last
   *          the new mir start t2 last
   */
  public void setMirStartT2Last(final String mirStartT2Last) {
    this.mirStartT2Last = mirStartT2Last;
  }

  /**
   * Sets the mir start t2 since.
   * 
   * @param mirStartT2Since
   *          the new mir start t2 since
   */
  public void setMirStartT2Since(final String mirStartT2Since) {
    this.mirStartT2Since = mirStartT2Since;
  }

  /**
   * Sets the mir start t from.
   * 
   * @param mirStartTFrom
   *          the new mir start t from
   */
  public void setMirStartTFrom(final String mirStartTFrom) {
    this.mirStartTFrom = mirStartTFrom;
  }

  /**
   * Sets the mir start t radio.
   * 
   * @param mirStartTRadio
   *          the new mir start t radio
   */
  public void setMirStartTRadio(final String mirStartTRadio) {
    this.mirStartTRadio = mirStartTRadio;
  }

  /**
   * Sets the mir start t to.
   * 
   * @param mirStartTTo
   *          the new mir start t to
   */
  public void setMirStartTTo(final String mirStartTTo) {
    this.mirStartTTo = mirStartTTo;
  }

  /**
   * Sets the mod code op.
   * 
   * @param modCodeOp
   *          the new mod code op
   */
  public void setModCodeOp(final String modCodeOp) {
    this.modCodeOp = modCodeOp;
  }

  /**
   * Sets the mod code value.
   * 
   * @param modCodeValue
   *          the new mod code value
   */
  public void setModCodeValue(final String modCodeValue) {
    this.modCodeValue = modCodeValue;
  }

  /**
   * Sets the oper frq op.
   * 
   * @param operFrqOp
   *          the new oper frq op
   */
  public void setOperFrqOp(final String operFrqOp) {
    this.operFrqOp = operFrqOp;
  }

  /**
   * Sets the oper frq value.
   * 
   * @param operFrqValue
   *          the new oper frq value
   */
  public void setOperFrqValue(final String operFrqValue) {
    this.operFrqValue = operFrqValue;
  }

  /**
   * Sets the part type op.
   * 
   * @param partTypeOp
   *          the new part type op
   */
  public void setPartTypeOp(final String partTypeOp) {
    this.partTypeOp = partTypeOp;
  }

  /**
   * Sets the part type value.
   * 
   * @param partTypeValue
   *          the new part type value
   */
  public void setPartTypeValue(final String partTypeValue) {
    this.partTypeValue = partTypeValue;
  }

  /**
   * Sets the proc id op.
   * 
   * @param procIdOp
   *          the new proc id op
   */
  public void setProcIdOp(final String procIdOp) {
    this.procIdOp = procIdOp;
  }

  /**
   * Sets the proc id value.
   * 
   * @param procIdValue
   *          the new proc id value
   */
  public void setProcIdValue(final String procIdValue) {
    this.procIdValue = procIdValue;
  }

  /**
   * Sets the rule set op.
   * 
   * @param ruleSetOp
   *          the new rule set op
   */
  public void setRuleSetOp(final String ruleSetOp) {
    this.ruleSetOp = ruleSetOp;
  }

  /**
   * Sets the rule set value.
   * 
   * @param ruleSetValue
   *          the new rule set value
   */
  public void setRuleSetValue(final String ruleSetValue) {
    this.ruleSetValue = ruleSetValue;
  }

  /**
   * Sets the rule set ver op.
   * 
   * @param ruleSetVerOp
   *          the new rule set ver op
   */
  public void setRuleSetVerOp(final String ruleSetVerOp) {
    this.ruleSetVerOp = ruleSetVerOp;
  }

  /**
   * Sets the rule set ver value.
   * 
   * @param ruleSetVerValue
   *          the new rule set ver value
   */
  public void setRuleSetVerValue(final String ruleSetVerValue) {
    this.ruleSetVerValue = ruleSetVerValue;
  }

  /**
   * Sets the spec nam op.
   * 
   * @param specNamOp
   *          the new spec nam op
   */
  public void setSpecNamOp(final String specNamOp) {
    this.specNamOp = specNamOp;
  }

  /**
   * Sets the spec nam value.
   * 
   * @param specNamValue
   *          the new spec nam value
   */
  public void setSpecNamValue(final String specNamValue) {
    this.specNamValue = specNamValue;
  }

  /**
   * Sets the spec ver op.
   * 
   * @param specVerOp
   *          the new spec ver op
   */
  public void setSpecVerOp(final String specVerOp) {
    this.specVerOp = specVerOp;
  }

  /**
   * Sets the spec ver value.
   * 
   * @param specVerValue
   *          the new spec ver value
   */
  public void setSpecVerValue(final String specVerValue) {
    this.specVerValue = specVerValue;
  }

  /**
   * Sets the stdf file name op.
   * 
   * @param stdfFileNameOp
   *          the new stdf file name op
   */
  public void setStdfFileNameOp(final String stdfFileNameOp) {
    this.stdfFileNameOp = stdfFileNameOp;
  }

  /**
   * Sets the stdf file name value.
   * 
   * @param stdfFileNameValue
   *          the new stdf file name value
   */
  public void setStdfFileNameValue(final String stdfFileNameValue) {
    this.stdfFileNameValue = stdfFileNameValue == null ? null : stdfFileNameValue.trim();
  }

  /**
   * Sets the supr nam op.
   * 
   * @param suprNamOp
   *          the new supr nam op
   */
  public void setSuprNamOp(final String suprNamOp) {
    this.suprNamOp = suprNamOp;
  }

  /**
   * Sets the supr nam value.
   * 
   * @param suprNamValue
   *          the new supr nam value
   */
  public void setSuprNamValue(final String suprNamValue) {
    this.suprNamValue = suprNamValue;
  }

  /**
   * Sets the tstr type op.
   * 
   * @param tstrTypeOp
   *          the new tstr type op
   */
  public void setTstrTypeOp(final String tstrTypeOp) {
    this.tstrTypeOp = tstrTypeOp;
  }

  /**
   * Sets the tstr type value.
   * 
   * @param tstrTypeValue
   *          the new tstr type value
   */
  public void setTstrTypeValue(final String tstrTypeValue) {
    this.tstrTypeValue = tstrTypeValue;
  }

  /**
   * To string.
   * 
   * @return the string {@inheritDoc}
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder(512);
    sb.append("FilterConditionInfo [checkedTimeFrom=").append(checkedTimeFrom);
    sb.append(", checkedTimeTo=").append(checkedTimeTo);
    sb.append(", checkedTime2Last=").append(checkedTime2Last);
    sb.append(", checkedTime2Since=").append(checkedTime2Since);
    sb.append(", checkedTimeRadio=").append(checkedTimeRadio);
    sb.append(", mirStartTFrom=").append(mirStartTFrom);
    sb.append(", mirStartTTo=").append(mirStartTTo);
    sb.append(", mirStartT2Last=").append(mirStartT2Last);
    sb.append(", mirStartT2Since=").append(mirStartT2Since);
    sb.append(", mirStartTRadio=").append(mirStartTRadio);
    sb.append(", mirFinishTFrom=").append(mirFinishTFrom);
    sb.append(", mirFinishTTo=").append(mirFinishTTo);
    sb.append(", mirFinishT2Last=").append(mirFinishT2Last);
    sb.append(", mirFinishT2Since=").append(mirFinishT2Since);
    sb.append(", mirFinishTRadio=").append(mirFinishTRadio);
    sb.append(", partTypeValue=").append(partTypeValue);
    sb.append(", flowIdValue=").append(flowIdValue);
    sb.append(", jobNameValue=").append(jobNameValue);
    sb.append(", dsgnRevValue=").append(dsgnRevValue);
    sb.append(", tstrTypeValue=").append(tstrTypeValue);
    sb.append(", jobRevValue=").append(jobRevValue);
    sb.append(", modCodeValue=").append(modCodeValue);
    sb.append(", execTypValue=").append(execTypValue);
    sb.append(", specNamValue=").append(specNamValue);
    sb.append(", cmodCodeValue=").append(cmodCodeValue);
    sb.append(", execVerValue=").append(execVerValue);
    sb.append(", specVerValue=").append(specVerValue);
    sb.append(", operFrqValue=").append(operFrqValue);
    sb.append(", procIdValue=").append(procIdValue);
    sb.append(", suprNamValue=").append(suprNamValue);
    sb.append(", compliancyScoreValue=").append(compliancyScoreValue);
    sb.append(", ruleSetValue=").append(ruleSetValue);
    sb.append(", ruleSetVerValue=").append(ruleSetVerValue);
    sb.append(", stdfFileNameValue=").append(stdfFileNameValue);
    sb.append(", partTypeOp=").append(partTypeOp);
    sb.append(", flowIdOp=").append(flowIdOp);
    sb.append(", jobNameOp=").append(jobNameOp);
    sb.append(", dsgnRevOp=").append(dsgnRevOp);
    sb.append(", tstrTypeOp=").append(tstrTypeOp);
    sb.append(", jobRevOp=").append(jobRevOp);
    sb.append(", modCodeOp=").append(modCodeOp);
    sb.append(", execTypOp=").append(execTypOp);
    sb.append(", specNamOp=").append(specNamOp);
    sb.append(", cmodCodeOp=").append(cmodCodeOp);
    sb.append(", execVerOp=").append(execVerOp);
    sb.append(", specVerOp=").append(specVerOp);
    sb.append(", operFrqOp=").append(operFrqOp);
    sb.append(", procIdOp=").append(procIdOp);
    sb.append(", suprNamOp=").append(suprNamOp);
    sb.append(", compliancyScoreOp=").append(compliancyScoreOp);
    sb.append(", ruleSetOp=").append(ruleSetOp);
    sb.append(", ruleSetVerOp=").append(ruleSetVerOp);
    sb.append(", stdfFileNameOp=").append(stdfFileNameOp).append("]");
    return sb.toString();
  }

  /**
   * Update sql.
   * 
   * @param fieldName
   *          the field name
   * @param value
   *          the value
   * @param op
   *          the op
   * @param sql
   *          the sql
   * @param params
   *          the params
   */
  private void updateSQL(final String fieldName, final String value, final String op,
      final StringBuilder sql, final Map<String, Object> params) {
    final SQLExecutor exe = SCWebServiceFactory.getSCExecutor();

    if (value != null && value.length() > 0) {
      sql.append(" AND ").append(fieldName).append(" ").append(op).append(" '");
      sql.append(Encoder.encodeForSQL(exe.getDBCodec(), value));
      sql.append("'");
    }
  }

  /**
   * Update sql.
   * 
   * @param fieldName
   * @param value
   * @param op
   * @param sql
   * @param params
   */
  private void updateSQLnoEncode(final String fieldName, final String value, final String op,
      final StringBuilder sql, final Map<String, Object> params) {
    if (value != null && value.length() > 0) {
      sql.append(" AND ").append(fieldName).append(" ").append(op).append(" '");
      sql.append(value);
      sql.append("'");
    }
  }

}
