package com.st.sc.webapp.reports;

import com.st.common.exception.SccException;
import com.st.sc.web.data.ReportData;

public class ScoreTableSetting extends BaseReportSetting {

  public String validateInputData() {
    return validateInputData("score_table_category_");
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.sc.webapp.reports.BaseReportSetting#getDataToShowReport()
   */
  public ReportData getDataToShowReport(final String viewName,final boolean isOnlineReport) throws SccException {
    initializeInputData();

    ReportData entity =
        getValuesToCreateScoreTableAndChart(mirField, null, true, scoreRanges, null, viewName,
            isOnlineReport);
    return entity;
  }

  public void generateSeries() {
    serieValues = generateSeries(numberOfSeries);
  }

  public String getReportTitle() {
    return " Compliancy by " + mirField;
  }

  public ScoreTableSetting copySetting() {
    ScoreTableSetting setting = new ScoreTableSetting();
    updateSetting(setting);
    return setting;
  }
}
