/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 25, 2011 4:00:19 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.util.List;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All rights reserved.
 *
 */
public class RuleDTO {
  private Long ruleId;
  private String ruleName;
 
  private List<RuleVersionDTO> ruleVersionList;
  private Integer selectedIndex;
  
  /**
   * @return the ruleId
   */
  public Long getRuleId() {
    return ruleId;
  }

  /**
   * @param ruleId the ruleId to set
   */
  public void setRuleId(Long ruleId) {
    this.ruleId = ruleId;
  }

  /**
   * @return the ruleName
   */
  public String getRuleName() {
    return ruleName;
  }

  /**
   * @param ruleName the ruleName to set
   */
  public void setRuleName(String ruleName) {
    this.ruleName = ruleName;
  }

  /**
   * @return the ruleVersionList
   */
  public List<RuleVersionDTO> getRuleVersionList() {
    return ruleVersionList;
  }

  /**
   * @param ruleVersionList the ruleVersionList to set
   */
  public void setRuleVersionList(List<RuleVersionDTO> ruleVersionList) {
    this.ruleVersionList = ruleVersionList;
  }

  /**
   * @return the selectedIndex
   */
  public Integer getSelectedIndex() {
    return selectedIndex;
  }

  /**
   * @param selectedIndex the selectedIndex to set
   */
  public void setSelectedIndex(Integer selectedIndex) {
    this.selectedIndex = selectedIndex;
  }
    
}
