package st.liotrox.dataview;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.dataview.event.DataViewPropertyChangeEvent;
import st.liotrox.db.DataSet;

/**
 * The Class SCDataview.
 */
public abstract class SCDataview extends DataView {

  private static final Logger LOGGER = LoggerFactory.getLogger(SCDataview.class);
  
  /** The current page. */
  private int currentPage = 1;

  /** The page rows. */
  private int pageRows = 0;

  /** The first displayed row. */
  private int firstDisplayedRow = 1;

  /** The row count. */
  private int rowCount = 1000;

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#getCurrentPage()
   */
  public int getCurrentPage() {
    return currentPage;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#getFirstDisplayedRow()
   */
  public int getFirstDisplayedRow() {
    if (getPageRows() == 0) {
      return 1;
    }
    if (getPageRows() == -1) {
      if (getModel().getSections().getCount() == 0) {
        raiseException("DataView.getFirstDisplayedRow(): cannot display the DataView in 'section' mode: no defined sections");
      }
      return getModel().getSections().get(getCurrentSection()).getStartRow();
    }
    LOGGER.debug("getFirstDisplayedRow = " + firstDisplayedRow);
    return firstDisplayedRow;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#getPageCount()
   */
  public int getPageCount() {

    if (getPageRows() == 0) {
      return 1;
    }

    int t = getRowCount() / getPageRows();
    if (getRowCount() % getPageRows() != 0) {
      ++t;
    }
    LOGGER.debug("getPageCount = " + t);
    return t;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#getPageRows()
   */
  public int getPageRows() {
    return pageRows;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#getRenderedRowInterval()
   */
  public RenderedRowInterval getRenderedRowInterval() {
    int startRow = 1;
    int endRow = startRow + pageRows - 1;

    final int rowCount = getModel().getDataSet().getRowCount();

    if (pageRows == 0) {
      startRow = 1;
      endRow = rowCount;
    }
    if (pageRows == -1) {
      if (getModel().getSections().getCount() == 0) {
        raiseException("DataView.getFirstRenderedRow(): cannot display the DataView in 'section' mode: no defined sections");
      }
      final Section s = getModel().getSections().get(getCurrentSection());
      startRow = s.getStartRow();
      endRow = s.getEndRow();
      if (endRow == 0) {
        endRow = rowCount;
      }
    }

    if (startRow < 1) {
      startRow = 1;
    }
    if (endRow > rowCount) {
      endRow = rowCount;
    }

    final RenderedRowInterval ri = new RenderedRowInterval(startRow, endRow);
    return ri;
  }

  /**
   * Gets the row count.
   * 
   * @return the row count
   */
  public int getRowCount() {
    return rowCount;
  }

  /**
   * Sets the row count.
   * 
   * @param rowCount
   *          the new row count
   */
  public void setRowCount(final int rowCount) {
    this.rowCount = rowCount;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#gotoFirstPage()
   */
  public void gotoFirstPage() {
    LOGGER.debug("gotoFirstPage");
    if (getCurrentPage() == 1) {
      LOGGER.debug("gotoFirstPage getCurrentPage == 1");
      return;
    }
    final int oldPage = getCurrentPage();
    if (!getEventListener()
        .beforePageChange(new DataViewPropertyChangeEvent(this, oldPage, 1))) {
      return;
    }
    internalGotoFirstPage();
    getEventListener().afterPageChange(
        new DataViewPropertyChangeEvent(this, oldPage, getCurrentPage()));

    updateDataset(getModel().getDataSet());
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#gotoLastPage()
   */
  public void gotoLastPage() {
    LOGGER.debug("gotoLastPage");
    if (getCurrentPage() == getPageCount()) {
      
      LOGGER.debug("gotoLastPage getCurrentPage == getPageCount");
      return;
    }

    final int oldPage = getCurrentPage();
    if (!getEventListener().beforePageChange(
        new DataViewPropertyChangeEvent(this, oldPage, getPageCount()))) {
      return;
    }
    internalGotoLastPage();
    getEventListener().afterPageChange(
        new DataViewPropertyChangeEvent(this, oldPage, getCurrentPage()));

    updateDataset(getModel().getDataSet());
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#gotoNextPage()
   */
  public void gotoNextPage() {
    LOGGER.debug("gotoNextPage");
    if (getCurrentPage() == getPageCount()) {
      LOGGER.debug("gotoNextPage getCurrentPage == getPageCount");
      return;
    }

    final int oldPage = getCurrentPage();
    if (!getEventListener().beforePageChange(
        new DataViewPropertyChangeEvent(this, oldPage, oldPage + 1))) {
      return;
    }
    internalGotoNextPage();

    getEventListener().afterPageChange(
        new DataViewPropertyChangeEvent(this, oldPage, getCurrentPage()));

    updateDataset(getModel().getDataSet());
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#gotoPage(int)
   */
  public void gotoPage(final int newPage) {
    
    LOGGER.debug("gotoPage newPage = " + newPage);
    if (getCurrentPage() == newPage) {
      
      LOGGER.debug("gotoPage getCurrentPage == newPage");
      return;
    }

    final int oldPage = getCurrentPage();
    if (!getEventListener().beforePageChange(
        new DataViewPropertyChangeEvent(this, oldPage, newPage))) {
      return;
    }
    internalGotoPage(newPage);
    getEventListener().afterPageChange(
        new DataViewPropertyChangeEvent(this, oldPage, getCurrentPage()));

    updateDataset(getModel().getDataSet());
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.dataview.DataView#gotoPreviousPage()
   */
  public void gotoPreviousPage() {
    LOGGER.debug("gotoPreviousPage");
    if (getCurrentPage() == 1) {
      LOGGER.debug("gotoPreviousPage getCurrentPage == 1");
      return;
    }

    final int oldPage = getCurrentPage();
    if (!getEventListener().beforePageChange(
        new DataViewPropertyChangeEvent(this, oldPage, oldPage - 1))) {
      return;
    }
    internalGotoPreviousPage();
    getEventListener().afterPageChange(
        new DataViewPropertyChangeEvent(this, oldPage, getCurrentPage()));

    updateDataset(getModel().getDataSet());
  }

  /**
   * Internal goto first page.
   */
  private void internalGotoFirstPage() {
    firstDisplayedRow = 1;
    currentPage = 1;
  }

  /**
   * Internal goto last page.
   */
  private void internalGotoLastPage() {
    if (getPageRows() == 0) {
      firstDisplayedRow = 1;
      currentPage = 1;
      return;
    }

    final int numberRows = getRowCount();
    currentPage = numberRows / getPageRows();

    if (numberRows % getPageRows() == 0) {
      firstDisplayedRow = (getCurrentPage() - 1) * getPageRows() + 1;
    } else {
      firstDisplayedRow = getCurrentPage() * getPageRows() + 1;
      currentPage += 1;
    }

    if (getCurrentPage() != 0) {
      return;
    }
    firstDisplayedRow = 1;
    currentPage = 1;
    return;
  }

  /**
   * Internal goto next page.
   */
  private void internalGotoNextPage() {
    currentPage += 1;
    firstDisplayedRow += getPageRows();
    if (getFirstDisplayedRow() > getRowCount()) {
      internalGotoPreviousPage();
    }

    if (getCurrentPage() <= getPageCount()) {
      return;
    }
    internalGotoLastPage();
  }

  /**
   * Internal goto page.
   * 
   * @param newPage
   *          the new page
   */
  private void internalGotoPage(final int newPage) {
    if (newPage >= 1 && newPage <= getPageCount()) {
      currentPage = newPage;
      firstDisplayedRow = (newPage - 1) * getPageRows() + 1;
    } else {
      internalGotoFirstPage();
    }
  }

  /**
   * Internal goto previous page.
   */
  private void internalGotoPreviousPage() {
    currentPage -= 1;
    firstDisplayedRow -= getPageRows();
    if (firstDisplayedRow < 1) {
      firstDisplayedRow = 1;
      currentPage = 1;
    }
    if (getCurrentPage() >= 1) {
      return;
    }
    internalGotoFirstPage();
  }

  /**
   * Sets the page rows.
   * 
   * @param newPageRows
   *          the new page rows {@inheritDoc}
   * @see st.liotrox.dataview.DataView#setPageRows(int)
   */
  public void setPageRows(final int newPageRows) {
    if (this.pageRows == newPageRows) {
      return;
    }
    int oldPageRows = this.pageRows;
    if (!(this.getEventListener().beforePageRowsChange(new DataViewPropertyChangeEvent(this,
        oldPageRows, newPageRows)))) {
      return;
    }
    this.pageRows = newPageRows;

    this.getEventListener().afterPageRowsChange(
        new DataViewPropertyChangeEvent(this, oldPageRows, newPageRows));
    
    updateDataset(getModel().getDataSet());
  }

  /**
   * Update dataset.
   * 
   * @param ds
   *          the DataSet
   */
  public abstract void updateDataset(final DataSet ds);

}
