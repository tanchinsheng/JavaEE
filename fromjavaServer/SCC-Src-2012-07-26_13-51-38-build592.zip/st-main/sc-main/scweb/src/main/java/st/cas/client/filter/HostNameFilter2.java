package st.cas.client.filter;

import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.ServletException;

public class HostNameFilter2
  implements DomainFilter
{
  public String getDomain(String url)
    throws ServletException
  {
    String host = null;
    try {
      host = new URL(url).getHost();
    } catch (MalformedURLException e) {
    }
    
    return host;
  }

  public static void tester()
    throws Exception
  {
  }
}

