/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.persistence.SQLExecutor;
import com.st.sc.util.SCWebServiceFactory;

/**
 * The Class CompliancyReportService.
 */
public class CompliancyReportService extends ReportService {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(CompliancyReportService.class);

  /**
   * Gets the from date.
   * 
   * @param fieldName
   *          the field name
   * @param viewName
   *          the view name
   * @return the from date
   */
  public Date getFromDate(final String fieldName, final String viewName) {
    final SQLExecutor exe = SCWebServiceFactory.getSCExecutor();
    final String query = "select min(" + fieldName + ") from " + viewName;
    final Timestamp tmp = exe.getTimestampValue(query, new Object[0]);
    if (tmp != null) {
      return new Date(tmp.getTime());
    }
    return null;
  }
  
  /**
   * Get min and max date.
   * @param fieldName
   * @param viewName
   * @return
   */
  public List<Date> getMinMaxDate(final String fieldName, final String viewName) {
    final String query =
        "select min(" + fieldName + "), max(" + fieldName + ") from " + viewName;
    List result = queryListObject(query, null, -1, -1);
    if (result != null && result.size() > 0) {
      Object[] obj = (Object[]) result.get(0);
      Timestamp min = (Timestamp) obj[0];
      Timestamp max = (Timestamp) obj[1];
      List<Date> returnList = new ArrayList<Date>();
      returnList.add(new Date(min.getTime()));
      returnList.add(new Date(max.getTime()));
      return returnList;
    }
    return null;
  }

  /**
   * Gets the to date.
   * 
   * @param fieldName
   *          the field name
   * @param viewName
   *          the view name
   * @return the to date
   */
  public Date getToDate(final String fieldName, final String viewName) {
    final SQLExecutor exe = SCWebServiceFactory.getSCExecutor();
    final String query = "select max(" + fieldName + ") from " + viewName;
    final Timestamp tmp = exe.getTimestampValue(query, new Object[0]);
    if (tmp != null) {
      return new Date(tmp.getTime());
    }
    return null;
  }

  public List queryMirFieldValues(final String[] mirFieldName, final String viewName,
      final String orderBy) {
    String mirCondition = buildCondition(mirFieldName);

    StringBuilder sqlBuilder = new StringBuilder();
    sqlBuilder.append("Select Distinct ").append(mirCondition);
    sqlBuilder.append(" From ").append(viewName);
    if ("ASC".equals(orderBy) || "DESC".equals(orderBy)) {
      sqlBuilder.append(" Order By ").append(mirCondition).append(" ").append(orderBy);
    }

    return queryListObject(sqlBuilder.toString(), null, -1, -1);
  }

  public List queryGroupByMirField(final String[] mirFields, final double minRange,
      final double maxRange, final String viewName) {
    String mirCondition = buildCondition(mirFields);

    StringBuilder sqlBuilder = new StringBuilder();
    sqlBuilder.append("Select ").append(mirCondition).append(",count(*) ");
    sqlBuilder.append(" From ").append(viewName);
    sqlBuilder.append(" Where ").append(
        "COMPLIANCY_SCORE<=:maxRange and COMPLIANCY_SCORE >=:minRange");
    sqlBuilder.append(" Group By ").append(mirCondition);

    Map<String, Object> params = new HashMap<String, Object>();
    params.put("maxRange", maxRange);
    params.put("minRange", minRange);

    return queryListObject(sqlBuilder.toString(), params, -1, -1);
  }

  public List queryGroupByMirField(final String[] mirFields, final String viewName,
      final Date from, final Date to, final String comparedField) {
    String mirCondition = buildCondition(mirFields);

    StringBuilder sqlBuilder = new StringBuilder();
    sqlBuilder.append("Select ").append(mirCondition).append(",count(*) ");
    sqlBuilder.append(" From ").append(viewName);
    sqlBuilder.append(" Where ").append(comparedField).append(">= :from And ")
        .append(comparedField).append("<= :to ");
    sqlBuilder.append(" Group By ").append(mirCondition);

    Map<String, Object> params = new HashMap<String, Object>();
    params.put("from", from);
    params.put("to", to);

    return queryListObject(sqlBuilder.toString(), params, -1, -1);
  }

  public List queryByScoreRange(final String[] returnedColumns, final String viewName,
      final double minRange, final double maxRange, final int firstRecord, final int maxRecord) {
    String select = buildCondition(returnedColumns);

    StringBuilder sqlBuilder = new StringBuilder();
    sqlBuilder.append("Select ").append(select);
    sqlBuilder.append(" From ").append(viewName);
    sqlBuilder.append(" Where ").append(
        "COMPLIANCY_SCORE<=:maxRange and COMPLIANCY_SCORE >=:minRange");

    Map<String, Object> params = new HashMap<String, Object>();
    params.put("maxRange", maxRange);
    params.put("minRange", minRange);
    List list = queryListObject(sqlBuilder.toString(), params, firstRecord, maxRecord);
    return list;
  }

  public List queryByMirFieldValue(final String[] returnedColumns, final String viewName,
      final String[] mirField, final String[] mirValues, final int firstRecord,
      final int maxRecord) {
    String select = buildCondition(returnedColumns);

    StringBuilder sqlBuilder = new StringBuilder();
    sqlBuilder.append("Select ").append(select);
    sqlBuilder.append(" From ").append(viewName);

    StringBuilder whereClause = new StringBuilder();
    Map<String, Object> params = new HashMap<String, Object>();
    int length = mirField.length;
    for (int i = 0; i < length; i++) {
      if (mirValues != null && mirValues.length > i && mirValues[i] != null) {
        whereClause.append(mirField[i]).append("= :mir").append(i);
        params.put("mir" + i, mirValues[i]);
      } else {
        whereClause.append(mirField[i]).append(" is NULL");
      }
      if (i < length - 1) {
        whereClause.append(" AND ");
      }
    }
    if (whereClause.length() > 0) {
      sqlBuilder.append(" WHERE ").append(whereClause.toString());
    }
    List list = queryListObject(sqlBuilder.toString(), params, firstRecord, maxRecord);
    return list;
  }

  public List queryByTimeRange(final String[] returnedColumns, final String viewName,
      final Date from, final Date to, final String comparedField, final int firstRecord,
      final int maxRecord) {
    String select = buildCondition(returnedColumns);

    StringBuilder sqlBuilder = new StringBuilder();
    sqlBuilder.append("Select ").append(select);
    sqlBuilder.append(" From ").append(viewName);
    sqlBuilder.append(" Where ").append(comparedField).append(">= :from And ")
        .append(comparedField).append("<= :to ");

    Map<String, Object> params = new HashMap<String, Object>();
    params.put("from", from);
    params.put("to", to);

    List list = queryListObject(sqlBuilder.toString(), params, firstRecord, maxRecord);
    return list;
  }

  private String buildCondition(final String[] columList) {
    final String connector = ",";
    StringBuilder mirCondition = new StringBuilder();
    for (String mir : columList) {
      mirCondition.append(mir).append(connector);
    }
    if (mirCondition.length() > 0) {
      mirCondition.setLength(mirCondition.length() - connector.length());
    }
    return mirCondition.toString();
  }

  /**
   * Depend on number of returned columns in select clause, the result will be
   * list of Object[] or list of an Object.
   * 
   * @param sql
   * @param params
   * @return List<Object[]> or List<Object>.
   */
  private List queryListObject(final String sql, final Map<String, Object> params,
      int firstResult, int maxResult) {
    EntityManagerFactory factory = SCWebServiceFactory.getScEntityManagerFactory();
    EntityManager entityManager = factory.createEntityManager();
    List<Object[]> list = null;
    try {
      Query query = entityManager.createNativeQuery(sql);
      if (params != null) {
        Set<Entry<String, Object>> entrySet = params.entrySet();
        for (Entry<String, Object> entry : entrySet) {
          query.setParameter(entry.getKey(), entry.getValue());
          // query.setParameter("from", from, TemporalType.TIMESTAMP);
        }
      }
      if (firstResult > -1 && maxResult > -1) {
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResult);
      }

      list = query.getResultList();
    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (entityManager != null) {
        entityManager.close();
      }
    }
    return list;
  }

}
