/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package st.liotrox.chart.jfreechart;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.LiotroRuntimeException;
import st.liotrox.WRequest;
import st.liotrox.chart.ChartContext;
import st.liotrox.service.SCTicketProcessorService;
import st.liotrox.service.TicketProcessorService;
import st.liotrox.util.Assert;
import st.liotrox.util.Convert;
import st.liotrox.util.StringUtil;
import st.liotrox.web.html.Picture;

/**
 * The Class SCJFreeChartRenderer.
 */
public class SCJFreeChartRenderer extends JFreeChartRenderer {
  
  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SCJFreeChartRenderer.class);

  /**
   * Instantiates a new sCJ free chart renderer.
   * 
   * @param value
   *          the value
   * @param model
   *          the model
   */
  public SCJFreeChartRenderer(final JFreeChartLibrary value, final Object model) {
    super(value, model);
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.chart.jfreechart.AbstractChartRenderer#renderHTML(st.liotrox.WRequest,
   *      st.liotrox.chart.ChartContext)
   */
  public String renderHTML(final WRequest request, final ChartContext context) {
    String url = null;

    String chartID = context.getChartID();
    if (chartID == null) {
      url = createTicketURL(request, context);
    } else {
      if ((chartID.trim().length() == 0)
          || (!(StringUtil.isValidIdentifier(FILE_PREFIX + chartID)))) {
        throw new LiotroRuntimeException(
            "AbstractChartRender.renderHTML(): Invalid chartid ('" + chartID
                + "'). It must be a valid identifier.");
      }
      url = createFile(request, context);
    }

    Picture p = new Picture(url);

    Object border = context.getParameterAsObject("border");

    if (border == null) {
      p.setAttribute("BORDER", "0");
    } else {
      p.setAttribute("BORDER", border.toString());
    }
    if (generateImageMap(context)) {
      p.setAttribute("usemap", "#" + context.getParameter("chartName"));
    }
    return p.toString();
  }

  /**
   * Creates the ticket url.
   * 
   * @param request
   *          the request
   * @param context
   *          the context
   * @return the string
   */
  private String createTicketURL(final WRequest request, final ChartContext context) {
    processChart(request, context);
    TicketProcessorService tps =
        (TicketProcessorService) WRequest
            .resolveApplicationScopeComponent("/system/ticketProcessor");
    Assert
        .isNotNull(tps,
            "AbstractChartRenderer.renderHTML(): cannot reference the TicketProcessorService instance");
    return SCTicketProcessorService.createTicketURL(tps.createTicket(context, this));
  }

  /**
   * Creates the file.
   * 
   * @param request
   *          the request
   * @param context
   *          the context
   * @return the string
   */
  private String createFile(final WRequest request, final ChartContext context) {
    File file = new File(getChartFilePath(context.getChartID(), context.getOutput()));

    if (!(file.exists())) {
      processChart(request, context);
      try {
        OutputStream out = new BufferedOutputStream(new FileOutputStream(file));

        writeChart(request, context, out);
        out.close();
      } catch (Exception e) {
        LOG.error(e.getMessage(), e);
      }
    }

    return getChartURL(context.getChartID(), context.getOutput());
  }

  /**
   * Generate image map.
   * 
   * @param ctx
   *          the ctx
   * @return true, if successful
   */
  private boolean generateImageMap(final ChartContext ctx) {
    return Convert.stringToBoolean(ctx.getParameter("imageMap", "false"));
  }
}
