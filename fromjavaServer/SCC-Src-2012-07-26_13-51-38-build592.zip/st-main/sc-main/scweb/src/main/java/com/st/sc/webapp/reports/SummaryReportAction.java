/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - Nov 15, 2011 1:34:56 PM - duytv - Initialize version
/******************************************************************************/
package com.st.sc.webapp.reports;

import java.awt.Color;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpSession;

import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.BoundColumn;
import st.liotrox.dataview.Cell;
import st.liotrox.dataview.ColumnGroup;
import st.liotrox.dataview.ColumnList;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.db.DataSet;
import st.liotrox.db.DefaultDataSet;
import st.liotrox.template.element.control.DataViewElement;
import st.liotrox.template.element.control.TabbedPanelElement;
import st.liotrox.web.html.Table;

import com.st.common.config.ConfigLoader;
import com.st.common.exception.SccException;
import com.st.common.exception.ServiceException;
import com.st.common.mail.EmailNotification;
import com.st.common.mail.MailItem;
import com.st.common.web.LiotroxContants;
import com.st.common.web.config.ConfigReloader;
import com.st.common.web.util.ServletUtils;
import com.st.persistence.entity.SettingEntity;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.OfflineReport;
import com.st.sc.entity.OfflineReportBinary;
import com.st.sc.entity.OfflineReportEntity;
import com.st.sc.service.ReportService;
import com.st.sc.util.ChartUtils;
import com.st.sc.util.DateTimeUtils;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.web.data.OfflineReportDTO;
import com.st.sc.web.data.ReportData;
import com.st.sc.webapp.BaseAction;
import com.st.sc.webapp.WebContext;
import com.st.scc.common.utils.ByteUtil;
import com.st.scc.common.utils.DateUtils;

/**
 * The Class BaseReportAction.
 */
public class SummaryReportAction extends BaseAction {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(SummaryReportAction.class);

  /** The Constant REPORT_TYPE_TABLE. */
  private static final String REPORT_TYPE_TABLE = "table";

  /** The Constant REPORT_TYPE_TREND_TABLE. */
  private static final String REPORT_TYPE_TREND_TABLE = "trendTable";

  /** The Constant REPORT_TYPE_BAR_CHART. */
  private static final String REPORT_TYPE_BAR_CHART = "barChart";

  /** The Constant REPORT_TYPE_TREND_CHART. */
  private static final String REPORT_TYPE_TREND_CHART = "trendBarLineChart";

  /** The report type. */
  private String reportType = REPORT_TYPE_TABLE;

  /** The mir fields. */
  private String[] mirFields = new String[]{"CMOD_COD", "DSGN_REV", "EXEC_TYP", "FLOW_ID",
      "JOB_NAM", "MODE_COD", "OPER_FRQ", "PART_TYP", "PROC_ID", "SPEC_NAM", "SUPR_NAM",
      "TSTR_TYP" };

  /** The score table setting. */
  private ScoreTableSetting scoreTableSetting = new ScoreTableSetting();

  /** The trend table setting. */
  private TrendTableSetting trendTableSetting = new TrendTableSetting();

  /** The bar chart setting. */
  private BarChartSetting barChartSetting = new BarChartSetting();

  /** The trend and line chart setting. */
  private TrendAndLineChartSetting trendAndLineChartSetting = new TrendAndLineChartSetting();

  /** The dataview report. */
  private DataView dataviewReportTable;

  /** The dataview report ds. */
  private DataSet datasetReportTable;

  /**
   * Data set for table of chart.
   */
  private DataSet datasetOfflineReport;

  /** The data view bar chart. */
  private DataView dataViewOfflineReport;

  /** The report type hidden. */
  private String reportTypeHidden = REPORT_TYPE_TABLE;

  /** The merge indexs. */
  private List<Integer> mergedCellIndexs;

  /**
   * Model of chart.
   */
  private JFreeChart chartModel;

  /**
   * Data set for table of chart.
   */
  private DataSet datasetOfTableOfChart;

  /** The data view bar chart. */
  private DataView dataViewOfTableOfChart;

  /** The colors bar chart. */
  private Color[] colorsDrawChart;

  /** The chart servlet path. */
  private String chartServletPath;

  /** The create offline report. */
  private boolean createOfflineReport = false;

  /** The offline report checked time. */
  private String offlineReportCheckedTime;

  /** The offline report start t. */
  private String offlineReportStartT;

  /** The offline report finish t. */
  private String offlineReportFinishT;

  /** The OFFLIN e_ repor t_ tabl e_ type. Max value = 30 characters */
  private final String OFFLINE_REPORT_TABLE_TYPE = "Table";

  /** The OFFLINe report trend table type. Max value = 30 characters */
  private final String OFFLINE_REPORT_TREND_TABLE_TYPE = "Trend-Table";

  /** The OFFLIN e_ repor t_ ba r_ cluste r_ type. Max value = 30 characters */
  private final String OFFLINE_REPORT_BAR_CLUSTER_TYPE = "Bar-Clusterd";

  /** The OFFLIN e_ repor t_ ba r_ stac k_ type. Max value = 30 characters */
  private final String OFFLINE_REPORT_BAR_STACK_TYPE = "Bar-Stack";

  /** The OFFLIN e_ repor t_ ba r_ stac k100_ type. Max value = 30 characters */
  private final String OFFLINE_REPORT_BAR_100STACK_TYPE = "Bar-100Stack";

  /** The OFFLIN e_ repor t_ tren d_ stac k_ type. Max value = 30 characters */
  private final String OFFLINE_REPORT_TREND_STACK_TYPE = "Trend-Stack";

  /** The OFFLIN e_ repor t_ tren d_ stac k100_ type. Max value = 30 characters */
  private final String OFFLINE_REPORT_TREND_100STACK_TYPE = "Trend-100Stack";

  /** The OFFLIN e_ repor t_ lin e_ n o_ std f_ type. Max value = 30 characters */
  private final String OFFLINE_REPORT_LINE_NO_STDF_TYPE = "Trend-Line Chart-No";

  /** The OFFLIN e_ repor t_ lin e_ percen t_ type. */
  private final String OFFLINE_REPORT_LINE_PERCENT_TYPE = "Trend-Line Chart-Percent";

  /**
   * URL of offline report tab.
   */
  private static String urlOfflineReport = null;

  /** The Constant SERIES_LIST. */
  private static String[] series_list;

  /**
   * Gets the series.
   * 
   * @return the series
   */
  public String[] getSeries() {
    return series_list;
  }

  /** The Constant REPORT_TYPE_LIST. */
  private static final String[] REPORT_TYPE_LIST = new String[]{REPORT_TYPE_TABLE,
      REPORT_TYPE_TREND_TABLE, REPORT_TYPE_BAR_CHART, REPORT_TYPE_TREND_CHART };

  /**
   * Gets the report type list.
   * 
   * @return the report type list
   */
  public String[] getReportTypeList() {
    return REPORT_TYPE_LIST;
  }

  /**
   * This function is used to check on template file.
   * 
   * @return the table report
   */
  public boolean getTableReport() {
    if (REPORT_TYPE_TABLE.equals(reportType) || REPORT_TYPE_TREND_TABLE.equals(reportType)) {
      return true;
    }
    return false;
  }

  /**
   * Gets the dataview report ds.
   * 
   * @return the dataview report ds
   */
  public DataSet getDatasetReportTable() {
    if (datasetReportTable == null) {
      datasetReportTable = new DefaultDataSet();
    }
    return datasetReportTable;
  }

  /**
   * Gets the bar chart table dataset.
   * 
   * @return the bar chart table dataset
   */
  public DataSet getDatasetOfTableOfChart() {
    if (datasetOfTableOfChart == null) {
      datasetOfTableOfChart = new DefaultDataSet();
    }
    return datasetOfTableOfChart;
  }

  /**
   * Gets the dataview report.
   * 
   * @return the dataview report
   */
  public DataView getDataviewReport() {
    if (dataviewReportTable == null) {
      DataViewElement dvElement = (DataViewElement) findControl("dataviewReport");
      if (dvElement != null) {
        dataviewReportTable = dvElement.getDataView(WRequest.getCurrentInstance());
      }
    }
    return dataviewReportTable;
  }

  /**
   * Get the DataView.
   * 
   * @return the DataView
   */
  public DataView getDataViewOfTableOfChart() {
    if (dataViewOfTableOfChart == null) {
      DataViewElement dvElement = (DataViewElement) findControl("barChartDataView");
      if (dvElement != null) {
        dataViewOfTableOfChart = dvElement.getDataView(WRequest.getCurrentInstance());
      }
    }
    return dataViewOfTableOfChart;
  }

  /**
   * Gets the dataset offline report.
   * 
   * @return the dataset offline report
   */
  public DataSet getDatasetOfflineReport() {
    if (datasetOfflineReport == null) {
      datasetOfflineReport = new DefaultDataSet();
    }
    return datasetOfflineReport;
  }

  /**
   * Gets the data view offline report.
   * 
   * @return the data view offline report
   */
  public DataView getDataViewOfflineReport() {
    if (dataViewOfflineReport == null) {
      DataViewElement dvElement = (DataViewElement) findControl("offlineReportDataView");
      if (dvElement != null) {
        dataViewOfflineReport = dvElement.getDataView(WRequest.getCurrentInstance());
      }
    }
    return dataViewOfflineReport;
  }

  public SummaryReportAction() {
    if (urlOfflineReport == null) {
      urlOfflineReport = buildLinkOfflineReport(WRequest.getCurrentInstance());
    }
  }

  /**
   * Map from offline report type.
   * 
   * @param offlineReportType
   *          the offline report type
   */
  private String mapFromOfflineReportType(final String offlineReportType) {
    String reportType = "";
    if (OFFLINE_REPORT_TABLE_TYPE.equals(offlineReportType)) {
      reportType = REPORT_TYPE_TABLE;
    } else if (OFFLINE_REPORT_TREND_TABLE_TYPE.equals(offlineReportType)) {
      reportType = REPORT_TYPE_TREND_TABLE;
    } else if (OFFLINE_REPORT_BAR_CLUSTER_TYPE.equals(offlineReportType)
        || OFFLINE_REPORT_BAR_STACK_TYPE.equals(offlineReportType)
        || OFFLINE_REPORT_BAR_100STACK_TYPE.equals(offlineReportType)) {
      reportType = REPORT_TYPE_BAR_CHART;
    } else if (OFFLINE_REPORT_TREND_STACK_TYPE.equals(offlineReportType)
        || OFFLINE_REPORT_TREND_100STACK_TYPE.equals(offlineReportType)
        || OFFLINE_REPORT_LINE_NO_STDF_TYPE.equals(offlineReportType)
        || OFFLINE_REPORT_LINE_PERCENT_TYPE.equals(offlineReportType)) {
      reportType = REPORT_TYPE_TREND_CHART;
    }
    return reportType;
  }

  /**
   * Map to offline report type.
   * 
   * @param reportType
   *          the report type
   * @param chartType
   *          the chart type
   * @return the string
   */
  private String mapToOfflineReportType(final String reportType, final String chartType) {
    String offlineReportType = "";
    if (REPORT_TYPE_TABLE.equals(reportType)) {
      offlineReportType = OFFLINE_REPORT_TABLE_TYPE;
    } else if (REPORT_TYPE_TREND_TABLE.equals(reportType)) {
      offlineReportType = OFFLINE_REPORT_TREND_TABLE_TYPE;
    } else if (REPORT_TYPE_BAR_CHART.equals(reportType)) {
      if (BarChartSetting.BAR_CHART_CLUSTERED_COLUMN.equals(chartType)) {
        offlineReportType = OFFLINE_REPORT_BAR_CLUSTER_TYPE;
      } else if (BarChartSetting.BAR_CHART_STACKED_COLUMN.equals(chartType)) {
        offlineReportType = OFFLINE_REPORT_BAR_STACK_TYPE;
      } else if (BarChartSetting.BAR_CHART_100_STACKED_COLUMN.equals(chartType)) {
        offlineReportType = OFFLINE_REPORT_BAR_100STACK_TYPE;
      }
    } else if (REPORT_TYPE_TREND_CHART.equals(reportType)) {
      if (TrendAndLineChartSetting.TREND_CHART_STACKED_COLUMN.equals(chartType)) {
        offlineReportType = OFFLINE_REPORT_TREND_STACK_TYPE;
      } else if (TrendAndLineChartSetting.TREND_CHART_100_STACKED_COLUMN.equals(chartType)) {
        offlineReportType = OFFLINE_REPORT_TREND_100STACK_TYPE;
      } else if (TrendAndLineChartSetting.LINE_CHART_BY_NO_STDF.equals(chartType)) {
        offlineReportType = OFFLINE_REPORT_LINE_NO_STDF_TYPE;
      } else if (TrendAndLineChartSetting.LINE_CHART_BY_PERCENTAGE.equals(chartType)) {
        offlineReportType = OFFLINE_REPORT_LINE_PERCENT_TYPE;
      }
    }
    return offlineReportType;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#handleAction(st.liotrox.WRequest,
   *      st.liotrox.Event)
   */
  public void handleAction(WRequest request, Event event) throws Throwable {
    // This is called when you click on each tab.
    super.handleAction(request, event);

    boolean getNewData = false;
    // handle change tab event
    // handle click on offline report tab.
    String eventBkmParams = event.getParameter("LX_BKM_EVT");
    if (eventBkmParams == null || eventBkmParams.contains("changeTab")) {
      getNewData = true;
    }
    if (getNewData) {
      TabbedPanelElement mainTabPanel = (TabbedPanelElement) findControl("mainTabPanel");
      String selectedTabName = mainTabPanel.getSelectedTab();
      if ("offline_report".equals(selectedTabName)) {
        doShowListOfflineReport(request, event);
      } else if ("setting_info".equals(selectedTabName)) {
        // reset settings
        resetOnInfoAndSettingPage();
      }
    }
  }

  /**
   * Called from Filtering page.
   * 
   * @param request
   * @param event
   */
  public void displayInfoSetting(WRequest request, Event event) {
    LOGGER.debug("displayInfoSetting()");
    TabbedPanelElement mainTabPanel = (TabbedPanelElement) findControl("mainTabPanel");
    mainTabPanel.setSelectedTab("setting_info");
    // reset settings
    resetOnInfoAndSettingPage();
  }

  /**
   * Display offline report tab.
   * 
   * @param request
   * @param event
   */
  public void displayOfflineReportTab(WRequest request, Event event) {
    LOGGER.debug("displayOfflineReportTab()");
    TabbedPanelElement mainTabPanel = (TabbedPanelElement) findControl("mainTabPanel");
    mainTabPanel.setSelectedTab("offline_report");
    doShowListOfflineReport(request, event);
  }

  /**
   * Apply setting.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void changeReportType(final WRequest request, final Event event) {
    this.errorMessage = "";
    this.infoMessage = "";
    this.reportTypeHidden = reportType;
  }

  /**
   * Before render.
   * 
   * @param request
   *          the request {@inheritDoc}
   * @see st.liotrox.page.WPage#beforeRender(st.liotrox.WRequest)
   */
  public void beforeRender(final WRequest request) {
    LOGGER.debug("Begin beforeRender()");
    super.beforeRender(request);

    if (createOfflineReport) {
      LOGGER
          .debug("beforeRender(), add javascript function onLoadCheckOfflineReport() to show OfflineReport dialog.");
      // Add javacript function call in OnLoad(), to open dialog offline report.
      addOnLoadCode("onLoadCheckOfflineReport();");
    }
    isDataViewOfChartVisible();
    LOGGER.debug("End beforeRender()");
  }

  /**
   * Validate input data.
   * 
   * @return true, if successful
   */
  private boolean validateInputData() {
    errorMessage = "";
    infoMessage = "";

    if (REPORT_TYPE_TABLE.equals(this.reportType)) {
      errorMessage = scoreTableSetting.validateInputData();
    } else if (REPORT_TYPE_TREND_TABLE.equals(this.reportType)) {
      errorMessage = trendTableSetting.validateInputData();
    } else if (REPORT_TYPE_BAR_CHART.equals(this.reportType)) {
      errorMessage = barChartSetting.validateInputData();
    } else if (REPORT_TYPE_TREND_CHART.equals(this.reportType)) {
      errorMessage = trendAndLineChartSetting.validateInputData();
    }
    if (errorMessage.length() == 0) {
      return true;
    }
    return false;
  }

  /**
   * Check filter condition is offline report.
   * 
   * @param request
   *          the request
   * @return true, if successful
   * @throws ParseException
   *           the parse exception
   */
  private boolean checkFilterConditionIsOfflineReport(final WRequest request)
      throws ParseException {
    final FilteringAction filteringAction =
        (FilteringAction) request.resolvePath("/pages/sc/reports/filterringPage");
    FilterConditionInfo condition = filteringAction.getConditionInfo();

    boolean isOfflineReport = false;
    offlineReportCheckedTime = offlineReportFinishT = offlineReportStartT = "";
    // Check on checked time field.
    int dayDiff = 0;
    if ("1".equals(condition.getCheckedTimeRadio())) {
      Date from =
          DateUtils.stringToDate(condition.getCheckedTimeFrom(),
              LiotroxContants.DEFAULT_DATE_FORMAT);
      Date to =
          DateUtils.stringToDate(condition.getCheckedTimeTo(),
              LiotroxContants.DEFAULT_DATE_FORMAT);
      // count number of day
      dayDiff = DateTimeUtils.daysDiff(from, to) + 1;

      offlineReportCheckedTime =
          condition.getCheckedTimeFrom() + "~" + condition.getCheckedTimeTo();
    } else if ("2".equals(condition.getCheckedTimeRadio())) {
      dayDiff = Integer.parseInt(condition.getCheckedTime2Last());
      offlineReportCheckedTime =
          "Last " + condition.getCheckedTime2Last() + " Since "
              + condition.getCheckedTime2Since();
    } else {
      isOfflineReport = true;
    }
    if (!isOfflineReport) {
      final Number numberOnlineDay =
          (Number) ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getValue(
              ConfigLoader.ONLINE_REPORT_TIME);
      if (numberOnlineDay != null && dayDiff > numberOnlineDay.intValue()) {
        isOfflineReport = true;
      }
    }

    if ("1".equals(condition.getMirStartTRadio())) {
      offlineReportStartT = condition.getMirStartTFrom() + "~" + condition.getMirStartTTo();
    } else if ("2".equals(condition.getMirStartTRadio())) {
      offlineReportStartT =
          "Last " + condition.getMirStartT2Last() + " Since " + condition.getMirStartT2Since();
    }
    if ("1".equals(condition.getMirFinishTRadio())) {
      offlineReportFinishT = condition.getMirFinishTFrom() + "~" + condition.getMirFinishTTo();
    } else if ("2".equals(condition.getMirFinishTRadio())) {
      offlineReportFinishT =
          "Last " + condition.getMirFinishT2Last() + " Since "
              + condition.getMirFinishT2Since();
    }

    return isOfflineReport;
  }

  /**
   * Reset dataset and chart when no data.
   */
  private void resetDataViewAndChart() {
    datasetReportTable = new DefaultDataSet();
    getDataviewReport().getModel().setDataSet(datasetReportTable);

    datasetOfTableOfChart = new DefaultDataSet();
    getDataViewOfTableOfChart().getModel().setDataSet(datasetOfTableOfChart);

    chartModel = null;
  }

  /**
   * Reset data when call from another page to SummaryReport, or when from
   * another tab to Info&Setting tab.
   */
  private void resetOnInfoAndSettingPage() {
    // reset offline report
    createOfflineReport = false;
    errorMessage = infoMessage = "";

    // refresh config to get number series from config
    Number numberSeries =
        (Number) ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getValue(
            ConfigLoader.MAX_NUM_OF_COMPLIANCY_SCORE_RANGE);
    if (numberSeries == null) {
      numberSeries = 10;
    }
    // check max number series changed.
    if (series_list == null || series_list.length != numberSeries.intValue()) {
      final int num = numberSeries.intValue();
      series_list = new String[num];
      for (int i = 1; i <= num; i++) {
        series_list[i - 1] = "" + i;
      }
      // reset number categories = 1
      scoreTableSetting.setNumberOfSeries(1);
      trendTableSetting.setNumberOfSeries(1);
      barChartSetting.setNumberOfSeries(1);
      trendAndLineChartSetting.setNumberOfSeries(1);

      // generate new text box of series.
      scoreTableSetting.generateSeries();
      trendTableSetting.generateSeries();
      barChartSetting.generateSeries();
      trendAndLineChartSetting.generateSeries();
    }
  }

  /**
   * Show report.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void showReport(final WRequest request, final Event event) {
    LOGGER.debug("Begin SummaryReportAction.showReport()");
    createOfflineReport = false;

    try {
      if (!validateInputData()) {
        return;
      }

      if (checkFilterConditionIsOfflineReport(request)) {
        // create offline report.
        // Open dialog to user input report name.
        // javascript function onLoadCheckOfflineReport() will call open dialog.
        createOfflineReport = true;
      } else {
        // create online report.
        try {
          if (!new ReportService().viewIsExist(ServletUtils.getViewName())) {
            // re-create view
            reCreateView();
          }
        } catch (Exception e1) {
          LOGGER.error(e1.getMessage(), e1);
          this.errorMessage = "There is an error when creating report.";
          return;
        }
        createOnlineReport(this.reportType);
        // go to tab show chart
        TabbedPanelElement mainTabPanel = (TabbedPanelElement) findControl("mainTabPanel");
        mainTabPanel.setSelectedTab("summaryReport");
      }
    } catch (Exception e) {
      this.errorMessage = "There is an error when creating report.";
      LOGGER.error(e.getMessage(), e);
    }
  }

  /**
   * Creates the offline report.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void createOfflineReport(final WRequest request, final Event event) {
    LOGGER.debug("Begin SummaryReportAction.createOfflineReport()");
    // insert a record to OFFLINE-REPORT table with status is in-progess
    // get data of offline report from session.
    String sessionKey = event.getParameter("offlineReportSessionKey");
    OfflineReport entity = (OfflineReport) request.getSession().getAttribute(sessionKey);
    entity.setStatus(OfflineReport.STATUS_IN_PROGRESS);
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");
    entity.setOwners(loginUser);
    String chartType = "";
    final String reportType = this.reportType;
    if (REPORT_TYPE_BAR_CHART.equals(reportType)) {
      chartType = barChartSetting.getChartType();
    } else if (REPORT_TYPE_TREND_CHART.equals(reportType)) {
      chartType = trendAndLineChartSetting.getChartType();
    }
    entity.setReportType(mapToOfflineReportType(reportType, chartType));
    entity.setReportTime(SCWebServiceFactory.getSCExecutor().getSysDate());
    entity.setCheckingTime(offlineReportCheckedTime);
    entity.setMirStartT(offlineReportStartT);
    entity.setMrrFinishT(offlineReportFinishT);
    entity.setServerId(WebContext.getInstance().getServerId());
    final Long reportId =
        SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_OFFLINE_REPORT);
    if (reportId == null) {
      errorMessage = "Cannot get new OFFLINE_REPORT_ID, cannot insert DB.";
      return;
    }
    entity.setOfflineReportId(reportId);
    final String reportName = entity.getReportName();
    SCWebServiceFactory.getSCExecutor().addEntities(entity);

    try {
      // get where clause from filtering page
      final FilteringAction filteringAction =
          (FilteringAction) request.resolvePath("/pages/sc/reports/filterringPage");
      FilterConditionInfo conditionInfo = filteringAction.getConditionInfo();
      // get where clause.
      final Map<String, Object> params = new HashMap<String, Object>();
      final String whereClause = conditionInfo.buildSQLWhere(params);

      BaseReportSetting setting = null;
      if (REPORT_TYPE_TABLE.equals(reportType)) {
        setting = scoreTableSetting.copySetting();
      } else if (REPORT_TYPE_TREND_TABLE.equals(reportType)) {
        setting = trendTableSetting.copySetting();
      } else if (REPORT_TYPE_BAR_CHART.equals(reportType)) {
        setting = barChartSetting.copySetting();
      } else if (REPORT_TYPE_TREND_CHART.equals(reportType)) {
        setting = trendAndLineChartSetting.copySetting();
      }
      final BaseReportSetting finalSetting = setting;
      long timeOut = getSettingOfflineReportTimeOut();
      finalSetting.setReportTimeOutConfig(timeOut);
      
      // create report.
      Runnable runable = new Runnable() {
        public void run() {
          try {
            // Check memory and wait
            checkMemoryBeforeCreateReport(false);

            queryDataForOfflineReport(finalSetting, reportId, reportName, whereClause, params);
          } catch (ServiceException e) {
            processDatabaseError(reportId);
          } catch (Throwable e) {
            LOGGER.error(e.getMessage(), e);
            String errorMsg = "Throw exception when creating report";
            if (e.getMessage() != null) {
              errorMsg = e.getMessage().substring(0, 255);
            }
            final ReportService reportService = new ReportService();
            OfflineReport entity = reportService.updateFailed(reportId, errorMsg);

            // Send mail to owners
            final String emailList = entity.getEmailList();
            if (emailList != null && emailList.length() > 0) {
              sendEmail(reportName, entity.getStatus(), entity.getEmailList());
            }
          }
        }
      };
      WebContext.getInstance().getOfflineReportPool().submit(runable);
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
    LOGGER.debug("End SummaryReportAction.createOfflineReport()");
  }

  private void checkMemoryBeforeCreateReport(final boolean isOnline) {
    // Check memory and wait
    long needMemory = 6 * 1024 * 1024;
    if (isOnline) {
      needMemory = 5 * 1024 * 1024;
    }
    while (true) {
      Runtime.getRuntime().gc();
      final long freeMemory = Runtime.getRuntime().freeMemory();
      if (freeMemory >= needMemory) {
        break;
      }
      // wait for free memory
      LOGGER.info("Wait for free memory, minimum needed memory=" + needMemory
          + ", current free memory=" + freeMemory);
      try {
        Thread.currentThread().sleep(2000);
      } catch (InterruptedException e) {
        LOGGER.error(e.getMessage(), e);
      }
    }
  }
  
  /**
   * Re create view.
   * 
   * @throws ParseException
   *           the parse exception
   */
  private void reCreateView() throws ParseException {
    LOGGER.debug("Begin SummaryReportAction.reCreateView()");
    FilteringAction filteringComp =
        (FilteringAction) WRequest.getCurrentInstance().resolvePath(
            "/pages/sc/reports/filterringPage");

    FilterConditionInfo con = filteringComp.getConditionInfo();
    ReportService service = new ReportService();
    Map<String, Object> params = new HashMap<String, Object>();
    String where = con.buildSQLWhere(params);
    String viewName = ServletUtils.getViewName();
    WebContext.getInstance().addTempView(viewName);
    service.createView(viewName, where, params);
    LOGGER.debug("End SummaryReportAction.reCreateView()");
  }

  /**
   * Get offline report timeout setting.
   * @return
   */
  private long getSettingOfflineReportTimeOut() {
    //In DB, unit is minute.
    final long defaultTimeOut = 5 * 60; // 5h , unit is minute
    SettingEntity timeOutEntity =
        SCWebServiceFactory.getSettingService().find(ConfigLoader.KEY_OFLINE_REPORT_TIMEOUT);
    long returnTimeout = defaultTimeOut;
    if (timeOutEntity == null) {
      // insert key to indicate value of offline report timeout.
      SettingEntity entity = new SettingEntity();
      entity.setParaCode(ConfigLoader.KEY_OFLINE_REPORT_TIMEOUT);
      entity.setParaValue("" + defaultTimeOut);
      // number
      entity.setDataType(0);
      entity.setDescription("The timeout of offline report. Unit is minute.");

      Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
      entity.setUpdatedOn(currentTime);
      SCWebServiceFactory.getSCExecutor().mergeEntities(entity);
    } else {
      String timeOut = timeOutEntity.getParaValue();
      try {
        returnTimeout = Long.parseLong(timeOut);
      } catch (Exception e) {
      }
    }
    returnTimeout *= 60 * 1000; //convert milisecond
    return returnTimeout;
  }
  
  /**
   * Do show list offline report.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void doShowListOfflineReport(final WRequest request, final Event event) {
    LOGGER.debug("Begin SummaryReportAction.doShowListOfflineReport()");
    errorMessage = "";
    infoMessage = "";
    ReportService service = new ReportService();
    long timeOut = getSettingOfflineReportTimeOut();
    Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
    Timestamp reportTimeOut = new Timestamp(currentTime.getTime() - timeOut);
    double hours = timeOut / (double) (3600 * 1000);
    NumberFormat format = new DecimalFormat("##.##");
    String message = "Failed due to over " + format.format(hours) + " hour(s) processing";
    service.updateInProgessReportToFail(message, reportTimeOut);
    refeshOfflineReportDataView();
    LOGGER.debug("End SummaryReportAction.doShowListOfflineReport()");
  }

  private void refeshOfflineReportDataView() {
    ReportService serv = new ReportService();
    List<OfflineReportEntity> list = serv.getAllOfflineReport();
    if (list != null && list.size() > 0) {
      List<OfflineReportDTO> listDto = new ArrayList<OfflineReportDTO>(list.size());
      for (OfflineReportEntity offlineReport : list) {
        listDto.add(new OfflineReportDTO(offlineReport));
      }

      datasetOfflineReport = createDataSet(listDto);
      int currentPage = getDataViewOfflineReport().getCurrentPage();
      getDataViewOfflineReport().getModel().setDataSet(datasetOfflineReport);
      getDataViewOfflineReport().gotoPage(currentPage);
    } else {
      datasetOfflineReport = new DefaultDataSet();
      getDataViewOfflineReport().getModel().setDataSet(datasetOfflineReport);
    }
  }

  /**
   * Do view offline report.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void doViewOfflineReport(final WRequest request, final Event event) {
    LOGGER.debug("Begin SummaryReportAction.doViewOfflineReport()");
    errorMessage = "";
    infoMessage = "";
    int[] selectedRows = getDataViewOfflineReport().getSelectedRows();
    if (selectedRows.length != 1) {
      errorMessage = CommonUtils.getCommonBundleMessage("choose_one_record");
      return;
    }
    Long reportId =
        (Long) getDataViewOfflineReport().getModel().getDataSet()
            .getValue(selectedRows[0], "offlineReportId");
    ReportService service = new ReportService();
    OfflineReportEntity entity = service.getOfflineReportEntityById(reportId);
    if (entity == null) {
      infoMessage = "This report has been deleted.";
      return;
    }
    if (OfflineReport.STATUS_DONE.equals(entity.getStatus())) {
      OfflineReportBinary binary = service.getOfflineReportBinaryData(reportId);
      if (binary.getReportData() != null) {
        ReportData reportData = (ReportData) ByteUtil.toObject(binary.getReportData());
        final String offlineReportType = mapFromOfflineReportType(entity.getReportType());
        if (reportData != null) {
          if (REPORT_TYPE_TABLE.equals(offlineReportType)) {
            showScoreTable(reportData);
          } else if (REPORT_TYPE_TREND_TABLE.equals(offlineReportType)) {
            showScoreTrendTable(reportData);
          } else if (REPORT_TYPE_BAR_CHART.equals(offlineReportType)) {
            // create chart and assign to chartModel
            showBarChartReport(reportData);
          } else if (REPORT_TYPE_TREND_CHART.equals(offlineReportType)) {
            showTrendAndLineChartReport(reportData);
          }
        } else {
          LOGGER.info("Error when deserialize binary data to object.");
        }
        // update the global variable reportType to show chart offline
        setReportType(offlineReportType);

        // go to tab show chart
        TabbedPanelElement mainTabPanel = (TabbedPanelElement) findControl("mainTabPanel");
        mainTabPanel.setSelectedTab("summaryReport");
      } else {
        infoMessage = "There is no data.";
      }
    } else {
      infoMessage = "Cannot view this report, its status is not \"Done\".";
    }
    LOGGER.debug("End SummaryReportAction.doViewOfflineReport()");
  }

  /**
   * Do delete offline report.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void doDeleteOfflineReport(final WRequest request, final Event event) {
    errorMessage = "";
    infoMessage = "";
    int[] selectedRows = getDataViewOfflineReport().getSelectedRows();
    if (selectedRows.length == 0) {
      errorMessage = CommonUtils.getCommonBundleMessage("choose_least_one_record");
      return;
    }
    // get current user
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");
    String role = request.getUserProfile().getAttribute("liotrox.role");
    boolean canDelete = false;
    boolean isAdmin = false;
    if ("admin".equals(role)) {
      canDelete = true;
      isAdmin = true;
    }
    DataSet ds = getDataViewOfflineReport().getModel().getDataSet();
    ReportService service = new ReportService();
    int numberDeleted = 0;
    boolean haveInprogess = false;
    boolean isNotOwner = false;
    for (int i = 0; i < selectedRows.length; i++) {
      // get status of report
      String status = (String) ds.getValue(selectedRows[i], "status");
      if (!OfflineReport.STATUS_IN_PROGRESS.equals(status)) {
        if (!isAdmin) {
          canDelete = false;
          // Query report
          String owner = (String) ds.getValue(selectedRows[i], "owners");
          // check is owners
          if (owner.toUpperCase().contains(loginUser.toUpperCase())) {
            canDelete = true;
          }
        }
        if (canDelete) {
          Long reportId = (Long) ds.getValue(selectedRows[i], "offlineReportId");
          if (service.deleteOfflineReport(reportId)) {
            numberDeleted++;
          }
        } else {
          isNotOwner = true;
        }
      } else {
        haveInprogess = true;
      }
    }
    if (numberDeleted == selectedRows.length) {
      infoMessage = "Deleted offline reports successfully.";
    } else {
      if (numberDeleted == 0) {
        if (haveInprogess) {
          errorMessage += "Reports have status \"In-progess\".<br/>";
        }
        if (isNotOwner) {
          errorMessage += "You are not owner of reports.<br/>";
        }
      } else {
        errorMessage =
            "Deleted " + numberDeleted
                + " offline reports successfully, others cannot be deleted.<br/>";
        if (haveInprogess) {
          infoMessage += "Reports have status \"In-progess\".<br/>";
        }
        if (isNotOwner) {
          infoMessage += "You are not owner of reports.<br/>";
        }
      }
    }
    refeshOfflineReportDataView();
  }

  /**
   * Removes the group.
   * 
   * @param dv
   *          the dv
   */
  private static void removeGroup(final DataView dv) {
    ColumnList columns = dv.getModel().getColumns();
    ColumnGroup root = columns.getColumnGroups();
    while (root.getGroupCount() > 0) {
      root.removeGroup(0);
    }
  }

  /**
   * Remove merged cells.
   * 
   * @param dv
   *          the dv
   */
  private static void removeMergedCells(final DataView dv) {
    if (dv.getModel() != null && dv.getModel().getCells() != null) {
      dv.getModel().getCells().clear();
    }
  }

  /**
   * Remove all columns of dataview.
   * 
   * @param dv
   *          the dv
   */
  private static void removeAllColumns(final DataView dv) {
    if (dv.getModel() != null && dv.getModel().getColumns() != null) {
      dv.getModel().getColumns().clear();
    }
  }

  /**
   * Inits the chart colors.
   * 
   * @param numColor
   *          the num color
   * @return the color[]
   */
  private Color[] initChartColors(int numColor) {
    Color[] colors = new Color[numColor];
    for (int i = 0; i < numColor; i++) {
      colors[i] = ChartUtils.getColor(i);
    }
    return colors;
  }

  /**
   * Builds the score table report.
   * 
   * @param dataview
   *          the dataview
   * @param dataSet
   *          the data set
   * @param reportEntity
   *          the report entity
   * @param reportType
   *          the report type
   */
  private void buildTableReport(final DataView dataview, final DataSet dataSet,
      final ReportData reportEntity, final String reportType) {

    // clear all state of the dataview
    dataview.clearState();
    removeAllColumns(dataview);
    removeGroup(dataview);
    removeMergedCells(dataview);

    int colCount = reportEntity.countNumberColumn();
    // check whether have group rows
    boolean haveRowGroup = reportEntity.haveRowGroup();
    if (haveRowGroup) {
      colCount += 2;
    } else {
      colCount += 1;
    }
    // create column names
    String[] columnNames = new String[colCount];
    for (int i = 0; i < colCount; i++) {
      columnNames[i] = "col_" + i;
    }
    dataSet.appendColumns(colCount);
    dataSet.setColumnNames(columnNames);
    dataSet.loadFromMatrix(reportEntity.getTableData());
    dataview.getModel().setDataSet(dataSet);
    // display all rows, don't paging data.
    if (REPORT_TYPE_BAR_CHART.equals(reportType) || REPORT_TYPE_TREND_CHART.equals(reportType)) {
      dataview.setPageRows(reportEntity.countNumberRow());
    }

    ColumnList columns = dataview.getModel().getColumns();
    // format first or second row as header
    if (REPORT_TYPE_TABLE.equals(reportType) || REPORT_TYPE_TREND_TABLE.equals(reportType)) {
      // first second, set background to color of header.
      BoundColumn firstColumn = (BoundColumn) columns.get(1);
      firstColumn.setDynamicContent("@PAGE.formatHeaderCellText");
      firstColumn.setHideIconVisible(false);
      firstColumn.setCollapsed(false);
      firstColumn.setCollapseIconVisible(false);
      firstColumn.setSortable(false);
      if (haveRowGroup) {
        BoundColumn secondColumn = (BoundColumn) columns.get(2);
        secondColumn.setDynamicContent("@PAGE.formatHeaderCellText");
        secondColumn.setHideIconVisible(false);
        secondColumn.setCollapsed(false);
        secondColumn.setCollapseIconVisible(false);
        secondColumn.setSortable(false);
      }
    } else {
      if (REPORT_TYPE_BAR_CHART.equals(reportType)
          || REPORT_TYPE_TREND_CHART.equals(reportType)) {
        // first second, set background to color of header.
        BoundColumn firstColumn = (BoundColumn) columns.get(1);
        firstColumn.setDynamicContent("@PAGE.formatCellTextOfTableBarChart");
        firstColumn.setHideIconVisible(false);
        firstColumn.setCollapsed(false);
        firstColumn.setCollapseIconVisible(false);
        firstColumn.setSortable(false);
        if (haveRowGroup) {
          firstColumn.setDynamicContent("@PAGE.formatHeaderCellText");
          BoundColumn secondColumn = (BoundColumn) columns.get(2);
          secondColumn.setDynamicContent("@PAGE.formatCellTextOfTableBarChart");
          secondColumn.setHideIconVisible(false);
          secondColumn.setCollapsed(false);
          secondColumn.setCollapseIconVisible(false);
          secondColumn.setSortable(false);
        }
      }
    }

    // set columns header
    if (columns.getCount() > 0) {
      // column index of dataview is start from 1.
      // Ignore the first column, set label from column 2.
      int colIndex = 2;
      // but if have row group, exclude first 2 column, mean that start from 3
      if (haveRowGroup) {
        colIndex = 3;
      }
      String[] columnLabels = reportEntity.getColumnLabels();
      int[] columnLabelIndexs = reportEntity.getColumnLabelIndex();
      // check have group or not
      boolean haveColumnGroup = reportEntity.haveColumnGroup();
      if (haveColumnGroup) {
        Map<String, List<String>> mapGroupColumnsName =
            new LinkedHashMap<String, List<String>>();
        String groupName = "";
        int startIndex = 0;
        int endIndex = 0;
        for (int i = 0; i < columnLabelIndexs.length; i++) {
          startIndex = columnLabelIndexs[i];
          if (i < columnLabelIndexs.length - 1) {
            endIndex = columnLabelIndexs[i + 1];
          } else {
            endIndex = columnLabels.length;
          }
          groupName = columnLabels[startIndex];
          List<String> columnsName = new ArrayList<String>();
          for (int j = startIndex + 1; j < endIndex; j++) {
            if (columnLabels[j] == null) {
              columns.get(colIndex).setLabel(SCConstants.NA_VALUE);
            } else {
              columns.get(colIndex).setLabel(columnLabels[j]);
            }
            // get column name and add to list.
            columnsName.add(columns.get(colIndex).getName());
            colIndex++;
          }
          mapGroupColumnsName.put(groupName, columnsName);
        }
        createGroup(dataview, mapGroupColumnsName);
      } else {
        for (String group : columnLabels) {
          if (group == null) {
            columns.get(colIndex).setLabel(SCConstants.NA_VALUE);
          } else {
            columns.get(colIndex).setLabel(group);
          }
          colIndex++;
        }
      }
      columns.get(1).setLabel("");
    }
    // merge cells on row
    if (haveRowGroup) {
      // set label of column, set empty 2 first column.
      columns.get(1).setLabel("");
      columns.get(2).setLabel("");

      // merge cells
      mergedCellIndexs = new ArrayList<Integer>();
      addFunctionMergeCell(dataview, "col_0", mergedCellIndexs);
    }
  }

  /**
   * Internal show report.
   * 
   * @param reportType
   *          the report type
   * @throws Exception
   *           the exception
   */
  public void createOnlineReport(final String reportType) throws Exception {

    LOGGER.info("Begin create online report. Report type=" + reportType);
    final String viewName = ServletUtils.getViewName();

    // Check memory and wait
    checkMemoryBeforeCreateReport(true);
    ReportData reportData = null;
    if (REPORT_TYPE_TABLE.equals(reportType)) {
      reportData = scoreTableSetting.getDataToShowReport(viewName,true);
      if (reportData != null) {
        showScoreTable(reportData);
      }
    } else if (REPORT_TYPE_TREND_TABLE.equals(reportType)) {
      reportData = trendTableSetting.getDataToShowReport(viewName,true);
      if (reportData != null) {
        showScoreTrendTable(reportData);
      }
    } else if (REPORT_TYPE_BAR_CHART.equals(reportType)) {
      // create chart and assign to chartModel
      reportData = barChartSetting.getDataToShowReport(viewName,true);
      if (reportData != null) {
        showBarChartReport(reportData);
      }
    } else if (REPORT_TYPE_TREND_CHART.equals(reportType)) {
      reportData = trendAndLineChartSetting.getDataToShowReport(viewName,true);
      if (reportData != null) {
        showTrendAndLineChartReport(reportData);
      }
    }
    if (reportData != null) {
      infoMessage = "See result in \"Summary report\" tab.";
    } else {
      infoMessage = "There is no data.";
      resetDataViewAndChart();
    }
    LOGGER.info("Finished create online report.");
  }

  /**
   * Query data for offline report.
   * 
   * @param reportType
   *          the report type
   * @param offlineReportId
   *          the offline report id
   * @param reportName
   *          the report name
   * @param whereClause
   *          the where clause
   * @param paramsOfWhere
   *          the params of where
   * @throws Exception
   *           the exception
   */
  private void queryDataForOfflineReport(final BaseReportSetting setting,
      final Long offlineReportId, final String reportName, String whereClause,
      final Map<String, Object> paramsOfWhere) throws Exception {

    LOGGER.info("Begin create offline report, name=" + reportName);
    ReportData reportData = null;
    OfflineReport entity = null;
    ReportService reportService = new ReportService();
    try {
      // create new view on DB
      // max view name length = 30 characters.
      String offlineReportViewName = WebContext.getInstance().getOfflineReportViewName();
      reportService.createView(offlineReportViewName, whereClause, paramsOfWhere);

      reportData = setting.getDataToShowReport(offlineReportViewName, false);
      if (setting.isTimeOut()) {        
        double hours = setting.getReportTimeOutConfig() / (double) (3600 * 1000);
        NumberFormat format = new DecimalFormat("##.##");
        String message = "Failed due to over " + format.format(hours) + " hour(s) processing";
        reportService.updateFailed(offlineReportId, message);
        LOGGER.info("The report \"" + reportName + "\" stopped because it's over "
            + format.format(hours) + " hour(s) processing");
        return;
      }
      
    } catch (PersistenceException e) {
      throw new ServiceException("Cannot connect to database when reporting", e);
    } catch (ServiceException e) {
      throw new ServiceException("Cannot connect to database when reporting", e);
    } catch (SccException e) {
      throw e;
    }

    byte[] byteArray = null;
    if (reportData != null) {
      byteArray = ByteUtil.toByteArray(reportData);
    }
    entity = reportService.updateDone(offlineReportId, reportName, byteArray);
    if (entity == null) {
      return;
    }

    // Send mail to owners
    final String emailList = entity.getEmailList();
    if (emailList != null && emailList.length() > 0) {
      sendEmail(reportName, entity.getStatus(), entity.getEmailList());
    }
    LOGGER.info("Finished create offline report, name=" + entity.getReportName());
  }

  /**
   * Send email for offline report
   * 
   * @param reportName
   * @param status
   * @param emailList
   */
  private void sendEmail(final String reportName, final String status, final String emailList) {
    final MailItem mailItem = new MailItem();
    mailItem.setSendAsHtml(true);
    mailItem.setFrom(EmailNotification.getInstance().getDefaultFrom());
    mailItem.setFromDisplayName(EmailNotification.getInstance().getDefaultFromDisplayName());
    mailItem.setTo(emailList);
    mailItem.setSubject("Offline report finished");
    String emailMsg = buildOfflineReportEmailMessage(reportName, status);
    mailItem.setMessage(emailMsg);
    EmailNotification.getInstance().sendMail(mailItem);
    LOGGER.info("Sent mail to " + emailList);
  }

  /**
   * Build email message of offline report.
   * 
   * @param reportName
   * @param status
   * @return
   */
  private String buildOfflineReportEmailMessage(final String reportName, final String status) {
    //Rule : one character = 2 space of html, space on code= space of html.
    String emailMsg = "Report name : " + reportName + " <br/>";
    emailMsg += "Status&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: " + status + " <br/>";
    emailMsg +=
        "Link&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <a href=\""
            + urlOfflineReport + "\">" + urlOfflineReport + "</a>";
    return emailMsg;
  }

  /**
   * Build link of offline report view.
   * 
   * @param request
   * @return
   */
  private String buildLinkOfflineReport(WRequest request) {
    String url = "";
    StringBuffer serverUrl = request.getHttpRequest().getRequestURL();
    int index = serverUrl.indexOf(SCConstants.getContextPath());
    if (index > -1) {
      url =
          serverUrl.substring(0, index) + SCConstants.getContextPath()
              + SCConstants.OFFLINE_REPORT_URL;
    } else {
      url = SCConstants.getContextPath() + SCConstants.OFFLINE_REPORT_URL;
    }
    return url;
  }

  /**
   * Process database error.
   */
  private void processDatabaseError(Long offlineReportId) {
    long startTime = System.currentTimeMillis();
    long endTime = startTime;
    boolean stop = false;
    while (!stop) {
      try {
        final OfflineReportEntity entity =
            new ReportService().getOfflineReportEntityById(offlineReportId);
        entity.setErrorMessage("DB connection interrupted");
        entity.setStatus(OfflineReport.STATUS_FAIL);
        SCWebServiceFactory.getSCExecutor().mergeEntities(entity);
        stop = true;
      } catch (final Exception e) {
        try {
          Thread.sleep(15000);
        } catch (InterruptedException ie) {
          // ignore exception
        }
        endTime = System.currentTimeMillis();
        stop = endTime - 60 * 5 * 1000 > startTime;
        LOGGER.error(e.getMessage(), e);
      }
    }
  }

  /**
   * Show score table.
   * 
   * @param reportData
   *          the report data
   */
  private void showScoreTable(final ReportData reportData) {
    if (reportData != null) {
      datasetReportTable = new DefaultDataSet();
      buildTableReport(getDataviewReport(), datasetReportTable, reportData, REPORT_TYPE_TABLE);
    }
  }

  /**
   * Show score trend table.
   * 
   * @param reportData
   *          the report data
   */
  private void showScoreTrendTable(final ReportData reportData) {
    if (reportData != null) {
      datasetReportTable = new DefaultDataSet();
      buildTableReport(getDataviewReport(), datasetReportTable, reportData,
          REPORT_TYPE_TREND_TABLE);
    }
  }

  /**
   * Get data and draw all bar chart type.
   * 
   * @param reportData
   *          the report data
   */
  private void showBarChartReport(final ReportData reportData) {
    if (reportData != null) {
      BarChartSetting setting = (BarChartSetting) reportData.getSetting();
      if (BarChartSetting.ONE_CATEGORY.equals(setting.getCategoryOption())) {
        drawBarChartOneCategory(reportData);
      }
      if (BarChartSetting.MULTIPLE_CATEGORY.equals(setting.getCategoryOption())) {
        drawBarChartMultipleCategory(reportData);
      }
    }
  }

  /**
   * Show trend and line chart report.
   * 
   * @param reportData
   *          the report data
   */
  private void showTrendAndLineChartReport(final ReportData reportData) {
    if (reportData != null) {
      drawBarChartMultipleCategory(reportData);
    }

  }

  /**
   * Draw bar chart with one category.
   * 
   * @param reportData
   */
  private void drawBarChartOneCategory(ReportData reportData) {
    LOGGER.debug("Begin SummaryReportAction.drawBarChartOneCategory()");
    BarChartSetting setting = (BarChartSetting) reportData.getSetting();
    final String categoryOrder = setting.getCategoriesOrder();
    final String seriesOrder = setting.getSeriesOrder();
    final String chartType = setting.getChartType();

    // create the dataset
    final DefaultCategoryDataset dataset = new DefaultCategoryDataset();

    // Sum value in each series.
    final int rowCount = reportData.countNumberRow();
    final int columCount = reportData.countNumberColumn();
    Integer[] sumList = new Integer[rowCount];
    for (int i = 0; i < rowCount; i++) {
      int sum = 0;
      // first column of data is labels, real data from column 1
      for (int j = 0; j < columCount; j++) {
        sum += (Integer) reportData.getTableData()[i][j + 1];
      }
      sumList[i] = sum;
    }
    // create list to sort
    List<SeriesDTO> seriesList = new ArrayList<SeriesDTO>();
    for (int i = 0; i < rowCount; i++) {
      seriesList.add(new SeriesDTO(sumList[i], reportData.getRowLabels()[i]));
    }

    // Sort values to draw chart
    // But with stack chart: expected order is top to bottom, JFreeChart draw
    // from bottom to top.
    // We must reverse inputed order of users
    String order = categoryOrder;
    if (BarChartSetting.BAR_CHART_STACKED_COLUMN.equals(chartType)
        || BarChartSetting.BAR_CHART_100_STACKED_COLUMN.equals(chartType)) {
      if (BaseReportSetting.ASC_ORDER.equals(categoryOrder)) {
        order = BaseReportSetting.DESC_ORDER;
      } else if (BaseReportSetting.DESC_ORDER.equals(categoryOrder)) {
        order = BaseReportSetting.ASC_ORDER;
      }
    }
    Collections.sort(seriesList, new SeriesValueComparator());
    if (BaseReportSetting.DESC_ORDER.equals(order)) {
      Collections.reverse(seriesList);
    }

    // group all MIR criteria in one category.
    StringBuilder builder = new StringBuilder();
    String[] categories = reportData.buildCombineColumnLabels();
    for (String mirValue : categories) {
      builder.append(mirValue).append(",");
    }
    // remove last ','
    builder.setLength(builder.length() - 1);
    String categoryName = builder.toString();

    if (BarChartSetting.BAR_CHART_CLUSTERED_COLUMN.equals(chartType)
        || BarChartSetting.BAR_CHART_STACKED_COLUMN.equals(chartType)) {
      for (int i = 0; i < rowCount; i++) {
        dataset.addValue((Integer) seriesList.get(i).value, seriesList.get(i).name,
            categoryName);
      }
    } else if (BarChartSetting.BAR_CHART_100_STACKED_COLUMN.equals(chartType)) {
      // update again sumList and seriesNames after sort
      for (int i = 0; i < rowCount; i++) {
        sumList[i] = seriesList.get(i).value;
        reportData.getRowLabels()[i] = seriesList.get(i).name;
      }
      double[] percentages = calculatePercentage(sumList);
      for (int i = 0; i < rowCount; i++) {
        dataset.addValue(percentages[i], reportData.getRowLabels()[i], categoryName);
      }
    }

    // get color to draw chart.
    colorsDrawChart = initChartColors(rowCount);
    drawChart(dataset, colorsDrawChart, setting);
    // insert color to series list to sort by series name
    for (int i = 0; i < rowCount; i++) {
      seriesList.get(i).color = colorsDrawChart[i];
    }

    // create table, must sort again by series order
    Collections.sort(seriesList, new SeriesNameComparator());
    if (BaseReportSetting.DESC_ORDER.equals(seriesOrder)) {
      Collections.reverse(seriesList);
    }
    // update again sumList and seriesNames, and color after sort
    for (int i = 0; i < rowCount; i++) {
      sumList[i] = seriesList.get(i).value;
      reportData.getRowLabels()[i] = seriesList.get(i).name;
      colorsDrawChart[i] = seriesList.get(i).color;
    }

    // Update again data of table in one category.
    Object[][] dataOfOneCategory = new Object[rowCount][2];
    for (int i = 0; i < rowCount; i++) {
      dataOfOneCategory[i][0] = reportData.getRowLabels()[i];
      dataOfOneCategory[i][1] = sumList[i];
    }
    reportData.setTableData(dataOfOneCategory);
    reportData.setColumnLabels(new String[]{categoryName });
    reportData.setColumnLabelIndex(new int[]{0 });

    datasetOfTableOfChart = new DefaultDataSet();
    buildTableReport(getDataViewOfTableOfChart(), datasetOfTableOfChart, reportData,
        REPORT_TYPE_BAR_CHART);
    LOGGER.debug("End SummaryReportAction.drawBarChartOneCategory()");
  }

  /**
   * Draw bar chart with multiple categories.
   * 
   * @param reportData
   *          the report data
   * @param reportType
   *          the report type
   * @param chartType
   *          the chart type
   */
  private void drawBarChartMultipleCategory(ReportData reportData) {
    LOGGER.debug("Begin SummaryReportAction.drawBarChartMultipleCategory()");

    BaseReportSetting setting = reportData.getSetting();
    String reportType = "";
    String chartType = "";
    if (setting instanceof BarChartSetting) {
      reportType = REPORT_TYPE_BAR_CHART;
      BarChartSetting barChart = (BarChartSetting) setting;
      chartType = barChart.getChartType();
    } else if (setting instanceof TrendAndLineChartSetting) {
      reportType = REPORT_TYPE_TREND_CHART;
      TrendAndLineChartSetting trendChart = (TrendAndLineChartSetting) setting;
      chartType = trendChart.getChartType();
    }
    if (!REPORT_TYPE_TREND_CHART.equals(reportType)
        && !REPORT_TYPE_BAR_CHART.equals(reportType)) {
      LOGGER.info("Report type is not bar chart or trend chart, cannot draw chart.");
      return;
    }

    // create the dataset
    final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    final int seriesCount = reportData.countNumberRow();
    final int categoryCount = reportData.countNumberColumn();

    String[] seriesNames = reportData.buildCombineRowLabels();
    String[] categories = reportData.buildCombineColumnLabels();

    // With stack chart, order of series when drawing chart is bottom -> top.
    // But expected requirement: order of series chart is top-> bottom.
    // Therefore, with stack chart, must reverse input data to dataset of chart.
    boolean reverseInput = false;
    if (BarChartSetting.BAR_CHART_STACKED_COLUMN.equals(chartType)
        || TrendAndLineChartSetting.TREND_CHART_STACKED_COLUMN.equals(chartType)
        || BarChartSetting.BAR_CHART_100_STACKED_COLUMN.equals(chartType)
        || TrendAndLineChartSetting.TREND_CHART_100_STACKED_COLUMN.equals(chartType)) {
      reverseInput = true;
    }

    if (BarChartSetting.BAR_CHART_CLUSTERED_COLUMN.equals(chartType)
        || BarChartSetting.BAR_CHART_STACKED_COLUMN.equals(chartType)
        || TrendAndLineChartSetting.TREND_CHART_STACKED_COLUMN.equals(chartType)
        || TrendAndLineChartSetting.LINE_CHART_BY_NO_STDF.equals(chartType)
        || BarChartSetting.BAR_CHART_100_STACKED_COLUMN.equals(chartType)
        || TrendAndLineChartSetting.TREND_CHART_100_STACKED_COLUMN.equals(chartType)) {
      // check whether have group rows
      boolean haveRowGroup = reportData.haveRowGroup();
      int countFirstColumn = 1;
      if (haveRowGroup) {
        // But if have row group, there are 2 first column.
        countFirstColumn = 2;
      }
      int rowIdx = 0;
      for (int i = 0; i < categoryCount; i++) {
        // each MIR criteria is a category.
        // each series is a column.
        for (int j = 0; j < seriesCount; j++) {
          // data in two-dimension array of ReportDataEntity include labels of
          // first column.
          // When get real data to draw chart, must ignore first column.
          // But if have row group, there are 2 first column.
          rowIdx = j;
          if (reverseInput) {
            rowIdx = seriesCount - 1 - j;
          }
          dataset.addValue((Integer) reportData.getTableData()[rowIdx][countFirstColumn + i],
              seriesNames[rowIdx], categories[i]);
        }
      }
    } else if (TrendAndLineChartSetting.LINE_CHART_BY_PERCENTAGE.equals(chartType)) {
      Integer[] valuesOfSeries = null;
      Object[] percentageTexts = null;
      double[] percentages = null;
      // If Line chart, after calculating percentage of value,
      // we must update this percentage again ReportDataEntity to display
      // percentage on table.
      int rowIdx = 0;
      // each MIR criteria is a category.
      for (int i = 0; i < categoryCount; i++) {
        // value (number of stdf) of each series of a category.
        valuesOfSeries = reportData.getColumnValues(i);
        percentages = calculatePercentage(valuesOfSeries);
        percentageTexts = new Object[percentages.length];
        for (int j = 0; j < seriesCount; j++) {
          rowIdx = j;
          if (reverseInput) {
            rowIdx = seriesCount - 1 - j;
          }
          dataset.addValue(percentages[rowIdx], seriesNames[rowIdx], categories[i]);
          // store percentage in text to create table below chart.
          percentageTexts[rowIdx] = percentages[rowIdx] + "%";
        }

        // update percent value to report data
        reportData.updateColumValues(i, percentageTexts);
      }
    }

    // get color to draw chart.
    colorsDrawChart = initChartColors(seriesCount);
    drawChart(dataset, colorsDrawChart, setting);

    // direction of series on table below chart : top -> bottom
    // direction of colors when drawing stack chart: bottom -> top.
    if (reverseInput) {
      // if reverse input data, must revert colors
      // -> display correct colors in table below chart
      Color tmp = null;
      final int mid = colorsDrawChart.length / 2;
      final int left = colorsDrawChart.length - 1;
      for (int i = 0; i < mid; i++) {
        tmp = colorsDrawChart[i];
        colorsDrawChart[i] = colorsDrawChart[left - i];
        colorsDrawChart[left - i] = tmp;
      }
    }
    datasetOfTableOfChart = new DefaultDataSet();
    buildTableReport(getDataViewOfTableOfChart(), datasetOfTableOfChart, reportData,
        reportType);

    LOGGER.debug("End SummaryReportAction.drawBarChartMultipleCategory()");
  }

  /**
   * Calculate percentage.
   * 
   * @param valuesOfSeries
   *          the values of series
   * @return the double[]
   */
  private double[] calculatePercentage(final Integer[] valuesOfSeries) {
    int sumAll = 0;
    final int numSeries = valuesOfSeries.length;
    for (int j = 0; j < numSeries; j++) {
      sumAll += valuesOfSeries[j];
    }

    double[] percentList = new double[numSeries];
    if (sumAll == 0) {
      for (int j = 0; j < numSeries; j++) {
        percentList[j] = 0;
      }
    } else {
      double percent = 0;
      for (int j = 0; j < numSeries; j++) {
        percent = CommonUtils.roundDouble((double) valuesOfSeries[j] / sumAll * 100);
        percentList[j] = percent;
      }
      // double lastPercent = CommonUtils.roundDouble(100f - sumPercent);
      // percentList[numSeries - 1] = lastPercent;
    }
    return percentList;
  }

  /**
   * Draw chart.
   * 
   * @param dataset
   *          the dataset
   * @param colors
   *          the colors
   * @param chartType
   *          the chart type
   */
  private void drawChart(final DefaultCategoryDataset dataset, final Color[] colors,
      final BaseReportSetting setting) {
    LOGGER.debug("Begin SummaryReportAction.drawChart()");
    final String yAxisTitle = "No. of STDF files";
    final String yAxisPercentTitle = "(%)";
    final String yAxis100PercentTitle = "( x 100% )";

    String chartType = "";
    String chartTitle = "";
    int percentageBarWidth = 100;
    if (setting instanceof BarChartSetting) {
      BarChartSetting barChart = (BarChartSetting) setting;
      chartType = barChart.getChartType();
      chartTitle = barChart.getReportTitle();
      percentageBarWidth = barChart.getPercentageBarChartWidth();
    } else if (setting instanceof TrendAndLineChartSetting) {
      TrendAndLineChartSetting trendChart = (TrendAndLineChartSetting) setting;
      chartType = trendChart.getChartType();
      chartTitle = trendChart.getReportTitle();
      percentageBarWidth = trendChart.getPercentageBarChartWidth();
    }

    int widthUnit = 80 * percentageBarWidth / 100;
    int numBarOfCategory = 1;
    if (BarChartSetting.BAR_CHART_CLUSTERED_COLUMN.equals(chartType)) {
      numBarOfCategory = dataset.getRowCount();
      // create chart
      chartModel =
          ChartUtils.createClusteredBarChart(dataset, chartTitle, yAxisTitle, colorsDrawChart);
    } else if (BarChartSetting.BAR_CHART_STACKED_COLUMN.equals(chartType)
        || TrendAndLineChartSetting.TREND_CHART_STACKED_COLUMN.equals(chartType)) {
      // create chart
      chartModel =
          ChartUtils.createStackedBarChart(dataset, chartTitle, yAxisTitle, colorsDrawChart,
              false);
    } else if (BarChartSetting.BAR_CHART_100_STACKED_COLUMN.equals(chartType)
        || TrendAndLineChartSetting.TREND_CHART_100_STACKED_COLUMN.equals(chartType)) {
      // create chart
      chartModel =
          ChartUtils.createStackedBarChart(dataset, chartTitle, yAxis100PercentTitle,
              colorsDrawChart, true);
    } else if (TrendAndLineChartSetting.LINE_CHART_BY_NO_STDF.equals(chartType)) {
      widthUnit = 110;
      chartModel =
          ChartUtils.createLineChart(dataset, chartTitle, yAxisTitle, colorsDrawChart);
    } else if (TrendAndLineChartSetting.LINE_CHART_BY_PERCENTAGE.equals(chartType)) {
      widthUnit = 110;
      chartModel =
          ChartUtils.createLineChart(dataset, chartTitle, yAxisPercentTitle, colorsDrawChart);
    }

    // save image path of chart with milisecond time to not be cached on
    // browser.
    chartServletPath = SCConstants.getContextPath() + "/ChartServlet?t=" + System.currentTimeMillis();

    HttpSession session = WRequest.getCurrentInstance().getSession();
    // store chartModel in session
    session.setAttribute(SCConstants.SESSION_KEY_BAR_CHART, chartModel);
    // store number of categories of chart
    // number of category of chart
    final int numberCategoryOfChart = dataset.getColumnCount();
    int widthChart = widthUnit * numberCategoryOfChart * numBarOfCategory;
    final int minWidth = 300;
    if (widthChart < minWidth) {
      widthChart = minWidth;
    }
    session.setAttribute(SCConstants.SESSION_KEY_BAR_CHART_WIDTH, widthChart);
    LOGGER.debug("End SummaryReportAction.drawChart()");
  }

  /**
   * Apply number of series.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void applyNumberOfSeries(final WRequest request, final Event event) {

    this.errorMessage = "";
    this.infoMessage = "";

    this.reportType = this.reportTypeHidden;
    if (REPORT_TYPE_TABLE.equals(reportType)) {
      scoreTableSetting.generateSeries();
    } else if (REPORT_TYPE_TREND_TABLE.equals(reportType)) {
      trendTableSetting.generateSeries();
    } else if (REPORT_TYPE_BAR_CHART.equals(reportType)) {
      barChartSetting.generateSeries();
    } else if (REPORT_TYPE_TREND_CHART.equals(reportType)) {
      trendAndLineChartSetting.generateSeries();
    }

  }

  /**
   * When change trend chart type, display or hide textbox percentage of bar
   * width
   * 
   * @param request
   * @param event
   */
  public void changeTrendChartType(final WRequest request, final Event event) {
    // do nothing here, just call this function to submit data to server.
    // purpose: when change trend chart type, display or hide textbox percentage
    // of bar width.
  }

  /**
   * Gets the identifier.
   * 
   * @param str
   *          the str
   * @return the identifier
   */
  public static String getIdentifier(final String str) {
    try {
      return Arrays.toString(str.getBytes("UTF-8")).replaceAll("\\D+", "_");
    } catch (UnsupportedEncodingException e) {
      // UTF-8 is always supported, but this catch is required by compiler
      return null;
    }
  }

  /**
   * Create groups of the dataview.
   * 
   * @param dataView
   *          the data view
   * @param mapGroupNameColumns
   *          map of group name and columns in the group.
   */
  private void createGroup(final DataView dataView,
      final Map<String, List<String>> mapGroupNameColumns) {

    ColumnList columns = dataView.getModel().getColumns();

    ColumnGroup root = columns.getColumnGroups();
    while (root.getGroupCount() > 0) {
      root.removeGroup(0);
    }
    // add first group is first column
    ColumnGroup firstGroup = new ColumnGroup(columns);
    firstGroup.setName(getIdentifier("First_Group"));
    firstGroup.setColumns(new String[]{columns.get(1).getName() });
    // set label of first group
    firstGroup.setLabel("");
    root.addGroup(firstGroup);

    // add remain groups
    for (Iterator<String> ite = mapGroupNameColumns.keySet().iterator(); ite.hasNext();) {
      String groupName = ite.next();
      List<String> columnsName = mapGroupNameColumns.get(groupName);
      if (groupName == null) {
        groupName = SCConstants.NA_VALUE;
      }
      // create group
      ColumnGroup newGroup = new ColumnGroup(columns);
      newGroup.setName(getIdentifier(groupName));
      newGroup.setLabel(groupName);
      newGroup.setColumns(columnsName.toArray(new String[columnsName.size()]));
      root.addGroup(newGroup);
    }
  }

  /**
   * Adds the function merge cell.
   * 
   * @param dv
   *          the dv
   * @param colName
   *          the col name
   * @param mergeIndexs
   *          the merge indexs
   */
  private void addFunctionMergeCell(final DataView dv, final String colName,
      final List<Integer> mergeIndexs) {
    List<String> colValues = new ArrayList<String>();

    int rowCount = dv.getModel().getRows().getCount();
    for (int i = 1; i <= rowCount; i++) {
      colValues.add((String) dv.getModel().getDataSet().getValue(i, colName));
    }

    Set<String> addedValues = new HashSet<String>();
    for (int i = 0; i < colValues.size(); i++) {
      String currValue = colValues.get(i);
      // String preValue = colValues.get(i - 1);
      if (!addedValues.contains(currValue)) {
        mergeIndexs.add(i + 1);
        addedValues.add(currValue);
      }
    }

    dv.getModel().getCells().clear();
    for (int i = 0; i < mergeIndexs.size(); i++) {
      int mergeIndex = mergeIndexs.get(i);
      Cell c = new Cell();
      c.setRow(mergeIndex);
      c.setColumn(colName);
      c.setDynamicContent("@PAGE.mergeCell");
      dv.getModel().getCells().add(c);

      int nextIndex = rowCount + 1;
      if (i < mergeIndexs.size() - 1) {
        nextIndex = mergeIndexs.get(i + 1);
      }
      for (int emptyIndex = mergeIndex + 1; emptyIndex < nextIndex; emptyIndex++) {
        c = new Cell();
        c.setRow(emptyIndex);
        c.setColumn(colName);
        c.setDynamicContent("@PAGE.mergeEmpty");
        dv.getModel().getCells().add(c);
      }
    }
  }

  /**
   * Format header cell text.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String formatHeaderCellText(final WRequest request, final DataViewEvent event) {
    if (event.getValue() == null) {
      event.setValue(SCConstants.NA_VALUE);
    }
    return "<table width='100%' height='100%' cellSpacing='0' cellPadding='0'><tr class='dataview_column_header'><td class='dataview_column_header'>"
        + formatText(request, event) + "</td></tr></table>";
  }

  /**
   * Format first cell of table of bar chart.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String formatCellTextOfTableBarChart(final WRequest request, final DataViewEvent event) {
    String text = (String) event.getValue();
    if (text == null) {
      text = SCConstants.NA_VALUE;
    }
    // format color in first cells.
    // row index start from 1.
    Color color = colorsDrawChart[event.getRow() - 1];
    String div =
        "<table><tr class='dataview_column_header'>" + "<td> <table><tr><td bgcolor=\"#";
    div +=
        CommonUtils.convertToHex(color.getRed()) + CommonUtils.convertToHex(color.getGreen())
            + CommonUtils.convertToHex(color.getBlue())
            + "\" >&nbsp;&nbsp;&nbsp;&nbsp;</td></tr></table> </td>";
    div += "<td>" + text + "</td>";
    div += "</tr></table>";
    return div;
  }

  /**
   * Merge cell.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String mergeCell(final WRequest request, final DataViewEvent event) {
    int rowCount = event.getDataView().getModel().getRows().getCount();
    int currRow = event.getRow();
    int rowSpan = 0;

    for (int i = 0; i < mergedCellIndexs.size(); i++) {
      if (currRow == mergedCellIndexs.get(i)) {
        if (i < mergedCellIndexs.size() - 1) {
          rowSpan = mergedCellIndexs.get(i + 1) - mergedCellIndexs.get(i);
        } else {
          rowSpan = (rowCount + 1) - mergedCellIndexs.get(i);
        }
        break;
      }
    }

    Object cellValue = event.getValue();
    if (cellValue == null) {
      cellValue = SCConstants.NA_VALUE;
    } else {
      cellValue = cellValue.toString();
    }
    event.getCellTag().classStyle("dataview_column_header").setAttribute("ROWSPAN=" + rowSpan);
    Table t = new Table(0);
    t.width("100%");
    t.height("100%");
    t.newRow();
    t.cell(cellValue).alignLeft();
    return t.toString();
  }

  /**
   * Merge empty.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String mergeEmpty(final WRequest request, final DataViewEvent event) {
    event.getCellTag().clear();
    return "";
  }

  /**
   * Gets the mir fields.
   * 
   * @return the mir fields
   */
  public String[] getMirFields() {
    return mirFields;
  }

  /**
   * Gets the report type.
   * 
   * @return the report type
   */
  public String getReportType() {
    return reportType;
  }

  /**
   * Sets the report type.
   * 
   * @param reportType
   *          the new report type
   */
  public void setReportType(final String reportType) {
    this.reportType = reportType;
  }

  /**
   * Gets the report type hidden.
   * 
   * @return the report type hidden
   */
  public String getReportTypeHidden() {
    return reportTypeHidden;
  }

  /**
   * Gets the score table setting.
   * 
   * @return the scoreTableSetting
   */
  public ScoreTableSetting getScoreTableSetting() {
    return scoreTableSetting;
  }

  /**
   * Sets the score table setting.
   * 
   * @param scoreTableSetting
   *          the scoreTableSetting to set
   */
  public void setScoreTableSetting(ScoreTableSetting scoreTableSetting) {
    this.scoreTableSetting = scoreTableSetting;
  }

  /**
   * Gets the trend table setting.
   * 
   * @return the trendTableSetting
   */
  public TrendTableSetting getTrendTableSetting() {
    return trendTableSetting;
  }

  /**
   * Sets the trend table setting.
   * 
   * @param trendTableSetting
   *          the trendTableSetting to set
   */
  public void setTrendTableSetting(TrendTableSetting trendTableSetting) {
    this.trendTableSetting = trendTableSetting;
  }

  /**
   * Gets the bar chart setting.
   * 
   * @return the barChartSetting
   */
  public BarChartSetting getBarChartSetting() {
    return barChartSetting;
  }

  /**
   * Sets the bar chart setting.
   * 
   * @param barChartSetting
   *          the barChartSetting to set
   */
  public void setBarChartSetting(BarChartSetting barChartSetting) {
    this.barChartSetting = barChartSetting;
  }

  /**
   * Gets the trend and line chart setting.
   * 
   * @return the trendAndLineChartSetting
   */
  public TrendAndLineChartSetting getTrendAndLineChartSetting() {
    return trendAndLineChartSetting;
  }

  /**
   * Sets the trend and line chart setting.
   * 
   * @param trendAndLineChartSetting
   *          the trendAndLineChartSetting to set
   */
  public void setTrendAndLineChartSetting(TrendAndLineChartSetting trendAndLineChartSetting) {
    this.trendAndLineChartSetting = trendAndLineChartSetting;
  }

  /**
   * Gets the chart model.
   * 
   * @return the chart model
   */
  public JFreeChart getChartModel() {
    return chartModel;
  }

  /**
   * Gets the chart servlet path.
   * 
   * @return the chart servlet path
   */
  public String getChartServletPath() {
    return chartServletPath;
  }

  /**
   * Checks if is data view visible.
   * 
   * @return true, if is data view visible
   */
  public boolean isDataViewTableVisible() {
    DataView dv = getDataviewReport();
    if (dv != null && dv.getModel() != null && dv.getModel().getRows().getCount() > 0) {
      if (dv.getModel().getColumns().getCount() > 1) {
        noDataMsg = "";
        return true;
      }
    }
    noDataMsg = "There is no data available for this report.";
    return false;
  }

  /**
   * Checks if is data view of chart visible.
   * 
   * @return true, if is data view of chart visible
   */
  private boolean isDataViewOfChartVisible() {
    DataView dv = getDataViewOfTableOfChart();
    if (dv != null && dv.getModel() != null && dv.getModel().getRows().getCount() > 0) {
      if (dv.getModel().getColumns().getCount() > 1) {
        noDataMsg = "";
        return true;
      }
    }
    noDataMsg = "There is no data available for this report.";
    return false;
  }

  /** The no data msg. */
  private String noDataMsg;

  /**
   * Gets the no data msg.
   * 
   * @return the no data msg
   */
  public String getNoDataMsg() {
    return noDataMsg;
  }

  /**
   * Gets the create offline report.
   * 
   * @return the createOfflineReport
   */
  public boolean getCreateOfflineReport() {
    return createOfflineReport;
  }

  /**
   * Sets the create offline report.
   * 
   * @param createOfflineReport
   *          the createOfflineReport to set
   */
  public void setCreateOfflineReport(boolean createOfflineReport) {
    this.createOfflineReport = createOfflineReport;
  }

  /**
   * The Class SeriesDTO.
   */
  private class SeriesDTO {

    /** The value. */
    private int value;

    /** The name. */
    private String name;

    /** The color. */
    private Color color;

    /**
     * Instantiates a new series dto.
     * 
     * @param value
     *          the value
     * @param name
     *          the name
     */
    public SeriesDTO(int value, String name) {
      this.value = value;
      this.name = name;
    }
  }

  /**
   * The Class SeriesValueComparator.
   */
  private class SeriesValueComparator implements Comparator<SeriesDTO> {

    /**
     * Compare.
     * 
     * @param o1
     *          the o1
     * @param o2
     *          the o2
     * @return the int {@inheritDoc}
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(SeriesDTO o1, SeriesDTO o2) {
      if (o1.value > o2.value) {
        return 1;
      }
      if (o1.value < o2.value) {
        return -1;
      }
      return 0;
    }

  }

  /**
   * The Class SeriesNameComparator.
   */
  private class SeriesNameComparator implements Comparator<SeriesDTO> {

    /**
     * Compare.
     * 
     * @param o1
     *          the o1
     * @param o2
     *          the o2
     * @return the int {@inheritDoc}
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(SeriesDTO o1, SeriesDTO o2) {
      return o1.name.compareTo(o2.name);
    }

  }

}
