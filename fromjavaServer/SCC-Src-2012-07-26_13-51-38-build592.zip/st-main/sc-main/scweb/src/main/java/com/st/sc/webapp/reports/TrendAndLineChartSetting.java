/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 22, 2012 9:05:01 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import com.st.common.exception.SccException;
import com.st.sc.web.data.ReportData;

/**
 * The Class TrendAndLineChartSetting.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class TrendAndLineChartSetting extends TrendTableSetting {

  /** The Constant TREND_CHART_STACKED_COLUMN. */
  public static final String TREND_CHART_STACKED_COLUMN = "Stacked Column Bar Chart";

  /** The Constant TREND_CHART_100_STACKED_COLUMN. */
  public static final String TREND_CHART_100_STACKED_COLUMN = "100% Stacked Column Bar Chart";

  /** The Constant LINE_CHART_BY_NO_STDF. */
  public static final String LINE_CHART_BY_NO_STDF = "Line Chart by no. of STDF";

  /** The Constant LINE_CHART_BY_PERCENTAGE. */
  public static final String LINE_CHART_BY_PERCENTAGE = "Line Chart by percentage";

  /** The series order. */
  private String seriesOrder;

  /** The chart type. */
  private String chartType = null;

  private int percentageBarChartWidth = 100;

  /**
   * Gets the trend and line chart list.
   * 
   * @return the trend and line chart list
   */
  public String[] getTrendAndLineChartList() {
    return new String[]{TREND_CHART_STACKED_COLUMN, TREND_CHART_100_STACKED_COLUMN,
        LINE_CHART_BY_NO_STDF, LINE_CHART_BY_PERCENTAGE };
  }

  /**
   * Used in template file, indicate whether display text box percentage of bar
   * width.
   * 
   * @return
   */
  public boolean getDisplayPercentageBarWidth() {
    if (TREND_CHART_STACKED_COLUMN.equals(chartType)
        || TREND_CHART_100_STACKED_COLUMN.equals(chartType) || chartType == null) {
      return true;
    }
    return false;
  }

  /**
   * Validate input data.
   * 
   * @return the string
   */
  public String validateInputData() {
    // bind row option, because when create offline report, cannot get value
    // from request.
    bindRowOption();
    return validateInputData("trend_line_chart_series_");
  }

  /**
   * Gets the data of trend and line chart.
   * 
   * @return the data of trend and line chart
   * @throws SccException
   */
  public ReportData getDataToShowReport(final String viewName, final boolean isOnlineReport) throws SccException {
    initializeInputData();

    ReportData reportData =
        getValuesToCreateTrendTableAndChart(columnOption, rowOption, groupBy, mirField,
            scoreRanges, seriesOrder, viewName, isOnlineReport);

    // if there is data
    if (reportData != null) {
      // set setting to draw chart
      reportData.setSetting(this.copySetting());
    }
    return reportData;
  }

  public TrendAndLineChartSetting copySetting() {
    TrendAndLineChartSetting setting = new TrendAndLineChartSetting();
    updateSetting(setting);
    setting.setChartType(chartType);
    setting.setSeriesOrder(seriesOrder);
    setting.setPercentageBarChartWidth(percentageBarChartWidth);
    return setting;
  }

  /**
   * Gets the series order.
   * 
   * @return the seriesOrder
   */
  public String getSeriesOrder() {
    return seriesOrder;
  }

  /**
   * Sets the series order.
   * 
   * @param seriesOrder
   *          the seriesOrder to set
   */
  public void setSeriesOrder(String seriesOrder) {
    this.seriesOrder = seriesOrder;
  }

  /**
   * Gets the chart type.
   * 
   * @return the chartType
   */
  public String getChartType() {
    return chartType;
  }

  /**
   * Sets the chart type.
   * 
   * @param chartType
   *          the chartType to set
   */
  public void setChartType(String chartType) {
    this.chartType = chartType;
  }

  /**
   * @return the percentageBarChartWidth
   */
  public int getPercentageBarChartWidth() {
    return percentageBarChartWidth;
  }

  /**
   * @param percentageBarChartWidth
   *          the percentageBarChartWidth to set
   */
  public void setPercentageBarChartWidth(int percentageBarChartWidth) {
    this.percentageBarChartWidth = percentageBarChartWidth;
  }

}
