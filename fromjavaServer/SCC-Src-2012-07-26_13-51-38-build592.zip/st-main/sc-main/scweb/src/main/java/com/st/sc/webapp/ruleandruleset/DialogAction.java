/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 29, 2011 4:51:29 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.ruleandruleset;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.db.DataSet;
import st.liotrox.db.DefaultDataSet;

import com.st.common.exception.SccException;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.util.recordloader.RecordLoader;
import com.st.sc.web.data.PopupData;
import com.st.sc.webapp.BaseAction;
import com.st.um.entity.UserEntity;
import com.st.um.enums.UserRoleEnum;
import com.st.um.service.UserService;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class DialogAction extends BaseAction {

  private static final Logger LOGGER = LoggerFactory.getLogger(DialogAction.class);

  private DataView dataView;
  private DataSet dialogDataSet;
  private String selectedData;
  private String dialogType;
  private boolean clickApply;

  private static final String COLUMN_USERNAME = "UserName";
  private static final String COLUMN_RECORDNAME = "RecordName";
  private static final String COLUMN_FIELDNAME = "FieldName";
  private static final String CONNECTOR = ",";
  private static final int MAX_NUMBER_FIELDS = 25;

  protected void beforeRender(WRequest request) {
    // Add javacript function call in OnLoad(), to show error message if have.
    addOnLoadCode("bindingDataToParentPage();");

    super.beforeRender(request);
  }

  private void resetSessionVariable() {
    clickApply = false;
    selectedData = "";
    dialogDataSet = null;
  }

  public void doShow(WRequest request, Event event) {
    resetSessionVariable();
    dialogType = request.getParameter("type");

    //create default dataset.
    dialogDataSet = new DefaultDataSet();
    if (isUserDialog()) {
      createUserDataSet();
    } else if (isRecordDialog()) {
      createRecordDataSet();
    } else if (isFieldDialog()) {
      createFieldDataSet(event);
    }
    getDataView().getModel().setDataSet(dialogDataSet);
  }

  private void createUserDataSet() {
    UserService us = SCWebServiceFactory.getUserService();
    List<UserEntity> list = new ArrayList<UserEntity>();
    try {
      List<UserEntity> list2 = us.getUsersByRole(UserRoleEnum.ADMIN);
      if (list2 != null && list2.size() > 0) {
        list.addAll(list2);
      }
      list2 = us.getUsersByRole(UserRoleEnum.ENGINEER);
      if (list2 != null && list2.size() > 0) {
        list.addAll(list2);
      }
      if (list.size() > 0) {
        List<PopupData> listPopupData = new ArrayList<PopupData>();
        for (UserEntity userEntity : list) {
          List<String> data = new ArrayList<String>();
          data.add(userEntity.getUsername());
          String id = "";
          if (userEntity.getUserId() != null) {
            id = userEntity.getUserId().toString();
          }
          listPopupData.add(new PopupData(id, data));
        }
        dialogDataSet = createDialogDataSet(listPopupData, new String[]{COLUMN_USERNAME });
      }
    } catch (SccException e) {
      LOGGER.error(e.getMessage(), e);
    }
  }

  private void createRecordDataSet() {
    String[] list = RecordLoader.getRecordList();
    if (list != null) {
      List<PopupData> listPopupData = new ArrayList<PopupData>();
      for (String record : list) {
        List<String> data = new ArrayList<String>();
        data.add(record);
        listPopupData.add(new PopupData(record, data));
      }
      dialogDataSet = createDialogDataSet(listPopupData, new String[]{COLUMN_RECORDNAME });
    }
  }

  private void createFieldDataSet(Event event) {
    String recordName = event.getParameter("record");
    String[] list = RecordLoader.getFieldsOfRecord(recordName);
    if (list != null) {
      List<PopupData> listPopupData = new ArrayList<PopupData>();
      for (String field : list) {
        List<String> data = new ArrayList<String>();
        data.add(field);
        listPopupData.add(new PopupData(field, data));
      }
      dialogDataSet = createDialogDataSet(listPopupData, new String[]{COLUMN_FIELDNAME });
    }
  }

  private DataSet createDialogDataSet(List<PopupData> listData, String[] columnNames) {
    DataSet dataSet = new DefaultDataSet();
    if (listData != null && listData.size() > 0) {
      int columnCount = listData.get(0).getDataList().size();
      // Append column and set name for each column.
      dataSet.appendColumns(columnCount);
      dataSet.setColumnNames(columnNames);
      int rowCount = listData.size();
      dataSet.appendRows(rowCount);
      // Set value for each cell of data set.
      for (int r = 1; r <= rowCount; r++) {
        for (int col = 1; col <= columnCount; col++) {
          dataSet.setValue(r, col, listData.get(r - 1).getDataList().get(col - 1));
        }
      }
    }
    return dataSet;
  }

  public void doApply(WRequest request, DataViewEvent event) {
    errorMessage = "";
    selectedData = "";
    clickApply = true;
    int[] rows = getDataView().getSelectedRows();
    if (rows != null && rows.length > 0) {
      String columnName = "";
      if (isUserDialog()) {
        columnName = COLUMN_USERNAME;
      }
      if (isRecordDialog()) {
        columnName = COLUMN_RECORDNAME;
      }
      if (isFieldDialog()) {
        columnName = COLUMN_FIELDNAME;
        // Max number of field is 10,
        if (rows.length > MAX_NUMBER_FIELDS) {
          errorMessage = "Maximum number of field is " + MAX_NUMBER_FIELDS;
          clickApply = false;
          return;
        }
      }
      StringBuilder builder = new StringBuilder();
      for (int i = 0; i < rows.length; i++) {
        String data =
            (String) getDataView().getModel().getDataSet().getValue(rows[i], columnName);
        builder.append(data).append(CONNECTOR);
      }
      if (builder.length() > 0) {
        builder.setLength(builder.length() - CONNECTOR.length());
      }
      selectedData = builder.toString();
    }
  }

  private boolean isUserDialog() {
    if ("userRule".equals(dialogType) || "userRuleSet".equals(dialogType)) {
      return true;
    }
    return false;
  }

  private boolean isRecordDialog() {
    if ("recordInGroup".equals(dialogType)) {
      return true;
    }
    return false;
  }

  private boolean isFieldDialog() {
    if ("fieldUnique".equals(dialogType) || "fieldMatchingRecord1".equals(dialogType)
        || "fieldMatchingRecord2".equals(dialogType)) {
      return true;
    }
    return false;
  }

  /**
   * @return the dialogDataSet
   */
  public DataSet getDialogDataSet() {
    return dialogDataSet;
  }

  /**
   * @return the dataView
   */
  public DataView getDataView() {
    if (dataView == null) {
      dataView = getDataViewFromRequest("dialogDataView");
    }
    return dataView;
  }

  /**
   * @return the selectedData
   */
  public String getSelectedData() {
    return selectedData;
  }

  /**
   * @param selectedData
   *          the selectedData to set
   */
  public void setSelectedData(String selectedData) {
    this.selectedData = selectedData;
  }

  /**
   * @return the dialogType
   */
  public String getDialogType() {
    return dialogType;
  }

  /**
   * @param dialogType
   *          the dialogType to set
   */
  public void setDialogType(String dialogType) {
    this.dialogType = dialogType;
  }

  /**
   * @return the clickApply
   */
  public boolean getClickApply() {
    return clickApply;
  }

  /**
   * @param clickApply
   *          the clickApply to set
   */
  public void setClickApply(boolean clickApply) {
    this.clickApply = clickApply;
  }

}
