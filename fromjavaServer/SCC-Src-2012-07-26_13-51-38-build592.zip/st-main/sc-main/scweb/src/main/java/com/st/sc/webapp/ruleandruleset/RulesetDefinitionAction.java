package com.st.sc.webapp.ruleandruleset;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;

import com.st.common.config.ConfigLoader;
import com.st.common.web.config.ConfigReloader;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.MirCriteria;
import com.st.sc.entity.RuleSetOwners;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.entity.RulesOfRS;
import com.st.sc.entity.util.Util;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.rulemanager.EntityExecutor;
import com.st.sc.rulemanager.QueryExecutor;
import com.st.sc.rulemanager.QueryStringExecutor;
import com.st.sc.rulemanager.RuleSetService;
import com.st.sc.util.RuleSetComparison;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.webapp.BaseAction;

public class RulesetDefinitionAction extends BaseAction {
  /**
   * The LOGGER of class.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(RulesetDefinitionAction.class);
  private static final String EDIT_TYPE = "edit";
  private static final String ADD_TYPE = "add";
  private final String INCREASE_VERSION_REQUEST_PARAMETER = "increaseVersion";

  private String actionType;
  private RuleSetVersion ruleSetVersion;
  private String owners;
  /**
   * Check login user whether is owner of rule set.
   */
  private boolean isOwnerOfRuleSet = false;

  /**
   * Check login user whether is creator of rule set.
   */
  private boolean isCreatorOfRuleSet = false;

  private String loginRole;

  private List<RuleSetOwners> oldRuleSetOwners;

  public RulesetDefinitionAction() {
    ruleSetVersion = new RuleSetVersion();
    ruleSetVersion.setMirCriteria(new MirCriteria());
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.WPage#beforeRender(st.liotrox.WRequest)
   */
  @Override
  protected void beforeRender(WRequest request) {
    // prevent NullPointer exception when framework render page.
    if (ruleSetVersion.getMirCriteria() == null) {
      ruleSetVersion.setMirCriteria(new MirCriteria());
    }
    super.beforeRender(request);
  }
  
  @Override
  protected void checkUserRole(WRequest request) {
    super.checkUserRole(request);
    if (!getIsManaged()) {
      isCreatorOfRuleSet = false;
      isOwnerOfRuleSet = false;
    }
    loginRole = request.getUserProfile().getAttribute("liotrox.role");;
  };
  
  public boolean getInputMirCriteria(){
    if("admin".equals(loginRole)){
      return false;
    }
    return true;
  }

  public void doShow(WRequest request, Event event) {
    // Check rule of user
    checkUserRole(request);
    // get action: add or edit.
    if (actionType == null) {
      actionType = request.getParameter("type");
    }
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");
    if (EDIT_TYPE.equals(actionType)) {
      // Get rule set version Id.
      String ruleSetVersionIdStr = request.getParameter("ruleSetVersionId");
      if (ruleSetVersionIdStr != null) {
        Long ruleSetVersionId = Long.parseLong(ruleSetVersionIdStr);
        BaseService base = new BaseService(SCWebServiceFactory.getScEntityManagerFactory());
        EntityManager entityManager = base.getEntityManagerFactory().createEntityManager();
        ruleSetVersion =
            base.queryByPrimaryKey(entityManager, RuleSetVersion.class, ruleSetVersionId);
        // prevent exception on GUI
        if (ruleSetVersion.getMirCriteria() == null) {
          ruleSetVersion.setMirCriteria(new MirCriteria());
        }
        buildOwnersString();
        // Close entity manager.
        base.closeEntityManager(entityManager);
      }
      if (getIsManaged()) {
        isOwnerOfRuleSet = checkIsOwner(loginUser);
        if (loginUser.equalsIgnoreCase(ruleSetVersion.getRuleSet().getCreatedBy())) {
          isCreatorOfRuleSet = true;
        }
      }
    }
    if (ADD_TYPE.equals(actionType)) {
      if (getIsManaged()) {
        isOwnerOfRuleSet = true;
        isCreatorOfRuleSet = true;
      }
      // Add new rule, must initial some values.
      // When add new rule, the version of rule is 1.
      ruleSetVersion.setVersion(1);
      // Set default origin
      ruleSetVersion.getRuleSet().setOrigin(
          (String) ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getValue(
              ConfigLoader.PLANT_CODE));
      owners = loginUser;
    }
  }

  private boolean checkExistRuleSetVersion(WRequest request, Long ruleSetVersionId) {
    BaseService base = SCWebServiceFactory.getScBaseService();
    RuleSetVersion ruleSetVersion =
        base.queryByPrimaryKey(RuleSetVersion.class, ruleSetVersionId);
    if (ruleSetVersion == null) {
      errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_version_was_deleted");
      return false;
    } else {
      oldRuleSetOwners = ruleSetVersion.getRuleSet().getUserRuleSets();
    }
    return true;
  }

  public void doSave(WRequest request, Event event) {
    boolean isEdit = false;
    boolean isAdd = false;
    Long startTime = System.currentTimeMillis();
    // Check action type
    if (EDIT_TYPE.equals(actionType)) {
      isEdit = true;
    }
    if (ADD_TYPE.equals(actionType)) {
      isAdd = true;
    }
    // Check rule set version whether is deleted when edit rule set.
    if (isEdit && !checkExistRuleSetVersion(request, ruleSetVersion.getRuleSetVersionId())) {
      return;
    }
    // Check exist rule set name
    String originRuleSetName = request.getParameter("origin_ruleset_name_h");
    if (isAdd
        || (isEdit && !originRuleSetName.equalsIgnoreCase(ruleSetVersion.getRuleSet()
            .getName()))) {
      boolean exist = checkExistRuleSetName(ruleSetVersion.getRuleSet().getName());
      if (exist) {
        errorMessage = CommonUtils.getRuleSetBundleMessage("ruleset_name_exist");
        return;
      }
    }
    // check origin field: Plant code
    if (ruleSetVersion.getRuleSet().getOrigin() == null
        || ruleSetVersion.getRuleSet().getOrigin().length() == 0) {
      errorMessage = CommonUtils.getCommonBundleMessage("msg_input_plant_code");
      return;
    }
    // get login user to be updated user of rule.
    String loginUser = request.getUserProfile().getAttribute("liotrox.user");

    if (isAdd) {
      // GET rule set id.
      Long ruleSetId =
          SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET);
      ruleSetVersion.setRuleSetId(ruleSetId);
      ruleSetVersion.getRuleSet().setRuleSetId(ruleSetId);
      // Get rule set version id
      Long ruleSetVersionId =
          SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET_VERSION);
      ruleSetVersion.setRuleSetVersionId(ruleSetVersionId);

      // set create by
      ruleSetVersion.getRuleSet().setCreatedBy(loginUser);
      ruleSetVersion.setStatus(false);
    }

    // Set updated by for rule version
    ruleSetVersion.setUpdatedBy(loginUser);

    BaseService baseServ = SCWebServiceFactory.getScBaseService();
    List<RulesOfRS> ruleListOfRuleSetVersion = null;
    Long oldRuleSetVersionId = null;
    // Check Increase versions when edit rule
    if (isEdit) {
      // I check increase version on client side with general information:
      // owners, alarm threshold, description.
      // I put parameter to request to check increase version.
      String increase = request.getParameter(INCREASE_VERSION_REQUEST_PARAMETER);
      if ("true".equals(increase)) {
        // store old rule set version id.
        oldRuleSetVersionId = ruleSetVersion.getRuleSetVersionId();
        // increase version of rule
        Integer maxVersion =
            new RuleSetService(baseServ).getMaxVersionOfRuleSet(ruleSetVersion.getRuleSet()
                .getRuleSetId());
        if (maxVersion == null) {
          errorMessage = CommonUtils.getRuleSetBundleMessage("cannot_get_max_rulesetversion");
          return;
        }
        ruleSetVersion.setVersion(maxVersion + 1);
        ruleSetVersion.setStatus(false);
        Long currentRuleSetVersionId = ruleSetVersion.getRuleSetVersionId();
        // Increase rule set version id.
        Long newRuleSetVersionId =
            SCWebServiceFactory.getSCExecutor().getSequence(SCConstants.SEQ_RULE_SET_VERSION);
        ruleSetVersion.setRuleSetVersionId(newRuleSetVersionId);

        // Get rule list of current rule set version and at it to new version.
        RuleSetService ruleSetServ = new RuleSetService(baseServ);
        ruleListOfRuleSetVersion = ruleSetServ.getListRulesOfRS(currentRuleSetVersionId);
        if (ruleListOfRuleSetVersion != null && ruleListOfRuleSetVersion.size() > 0) {
          for (RulesOfRS rulesOfRS : ruleListOfRuleSetVersion) {
            rulesOfRS.getId().setRuleSetVersionId(newRuleSetVersionId);
          }
        }
      }
    }
    // Check MIR criteria is empty or not
    if (Util.countMirCriteria(ruleSetVersion.getMirCriteria()) == 0) {
      ruleSetVersion.setMirCriteria(null);
    } else {
      // Assign Id for MirCriteria.
      ruleSetVersion.getMirCriteria()
          .setRuleSetVersionId(ruleSetVersion.getRuleSetVersionId());
      ruleSetVersion.getMirCriteria().setRuleSetVersion(ruleSetVersion);
    }
    // Update list of UserRule
    if (owners == null || owners.length() == 0) {
      owners = ruleSetVersion.getRuleSet().getCreatedBy();
    } else {
      // check creator exist in list
      String creator = ruleSetVersion.getRuleSet().getCreatedBy();
      if (owners.indexOf(creator) == -1) {
        owners = creator + SCConstants.STRING_CONNECTOR + owners;
      }
    }
    // Get list of RuleSetOwners from owners string.
    List<RuleSetOwners> userList =
        getOwnersOfRuleSet(owners, ruleSetVersion.getRuleSet().getRuleSetId());

    // Get next action, if save and close, we will save data to DB and close.
    String nextAction = event.getParameter("nextAction");
    if ("saveClose".equals(nextAction)) {
      List<QueryExecutor> listExecutor = new ArrayList<QueryExecutor>();
      // If we edit on rule, must remove old owners list of rule before insert
      // new owners.
      if (isEdit) {
        // Delete old UserRule before update new owners.
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("ruleSetId", ruleSetVersion.getRuleSet().getRuleSetId());
        QueryStringExecutor queryExecutor =
            new QueryStringExecutor(QueryStringExecutor.NAMED_QUERY,
                RuleSetOwners.DELETE_USERS, param);
        listExecutor.add(queryExecutor);
      }

      // Get current time on DB.
      Timestamp currentTime = SCWebServiceFactory.getSCExecutor().getSysDate();
      ruleSetVersion.setUpdatedOn(currentTime);
      ruleSetVersion.getRuleSet().setUpdatedOn(currentTime);
      if (isAdd) {
        ruleSetVersion.setStatusUpdatedTime(currentTime);
      }
      // Save data to DB.
      int saveType;
      if (isAdd) {
        saveType = EntityExecutor.INSERT_ENTITY;
      } else {
        saveType = EntityExecutor.UPDATE_ENTITY;
      }
      // Update rule set and its version
      listExecutor.add(new EntityExecutor(saveType, ruleSetVersion.getRuleSet()));
      listExecutor.add(new EntityExecutor(saveType, ruleSetVersion));

      for (RuleSetOwners userRuleset : userList) {
        listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, userRuleset));
      }
      // Insert rules of rule set version when increase version.
      if (ruleListOfRuleSetVersion != null && ruleListOfRuleSetVersion.size() > 0) {
        for (RulesOfRS rulesOfRS : ruleListOfRuleSetVersion) {
          listExecutor.add(new EntityExecutor(EntityExecutor.INSERT_ENTITY, rulesOfRS));
        }
      }
      try {
        baseServ.executeMultipleQuery(listExecutor);

        // insert action tracking
        insertActionTracking(isEdit, originRuleSetName, oldRuleSetVersionId, userList,
            System.currentTimeMillis() - startTime);
      } catch (Exception e) {
        LOGGER.error(e.getMessage(), e);
        errorMessage = CommonUtils.getRuleSetBundleMessage("error_when_save_ruleset");
        return;
      }

      // If successful, and add actions, redirect to rule set list page.
      redirectBackToRuleSetList(request, ruleSetVersion.getRuleSet().getRuleSetId(),
          ruleSetVersion.getRuleSetVersionId(), isAdd, isEdit && (oldRuleSetVersionId != null));
    }
    if ("edit_rule_list".equals(nextAction)) {
      // Don't save data to DB, store information in Session, and we continue
      // edit rule list.
      ruleSetVersion.getRuleSet().setUserRuleSets(userList);
      request.getSession().setAttribute(SCConstants.SESSION_KEY_RULESET_VERSION,
          ruleSetVersion);
      // redirect to define rule list page.
      // If we increase version of rule set, we will get old rule set version id
      // to display rule list.
      Long ruleSetVersionId = null;
      if (oldRuleSetVersionId != null) {
        ruleSetVersionId = oldRuleSetVersionId;
      } else {
        ruleSetVersionId = ruleSetVersion.getRuleSetVersionId();
      }
      String param = SCConstants.PARAMETER_CALL_FROM_RULESET_DEFINITION + "=true";
      if (isAdd) {
        param += ",add";
      }
      redirectToEditRuleListOfRuleSetPage(request, ruleSetVersionId, new String[]{param });
    }
  }

  private void insertActionTracking(boolean isEdit, String oldRuleSetName,
      Long oldRuleSetVersionId, List<RuleSetOwners> newOwners, long elapsedTime) {
    StringBuilder changedParam = new StringBuilder();
    if (isEdit) {
      if (!oldRuleSetName.equalsIgnoreCase(ruleSetVersion.getRuleSet().getName())) {
        changedParam.append("Rule Set Name: OldValue=").append(oldRuleSetName)
            .append(", NewValue=").append(ruleSetVersion.getRuleSet().getName());
      }
      // Have increase version.
      if (oldRuleSetVersionId != null
          && !oldRuleSetVersionId.equals(ruleSetVersion.getRuleSetVersionId())) {
        if (changedParam.length() > 0) {
          changedParam.append(";");
        }
        RuleSetVersion oldRuleSetVersion =
            SCWebServiceFactory.getScBaseService().queryByPrimaryKey(RuleSetVersion.class,
                oldRuleSetVersionId);
        changedParam.append("Version: OldValue=").append(oldRuleSetVersion.getVersion())
            .append(", NewValue=").append(ruleSetVersion.getVersion()).append("");

        RuleSetComparison.differentRuleSet(oldRuleSetVersion, ruleSetVersion, changedParam);
      }

      // compare 2 list owners
      boolean different = RuleSetComparison.isUserListDifferent(newOwners, oldRuleSetOwners);
      if (different) {
        if (changedParam.length() > 0) {
          changedParam.append(",");
        }
        changedParam.append("[Owners:");
        // old users
        for (RuleSetOwners oldOwner : oldRuleSetOwners) {
          changedParam.append(oldOwner.getId().getUserName()).append(",");
        }
        changedParam.append("->");
        // new owners
        for (RuleSetOwners newOwner : newOwners) {
          changedParam.append(newOwner.getId().getUserName()).append(",");
        }
        changedParam.append("]");
      }
    } else {
      changedParam.append("Rule Set Name:").append(ruleSetVersion.getRuleSet().getName());
    }
    if (changedParam.length() > 0) {
      ActionTrackingEntity trackingEntity = new ActionTrackingEntity();
      if (isEdit) {
        trackingEntity.setAction("Modify Rule Set");
      } else {
        trackingEntity.setAction("Create Rule Set");
      }
      trackingEntity.setParameters(changedParam.toString());
      trackingEntity.setElapsedTime(elapsedTime);

      trackAction(trackingEntity);
    }
  }

  /**
   * Check exist rule name.
   * 
   * @param ruleName
   *          name of rule.
   * @return true if rule name exist.
   */
  private boolean checkExistRuleSetName(String ruleSetName) {
    RuleSetService rsSer = new RuleSetService(SCWebServiceFactory.getScBaseService());
    if (rsSer.getRuleSetByName(ruleSetName) != null) {
      return true;
    }
    return false;
  }

  /**
   * Build string of owners of this rule.
   * 
   * @return string of owners.
   */
  private void buildOwnersString() {
    List<RuleSetOwners> list = ruleSetVersion.getRuleSet().getUserRuleSets();
    if (list != null && list.size() > 0) {
      StringBuilder usernameBuilder = new StringBuilder();
      for (RuleSetOwners user : list) {
        usernameBuilder.append(user.getId().getUserName())
            .append(SCConstants.STRING_CONNECTOR);
      }
      // Remove the last connector.
      if (usernameBuilder.length() > 0) {
        usernameBuilder.setLength(usernameBuilder.length()
            - SCConstants.STRING_CONNECTOR.length());
      }
      owners = usernameBuilder.toString();
    }
  }

  /**
   * Check user name whether is owner of rule set.
   * 
   * @param userName
   *          user name need to check.
   * @return true if it is owners.
   */
  private boolean checkIsOwner(String userName) {
    List<RuleSetOwners> list = ruleSetVersion.getRuleSet().getUserRuleSets();
    if (list != null && list.size() > 0) {
      for (RuleSetOwners user : list) {
        if (userName.equalsIgnoreCase(user.getId().getUserName())) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Get list of RuleSetOwners from owners string.
   * 
   * @param ownerList
   *          String of id of user.
   * @param ruleId
   * @return list of RuleSetOwners
   */
  private List<RuleSetOwners> getOwnersOfRuleSet(String ownerList, Long ruleSetId) {
    if (ownerList == null || ownerList.length() == 0) {
      return null;
    }
    String[] splitList = ownerList.split(SCConstants.STRING_CONNECTOR);
    List<RuleSetOwners> userList = new ArrayList<RuleSetOwners>();
    for (String userName : splitList) {
      userList.add(new RuleSetOwners(userName, ruleSetId));
    }
    return userList;
  }

  /**
   * @return the actionType
   */
  public String getActionType() {
    return actionType;
  }

  /**
   * @param actionType
   *          the actionType to set
   */
  public void setActionType(String actionType) {
    this.actionType = actionType;
  }

  /**
   * @return the ruleSetVersion
   */
  public RuleSetVersion getRuleSetVersion() {
    return ruleSetVersion;
  }

  /**
   * @param ruleSetVersion
   *          the ruleSetVersion to set
   */
  public void setRuleSetVersion(RuleSetVersion ruleSetVersion) {
    this.ruleSetVersion = ruleSetVersion;
  }

  /**
   * @return the owners
   */
  public String getOwners() {
    return owners;
  }

  /**
   * @param owners
   *          the owners to set
   */
  public void setOwners(String owners) {
    this.owners = owners;
  }

  public String getRulesetName() {
    return new String();
  }

  public String getMirPartType() {
    return new String();
  }

  public String getMirDsgnRev() {
    return new String();
  }

  public String getMirOperFrq() {
    return new String();
  }

  public String getMirTstrType() {
    return new String();
  }

  public String getMirExecType() {
    return new String();
  }

  public String getMirExecVer() {
    return new String();
  }

  public String getMirJobName() {
    return new String();
  }

  public String getMirJobRev() {
    return new String();
  }

  public boolean getIsOwnerOfRuleSet() {
    return isOwnerOfRuleSet;
  }

  public boolean getIsCreatorOfRuleSet() {
    return isCreatorOfRuleSet;
  }

  /**
   * @param isOwnerOfRuleSet
   *          the isOwnerOfRuleSet to set
   */
  public void setIsOwnerOfRuleSet(boolean isOwnerOfRuleSet) {
    this.isOwnerOfRuleSet = isOwnerOfRuleSet;
  }

  /**
   * @param isCreatorOfRuleSet
   *          the isCreatorOfRuleSet to set
   */
  public void setIsCreatorOfRuleSet(boolean isCreatorOfRuleSet) {
    this.isCreatorOfRuleSet = isCreatorOfRuleSet;
  }

  /**
   * @return the login role
   */
  public String getLoginRole() {
    return loginRole;
  }

  /**
   * @param loginRole the loginRole to set
   */
  public void setLoginRole(String loginRole) {
    this.loginRole = loginRole;
  }
  
}
