/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 1, 2011 3:58:18 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import com.st.sc.common.SCConstants;
import com.st.sc.entity.CompliancyResultEntity;

/**
 * The Class CompliancyResultDTO.
 */
public class CompliancyResultDTO {

  /** The file id. */
  private Long fileId;

  /** The checking time. */
  private String checkingTime;

  /** The compliancy score. */
  private Double compliancyScore;

  /** The file name. */
  private String fileName;

  /** The mir cmod cod. */
  private String mirCmodCod;

  /** The mir dsgn rev. */
  private String mirDsgnRev;

  /** The mir exec typ. */
  private String mirExecTyp;

  /** The mir exec ver. */
  private String mirExecVer;

  /** The mir flow id. */
  private String mirFlowId;

  /** The mir job nam. */
  private String mirJobNam;

  /** The mir job rev. */
  private String mirJobRev;

  /** The mir mode cod. */
  private String mirModeCod;

  /** The mir oper frq. */
  private String mirOperFrq;

  /** The mir part typ. */
  private String mirPartTyp;

  /** The mir proc id. */
  private String mirProcId;

  /** The mir spec nam. */
  private String mirSpecNam;

  /** The mir spec ver. */
  private String mirSpecVer;

  /** The mir start t. */
  private String mirStartT;

  /** The mir supr nam. */
  private String mirSuprNam;

  /** The mir tstr typ. */
  private String mirTstrTyp;

  /** The mrr finish t. */
  private String mrrFinishT;

  /** The rule set name. */
  private String ruleSetName;

  /** The rule set ver. */
  private Integer ruleSetVer;

  /**
   * Instantiates a new compliancy result dto.
   */
  public CompliancyResultDTO() {
  }

  /**
   * Instantiates a new compliancy result dto.
   *
   * @param e the e
   */
  public CompliancyResultDTO(CompliancyResultEntity e) {
    final SimpleDateFormat dateFormat = new SimpleDateFormat(SCConstants.FULL_DATE_FORMAT);
    Timestamp time = e.getCheckingTime();
    if (time != null) {
      setCheckingTime(dateFormat.format(time));
    }
    setCompliancyScore(e.getCompliancyScore());
    setFileId(e.getFileId());
    setFileName(e.getFileName());
    setMirCmodCod(e.getMirCmodCod());
    setMirDsgnRev(e.getMirDsgnRev());
    setMirExecTyp(e.getMirExecTyp());
    setMirExecVer(e.getMirExecVer());
    setMirFlowId(e.getMirFlowId());
    setMirJobNam(e.getMirJobNam());
    setMirJobRev(e.getMirJobRev());
    setMirModeCod(e.getMirModeCod());
    setMirOperFrq(e.getMirOperFrq());
    setMirPartTyp(e.getMirPartTyp());
    setMirProcId(e.getMirProcId());
    setMirSpecNam(e.getMirSpecNam());
    setMirSpecVer(e.getMirSpecVer());
    time = e.getMirStartT();
    if (time != null) {
      setMirStartT(dateFormat.format(time));
    }
    setMirSuprNam(e.getMirSuprNam());
    setMirTstrTyp(e.getMirTstrTyp());
    time = e.getMrrFinishT();
    if (time != null) {
      setMrrFinishT(dateFormat.format(time));
    }
    setRuleSetName(e.getRuleSetName());
    setRuleSetVer(e.getRuleSetVer());
  }

  /**
   * Gets the file id.
   *
   * @return the file id
   */
  public Long getFileId() {
    return this.fileId;
  }

  /**
   * Sets the file id.
   *
   * @param fileId the new file id
   */
  public void setFileId(Long fileId) {
    this.fileId = fileId;
  }

  /**
   * Gets the checking time.
   *
   * @return the checking time
   */
  public String getCheckingTime() {
    return this.checkingTime;
  }

  /**
   * Sets the checking time.
   *
   * @param checkingTime the new checking time
   */
  public void setCheckingTime(String checkingTime) {
    this.checkingTime = checkingTime;
  }

  /**
   * Gets the compliancy score.
   *
   * @return the compliancy score
   */
  public Double getCompliancyScore() {
    return this.compliancyScore;
  }

  /**
   * Sets the compliancy score.
   *
   * @param compliancyScore the new compliancy score
   */
  public void setCompliancyScore(Double compliancyScore) {
    this.compliancyScore = compliancyScore;
  }

  /**
   * Gets the file name.
   *
   * @return the file name
   */
  public String getFileName() {
    return this.fileName;
  }

  /**
   * Sets the file name.
   *
   * @param fileName the new file name
   */
  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  /**
   * Gets the mir cmod cod.
   *
   * @return the mir cmod cod
   */
  public String getMirCmodCod() {
    return this.mirCmodCod;
  }

  /**
   * Sets the mir cmod cod.
   *
   * @param mirCmodCod the new mir cmod cod
   */
  public void setMirCmodCod(String mirCmodCod) {
    this.mirCmodCod = mirCmodCod;
  }

  /**
   * Gets the mir dsgn rev.
   *
   * @return the mir dsgn rev
   */
  public String getMirDsgnRev() {
    return this.mirDsgnRev;
  }

  /**
   * Sets the mir dsgn rev.
   *
   * @param mirDsgnRev the new mir dsgn rev
   */
  public void setMirDsgnRev(String mirDsgnRev) {
    this.mirDsgnRev = mirDsgnRev;
  }

  /**
   * Gets the mir exec typ.
   *
   * @return the mir exec typ
   */
  public String getMirExecTyp() {
    return this.mirExecTyp;
  }

  /**
   * Sets the mir exec typ.
   *
   * @param mirExecTyp the new mir exec typ
   */
  public void setMirExecTyp(String mirExecTyp) {
    this.mirExecTyp = mirExecTyp;
  }

  /**
   * Gets the mir exec ver.
   *
   * @return the mir exec ver
   */
  public String getMirExecVer() {
    return this.mirExecVer;
  }

  /**
   * Sets the mir exec ver.
   *
   * @param mirExecVer the new mir exec ver
   */
  public void setMirExecVer(String mirExecVer) {
    this.mirExecVer = mirExecVer;
  }

  /**
   * Gets the mir flow id.
   *
   * @return the mir flow id
   */
  public String getMirFlowId() {
    return this.mirFlowId;
  }

  /**
   * Sets the mir flow id.
   *
   * @param mirFlowId the new mir flow id
   */
  public void setMirFlowId(String mirFlowId) {
    this.mirFlowId = mirFlowId;
  }

  /**
   * Gets the mir job nam.
   *
   * @return the mir job nam
   */
  public String getMirJobNam() {
    return this.mirJobNam;
  }

  /**
   * Sets the mir job nam.
   *
   * @param mirJobNam the new mir job nam
   */
  public void setMirJobNam(String mirJobNam) {
    this.mirJobNam = mirJobNam;
  }

  /**
   * Gets the mir job rev.
   *
   * @return the mir job rev
   */
  public String getMirJobRev() {
    return this.mirJobRev;
  }

  /**
   * Sets the mir job rev.
   *
   * @param mirJobRev the new mir job rev
   */
  public void setMirJobRev(String mirJobRev) {
    this.mirJobRev = mirJobRev;
  }

  /**
   * Gets the mir mode cod.
   *
   * @return the mir mode cod
   */
  public String getMirModeCod() {
    return this.mirModeCod;
  }

  /**
   * Sets the mir mode cod.
   *
   * @param mirModeCod the new mir mode cod
   */
  public void setMirModeCod(String mirModeCod) {
    this.mirModeCod = mirModeCod;
  }

  /**
   * Gets the mir oper frq.
   *
   * @return the mir oper frq
   */
  public String getMirOperFrq() {
    return this.mirOperFrq;
  }

  /**
   * Sets the mir oper frq.
   *
   * @param mirOperFrq the new mir oper frq
   */
  public void setMirOperFrq(String mirOperFrq) {
    this.mirOperFrq = mirOperFrq;
  }

  /**
   * Gets the mir part typ.
   *
   * @return the mir part typ
   */
  public String getMirPartTyp() {
    return this.mirPartTyp;
  }

  /**
   * Sets the mir part typ.
   *
   * @param mirPartTyp the new mir part typ
   */
  public void setMirPartTyp(String mirPartTyp) {
    this.mirPartTyp = mirPartTyp;
  }

  /**
   * Gets the mir proc id.
   *
   * @return the mir proc id
   */
  public String getMirProcId() {
    return this.mirProcId;
  }

  /**
   * Sets the mir proc id.
   *
   * @param mirProcId the new mir proc id
   */
  public void setMirProcId(String mirProcId) {
    this.mirProcId = mirProcId;
  }

  /**
   * Gets the mir spec nam.
   *
   * @return the mir spec nam
   */
  public String getMirSpecNam() {
    return this.mirSpecNam;
  }

  /**
   * Sets the mir spec nam.
   *
   * @param mirSpecNam the new mir spec nam
   */
  public void setMirSpecNam(String mirSpecNam) {
    this.mirSpecNam = mirSpecNam;
  }

  /**
   * Gets the mir spec ver.
   *
   * @return the mir spec ver
   */
  public String getMirSpecVer() {
    return this.mirSpecVer;
  }

  /**
   * Sets the mir spec ver.
   *
   * @param mirSpecVer the new mir spec ver
   */
  public void setMirSpecVer(String mirSpecVer) {
    this.mirSpecVer = mirSpecVer;
  }

  /**
   * Gets the mir start t.
   *
   * @return the mir start t
   */
  public String getMirStartT() {
    return this.mirStartT;
  }

  /**
   * Sets the mir start t.
   *
   * @param mirStartT the new mir start t
   */
  public void setMirStartT(String mirStartT) {
    this.mirStartT = mirStartT;
  }

  /**
   * Gets the mir supr nam.
   *
   * @return the mir supr nam
   */
  public String getMirSuprNam() {
    return this.mirSuprNam;
  }

  /**
   * Sets the mir supr nam.
   *
   * @param mirSuprNam the new mir supr nam
   */
  public void setMirSuprNam(String mirSuprNam) {
    this.mirSuprNam = mirSuprNam;
  }

  /**
   * Gets the mir tstr typ.
   *
   * @return the mir tstr typ
   */
  public String getMirTstrTyp() {
    return this.mirTstrTyp;
  }

  /**
   * Sets the mir tstr typ.
   *
   * @param mirTstrTyp the new mir tstr typ
   */
  public void setMirTstrTyp(String mirTstrTyp) {
    this.mirTstrTyp = mirTstrTyp;
  }

  /**
   * Gets the mrr finish t.
   *
   * @return the mrr finish t
   */
  public String getMrrFinishT() {
    return this.mrrFinishT;
  }

  /**
   * Sets the mrr finish t.
   *
   * @param mrrFinishT the new mrr finish t
   */
  public void setMrrFinishT(String mrrFinishT) {
    this.mrrFinishT = mrrFinishT;
  }

  /**
   * Gets the rule set name.
   *
   * @return the rule set name
   */
  public String getRuleSetName() {
    return this.ruleSetName;
  }

  /**
   * Sets the rule set name.
   *
   * @param ruleSetName the new rule set name
   */
  public void setRuleSetName(String ruleSetName) {
    this.ruleSetName = ruleSetName;
  }

  /**
   * Gets the rule set ver.
   *
   * @return the rule set ver
   */
  public Integer getRuleSetVer() {
    return this.ruleSetVer;
  }

  /**
   * Sets the rule set ver.
   *
   * @param ruleSetVer the new rule set ver
   */
  public void setRuleSetVer(Integer ruleSetVer) {
    this.ruleSetVer = ruleSetVer;
  }

}
