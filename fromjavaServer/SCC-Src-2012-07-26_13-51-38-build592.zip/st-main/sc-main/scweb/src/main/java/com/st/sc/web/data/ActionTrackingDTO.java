/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 12, 2011 8:47:41 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.web.data;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.st.persistence.entity.ActionTrackingEntity;
import com.st.sc.common.SCConstants;

/**
 * The Class ActionTrackingDTO.
 */
public class ActionTrackingDTO {

  /** The tracking id. */
  private Long trackingId;

  /** The author. */
  private String author;

  /** The action. */
  private String action;

  /** The elapsed time. */
  private Long elapsedTime;

  /** The parameters. */
  private String parameters;

  /** The updated on. */
  private String updatedOn;

  /**
   * Instantiates a new action tracking dto.
   * 
   * @param e
   *          the e
   */
  public ActionTrackingDTO(final ActionTrackingEntity e) {
    setTrackingId(e.getTrackingId());
    setAuthor(e.getAuthor());
    setAction(e.getAction());
    setElapsedTime(e.getElapsedTime());
    setParameters(e.getParameters());
    final Timestamp time = e.getUpdatedOn();
    if (time != null) {
      final DateFormat format = new SimpleDateFormat(SCConstants.FULL_DATE_FORMAT);
      setUpdatedOn(format.format(time));
    }
  }

  /**
   * Gets the action.
   * 
   * @return the action
   */
  public String getAction() {
    return action;
  }

  /**
   * Gets the author.
   * 
   * @return the author
   */
  public String getAuthor() {
    return author;
  }

  /**
   * Gets the elapsed time.
   * 
   * @return the elapsed time
   */
  public Long getElapsedTime() {
    return elapsedTime;
  }

  /**
   * Gets the parameters.
   * 
   * @return the parameters
   */
  public String getParameters() {
    return parameters;
  }

  /**
   * Gets the tracking id.
   * 
   * @return the tracking id
   */
  public Long getTrackingId() {
    return trackingId;
  }

  /**
   * Gets the updated on.
   * 
   * @return the updated on
   */
  public String getUpdatedOn() {
    return updatedOn;
  }

  /**
   * Sets the action.
   * 
   * @param action
   *          the new action
   */
  public void setAction(final String action) {
    this.action = action;
  }

  /**
   * Sets the author.
   * 
   * @param author
   *          the new author
   */
  public void setAuthor(final String author) {
    this.author = author;
  }

  /**
   * Sets the elapsed time.
   * 
   * @param elapsedTime
   *          the new elapsed time
   */
  public void setElapsedTime(final long elapsedTime) {
    this.elapsedTime = elapsedTime;
  }

  /**
   * Sets the parameters.
   * 
   * @param parameters
   *          the new parameters
   */
  public void setParameters(final String parameters) {
    this.parameters = parameters;
  }

  /**
   * Sets the tracking id.
   * 
   * @param trackingId
   *          the new tracking id
   */
  public void setTrackingId(final Long trackingId) {
    this.trackingId = trackingId;
  }

  /**
   * Sets the updated on.
   * 
   * @param updatedOn
   *          the new updated on
   */
  public void setUpdatedOn(final String updatedOn) {
    this.updatedOn = updatedOn;
  }
}
