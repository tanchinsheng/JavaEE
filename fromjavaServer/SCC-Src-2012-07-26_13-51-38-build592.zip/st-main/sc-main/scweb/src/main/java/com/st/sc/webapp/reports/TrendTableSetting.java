/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 22, 2012 7:37:53 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import st.liotrox.WRequest;

import com.st.common.exception.SccException;
import com.st.sc.common.CommonUtils;
import com.st.sc.web.data.ReportData;

/**
 * The Class TrendTableSetting.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class TrendTableSetting extends BaseReportSetting {

  /** The Constant NUMBER_OF_STDF_OPTION. */
  public static final String NUMBER_OF_STDF_OPTION = "nos";

  /** The Constant MIR_FIELD_OPTION. */
  public static final String MIR_FIELD_OPTION = "mmf";

  /** The Constant WEEK_OPTION. */
  public static final String WEEK_OPTION = "w";

  /** The Constant MONTH_OPTION. */
  public static final String MONTH_OPTION = "m";

  /** The Constant QUARTER_OPTION. */
  public static final String QUARTER_OPTION = "q";

  /** The column option. */
  protected String columnOption;

  /** The row option. */
  protected String rowOption;

  /** The group by. */
  protected String groupBy;

  /** The is mir field checked. */
  protected boolean isMirFieldChecked = true;

  /** The cell option. */
  private String cellOption;

  /**
   * Validate input data.
   * 
   * @return the string
   */
  public String validateInputData() {
    // bind row option, because when create offline report, cannot get value
    // from request.
    bindRowOption();
    return validateInputData("trend_table_series_");
  }

  /**
   * Gets the data of score trend table.
   * 
   * @return the data of score trend table
   * @throws SccException
   */
  public ReportData getDataToShowReport(final String viewName,final boolean isOnlineReport) throws SccException {
    initializeInputData();

    ReportData reportData =
        getValuesToCreateTrendTableAndChart(columnOption, rowOption, groupBy, mirField,
            scoreRanges, null, viewName, isOnlineReport);

    if (reportData == null) {
      return null;
    }
    if ("pos".equals(cellOption)) {
      // ignore first column, or first and second column if have row group.
      boolean haveRowGroup = reportData.haveRowGroup();
      int numberFirstColumn = 1;
      if (haveRowGroup) {
        numberFirstColumn = 2;
      }
      // countColumn is just number column of data, don't include row labels
      final int countColumn = reportData.countNumberColumn();
      final int countRow = reportData.countNumberRow();
      int[] totalStdfArr = new int[countColumn];
      int sum = 0;
      for (int col = 0; col < countColumn; col++) {
        // Table data contains: data and row labels.
        // countColumn is just number column of data, don't include row labels.
        // We must add number first column to index
        final int realColumn = col + numberFirstColumn;
        sum = 0;
        for (int row = 0; row < countRow; row++) {
          sum += (Integer) reportData.getTableData()[row][realColumn];
        }
        totalStdfArr[col] = sum;
      }
      double percent = 1;
      for (int col = 0; col < countColumn; col++) {
        final int realColumn = col + numberFirstColumn;
        for (int row = 0; row < countRow; row++) {
          if (totalStdfArr[col] > 0) {
            percent =
                CommonUtils
                    .roundDouble((double) (Integer) reportData.getTableData()[row][realColumn]
                        / totalStdfArr[col] * 100);
          } else {
            percent = 0;
          }
          reportData.getTableData()[row][realColumn] = percent + "%";
        }
      }
    }
    return reportData;
  }

  /**
   * Generate series.
   */
  public void generateSeries() {
    serieValues = generateSeries(numberOfSeries);
    bindRowOption();
  }

  /**
   * Bind row option.
   */
  protected void bindRowOption() {
    rowOption = WRequest.getCurrentInstance().getParameter("trend_table_rowOption");
    if (MIR_FIELD_OPTION.equals(rowOption)) {
      isMirFieldChecked = true;
    } else if (NUMBER_OF_STDF_OPTION.equals(rowOption)) {
      isMirFieldChecked = false;
    }
  }

  public String getReportTitle() {
    String title = "Compliancy Trend";
    if (TrendTableSetting.MIR_FIELD_OPTION.equals(rowOption)) {
      title = " Compliancy Trend by " + mirField;
    }
    return title;
  }

  public TrendTableSetting copySetting() {
    TrendTableSetting setting = new TrendTableSetting();
    updateSetting(setting);
    return setting;
  }

  /**
   * Update setting.
   * 
   * @param setting
   *          must be not null.
   */
  protected void updateSetting(TrendTableSetting setting) {
    if (setting != null) {
      super.updateSetting(setting);
      setting.setCellOption(cellOption);
      setting.setColumnOption(columnOption);
      setting.setRowOption(rowOption);
      setting.setGroupBy(groupBy);
    }
  }

  /**
   * This function return value to check radio button on client.
   * 
   * @return the mir field checked
   */
  public String getMirFieldChecked() {
    if (isMirFieldChecked) {
      return "checked";
    }
    return "";
  }

  /**
   * This function return value to check radio button on client.
   * 
   * @return the num of series checked
   */
  public String getNumOfSeriesChecked() {
    if (!isMirFieldChecked) {
      return "checked";
    }
    return "";
  }

  /**
   * Gets the column option.
   * 
   * @return the columnOption
   */
  public String getColumnOption() {
    return columnOption;
  }

  /**
   * Sets the column option.
   * 
   * @param columnOption
   *          the columnOption to set
   */
  public void setColumnOption(String columnOption) {
    this.columnOption = columnOption;
  }

  /**
   * Gets the row option.
   * 
   * @return the rowOption
   */
  public String getRowOption() {
    return rowOption;
  }

  /**
   * Sets the row option.
   * 
   * @param rowOption
   *          the rowOption to set
   */
  public void setRowOption(String rowOption) {
    this.rowOption = rowOption;
  }

  /**
   * Gets the group by.
   * 
   * @return the groupBy
   */
  public String getGroupBy() {
    return groupBy;
  }

  /**
   * Sets the group by.
   * 
   * @param groupBy
   *          the groupBy to set
   */
  public void setGroupBy(String groupBy) {
    this.groupBy = groupBy;
  }

  /**
   * Gets the mir field.
   * 
   * @return the mirField
   */
  public String getMirField() {
    return mirField;
  }

  /**
   * Sets the mir field.
   * 
   * @param mirField
   *          the mirField to set
   */
  public void setMirField(String mirField) {
    this.mirField = mirField;
  }

  /**
   * Gets the operator.
   * 
   * @return the operator
   */
  public String getOperator() {
    return operator;
  }

  /**
   * Sets the operator.
   * 
   * @param operator
   *          the operator to set
   */
  public void setOperator(String operator) {
    this.operator = operator;
  }

  /**
   * Gets the serie values.
   * 
   * @return the serieValues
   */
  public double[] getSerieValues() {
    return serieValues;
  }

  /**
   * Sets the serie values.
   * 
   * @param serieValues
   *          the serieValues to set
   */
  public void setSerieValues(double[] serieValues) {
    this.serieValues = serieValues;
  }

  /**
   * Gets the number of series.
   * 
   * @return the numberOfSeries
   */
  public int getNumberOfSeries() {
    return numberOfSeries;
  }

  /**
   * Sets the number of series.
   * 
   * @param numberOfSeries
   *          the numberOfSeries to set
   */
  public void setNumberOfSeries(int numberOfSeries) {
    this.numberOfSeries = numberOfSeries;
  }

  /**
   * Gets the cell option.
   * 
   * @return the cellOption
   */
  public String getCellOption() {
    return cellOption;
  }

  /**
   * Sets the cell option.
   * 
   * @param cellOption
   *          the cellOption to set
   */
  public void setCellOption(String cellOption) {
    this.cellOption = cellOption;
  }

}
