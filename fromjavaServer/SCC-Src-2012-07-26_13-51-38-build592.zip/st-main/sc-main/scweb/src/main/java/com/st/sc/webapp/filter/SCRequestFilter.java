/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 28, 2012 6:05:18 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.webapp.filter;

import com.st.common.web.filter.RequestFilter;
import com.st.persistence.SQLExecutor;
import com.st.sc.common.SCConstants;
import com.st.sc.util.SCWebServiceFactory;
import com.st.um.service.UserService;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class SCRequestFilter extends RequestFilter {


  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.web.filter.RequestFilter#getUserService()
   */
  @Override
  protected UserService getUserService() {
    return SCWebServiceFactory.getUserService();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.web.filter.RequestFilter#getErrorNotImportedURL()
   */
  @Override
  protected String getErrorNotImportedURL() {
    return SCConstants.getContextPath() + SCConstants.ERROR_NOT_IMPORTED_URL;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.web.filter.RequestFilter#getSQLExecutorOfActionTracking()
   */
  @Override
  protected SQLExecutor getSQLExecutorOfActionTracking() {
    return SCWebServiceFactory.getSCExecutor();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.web.filter.RequestFilter#getDBName()
   */
  @Override
  protected String getDBName() {
    return "SC";
  }

}
