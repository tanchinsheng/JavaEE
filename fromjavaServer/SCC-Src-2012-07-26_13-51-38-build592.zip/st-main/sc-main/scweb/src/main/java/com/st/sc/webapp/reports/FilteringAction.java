/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.sc.webapp.reports;

import static com.st.scc.common.utils.StringUtil.isNullOrEmpty;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.event.DataViewEvent;
import st.liotrox.db.DataSet;
import st.liotrox.db.DefaultDataSet;
import st.liotrox.template.element.control.DataViewElement;
import st.liotrox.template.element.control.PanelElement;
import st.liotrox.util.Encode;
import st.liotrox.web.html.Table;

import com.st.common.config.ConfigLoader;
import com.st.common.web.config.ConfigReloader;
import com.st.common.web.util.ServletUtils;
import com.st.sc.common.CommonUtils;
import com.st.sc.common.SCConstants;
import com.st.sc.entity.CompliancyResultEntity;
import com.st.sc.service.ReportService;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.webapp.BaseAction;
import com.st.sc.webapp.WebContext;
import com.st.scc.common.utils.ConvertUtils;

/**
 * The Class FilteringAction.
 */
public class FilteringAction extends BaseAction {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(FilteringAction.class);

  /** The data view. */
  private DataView dataView = null;

  /** The dataset. */
  private DataSet dataset;

  /** The condition info. */
  private FilterConditionInfo conditionInfo = new FilterConditionInfo();

  /** The dataset visible. */
  private boolean datasetVisible;

  /** The Constant TEXT_WIDTH. */
  private static final int TEXT_WIDTH = 145;

  /**
   * Store previous filter condition. If this condition is different, we must
   * create new view.
   */
  private String previousWhereCondition;

  /**
   * Get the DataView.
   * 
   * @return the DataView
   */
  public DataView getDataView() {
    if (dataView == null) {
      DataViewElement dvElement = (DataViewElement) findControl("datasetDataView");
      dataView = dvElement.getDataView(WRequest.getCurrentInstance());
    }
    return dataView;
  }

  /**
   * Before populate.
   * 
   * @param request
   *          the request {@inheritDoc}
   * @see st.liotrox.page.WPage#beforePopulate(st.liotrox.WRequest)
   */
  public void beforePopulate(final WRequest request) {
    // Get DataView object
    dataView = getDataView();
  }

  /**
   * This method is invoked by the framework BEFORE rendering the page.
   * 
   * @param request
   *          the request
   */
  public void beforeRender(final WRequest request) {
    // Get DataView object
    dataView = getDataView();
    if (request.is_NS_Browser()) {
      addOnLoadCode("window.setTimeout('removeEventMouseDown()', 500);");
    }
  }

  /**
   * Load a dataset from a text file.
   * 
   * @return the loaded DataSet
   */
  public DataSet getDataSet() {
    return dataset;
  }

  /**
   * Example of Java callback used to create the dataview header.
   * 
   * @param request
   *          the current request
   * @param event
   *          the event
   * @return the header
   */
  public String headerCallback(final WRequest request, final Event event) {
    Table t = new Table(0);
    t.width("100%").style("border:1px solid navy");
    t.newRow();
    t.cell("<h2>The Data Set</h2>").alignCenter().alignMiddle();
    return Encode.encodeForHTML(t.toString());
  }

  /**
   * Java callback returning NULL.
   * 
   * @param request
   *          the current request
   * @param event
   *          the event
   * @return always NULL
   */
  public String nullCallback(final WRequest request, final DataViewEvent event) {
    return null;
  }

  /**
   * Goto summary report.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void gotoSummaryReport(final WRequest request, final Event event) {
    LOGGER.debug("Begin FilteringAction.gotoSummaryReport()");
    try {
      PanelElement filterPanel = (PanelElement) findControl("filterPanel");
      if (filterPanel.isExpanded()) {
        this.errorMessage = null;
        conditionInfo.fillValue(request);
        // validate user input
        this.errorMessage = validateConditionInfo(conditionInfo);
        if (errorMessage.length() > 0) {
          errorMessage = errorMessage + ".";
          return;
        }
      }
      ReportService service = new ReportService();
      // create temporary view
      String viewName = ServletUtils.getViewName();
      if (!service.viewIsExist(viewName)) {
        Map<String, Object> params = new HashMap<String, Object>();
        String where = conditionInfo.buildSQLWhere(params);
        // store this condition to compare at go to summary button.
        previousWhereCondition = where;
        WebContext.getInstance().addTempView(viewName);
        service.createView(viewName, where, params);
      } else {
        Map<String, Object> params = new HashMap<String, Object>();
        String where = conditionInfo.buildSQLWhere(params);
        // If user change condition, must update view.
        if (!where.equals(previousWhereCondition)) {
          // store this condition to compare at go to summary button.
          previousWhereCondition = where;
          WebContext.getInstance().addTempView(viewName);
          service.createView(viewName, where, params);
        }
      }
      // redirect report page
      request.redirectTo(SCConstants.getContextPath()
          + "/app/path/pages/sc/reports/summaryReport.displayInfoSetting");
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
    LOGGER.debug("End FilteringAction.gotoSummaryReport()");
  }

  /**
   * Format stdf file name.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return formatted file name.
   */
  public String formatFileName(final WRequest request, final DataViewEvent event) {
    String fileName = (String) event.getValue();
    return adjustText(fileName, 290);
  }

  /**
   * Format text.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @return the string
   */
  public String formatText(final WRequest request, final DataViewEvent event) {
    return adjustText(event.getValue(), TEXT_WIDTH);
  }

  /**
   * Reset the conditionInfo.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void reset(final WRequest request, final Event event) {
    LOGGER.info("reset fiter condition");
    conditionInfo.reset();
  }

  public void clear1(final WRequest request, final Event event) {
    try {
      conditionInfo.fillValue(request);
    } catch (Exception e) {
    }
    conditionInfo.setCheckedTimeRadio(null);
  }

  public void clear2(final WRequest request, final Event event) {
    try {
      conditionInfo.fillValue(request);
    } catch (Exception e) {
    }
    conditionInfo.setMirStartTRadio(null);
  }

  public void clear3(final WRequest request, final Event event) {
    try {
      conditionInfo.fillValue(request);
    } catch (Exception e) {
    }
    conditionInfo.setMirFinishTRadio(null);
  }

  /**
   * Generate full detail.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void generateFullDetail(final WRequest request, final Event event) {
    LOGGER.debug("Begin FilteringAction.generateFullDetail()");
    errorMessage = "";
    dataView = getDataView();
    int[] selectedRows = dataView.getSelectedRows();
    if (selectedRows.length != 1) {
      errorMessage = CommonUtils.getCommonBundleMessage("choose_one_record");
      return;
    }
    Object fileId = dataView.getModel().getDataSet().getValue(selectedRows[0], "fileId");
    String fileName =
        (String) dataView.getModel().getDataSet().getValue(selectedRows[0], "fileName");
    Object finalCompliancyScore =
        dataView.getModel().getDataSet().getValue(selectedRows[0], "compliancyScore");
    if (finalCompliancyScore != null) {
      finalCompliancyScore = finalCompliancyScore.toString();
    }
    String checkingTime =
        (String) dataView.getModel().getDataSet().getValue(selectedRows[0], "checkingTime");
    String involvedRuleSet =
        (String) dataView.getModel().getDataSet().getValue(selectedRows[0], "ruleSetName");
    Object version = dataView.getModel().getDataSet().getValue(selectedRows[0], "ruleSetVer");
    if (version != null) {
      version = version.toString();
    }
    final String contextPath = SCConstants.getContextPath();
    StringBuilder url =
        new StringBuilder(contextPath +
            "/app/path/pages/sc/reports/fullDetailReport.generateFullDetailReport?");
    url.append("fileId=").append(ServletUtils.encodeUrlParam(fileId));
    url.append("&fileName=").append(ServletUtils.encodeUrlParam(fileName));
    url.append("&finalCompliancyScore=").append(
        ServletUtils.encodeUrlParam(finalCompliancyScore));
    url.append("&checkingTime=").append(ServletUtils.encodeUrlParam(checkingTime));
    url.append("&involvedRuleSet=").append(ServletUtils.encodeUrlParam(involvedRuleSet));
    url.append("&version=").append(ServletUtils.encodeUrlParam(version));
    url.append("&originalPage=").append(
        ServletUtils.encodeUrlParam(contextPath + "/app/path/pages/sc/reports/filterringPage.lxp"));

    request.redirectTo(url.toString());
    LOGGER.debug("End FilteringAction.generateFullDetail()");
  }

  /**
   * Generate dataset.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   */
  public void generateDataset(final WRequest request, final Event event) {
    LOGGER.debug("Begin FilteringAction.generateDataset()");
    // fill conditionInfo from request
    try {
      this.errorMessage = null;
      conditionInfo.fillValue(request);

      // validate user input
      this.errorMessage = validateConditionInfo(conditionInfo);
      if (errorMessage.length() > 0) {
        errorMessage = errorMessage + ".";
        return;
      }
      ReportService service = new ReportService();
      // create temporary view
      String viewName = ServletUtils.getViewName();
      Map<String, Object> params = new HashMap<String, Object>();
      String where = conditionInfo.buildSQLWhere(params);
      // store this condition to compare at go to summary button.
      previousWhereCondition = where;
      WebContext.getInstance().addTempView(viewName);
      service.createView(viewName, where, params);

      final Number maxRow =
          (Number) ConfigReloader.reload(SCWebServiceFactory.getSettingService()).getValue(
              ConfigLoader.KEY_MAX_ROW_ON_DATAVIEW);
      int maxResult = -1;
      if (maxRow != null) {
        maxResult = maxRow.intValue();
      }
      int size = 0;

      // get data from view
      List<CompliancyResultEntity> beans = service.getAllViewData(viewName, 0, maxResult);

      dataset = new DefaultDataSet();
      dataset.setColumnNames(ReportService.DATASET_COLUMNS);
      if (beans.size() > 0) {
        Object[][] matrix = service.buildDatasetMatrix(beans);
        size = matrix.length;
        dataset.loadFromMatrix(matrix);
      }
      dataView.getModel().setDataSet(dataset);

      if (maxResult != -1 && maxResult <= size) {
        int totalRow = service.getViewRowCount(viewName);
        if (totalRow > maxResult) {
          final String value =
              "<span style=\"color: navy; font-weight: bold;\">"
                  + CommonUtils.getReportBundleMessage("msg_show_num_lastest_records_report",
                      new Object[]{size, totalRow }) + "</span>";
          dataView.setHeader(value);
        } else {
          dataView.setHeader("<span style=\"color: navy; font-weight: bold;\">Found "
              + totalRow + " records</span>");
        }
      } else {
        dataView.setHeader("<span style=\"color: navy; font-weight: bold;\">Found " + size
            + " records</span>");
      }

      // enable data set area
      this.datasetVisible = true;
      // collapse filter panel
      PanelElement filterPanel = (PanelElement) findControl("filterPanel");
      filterPanel.setExpanded(false);

    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
    }
    LOGGER.debug("End FilteringAction.generateDataset()");
  }

  /**
   * Validate FilterConditionInfo.
   * 
   * @param bean
   *          the bean
   * @return error message if the information is invalid, otherwise return empty
   *         string.
   * @throws ParseException
   */
  private String validateConditionInfo(final FilterConditionInfo bean) throws ParseException {
    StringBuilder error = new StringBuilder();

    // check required fields
    if (isNullOrEmpty(bean.getCheckedTimeRadio()) && isNullOrEmpty(bean.getMirStartTRadio())
        && isNullOrEmpty(bean.getMirFinishTRadio())) {
      return CommonUtils.getReportBundleMessage("timing_range_required");
    }
    if ("1".equals(bean.getCheckedTimeRadio())) {
      // check from and to is inputed by user
      if (isNullOrEmpty(bean.getCheckedTimeFrom()) || isNullOrEmpty(bean.getCheckedTimeTo())) {
        error.append(CommonUtils.getReportBundleMessage("checking_time_from_to_required"));
      }
    } else if ("2".equals(bean.getCheckedTimeRadio())) {
      if (isNullOrEmpty(bean.getCheckedTime2Since()) || isNullOrEmpty(bean.getCheckedTime2Last())) {
        error.append(CommonUtils.getReportBundleMessage("checking_time_last_since_required"));
      }
    }
    if ("1".equals(bean.getMirStartTRadio())) {
      if (isNullOrEmpty(bean.getMirStartTFrom()) || isNullOrEmpty(bean.getMirStartTTo())) {
        if (error.length() > 0) {
          error.append(SCConstants.NEW_LINE);
        }
        error.append(CommonUtils.getReportBundleMessage("start_time_from_to_required"));
      }
    } else if ("2".equals(bean.getMirStartTRadio())) {
      if (isNullOrEmpty(bean.getMirStartT2Since()) || isNullOrEmpty(bean.getMirStartT2Last())) {
        if (error.length() > 0) {
          error.append(SCConstants.NEW_LINE);
        }
        error.append(CommonUtils.getReportBundleMessage("start_time_last_since_required"));
      }

    }
    if ("1".equals(bean.getMirFinishTRadio())) {
      if (isNullOrEmpty(bean.getMirFinishTFrom()) || isNullOrEmpty(bean.getMirFinishTTo())) {
        if (error.length() > 0) {
          error.append(SCConstants.NEW_LINE);
        }
        error.append(CommonUtils.getReportBundleMessage("finish_time_from_to_required"));
      }
    } else if ("2".equals(bean.getMirFinishTRadio())) {
      if (isNullOrEmpty(bean.getMirFinishT2Since()) || isNullOrEmpty(bean.getMirFinishT2Last())) {
        if (error.length() > 0) {
          error.append(SCConstants.NEW_LINE);
        }
        error.append(CommonUtils.getReportBundleMessage("finish_time_last_since_required"));
      }
    }

    String tmpVal = bean.getCompliancyScoreValue();
    if (!isNullOrEmpty(tmpVal)) {
      if ("~".equals(bean.getCompliancyScoreOp())) {
        tmpVal = tmpVal.replace("~", ",").trim();
        String[] strings = tmpVal.split(",");
        if (strings.length != 2) {
          if (error.length() > 0) {
            error.append(SCConstants.NEW_LINE);
          }
          error.append("Opeator '~' require 2 numbers and sepearate by '~' or ','");
        } else {
          Double from = ConvertUtils.getDoubleObject(strings[0]);
          Double to = ConvertUtils.getDoubleObject(strings[1]);
          if (from == null || to == null) {
            if (error.length() > 0) {
              error.append(SCConstants.NEW_LINE);
            }
            error.append("Compliancy Score value must be decimal number");
          }
        }
      } else {
        tmpVal = tmpVal.trim();
        Double val = ConvertUtils.getDoubleObject(tmpVal);
        if (val == null) {
          if (error.length() > 0) {
            error.append(SCConstants.NEW_LINE);
          }
          error.append("Compliancy Score value must be decimal number");
        }
      }
    }

    return error.toString();
  }

  /**
   * Gets the condition info.
   * 
   * @return the condition info
   */
  public FilterConditionInfo getConditionInfo() {
    return conditionInfo;
  }

  /**
   * Sets the condition info.
   * 
   * @param conditionInfo
   *          the new condition info
   */
  public void setConditionInfo(final FilterConditionInfo conditionInfo) {
    this.conditionInfo = conditionInfo;
  }

  /**
   * Checks if is dataset visible.
   * 
   * @return true, if is dataset visible
   */
  public boolean isDatasetVisible() {
    return datasetVisible;
  }

  /**
   * @return the previousWhereCondition
   */
  public String getPreviousWhereCondition() {
    return previousWhereCondition;
  }

  /**
   * @param previousWhereCondition
   *          the previousWhereCondition to set
   */
  public void setPreviousWhereCondition(String previousWhereCondition) {
    this.previousWhereCondition = previousWhereCondition;
  }

}
