/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - June 22, 2011 05:34:56 PM - nhatvn - Initialize version
/******************************************************************************/
package com.st.sc.webapp.servlet;

import java.io.File;
import java.util.Map;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.ConfigLoader;
import com.st.common.exception.SccException;
import com.st.common.web.util.DBFunctionConverter;
import com.st.sc.common.LiotroxManager;
import com.st.sc.service.ReportService;
import com.st.sc.util.DBStatus;
import com.st.sc.util.SCWebServiceFactory;
import com.st.sc.util.recordloader.RecordLoader;
import com.st.sc.webapp.WebContext;
import com.st.sc.webapp.ruleandruleset.RuleSetValidationResultAction;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class AppListener implements ServletContextListener {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(AppListener.class);

  /**
   * {@inheritDoc}
   * 
   * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
   */
  public void contextInitialized(final ServletContextEvent event) {
    // Load list of records STDF in SC.
    final String appPath = event.getServletContext().getRealPath("/");
    String seperator = System.getProperty("file.separator");
    final String configPath = appPath + "WEB-INF" + seperator + "record_config" + seperator;

    initializeConfig();
    DBFunctionConverter.getInstance().setDatabaseType(
        SCWebServiceFactory.getSCExecutor().getDatabaseType());
    
    try {
      RecordLoader.loadRecords(configPath);
    } catch (Exception e) {
      LOG.error("Cannot get list of STDF records from file. Detail error:" + e.getMessage(), e);
    }

    LiotroxManager.registers();

    dropTmpViews();
    // delete rule set validation folder in Jboss
    RuleSetValidationResultAction.deleteTempFailedValuesFolder();

    updateOfflineReportStatus();
  }

  /**
   * Initialize config.
   */
  private void initializeConfig() {
    LOG.info("Initialize config loader...");
    // Get config files
    final StringBuilder sb = new StringBuilder();
    final String seperator = File.separator;
    final ConfigLoader configLoader = ConfigLoader.getInstance();
    sb.append(configLoader.getWebappHomeDir()).append(seperator).append("conf")
        .append(seperator);
    configLoader.setConfigPath(sb.toString());

    LOG.info("Check status of connection SC DB.");
    LOG.info(DBStatus.getInstance().toString());
    final boolean scValid = DBStatus.getInstance().getSConnectionStatus();
    if (scValid) {
      LOG.info("Connect to SC DB OK.");
    } else {
      LOG.error("Cannot connect to SC DB, please correct database information and restart system");
    }
    if (!scValid) {
      LOG.info("Stop the server.");
      // Force shutdown JVM
      Runtime.getRuntime().halt(-1);
      return;
    }
    
    try {
      final Map<String, Object> map = SCWebServiceFactory.getSettingService().loadAll();
      configLoader.getSettingMap().putAll(map);
      configLoader.load();
    } catch (final SccException ex) {
      LOG.error("Failed to load config file: " + ex.getMessage());
      throw new RuntimeException(ex);
    }

    LOG.info("Loaded config file sucessfully.");
  }

  /**
   * {@inheritDoc}
   * 
   * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
   */
  public void contextDestroyed(ServletContextEvent arg0) {
    dropTmpViews();
    // delete rule set validation folder in Jboss
    RuleSetValidationResultAction.deleteTempFailedValuesFolder();
    WebContext.getInstance().shutdown();

    updateOfflineReportStatus();
  }

  /**
   * Drop tmp views.
   */
  private void dropTmpViews() {
    // clear all temporary views if exist
    ReportService service = new ReportService();
    service.dropTmpViews();
    service.dropView(WebContext.getInstance().getOfflineReportViewName());
  }

  private void updateOfflineReportStatus() {
    LOG.info("Update status for offline reports which have status 'In-progess'.");
    ReportService service = new ReportService();
    String serverId = WebContext.getInstance().getServerId();
    service.updateInProgessReportToFail("Server shut down", serverId);
  }
    
}
