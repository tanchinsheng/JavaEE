/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 20, 2011 3:19:10 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.sc.util.recordloader;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class RecordLoader {

  public static void loadRecords(String confiPath) throws Exception {
    final String schemaUrl = confiPath + "record_schema.xsd";
    final String recordListUrl = confiPath + "record_list.xml";
    TRecordList recordList = null;
    if (schemaUrl != null && recordListUrl != null) {
      final SchemaFactory schemaFactory =
          SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
      Schema schema = schemaFactory.newSchema(new File(schemaUrl));
      InputStream in = new FileInputStream(recordListUrl);
      final JAXBContext context = JAXBContext.newInstance("com.st.sc.util.recordloader");
      final Unmarshaller unmarshaller = context.createUnmarshaller();
      if (schema != null) {
        unmarshaller.setSchema(schema);
      }
      Object ob = unmarshaller.unmarshal(in);
      if (ob instanceof TRecordList) {
        recordList = (TRecordList) ob;
      } else {
        if (ob instanceof JAXBElement) {
          recordList = ((JAXBElement<TRecordList>) ob).getValue();
        }
      }
    }

    fillRecordListToMap(recordList);
  }

  private static Map<String, String[]> mapRecordFields = new HashMap<String, String[]>();

  private static String[] records;

  private static String[] listRecordHaveHeadNumSiteNum;
  private static final String HEAD_NUM = "HEAD_NUM";
  private static final String SITE_NUM = "SITE_NUM";
  private static final String SITE_GRP = "SITE_GRP";
  
  public static String[] getRecordList() {
    return records;
  }

  private static void fillRecordListToMap(TRecordList tRecordList) {
    List<String> listRecordName = new ArrayList<String>();
    if (tRecordList != null) {
      List<TRecord> listRecord = tRecordList.getRecord();
      if (listRecord != null && listRecord.size() > 0) {
        for (TRecord r : listRecord) {
          String[] fields = new String[0];
          if (r.getFields() != null) {
            fields = r.getFields().split(",");
          }
          mapRecordFields.put(r.getName(), fields);
          listRecordName.add(r.getName());
        }
      }
    }
    records = listRecordName.toArray(new String[0]);

    recordHeadNumSiteNum();
  }

  public static String[] getFieldsOfRecord(String recordName) {
    return mapRecordFields.get(recordName);
  }

  public static String[] getRecordsHaveHeadNumSiteNum() {
    return listRecordHaveHeadNumSiteNum;
  }

  private static String[] recordHeadNumSiteNum() {
    List<String> list = new ArrayList<String>();
    boolean haveHeadNum = false;
    boolean haveSiteNum = false;
    for (String recordName : records) {
      String[] fieldsOfRecord = getFieldsOfRecord(recordName);
      haveHeadNum = false;
      haveSiteNum = false;
      for (int i = 0; i < fieldsOfRecord.length; i++) {
        if (HEAD_NUM.equals(fieldsOfRecord[i])) {
          haveHeadNum = true;
        } else {
          if (SITE_NUM.equals(fieldsOfRecord[i]) || SITE_GRP.equals(fieldsOfRecord[i])) {
            haveSiteNum = true;
          }
        }
        if (haveHeadNum && haveSiteNum) {
          list.add(recordName);
          break;
        }
      }
    }
    listRecordHaveHeadNumSiteNum = list.toArray(new String[0]);
    return listRecordHaveHeadNumSiteNum;
  }
}
