/**
 * 
 */
package st.liotrox.template.element.control;

import java.util.ArrayList;
import java.util.List;

import st.liotrox.WRequest;
import st.liotrox.template.TemplateException;
import st.liotrox.util.FastStringBuffer;
import st.liotrox.util.ItemList;
import st.liotrox.util.ItemListFactory;
import st.liotrox.web.html.WriteHTML;

/**
 * @author nhatvn
 */
public class StringComparatorElement extends CustomElement {

  private static final String ATTRIBUTE_TYPE = "type";
  private static final String ATTRIBUTE_OPERATOR_LIST = "operatorList";
  private static final String ATTRIBUTE_SELECTED_VALUE = "selectedValue";
  private static final String ATTRIBUTE_UNIT = "unit";
  private static final String ATTRIBUTE_COMPARE_VALUE = "compareValue";
  private static final String STRING_TYPE = "string";
  private static final String NUMBER_TYPE = "number";

  public void validate() throws TemplateException {
    super.validate();

    String type = getAttribute(ATTRIBUTE_TYPE);
    if (type == null) {
      raiseException("You must specify 'type' attribute, its values is 'string' or 'number'. ");
    }
  }

  @Override
  public void writeContent(WRequest request, FastStringBuffer fs) {
    // Write label
    String label = getLabel(request);
    int labelLength = getLabelLength(request);
    //Start table
    writeTableStartWithLabelLength(fs, labelLength);
    writeLabel(fs, label);
    WriteHTML.Table.cellEnd(fs);
    
    // get type of control : string or number.
    String type = resolveAttributeAsString(request, ATTRIBUTE_TYPE);
    String name = getName(request);
    // get list of operator.
    Object operators = resolveAttribute(request, ATTRIBUTE_OPERATOR_LIST);
    if (operators == null) {
      // If user don't specify operators, we will get default operator.
      // For a string, support: '=' and 'Like'. For a number, support:
      // '=','>','<','>=','<=','~'
      if (STRING_TYPE.equals(type)) {
        operators = getDefaultOperatorString();
      } else {
        if (NUMBER_TYPE.equals(type)) {
          operators = getDefaultOperatorNumber();
        }
      }
    }
    // get selected value
    String selectedValue = resolveAttributeAsString(request, ATTRIBUTE_SELECTED_VALUE);

    ItemList items = ItemListFactory.create(operators, operators);
    int count = items.getItemCount();
    
    // create select box
    WriteHTML.Table.cellStart(fs);
    WriteHTML.Select.selectStartWithAttrs(fs);
    WriteHTML.Select.name(fs, name + "Op");
    WriteHTML.Select.style(fs, "width:50px");
    WriteHTML.Select.closeTag(fs);
    boolean selected = false;
    for (int i = 0; i < count; i++) {
      String text = items.getItemText(i);
      String value = items.getItemValue(i);
      selected = false;
      if (value != null && value.equals(selectedValue)) {
        selected = true;
      }
      WriteHTML.Select.option(fs, text, value, selected, true);
    }
    WriteHTML.Select.selectEnd(fs);
    WriteHTML.Table.cellEnd(fs);
    
    writeNewLine(fs);
    
    // write text box
    String classCss = getClassCss(request);
    WriteHTML.Table.cellStart(fs);
    WriteHTML.Input.inputStartWithAttrs(fs);
    WriteHTML.Input.typeText(fs);
    WriteHTML.Input.name(fs, name + "Value");
    String value = resolveAttributeAsString(request, ATTRIBUTE_COMPARE_VALUE);
    WriteHTML.Input.value(fs, value);
    // If this element is number, add keypress event to only number.
    if (NUMBER_TYPE.equals(type)) {
      writeKeyPressForNumberOnly(fs);
    }
    WriteHTML.Input.attribute(fs, "class", classCss);
    // If netscape browser, we decrease size of text box
    if (request.is_NS_Browser()) {
      WriteHTML.Input.attribute(fs, "size", 10);
    }
    WriteHTML.Input.closeTag(fs);
    WriteHTML.Input.inputEnd(fs);
    // write the unit
    String unit = resolveAttributeAsString(request, ATTRIBUTE_UNIT);
    if (unit != null) {
      writeWhiteSpace(fs);
      fs.append(unit);
    }
    WriteHTML.Table.cellEnd(fs);
    
    //Close table
    writeTableClose(fs);
  }

  /**
   * Get default operator of a string.
   * 
   * @return
   */
  private List<String> getDefaultOperatorString() {
    List<String> list = new ArrayList<String>();
    list.add("=");
    list.add("Like");
    return list;
  }

  /**
   * Get default operator of a number.
   * 
   * @return
   */
  private List<String> getDefaultOperatorNumber() {
    List<String> list = new ArrayList<String>();
    list.add("=");
    list.add(">");
    list.add("<");
    list.add(">=");
    list.add("<=");
    list.add("~");
    return list;
  }

  /**
   * Write javascript function of keyPress event to number only text box.
   * 
   * @param fs
   */
  private void writeKeyPressForNumberOnly(FastStringBuffer fs) {
    String numberOnly = "return numberOnly(event);";
    WriteHTML.Input.attribute(fs, ATTRIBUTE_EVENT_ON_KEY_PRESS, numberOnly);
  }
}
