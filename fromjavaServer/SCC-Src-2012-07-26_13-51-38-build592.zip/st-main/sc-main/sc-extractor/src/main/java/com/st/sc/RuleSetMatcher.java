/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 14, 2011 5:48:05 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.st.sc.data.MirData;
import com.st.sc.entity.MirCriteria;
import com.st.sc.entity.RuleSetVersion;

/**
 * The Class RuleSetMatcher.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class RuleSetMatcher {

  /**
   * The Class RuleSetVersionOrderComparator.
   */
  public static class RuleSetVersionOrderComparator implements Comparator<RuleSetVersion> {

    /** The check MIR criteria count. */
    private final boolean checkMirCriteriaCount;

    /**
     * Instantiates a new rule set version order comparator.
     */
    public RuleSetVersionOrderComparator() {
      this(true);
    }

    /**
     * Instantiates a new rule set version order comparator.
     * 
     * @param checkMirCriteriaCount
     *          the check MIR criteria count
     */
    public RuleSetVersionOrderComparator(final boolean checkMirCriteriaCount) {
      super();
      this.checkMirCriteriaCount = checkMirCriteriaCount;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(final RuleSetVersion v1, final RuleSetVersion v2) {
      if (v1 == null && v2 != null) {
        return -1;
      }
      if (v1 != null && v2 == null) {
        return 1;
      }
      if (v1 == null && v2 == null) {
        return 0;
      }

      if (checkMirCriteriaCount) {
        if (v1.getCountMirCriteria() < v2.getCountMirCriteria()) {
          return -1;
        } else if (v1.getCountMirCriteria() > v2.getCountMirCriteria()) {
          return 1;
        }
      }

      final Timestamp time1 = v1.getStatusUpdatedTime();
      final Timestamp time2 = v2.getStatusUpdatedTime();
      if (time1 == null && time2 != null) {
        return -1;
      }
      if (time1 != null && time2 == null) {
        return 1;
      }
      if (time1 == null && time2 == null) {
        return 0;
      }

      if (time1.getTime() < time2.getTime()) {
        return -1;
      } else if (time1.getTime() > time2.getTime()) {
        return 1;
      }

      return 0;
    }

  }

  /**
   * Compare MIR Criteria and MIR data.
   * 
   * @param criteria
   *          the criteria
   * @param data
   *          the data
   * @return true, if compare
   */
  private static boolean compare(final MirCriteria criteria, final MirData data) {
    if (!compareCriteria(criteria.getCmodCod(), data.getCmodCod())) {
      return false;
    }
    if (!compareCriteria(criteria.getDsgnRev(), data.getDsgnRev())) {
      return false;
    }
    if (!compareCriteria(criteria.getExecTyp(), data.getExecTyp())) {
      return false;
    }
    if (!compareCriteria(criteria.getExecVer(), data.getExecVer())) {
      return false;
    }
    if (!compareCriteria(criteria.getFlowId(), data.getFlowId())) {
      return false;
    }
    if (!compareCriteria(criteria.getJobNam(), data.getJobNam())) {
      return false;
    }
    if (!compareCriteria(criteria.getJobRev(), data.getJobRev())) {
      return false;
    }
    if (!compareCriteria(criteria.getModeCod(), data.getModeCod())) {
      return false;
    }
    if (!compareCriteria(criteria.getOperFrq(), data.getOperFrq())) {
      return false;
    }
    if (!compareCriteria(criteria.getPartTyp(), data.getPartTyp())) {
      return false;
    }
    if (!compareCriteria(criteria.getProcId(), data.getProcId())) {
      return false;
    }
    if (!compareCriteria(criteria.getSpecNam(), data.getSpecNam())) {
      return false;
    }
    if (!compareCriteria(criteria.getSpecVer(), data.getSpecVer())) {
      return false;
    }
    if (!compareCriteria(criteria.getSuprNam(), data.getSuprNam())) {
      return false;
    }
    if (!compareCriteria(criteria.getTstrTyp(), data.getTstrTyp())) {
      return false;
    }
    return true;
  }

  /**
   * Compare criteria.
   * 
   * @param f1
   *          the f1
   * @param f2
   *          the f2
   * @return true, if compare criteria
   */
  private static boolean compareCriteria(final String f1, final String f2) {
    if (f1 != null && f1.length() > 0) {
      if (f2 == null || f2.length() == 0) {
        return false;
      } else {
        return f1.equals(f2);
      }
    }
    return true;
  }

  /**
   * Filter sort default rule sets.
   * 
   * @param list
   *          the list
   * @param filteredList
   *          the filtered list
   * @param defaultList
   *          the default list
   */
  public static void filterSortDefaultRuleSets(final List<RuleSetVersion> list,
      final List<RuleSetVersion> filteredList, final List<RuleSetVersion> defaultList) {
    for (final RuleSetVersion e : list) {
      if (e != null) {
        if (e.getCountMirCriteria() == 0) {
          defaultList.add(e);
        } else {
          filteredList.add(e);
        }
      }
    }
    sortForMatch(filteredList, new RuleSetVersionOrderComparator());
    sortForMatch(defaultList, new RuleSetVersionOrderComparator(false));
  }

  /**
   * Find match rule set.
   * 
   * @param list
   *          the list
   * @param mirData
   *          the MIR data
   * @param defaultRuleSet
   *          the default rule set
   * @return the rule set version
   */
  public static RuleSetVersion findMatchRuleSet(final List<RuleSetVersion> list,
      final MirData mirData, final RuleSetVersion defaultRuleSet) {
    RuleSetVersion retVal = null;
    for (final RuleSetVersion version : list) {
      if (compare(version.getMirCriteria(), mirData)) {
        retVal = version;
        break;
      }
    }
    if (retVal == null) {
      retVal = defaultRuleSet;
    }
    return retVal;
  }

  /**
   * Sort for match.
   * 
   * @param list
   *          the list
   * @param comparator
   *          the comparator
   */
  public static void sortForMatch(final List<RuleSetVersion> list,
      final Comparator<RuleSetVersion> comparator) {
    Collections.sort(list, Collections.reverseOrder(comparator));
  }

  /**
   * Instantiates a new rule set matcher.
   */
  private RuleSetMatcher() {

  }
}
