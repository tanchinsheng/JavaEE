/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 4, 2011 10:58:46 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.sc;

import java.io.File;

import org.apache.log4j.xml.DOMConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.ConfigLoader;
import com.st.common.mail.EmailNotification;
import com.st.scc.common.utils.ConvertUtils;
import com.st.stdfparser.StdfManager;
import com.st.stdfparser.StdfManagerContext;

/**
 * The class SMMain for run STDF file reader.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 * @author nghiatn
 */
public final class SCMain {

  /** The Constant DEFAULT_MEMORY_PER_FILE. */
  private static final long DEFAULT_MEMORY_PER_FILE = 256 * 1024 * 1024;

  /** The Constant memoryPerFile. */
  private static long memoryPerFile;

  /** The Constant serverId. */
  private static String serverId;

  static {
    String logPath = System.getProperty("log4j.xml");
    if (logPath == null) {
      final String dir = System.getProperty("user.dir");
      final String separator = File.separator;
      final StringBuilder sb = new StringBuilder();
      sb.append(dir).append(separator).append("conf").append(separator).append("log4j.xml");
      logPath = sb.toString();
    }
    final File file = new File(logPath);
    if (file.exists()) {
      DOMConfigurator.configure(logPath);
    } else {
      System.out.println("File configure " + file.getAbsolutePath() + " is not found");
    }

    serverId = System.getProperty("serverId");
    final String memoryPerFileStr = System.getProperty("memoryPerFile");
    if (memoryPerFileStr != null) {
      memoryPerFile = ConvertUtils.getLong(memoryPerFileStr);
      if (memoryPerFile <= 0) {
        memoryPerFile = DEFAULT_MEMORY_PER_FILE;
      }
    } else {
      memoryPerFile = DEFAULT_MEMORY_PER_FILE;
    }
  }

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SCMain.class);

  /**
   * function main.
   * 
   * @param args
   *          the arguments
   */
  public static void main(final String[] args) {
    boolean printVersion = false;
    if (args != null && args.length > 0) {
      if ("-v".equalsIgnoreCase(args[0])) {
        printVersion = true;
      }
    }

    final StdfManager sm = new StdfManager(memoryPerFile);
    sm.setAppName("SC Extractor");
    StdfManagerContext.getInstance().initialize();
    if (serverId != null) {
      StdfManagerContext.getInstance().setServerId(serverId);
    }
    try {
      if (!printVersion) {
        LOG.info("Starting " + sm.getAppName() + "............");
        sm.initialize();
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {

          /**
           * {@inheritDoc}
           * 
           * @see java.lang.Runnable#run()
           */
          public void run() {
            LOG.info("Stopping " + sm.getAppName() + "...");
            sm.shutdown();
            LOG.info("Stopped " + sm.getAppName() + " {} successfully", ConfigLoader
                .getInstance().getVersion());
          }
        }));
        LOG.info("Started " + sm.getAppName() + " {} successfully", ConfigLoader.getInstance()
            .getVersion());
      } else {
        String msg = sm.getAppName() + " " + ConfigLoader.getInstance().getVersion();
        msg += ", ServerId=" + StdfManagerContext.getInstance().getServerId();
        LOG.info(msg);
        System.out.println(msg);
        System.exit(0);
      }

      sm.start();
    } catch (final Throwable e) {
      final String msg = "Failed to start " + sm.getAppName() + ": " + e.getMessage();
      LOG.error(msg, e);
      EmailNotification.getInstance().sendMail(msg);
      System.exit(1);
    }
  }

  /**
   * The Constructor.
   */
  private SCMain() {

  }
}
