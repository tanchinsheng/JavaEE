/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 3:41:31 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.data;

import com.st.scc.common.utils.StringUtil;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;

/**
 * The Class MirData.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class MirData {

  /** The cmod cod. */
  private String cmodCod;

  /** The dsgn rev. */
  private String dsgnRev;

  /** The exec typ. */
  private String execTyp;

  /** The exec ver. */
  private String execVer;

  /** The flow id. */
  private String flowId;

  /** The job nam. */
  private String jobNam;

  /** The job rev. */
  private String jobRev;

  /** The mode cod. */
  private String modeCod;

  /** The oper frq. */
  private String operFrq;

  /** The part typ. */
  private String partTyp;

  /** The proc id. */
  private String procId;

  /** The spec nam. */
  private String specNam;

  /** The spec ver. */
  private String specVer;

  /** The supr nam. */
  private String suprNam;

  /** The tstr typ. */
  private String tstrTyp;

  /** The count fields. */
  private int countFields;

  /**
   * Instantiates a new mir data.
   * 
   * @param record
   *          the record
   */
  public MirData(final Record record) {
    countFields = 0;
    populateFields(record);
  }

  /**
   * Gets the cmod cod.
   * 
   * @return the cmod cod
   */
  public String getCmodCod() {
    return cmodCod;
  }

  /**
   * Gets the count fields.
   * 
   * @return the count fields
   */
  public int getCountFields() {
    return countFields;
  }

  /**
   * Gets the dsgn rev.
   * 
   * @return the dsgn rev
   */
  public String getDsgnRev() {
    return dsgnRev;
  }

  /**
   * Gets the exec typ.
   * 
   * @return the exec typ
   */
  public String getExecTyp() {
    return execTyp;
  }

  /**
   * Gets the exec ver.
   * 
   * @return the exec ver
   */
  public String getExecVer() {
    return execVer;
  }

  /**
   * Gets the flow id.
   * 
   * @return the flow id
   */
  public String getFlowId() {
    return flowId;
  }

  /**
   * Gets the job nam.
   * 
   * @return the job nam
   */
  public String getJobNam() {
    return jobNam;
  }

  /**
   * Gets the job rev.
   * 
   * @return the job rev
   */
  public String getJobRev() {
    return jobRev;
  }

  /**
   * Gets the mode cod.
   * 
   * @return the mode cod
   */
  public String getModeCod() {
    return modeCod;
  }

  /**
   * Gets the oper frq.
   * 
   * @return the oper frq
   */
  public String getOperFrq() {
    return operFrq;
  }

  /**
   * Gets the part typ.
   * 
   * @return the part typ
   */
  public String getPartTyp() {
    return partTyp;
  }

  /**
   * Gets the proc id.
   * 
   * @return the proc id
   */
  public String getProcId() {
    return procId;
  }

  /**
   * Gets the spec nam.
   * 
   * @return the spec nam
   */
  public String getSpecNam() {
    return specNam;
  }

  /**
   * Gets the spec ver.
   * 
   * @return the spec ver
   */
  public String getSpecVer() {
    return specVer;
  }

  /**
   * Gets the supr nam.
   * 
   * @return the supr nam
   */
  public String getSuprNam() {
    return suprNam;
  }

  /**
   * Gets the tstr typ.
   * 
   * @return the tstr typ
   */
  public String getTstrTyp() {
    return tstrTyp;
  }

  /**
   * Populate fields.
   * 
   * @param record
   *          the record
   */
  private void populateFields(final Record record) {
    partTyp = (String) record.getFieldValue(FieldEnum.PART_TYP);
    dsgnRev = (String) record.getFieldValue(FieldEnum.DSGN_REV);
    modeCod = (String) record.getFieldValue(FieldEnum.MODE_COD);
    cmodCod = (String) record.getFieldValue(FieldEnum.CMOD_COD);
    operFrq = (String) record.getFieldValue(FieldEnum.OPER_FRQ);
    flowId = (String) record.getFieldValue(FieldEnum.FLOW_ID);
    tstrTyp = (String) record.getFieldValue(FieldEnum.TSTR_TYP);
    execTyp = (String) record.getFieldValue(FieldEnum.EXEC_TYP);
    execVer = (String) record.getFieldValue(FieldEnum.EXEC_VER);
    jobNam = (String) record.getFieldValue(FieldEnum.JOB_NAM);
    jobRev = (String) record.getFieldValue(FieldEnum.JOB_REV);
    specNam = (String) record.getFieldValue(FieldEnum.SPEC_NAM);
    specVer = (String) record.getFieldValue(FieldEnum.SPEC_VER);
    procId = (String) record.getFieldValue(FieldEnum.PROC_ID);
    suprNam = (String) record.getFieldValue(FieldEnum.SUPR_NAM);

    countFields = StringUtil.isNullOrEmpty(partTyp) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(dsgnRev) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(modeCod) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(cmodCod) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(operFrq) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(flowId) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(tstrTyp) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(execTyp) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(execVer) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(jobNam) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(jobRev) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(specNam) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(specVer) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(procId) ? countFields : countFields + 1;
    countFields = StringUtil.isNullOrEmpty(suprNam) ? countFields : countFields + 1;
  }
}
