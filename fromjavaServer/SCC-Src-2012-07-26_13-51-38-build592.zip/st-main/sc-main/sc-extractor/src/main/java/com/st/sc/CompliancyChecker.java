/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 3:18:21 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc;

import static com.st.scc.common.utils.StringUtil.toTrimmedString;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.apcd.APCDMessage;
import com.st.common.apcd.APCDSender;
import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.config.ConfigLoader;
import com.st.common.config.FolderInfo;
import com.st.common.exception.SccException;
import com.st.common.exception.ServiceException;
import com.st.common.fileaccess.FileAccessFactory;
import com.st.common.fileaccess.SccFileAccess;
import com.st.common.mail.EmailNotification;
import com.st.common.mail.EmailNotification.ErrorMailEnum;
import com.st.persistence.entity.ParseFileStatus;
import com.st.sc.data.MirData;
import com.st.sc.entity.CompliancyResult;
import com.st.sc.entity.RuleSetVersion;
import com.st.sc.rulemanager.RuleService;
import com.st.sc.rulemanager.RuleSetService;
import com.st.sc.rulemanager.data.ContextData;
import com.st.sc.rulemanager.data.FailedValueData;
import com.st.sc.rulemanager.data.RuleEngine;
import com.st.sc.rulemanager.rule.validation.RuleValidation;
import com.st.sc.rulemanager.rule.validation.RuleValidationFactory;
import com.st.sc.rulemanager.serialization.RuleValidationDetail;
import com.st.sc.rulemanager.util.DetailResultUtil;
import com.st.sc.service.SCServiceFactory;
import com.st.scc.common.utils.ConvertUtils;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.common.utils.StringUtil;
import com.st.stdfparser.plugin.IPlugin;
import com.st.stdfparser.plugin.PluginStatus;
import com.st.stdfparser.stdf.FieldEnum;
import com.st.stdfparser.stdf.Record;
import com.st.stdfparser.stdf.RecordEnum;
import com.st.stdfparser.stdf.StdfInputStream;
import com.st.stdfparser.stdf.StdfInputStreamFactory;
import com.st.stdfparser.stdf.util.GDRConverter;

/**
 * The Class CompliancyChecker.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class CompliancyChecker implements IPlugin {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(CompliancyChecker.class);

  /** The Constant TEMP_FAIL_ROOT_PATH. */
  private static final String TEMP_FAIL_ROOT_PATH = System.getProperty("user.dir")
      + File.separator + "tmp" + File.separator + "fail";

  /** The name. */
  private String name;

  /** The record types. */
  private Set<RecordEnum> recordTypes;

  /** The rule service. */
  private RuleService ruleService;

  /** The rule set service. */
  private RuleSetService ruleSetService;

  /** The rule sets. */
  private List<RuleSetVersion> ruleSets;

  /** The data map. */
  private Map<Long, RuleEngine> dataMap;

  /** The default rule set. */
  private RuleSetVersion defaultRuleSet;

  /**
   * Instantiates a new compliancy checker.
   */
  public CompliancyChecker() {
    dataMap = new ConcurrentHashMap<Long, RuleEngine>();
  }

  /**
   * Check validation.
   * 
   * @param rules
   *          the rules
   * @param contextData
   * @param record
   *          the record
   */
  private void checkValidation(final List<RuleValidation> rules,
      final ContextData contextData, final Record record) {
    for (final RuleValidation ruleValidation : rules) {
      if (ruleValidation.canValidate(record)) {
        ruleValidation.validate(record);
      }
      contextData.getFailedData().flushFailedValues(ruleValidation.getRecordType(), false);
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#destroy()
   */
  public void destroy() {
    ruleSets.clear();
    ruleSets = null;
    dataMap.clear();
    dataMap = null;
  }

  /**
   * Find MIR record.
   * 
   * @param stdfFile
   *          the STDF file
   * @return the record
   */
  private Record findMirRecord(final File stdfFile) {
    Record miRecord = null;
    StdfInputStream stream = null;
    try {
      final Set<RecordEnum> supportedRecords = new HashSet<RecordEnum>();
      supportedRecords.add(RecordEnum.FAR);
      supportedRecords.add(RecordEnum.MIR);
      stream = StdfInputStreamFactory.create(stdfFile, supportedRecords);
      Record record = null;
      while ((record = stream.readNext()) != null) {
        if (record.getType() == RecordEnum.MIR) {
          miRecord = record;
          break;
        }
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (stream != null) {
        try {
          stream.close();
        } catch (final IOException e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }
    return miRecord;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#getName()
   */
  public String getName() {
    return name;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#initialize()
   */
  public void initialize() throws SccException {
    ruleService = SCServiceFactory.getRuleService();
    ruleSetService = SCServiceFactory.getRuleSetService();
    ruleSets = new ArrayList<RuleSetVersion>();
  }

  /**
   * Initializes the rule validations.
   * 
   * @param ruleEngine
   *          the rule engine
   * @param ruleSet
   *          the matched rule set
   * @throws ServiceException
   *           the service exception
   */
  private void initRuleValidations(final RuleEngine ruleEngine, final RuleSetVersion ruleSet)
      throws ServiceException {
    List<RuleValidation> ruleValidations = null;
    final ContextData contextData = ruleEngine.getContextData();
    if (ruleSet != null) {
      final RuleSetVersion matchRuleSet = ruleService.loadRuleVersions(ruleSet);
      final Long resultId = SCServiceFactory.getCompliancyResultService().getNextId();
      contextData.setCompliancyResultFileId(resultId);

      String detailPath = "";
      final FolderInfo folderInfo =
          ConfigLoader.getInstance().getFolder(ConfigLoader.FOLDER_NAME_FAIL_VALUES);
      if (folderInfo != null && folderInfo.getFolderType() != null) {
        if (folderInfo.getFolderType() != FileTypeEnum.NFS) {
          contextData.getFailedData().setUploadFolder(folderInfo);
          contextData.setRootPath(TEMP_FAIL_ROOT_PATH);
          detailPath = DetailResultUtil.getFilePath(null, resultId.longValue());
        } else {
          contextData.setRootPath(folderInfo.getFolder());
          detailPath =
              DetailResultUtil.getFilePath(new Timestamp(contextData.getCheckingTime()),
                  resultId.longValue());
        }
      } else {
        contextData.setRootPath(TEMP_FAIL_ROOT_PATH);
        detailPath = DetailResultUtil.getFilePath(null, resultId.longValue());
      }
      final Number limitFailedNum =
          (Number) ConfigLoader.getInstance().getSettingMap()
              .get(ConfigLoader.LIMIT_FAIL_VALUES);
      if (limitFailedNum != null) {
        contextData.getFailedData().setLimitFailedNum(
            Integer.valueOf(limitFailedNum.intValue()));
      }
      ruleEngine.setRuleSetName(matchRuleSet.getRuleSet().getName());
      ruleEngine.setRuleSetVersion(matchRuleSet.getVersion());
      ruleEngine.setAlarmThreshold(ruleSet.getAlarmThreshold());

      ruleValidations =
          RuleValidationFactory.createRuleValidations(matchRuleSet.getRuleVersions(),
              contextData, detailPath);
    }
    if (ruleValidations != null) {
      ruleEngine.initialize(ruleValidations);
    } else {
      LOG.error("[FileId={}] Could not find rule set", contextData.getFileId());
    }
    if (ruleEngine.getAlarmThreshold() == null) {
      LOG.warn("[FileId={}] No alarm threshold is set, using default value 0.0");
      ruleEngine.setAlarmThreshold(Double.valueOf(0.0));
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#isSupported(com.st.stdfparser.stdf.RecordEnum)
   */
  public boolean isSupported(final RecordEnum recordType) {
    if (recordTypes != null) {
      return recordTypes.contains(recordType);
    } else {
      return true;
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#onError(com.st.persistence.entity.ParseFileStatus,
   *      java.lang.Throwable)
   */
  public void onError(final ParseFileStatus file, final Throwable exception) {
    final RuleEngine ruleEngine = dataMap.get(file.getFileId());
    if (ruleEngine != null) {
      ruleEngine.setFileError(true);
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#processDownload(com.st.persistence.entity.ParseFileStatus)
   */
  public PluginStatus processDownload(final ParseFileStatus file) {
    return PluginStatus.OK;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#processEOF(com.st.persistence.entity.ParseFileStatus)
   */
  public PluginStatus processEOF(final ParseFileStatus file) {
    PluginStatus pluginStatus = PluginStatus.OK;

    RuleEngine ruleEngine = dataMap.remove(file.getFileId());
    if (ruleEngine != null) {
      try {
        final ContextData contextData = ruleEngine.getContextData();
        if (LOG.isDebugEnabled()) {
          LOG.debug("[FileId={}] Count records: {}", file.getFileId(),
              contextData.getCountMap());
        }
        if (ruleEngine.isFileError()) {
          return PluginStatus.ERROR;
        }
        if (ruleEngine.getRuleSetName() == null || ruleEngine.getRuleSetVersion() == null) {
          file.setDescription("No best matched rule set");
          sendEventAlarmMessage(ruleEngine, null);
          return PluginStatus.ERROR;
        }

        final List<RuleValidationDetail> detailResultList =
            new ArrayList<RuleValidationDetail>();
        final CompliancyResult result =
            DetailResultUtil.calculateResult(ruleEngine, detailResultList);
        RuleValidationDetail[] detailResultListArr = new RuleValidationDetail[0];
        if (detailResultList.size() > 0) {
          detailResultListArr =
              detailResultList.toArray(new RuleValidationDetail[detailResultList.size()]);
        }
        result.setDetailResult(DetailResultUtil.toBytes(detailResultListArr));
        result.setFileId(contextData.getCompliancyResultFileId());

        SCServiceFactory.getCompliancyResultService().merge(result);
        LOG.info("[FileId={}] Stored compliancy checking result, score: {}", file.getFileId(),
            result.getCompliancyScore());

        final FailedValueData failedData = contextData.getFailedData();
        if (failedData.getUploadFolder() != null) {
          uploadFailedValue(
              failedData,
              DetailResultUtil.getFilePath(new Timestamp(contextData.getCheckingTime()),
                  contextData.getCompliancyResultFileId()).replaceAll("\\\\", "/"));
        }
        sendEventAlarmMessage(ruleEngine, result.getCompliancyScore());

      } catch (final Exception e) {
        LOG.error(e.getMessage(), e);
        EmailNotification.getInstance().sendOTM(ErrorMailEnum.DB_ERROR);
        pluginStatus = PluginStatus.SKIP;
      } catch (final Throwable e) {
        LOG.error(e.getMessage(), e);
        pluginStatus = PluginStatus.SKIP;
      } finally {
        ruleEngine.clear();
        ruleEngine = null;
      }
    }
    return pluginStatus;
  }

  /**
   * Process MIR record.
   * 
   * @param ruleEngine
   *          the rule engine
   * @param mirData
   *          the MIR data
   * @throws ServiceException
   *           the service exception
   */
  private void processMirRecord(final RuleEngine ruleEngine, final MirData mirData)
      throws ServiceException {
    LOG.info("[FileId={}] Found MIR record", ruleEngine.getContextData().getFileId());

    RuleSetVersion matchRuleSet = null;
    if (mirData.getCountFields() > 0) {
      matchRuleSet = RuleSetMatcher.findMatchRuleSet(ruleSets, mirData, defaultRuleSet);
    } else {
      matchRuleSet = defaultRuleSet;
    }
    initRuleValidations(ruleEngine, matchRuleSet);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#processRecords(com.st.persistence.entity.ParseFileStatus,
   *      java.util.List)
   */
  public PluginStatus processRecords(final ParseFileStatus file, final List<Record> records) {
    final Long fileId = file.getFileId();
    final RuleEngine ruleEngine = dataMap.get(fileId);
    if (ruleEngine.isFileError()) {
      return PluginStatus.ERROR;
    }

    try {
      final ContextData contextData = ruleEngine.getContextData();
      for (Record record : records) {
        final RecordEnum recordType = record.getType();
        Record specialGDR = null;
        if (recordType == RecordEnum.GDR) {
          specialGDR = GDRConverter.convert(record);
          // After converting, it is not a special GDR.
          if (specialGDR.getType() == RecordEnum.GDR) {
            specialGDR = null;
          }
        }
        // Because when validating a Rule on a general GDR record,
        // we must include special GDR records.
        // Thus, after converting to a special GDR, we also validate Rules
        // on general GDR.
        List<Record> tmpList = new ArrayList<Record>();
        tmpList.add(record);
        if (specialGDR != null) {
          tmpList.add(specialGDR);
        }
        for (Record record2 : tmpList) {
          contextData.updateData(record2);

          if (ruleEngine.isFoundMir()) {
            checkValidation(ruleEngine.getCrossRules(), contextData, record2);
          } else {
            if (recordType == RecordEnum.MIR) {
              ruleEngine.setFoundMir(true);
              ruleEngine.getRecords().add(record2);
              processMirRecord(ruleEngine, new MirData(record2));

              final List<RuleValidation> crossRules = ruleEngine.getCrossRules();
              final List<Record> tmpRecordList = ruleEngine.getRecords();
              if (crossRules.size() > 0) {
                for (final Record tmpRecord : tmpRecordList) {
                  checkValidation(crossRules, contextData, tmpRecord);
                }
              }
              tmpRecordList.clear();
            } else {
              ruleEngine.getRecords().add(record2);
            }
          }
        }
      }
    } catch (final Throwable e) {
      LOG.error(e.getMessage(), e);
    }
    return PluginStatus.OK;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#processStartFile(com.st.persistence.entity.ParseFileStatus,
   *      java.util.Map)
   */
  public PluginStatus processStartFile(final ParseFileStatus file,
      final Map<String, Object> map) {
    PluginStatus pluginStatus = PluginStatus.OK;
    try {
      final RuleEngine ruleEngine = new RuleEngine();
      ruleEngine.setFileName(FileUtils.getFileName(file.getPathFileName()));
      final ContextData contextData = ruleEngine.getContextData();
      contextData.setFileId(file.getFileId());
      contextData.setCheckingTime(System.currentTimeMillis());
      final Object alarmThreshold =
          ConfigLoader.getInstance().getSettingMap().get(ConfigLoader.DEFAULT_ALARM_THRESHOLD);
      if (alarmThreshold instanceof Number) {
        ruleEngine.setAlarmThreshold(Double.valueOf(((Number) alarmThreshold).doubleValue()));
      }

      if (ConfigLoader.getInstance().isFindMir()) {
        Record miRecord = null;
        if (map != null && map.size() > 0) {
          final File stdfFile = (File) map.get(ConfigLoader.FIND_MIR);
          if (stdfFile != null) {
            miRecord = findMirRecord(stdfFile);
          }
        }
        if (miRecord != null) {
          processMirRecord(ruleEngine, new MirData(miRecord));
        } else {
          initRuleValidations(ruleEngine, defaultRuleSet);
        }
        ruleEngine.setFoundMir(true);
      }

      dataMap.put(file.getFileId(), ruleEngine);
    } catch (final Throwable e) {
      pluginStatus = PluginStatus.SKIP;
      LOG.error(e.getMessage(), e);
    }
    return pluginStatus;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#receiveNewFiles()
   */
  public PluginStatus receiveNewFiles() {
    PluginStatus pluginStatus = PluginStatus.OK;
    try {
      final List<RuleSetVersion> activeList = ruleSetService.getActiveRuleSetVersions();
      ruleSets = new ArrayList<RuleSetVersion>();
      final List<RuleSetVersion> defaultList = new ArrayList<RuleSetVersion>();
      RuleSetMatcher.filterSortDefaultRuleSets(activeList, ruleSets, defaultList);
      if (defaultList.size() > 0) {
        defaultRuleSet = defaultList.get(0);
      } else {
        defaultRuleSet = null;
        LOG.warn("Could not find default rule set");
      }
    } catch (final Throwable e) {
      pluginStatus = PluginStatus.ERROR;
      LOG.error(e.getMessage(), e);
    }
    return pluginStatus;
  }

  /**
   * Send event alarm message.
   * 
   * @param ruleEngine
   *          the rule engine
   * @param compliancyScore
   *          the compliancy score
   */
  private void sendEventAlarmMessage(final RuleEngine ruleEngine, final Double compliancyScore) {
    final Map<String, Object> settingMap = ConfigLoader.getInstance().getSettingMap();
    final String host = (String) settingMap.get(ConfigLoader.APCD_HOST);
    if (!StringUtil.isNullOrEmpty(host)) {
      double score = 0.0;
      if (compliancyScore != null) {
        score = compliancyScore.doubleValue();
      }
      double threshold = 0.0;
      if (ruleEngine.getAlarmThreshold() != null) {
        threshold = ruleEngine.getAlarmThreshold().doubleValue();
      }

      final APCDMessage msg = ruleEngine.getContextData().getApcdMessage();
      msg.setMid("SCWeb");
      msg.setMty("E");
      msg.setEcd(0);
      final ContextData contextData = ruleEngine.getContextData();
      final Record mir = contextData.getMirRecord();
      msg.setEtx(ruleEngine.getFileName());
      if (mir != null) {
        msg.setLot((String) mir.getFieldValue(FieldEnum.LOT_ID));
        msg.setOperations((String) mir.getFieldValue(FieldEnum.OPER_FRQ));
        msg.setFlowId((String) mir.getFieldValue(FieldEnum.FLOW_ID));
        msg.setWaferChuckTemp(ConvertUtils.getInt((String) mir
            .getFieldValue(FieldEnum.TST_TEMP)));
        msg.setFacility((String) mir.getFieldValue(FieldEnum.FACIL_ID));
        msg.setProduct((String) mir.getFieldValue(FieldEnum.PART_TYP));
        msg.setTesterName((String) mir.getFieldValue(FieldEnum.NODE_NAM));
        msg.setTestProgName((String) mir.getFieldValue(FieldEnum.JOB_NAM));
        msg.setTestProgVer((String) mir.getFieldValue(FieldEnum.JOB_REV));
        msg.setLots(msg.getLot());
      }
      msg.setCurrentWaferId(toTrimmedString(msg.getWaferIdList(), ","));
      msg.setProberName("");
      msg.setJobName(ruleEngine.getRuleSetName());
      msg.setPpExecName("");
      msg.setJigId("");
      msg.setCurrProbeCardName(toTrimmedString(msg.getCardIdList(), ","));
      msg.setUglyDieCount(0);
      msg.setProbeCardContCnt(0);
      msg.setPort(0);
      msg.setUser(msg.getMid());
      msg.setRoute("");
      msg.setMapServer("");
      msg.setMapDir("");
      msg.setMapId("");
      msg.setNewMapId("");
      msg.setDateTime(new Timestamp(ruleEngine.getContextData().getCheckingTime()));
      msg.setSecsRecipeName(ruleEngine.getRuleSetName());

      String message = "";
      final NumberFormat numberFormat = new DecimalFormat("00.00");
      if (score < threshold || ruleEngine.getRuleSetName() == null) {
        msg.setCmd("ALARM_REPORT");
        if (ruleEngine.getRuleSetName() != null) {
          msg.setAlarmId(-202500);
          msg.setAlarmText("Score=" + numberFormat.format(score) + "%, LogID="
              + toTrimmedString(ruleEngine.getLogIdList(), ","));
        } else {
          msg.setAlarmId(-201500);
          msg.setAlarmText("No best matched rule set");
        }
        msg.setAlarmState(1);
        msg.setEventId("STDF_CHECKING_REQUEST");

        message = msg.buildAlarmMessage();
      } else {
        msg.setCmd("EVENT_REPORT");
        msg.setEventId("STDF_CHECKING_REQUEST");
        msg.setEventText("Score=" + numberFormat.format(score) + "%");

        message = msg.buildEventMessage();
      }

      final Map<String, String> map = new HashMap<String, String>();
      map.put(APCDSender.KEY_REMOTE_HOST, host);
      map.put(APCDSender.KEY_MAIL_BOX,
          String.valueOf(settingMap.get(ConfigLoader.APCD_MAILBOX)));
      map.put(APCDSender.KEY_MBX, String.valueOf(settingMap.get(ConfigLoader.APCD_MBX)));
      final Number port = (Number) settingMap.get(ConfigLoader.APCD_PORT);
      if (port != null) {
        map.put(APCDSender.KEY_PORT, String.valueOf(port.intValue()));
      }

      final APCDSender sender = new APCDSender();
      final boolean result = sender.sendMessage(message, map);
      if (result) {
        LOG.info("Send APCD message successfully");
      } else {
        LOG.error("Failed to send APCD message");
        EmailNotification.getInstance().sendOneMessageMail("Failed to send APCD message");
      }
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#setName(java.lang.String)
   */
  public void setName(final String name) {
    this.name = name;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.stdfparser.plugin.IPlugin#setSupportedRecordTypes(java.util.Set)
   */
  public void setSupportedRecordTypes(final Set<RecordEnum> recordTypes) {
    this.recordTypes = recordTypes;
  }

  /**
   * Upload failed value.
   * 
   * @param failedData
   *          the failed data
   * @param detailPath
   *          the detail path
   */
  private void uploadFailedValue(final FailedValueData failedData, final String detailPath) {
    final FolderInfo folder = failedData.getUploadFolder();
    final Set<String> failedFilePaths = failedData.getFailedFilePaths();
    final FileTypeEnum fileTypeArchive = folder.getFolderType();
    final String pathFail = folder.getFolder();
    final FileInfo destFile = new FileInfo();
    destFile.setFileType(fileTypeArchive);
    destFile.setPathRoot(pathFail);
    destFile.setHost(folder.getFileServer());
    destFile.setUserName(folder.getUserName());
    destFile.setPassWord(folder.getPassword());
    destFile.setPort(folder.getPort());
    LOG.info("Upload failed values to {}", fileTypeArchive);
    try {

      final long startTime = System.currentTimeMillis();
      final long retryInterval = ConfigLoader.getInstance().getRetryInterval();
      final long endTime = startTime + retryInterval;
      long currentTime = startTime;
      if (failedFilePaths != null && failedFilePaths.size() > 0) {
        while (failedFilePaths.size() > 0 && endTime > currentTime) {
          final SccFileAccess fileAccess = FileAccessFactory.create(destFile);
          for (final Iterator<String> iterator = failedFilePaths.iterator(); iterator
              .hasNext();) {
            final String filePath = iterator.next();
            final File file = new File(filePath);
            if (fileAccess != null && fileAccess.upload(filePath, detailPath + file.getName())) {
              iterator.remove();
            } else {
              LOG.warn("Failed to move file [{}] to fail folder {}", filePath, pathFail);
              final String message =
                  "Failed to move file(s) to fail folder " + pathFail + " on "
                      + fileTypeArchive
                      + " .Please check log file for more detail. Will try to upload until "
                      + new Date(endTime) + ". After this time files will be deleted.";
              EmailNotification.getInstance().sendOneMessageMail(message);
              currentTime = System.currentTimeMillis();
              try {
                Thread.sleep(30000);
              } catch (final InterruptedException e) {
                // ignore exception
              }
              break;
            }
          }
          if (fileAccess != null) {
            fileAccess.disconnect();
          }
        }
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    } finally {
      try {
        org.apache.commons.io.FileUtils.deleteDirectory(new File(failedData
            .getFailedValuePath()));
      } catch (final IOException e) {
        LOG.error(e.getMessage(), e);
      }
    }
  }

}
