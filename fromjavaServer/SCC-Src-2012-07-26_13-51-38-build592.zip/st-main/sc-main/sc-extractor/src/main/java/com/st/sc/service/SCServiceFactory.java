/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 14, 2011 9:58:50 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.sc.service;

import java.util.Map;

import javax.persistence.EntityManagerFactory;

import com.st.common.config.ConfigLoader;
import com.st.persistence.DatabaseConstants;
import com.st.persistence.util.EntityManagerUtils;
import com.st.sc.rulemanager.BaseService;
import com.st.sc.rulemanager.RuleService;
import com.st.sc.rulemanager.RuleSetService;
import com.st.sc.rulemanager.service.CompliancyResultService;
import com.st.scc.common.utils.PropertiesUtil;

/**
 * A factory for creating SCService objects.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class SCServiceFactory {

  /** The rule service. */
  private static RuleService ruleService;

  /** The rule set service. */
  private static RuleSetService ruleSetService;

  /** The compliancy result service. */
  private static CompliancyResultService compliancyResultService;

  static {
    final Map<String, String> properties =
        PropertiesUtil.loadFromXML(ConfigLoader.getInstance().getFile(
            DatabaseConstants.SC_DB_XML));
    final EntityManagerFactory factory =
        EntityManagerUtils.getEntityManagerFactory(DatabaseConstants.SC_DB_UNIT_NAME,
            properties);
    final BaseService scBaseService = new BaseService(factory);
    ruleService = new RuleService(scBaseService);
    ruleSetService = new RuleSetService(scBaseService);
    compliancyResultService = new CompliancyResultService();
    compliancyResultService.setEntityManagerFactory(factory);
  }

  /**
   * Gets the compliancy result service.
   * 
   * @return the compliancy result service
   */
  public static CompliancyResultService getCompliancyResultService() {
    return compliancyResultService;
  }

  /**
   * Gets the rule service.
   * 
   * @return the rule service
   */
  public static RuleService getRuleService() {
    return ruleService;
  }

  /**
   * Gets the rule set service.
   * 
   * @return the rule set service
   */
  public static RuleSetService getRuleSetService() {
    return ruleSetService;
  }

  /**
   * Instantiates a new SC service factory.
   */
  private SCServiceFactory() {

  }
}
