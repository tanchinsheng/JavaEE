/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 29, 2011 9:42:20 AM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All rights reserved.
 *
 */
public final class SQLCommandProcessor implements TranProcessor {

	private List<String> sqls;
	private List<Map<String, Object>> listParams;

	/**
	 * 
	 * Constructor
	 * @param sql
	 * @param params
	 */
	public SQLCommandProcessor(final String sql, final Map<String, Object> params) {

		if (sql == null) {
			throw new NullPointerException(
					"SQL command pass into constructor must not null");
		}
		this.sqls = new ArrayList<String>(1);
		this.sqls.add(sql);
		this.listParams = new ArrayList<Map<String, Object>>(1);
		this.listParams.add(params);
	}

	/**
	 * 
	 * Constructor
	 * @param sqls
	 * @param arrParams
	 */
	public SQLCommandProcessor(final String[] sqls, final Map<String, Object>[] arrParams) {
		
		if (sqls == null) {
			throw new NullPointerException(
					"SQLs command pass into constructor must not null");
		}
		if (sqls.length != arrParams.length) {
			throw new RuntimeException(
					"Number of SQL commands must equal number of parameters.");
		}
		this.sqls = Arrays.asList(sqls);
		this.listParams = Arrays.asList(arrParams);
	}

	/**
	 * 
	 * Constructor
	 * @param sqls
	 * @param listParams
	 */
	public SQLCommandProcessor(final List<String> sqls,
			final List<Map<String, Object>> listParams) {
		
		if (sqls == null) {
			throw new NullPointerException(
					"SQLs command pass into constructor must not null");
		}
		if (sqls.size() != listParams.size()) {
			throw new RuntimeException(
					"Number of SQL commands must equal number of parameters.");
		}
		this.sqls = sqls;
		this.listParams = listParams;
	}

	/**
	 * {@inheritDoc}
	 * @see com.st.persistence.TranProcessor#update(org.hibernate.Session)
	 */
	public int update(final Session session) {
		int result = 0;
		for (int sqlIndex = 0; sqlIndex < sqls.size(); sqlIndex++) {
			SQLQuery query = session.createSQLQuery(sqls.get(sqlIndex));
			Map<String, Object> params = listParams.get(sqlIndex);
			if (params != null) {
				for (Iterator<String> iter = params.keySet().iterator(); iter
						.hasNext();) {
					String key = iter.next();
					query.setParameter(key, params.get(key));
				}
			}
			result += query.executeUpdate();
		}
		return result;
	}
	
	 public int update(final EntityManager session) {
	    int result = 0;
	    for (int sqlIndex = 0; sqlIndex < sqls.size(); sqlIndex++) {
	      Query query = session.createNativeQuery(sqls.get(sqlIndex));
	      Map<String, Object> params = listParams.get(sqlIndex);
	      if (params != null) {
	        for (Iterator<String> iter = params.keySet().iterator(); iter
	            .hasNext();) {
	          String key = iter.next();
	          query.setParameter(key, params.get(key));
	        }
	      }
	      result += query.executeUpdate();
	    }
	    return result;
	  }
}
