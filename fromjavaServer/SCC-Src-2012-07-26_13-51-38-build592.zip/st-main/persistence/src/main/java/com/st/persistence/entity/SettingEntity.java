/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 1, 2011 10:53:55 AM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.st.persistence.util.QueryUtils;

/**
 * The Class SettingEntity.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
@Entity
@Table(name = "SETTINGS")
@NamedQueries({
    @NamedQuery(name = SettingEntity.FIND_ALL, query = "FROM SettingEntity"),
    @NamedQuery(name = SettingEntity.DELETE_KEY, query = "DELETE FROM SettingEntity s WHERE s.paraCode= :paraCode"),
    @NamedQuery(name = SettingEntity.FIND_BY_KEY, query = "SELECT s FROM SettingEntity s "
        + "WHERE s.paraCode = :" + QueryUtils.ID) })
public class SettingEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 603812290457858607L;

  /** The Constant FIND_ALL. */
  public static final String FIND_ALL = "Setting.findAll";

  /** The Constant FIND_BY_KEY. */
  public static final String FIND_BY_KEY = "Setting.findByKey";
  
  public static final String DELETE_KEY = "Setting.deleteKey";

  /** The para code. */
  @Id
  @Column(name = "PARA_CODE")
  private String paraCode;

  /** The para value. */
  @Column(name = "PARA_VALUE")
  private String paraValue;

  /** The data type. */
  @Column(name = "DATA_TYPE")
  private int dataType;

  /** The data length. */
  @Column(name = "DATA_LENGTH")
  private Integer dataLength;

  /** The data format. */
  @Column(name = "DATA_FORMAT")
  private String dataFormat;

  /** The value min. */
  @Column(name = "VALUE_MIN")
  private String valueMin;

  /** The value max. */
  @Column(name = "VALUE_MAX")
  private String valueMax;

  /** The value list. */
  @Column(name = "VALUE_LIST")
  private String valueList;

  /** The description. */
  @Column(name = "DESCRIPTION")
  private String description;

  /** The updated on. */
  @Column(name = "UPDATED_ON")
  private Timestamp updatedOn;

  /** The updated by. */
  @Column(name = "UPDATED_BY")
  private String updatedBy;

  /**
   * Gets the data format.
   * 
   * @return the data format
   */
  public String getDataFormat() {
    return dataFormat;
  }

  /**
   * Gets the data length.
   * 
   * @return the data length
   */
  public Integer getDataLength() {
    return dataLength;
  }

  /**
   * Gets the data type.
   * 
   * @return the data type
   */
  public int getDataType() {
    return dataType;
  }

  /**
   * Gets the description.
   * 
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets the para code.
   * 
   * @return the para code
   */
  public String getParaCode() {
    return paraCode;
  }

  /**
   * Gets the para value.
   * 
   * @return the para value
   */
  public String getParaValue() {
    return paraValue;
  }

  /**
   * Gets the updated by.
   * 
   * @return the updated by
   */
  public String getUpdatedBy() {
    return updatedBy;
  }

  /**
   * Gets the updated on.
   * 
   * @return the updated on
   */
  public Timestamp getUpdatedOn() {
    return updatedOn;
  }

  /**
   * Gets the value list.
   * 
   * @return the value list
   */
  public String getValueList() {
    return valueList;
  }

  /**
   * Gets the value max.
   * 
   * @return the value max
   */
  public String getValueMax() {
    return valueMax;
  }

  /**
   * Gets the value min.
   * 
   * @return the value min
   */
  public String getValueMin() {
    return valueMin;
  }

  /**
   * Sets the data format.
   * 
   * @param dataFormat
   *          the new data format
   */
  public void setDataFormat(final String dataFormat) {
    this.dataFormat = dataFormat;
  }

  /**
   * Sets the data length.
   * 
   * @param dataLength
   *          the new data length
   */
  public void setDataLength(final Integer dataLength) {
    this.dataLength = dataLength;
  }

  /**
   * Sets the data type.
   * 
   * @param dataType
   *          the new data type
   */
  public void setDataType(final int dataType) {
    this.dataType = dataType;
  }

  /**
   * Sets the description.
   * 
   * @param description
   *          the new description
   */
  public void setDescription(final String description) {
    this.description = description;
  }

  /**
   * Sets the para code.
   * 
   * @param paraCode
   *          the new para code
   */
  public void setParaCode(final String paraCode) {
    this.paraCode = paraCode;
  }

  /**
   * Sets the para value.
   * 
   * @param paraValue
   *          the new para value
   */
  public void setParaValue(final String paraValue) {
    this.paraValue = paraValue;
  }

  /**
   * Sets the updated by.
   * 
   * @param updatedBy
   *          the new updated by
   */
  public void setUpdatedBy(final String updatedBy) {
    this.updatedBy = updatedBy;
  }

  /**
   * Sets the updated on.
   * 
   * @param updatedOn
   *          the new updated on
   */
  public void setUpdatedOn(final Timestamp updatedOn) {
    this.updatedOn = updatedOn;
  }

  /**
   * Sets the value list.
   * 
   * @param valueList
   *          the new value list
   */
  public void setValueList(final String valueList) {
    this.valueList = valueList;
  }

  /**
   * Sets the value max.
   * 
   * @param valueMax
   *          the new value max
   */
  public void setValueMax(final String valueMax) {
    this.valueMax = valueMax;
  }

  /**
   * Sets the value min.
   * 
   * @param valueMin
   *          the new value min
   */
  public void setValueMin(final String valueMin) {
    this.valueMin = valueMin;
  }

}
