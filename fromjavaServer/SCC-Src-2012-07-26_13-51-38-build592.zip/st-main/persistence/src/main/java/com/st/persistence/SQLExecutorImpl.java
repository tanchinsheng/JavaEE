/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 4, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.FlushMode;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.context.ManagedSessionContext;
import org.hibernate.jdbc.Work;
import org.owasp.esapi.codecs.Codec;
import org.owasp.esapi.codecs.OracleCodec;

import com.st.persistence.util.Encoder;
import com.st.persistence.util.QueryUtils;

/**
 * A thread safe class for process entities and execute sql statements.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class SQLExecutorImpl implements SQLExecutor {

	/**
	 * session factory field
	 */
	private SessionFactory factory;

	/**
	 * Gets default instance Constructor
	 */
	protected SQLExecutorImpl() {
	}

	/**
	 * 
	 * Constructor
	 * 
	 * @param factory
	 */
	public SQLExecutorImpl(final SessionFactory factory) {
		this.factory = factory;
	}

  /**
   * Gets database codec.
   * @return the Codec
   */
  public Codec getDBCodec(){
    return new OracleCodec();
  }
  
  /**
	 * Create a new Session.
	 * 
	 * For this method to work, the application managed session strategy has to
	 * be enabled. This basically means that the life of a session is controlled
	 * by you and and not by Hibernate.
	 * 
	 * To enable the application managed session strategy set the property
	 * hibernate.current_session_context_class to "managed".
	 * 
	 * Within this method we create a new session and set the flush mode to
	 * MANUAL. This ensures that we have full control over when the session is
	 * flushed to the database.
	 * 
	 * @return A new session
	 */
	private org.hibernate.Session createNewSession() {
		org.hibernate.classic.Session s = this.factory.openSession();
		s.setFlushMode(FlushMode.MANUAL);
		ManagedSessionContext.bind(s);
		return s;
	}

	/**
	 * Creates a new session and begins a transaction in it.
	 * 
	 * @return A new session with a transaction started
	 */
	private org.hibernate.Session createNewSessionAndTransaction() {
		Session s = createNewSession();
		s.beginTransaction();
		return s;
	}

	/**
	 * Commit the transaction within the given session. This method unbinds the
	 * session from the session context (ManagedSessionContext), flushes the
	 * session and then commit the session.
	 * 
	 * @param s
	 *            The session with the transaction to commit
	 */
	private void commitTransaction(final Session s) {
		ManagedSessionContext.unbind(this.factory);
		s.flush();
		s.getTransaction().commit();
	}

	/**
	 * Rolls back the transaction.
	 * 
	 * @param s
	 */
	private void rollBackTransaction(final Session s) {
		if (s != null && s.getTransaction() != null
				&& s.getTransaction().isActive()) {
			s.getTransaction().rollback();
		}
	}

	/**
	 * Gets sysdate from database.
	 * 
	 * @return sysdate
	 */
	public Timestamp getSysDate() {
		Session session = null;
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery("select sysdate from dual");

			Object obj = query.list().get(0);
			commitTransaction(session);
			return (Timestamp) obj;
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	/**
	 * Gets value in number.
	 * 
	 * @param sql
	 * @param params
	 *            Object[]
	 * @return value in number
	 */
	public BigDecimal getNumberValue(final String sql, Object[] params) {
		Object value = this.getScalarValue(sql, params);
		return QueryUtils.getBigDecimal(value);
	}

	/**
	 * Gets value in number.
	 * 
	 * @param sql
	 * @param params
	 *            Map<String, Object>
	 * @return value in number
	 */
	public BigDecimal getNumberValue2(final String sql,
			final Map<String, Object> params) {
		Object value = this.getScalarValue2(sql, params);
		return QueryUtils.getBigDecimal(value);
	}

	/**
	 * Gets value in timestamp.
	 * 
	 * @param sql
	 * @param params
	 * @return value in timestamp format
	 */
	public Timestamp getTimestampValue(final String sql, Object[] params) {
		Object value = this.getScalarValue(sql, params);
		if (value instanceof Timestamp) {
			return (Timestamp) value;
		}
		return null;
	}

	/**
	 * Gets scalar value.
	 * 
	 * @param sql
	 *            select command
	 * @param params
	 * @return value
	 */
	public Object getScalarValue(final String sql, Object[] params) {
		Session session = null;
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery(sql);
			if (params != null) {
				for (int i = 0; i < params.length; i++) {
					query.setParameter(i, params[i]);
				}
			}
			@SuppressWarnings("rawtypes")
			List ls = query.list();
			Object result = null;
			if (ls != null && ls.size() > 0) {
				result = ls.get(0);
			}
			commitTransaction(session);
			return result;
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	/**
	 * Gets scalar value.
	 * 
	 * @param sql
	 * @param params
	 * @return scalar value as object.
	 */
	public Object getScalarValue2(final String sql, Map<String, Object> params) {
		Session session = null;
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery(sql);
			if (params != null) {
				for (Iterator<String> iter = params.keySet().iterator(); iter
						.hasNext();) {
					String key = iter.next();
					query.setParameter(key, params.get(key));
				}
			}
			@SuppressWarnings("rawtypes")
			List ls = query.list();
			Object result = null;
			if (ls != null && ls.size() > 0) {
				result = ls.get(0);
			}
			commitTransaction(session);
			return result;
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	/**
	 * Gets Next value of sequence.
	 * 
	 * @param seqName
	 * @return next value of sequence
	 */
	public Long getSequence(final String seqName) {
		Session session = null;
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery("select " + seqName
					+ ".nextval from dual");
			Object obj = query.list().get(0);
			commitTransaction(session);
			return Long.valueOf(obj.toString());
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	/**
	 * Inserts entities into database.
	 * 
	 * @param entities
	 * @return rows affected
	 */
	public int addEntities(Object... entities) {
		TranProcessor processor = new EntityProcessor(entities,
				EntityProcessor.TYPE_INSERT);
		return execTran(processor);
	}

	/**
	 * Updates entities into database.
	 * 
	 * @param entities
	 * @return rows affected
	 */
	public int updateEntities(Object... entities) {
		TranProcessor processor = new EntityProcessor(entities,
				EntityProcessor.TYPE_UPDATE);
		return execTran(processor);
	}

	/**
	 * Merges entities into database.
	 * 
	 * @param entities
	 * @return rows affected
	 */
	public int mergeEntities(Object... entities) {
		TranProcessor processor = new EntityProcessor(entities,
				EntityProcessor.TYPE_MERGE);
		return execTran(processor);
	}

	/**
	 * Deletes entities into database.
	 * 
	 * @param entities
	 * @return rows affected
	 */
	public int deleteEntities(Object... entities) {
		TranProcessor processor = new EntityProcessor(entities,
				EntityProcessor.TYPE_DELETE);
		return execTran(processor);
	}

	/**
	 * Executes update.
	 * 
	 * @param sql
	 *            update command
	 * @param params
	 *            parameter of sql
	 * @return rows affected
	 */
	public int executeSQL(final String sql, final Object[] params) {
		Session session = null;
		int result = 0;
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery(sql);
			if (params != null) {
				for (int i = 0; i < params.length; i++) {
					query.setParameter(i, params[i]);
				}
			}
			result = query.executeUpdate();
			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Executes update.
	 * 
	 * @param sql
	 * @param params
	 * @return
	 */
	public int executeSQL(final String sql, final Map<String, Object> params) {
		TranProcessor tran = new SQLCommandProcessor(new String[] { sql },
				new Map[] { params });
		return execTran(tran);
	}

	/**
	 * Executes batch update sql.
	 * 
	 * @param sqls
	 *            update commands
	 * @param params
	 *            list parameter of sql commands
	 * @return rows affected
	 */
	public int executeSQLs(final List<String> sqls,
			final List<Object[]> listParams) {
		Session session = null;
		int result = 0;
		try {
			session = createNewSessionAndTransaction();
			for (int sqlIndex = 0; sqlIndex < sqls.size(); sqlIndex++) {
				SQLQuery query = session.createSQLQuery(sqls.get(sqlIndex));
				Object[] params = listParams.get(sqlIndex);
				if (params != null) {
					for (int i = 0; i < params.length; i++) {
						query.setParameter(i, params[i]);
					}
				}
				result += query.executeUpdate();
			}
			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Executes batch update sql.
	 * 
	 * @param sqls
	 * @param listParams
	 * @return rows affected
	 */
	public int executeSQL2(final List<String> sqls,
			final List<Map<String, Object>> listParams) {
		TranProcessor processor = new SQLCommandProcessor(sqls, listParams);
		return execTran(processor);
	}

	/**
	 * Gets entity object.
	 * 
	 * @param sql
	 * @param entityClass
	 * @param params
	 * @return entity object
	 */
	public Object getEntity(final String sql, final Class entityClass,
			final Map<String, Object> params) {
		@SuppressWarnings("unchecked")
		List ls = query(sql, entityClass, params);
		if (ls != null && ls.size() > 0) {
			return ls.get(0);
		}
		return null;
	}

	/**
	 * Executes query.
	 * 
	 * @param <E>
	 * @param sql
	 * @param entityClass
	 * @param params
	 * @return list entity
	 */
	@SuppressWarnings("unchecked")
	public <E> List<E> query(String sql, final Class<E> entityClass,
			final Map<String, Object> params) {
		Session session = null;
		List<E> result = new ArrayList<E>();
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery(sql);
			if (params != null) {
				for (Iterator<String> iter = params.keySet().iterator(); iter
						.hasNext();) {
					String key = iter.next();
					Object value = params.get(key);
					if (value instanceof List) {
						StringBuilder valueToPass = new StringBuilder();
						@SuppressWarnings("rawtypes")
						List ls = (List) value;
            for (Object obj : ls) {
              if (obj instanceof String) {
                valueToPass.append("'"
                    + Encoder.encodeForSQL(getDBCodec(), obj.toString()) + "'");
              } else {
                valueToPass.append(Encoder.encodeForSQL(getDBCodec(), obj.toString()));
              }
              valueToPass.append(",");
            }
            valueToPass = valueToPass.deleteCharAt(valueToPass.length() - 1);
            sql =
                sql.replaceAll(":" + key, valueToPass.toString());
            query = session.createSQLQuery(sql);
          } else if (value != null && value.getClass().isArray()) {
            StringBuilder valueToPass = new StringBuilder();
            Object[] arr = (Object[]) value;
            for (Object obj : arr) {
              if (obj instanceof String) {
                valueToPass.append("'"
                    + Encoder.encodeForSQL(getDBCodec(), obj.toString()) + "'");
              } else {
                valueToPass.append(Encoder.encodeForSQL(getDBCodec(), obj.toString()));
              }
              valueToPass.append(",");
            }
            valueToPass = valueToPass.deleteCharAt(valueToPass.length() - 1);
            sql = sql.replaceAll(":" + key, valueToPass.toString());
						query = session.createSQLQuery(sql);
					} else {
						query.setParameter(key, value);
					}
				}
			}
			query.addEntity(entityClass);
			result = query.list();
			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Executes query with result from firstResult and get max result is
	 * maxResult.
	 * 
	 * @param <E>
	 * @param sql
	 * @param entityClass
	 * @param params
	 * @param firstResult
	 * @param maxResult
	 * @return list entities.
	 */
	public <E> List<E> query(String sql, final Class<E> entityClass,
			final Map<String, Object> params, final int firstResult,
			final int maxResult) {
		Session session = null;
		List<E> result = new ArrayList<E>();
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery(sql);
			if (params != null) {
				for (Iterator<String> iter = params.keySet().iterator(); iter
						.hasNext();) {
					String key = iter.next();
					Object value = params.get(key);
					query.setParameter(key, value);
				}
			}
			query.addEntity(entityClass);
			query.setFirstResult(firstResult);
			query.setMaxResults(maxResult);
			result = query.list();
			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Executes select command.
	 * 
	 * @param sql
	 *            select command
	 * @param params
	 * @param columnNames
	 * @return list array object
	 */
	@SuppressWarnings("unchecked")
	public List<Object[]> query(final String sql,
			final Map<String, Object> params, final String[] columnNames) {
    return getListObject(sql, params, columnNames, -1, -1);
	}

	/**
	 * 
	 * @param sql
	 * @param params
	 * @param columnName
	 * @return
	 */
	public List query(final String sql, final Map<String, Object> params,
			final String columnName) {
    return getListObject(sql, params, new String[]{columnName }, -1, -1);
	}

	/**
	 * 
	 * {@inheritDoc}
	 * @see com.st.persistence.SQLExecutor#query(java.lang.String, java.util.Map, java.lang.String[], int, int)
	 */
  public List<Object[]> query(final String sql, final Map<String, Object> params,
      final String[] columnNames, final int firstResult, final int maxResult) {
    return getListObject(sql, params, columnNames, firstResult, maxResult);
  }
  
	/**
	 * Gets lit object of columnNames.
	 * 
	 * @param sql
	 * @param params
	 * @param columnNames
	 * @return list objects.
	 */
	private List getListObject(final String sql,
			final Map<String, Object> params, String[] columnNames, int firstResult, int maxResult) {
    if (columnNames == null || columnNames.length == 0) {
      return null;
    }
		Session session = null;
		List<Object[]> result = new ArrayList<Object[]>();
		try {
			session = createNewSessionAndTransaction();
			SQLQuery query = session.createSQLQuery(sql);
			if (params != null) {
				for (Iterator<String> iter = params.keySet().iterator(); iter
						.hasNext();) {
					String key = iter.next();
					query.setParameter(key, params.get(key));
				}
			}
			
			for (String colName : columnNames) {
				query.addScalar(colName, Hibernate.STRING);
			}
      if (firstResult > -1 && maxResult > -1) {
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResult);
      }
			result = query.list();
			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * Executes in one transaction of entities and sql commands.
	 * 
	 * @param processors
	 * @return rows affected.
	 */
	public int execTran(final TranProcessor... processors) {
		Session session = null;
		int result = 0;
		try {
			session = createNewSessionAndTransaction();
			for (TranProcessor tp : processors) {
				result += tp.update(session);
			}
			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return result;
	}

	public <E> List<E> queryList(List<String> sqls, Class<E> classEntity,
			List<Map<String, Object>> params) {
		List<E> listResult = new ArrayList<E>();
		Session session = null;
		try {
			session = createNewSessionAndTransaction();
			if (sqls != null) {
				int index = 0;
				for (index = 0; index < sqls.size(); index++) {
					SQLQuery query = session.createSQLQuery(sqls.get(index));
					if (params != null) {
						Map<String, Object> map = params.get(index);
						if (map != null) {
							for (Iterator<String> iterator = map.keySet()
									.iterator(); iterator.hasNext();) {
								String key = iterator.next();
								Object value = map.get(key);
								query.setParameter(key, value);
							}
						}
					}
					query.addEntity(classEntity);
					List<E> ls = query.list();
					listResult.addAll(ls);
				}
			}
			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return listResult;
	}
	
	/**
	 * Executes jdbc update.
	 * 
	 * @param sql
	 * @param params
	 * @return rows affected.
	 */
	public int executeJDBCUpdate(final String sql, Object[] params) {
		int result = 0;
		Session session = null;
		try {
			session = createNewSessionAndTransaction();
			// Create a SQL order of work, which we will use to execute a manual
			// SQL statement
			JDBCUpdateWork work = new JDBCUpdateWork(sql, params);
			session.doWork(work);
			result = work.getValue();

			commitTransaction(session);
		} catch (HibernateException e) {
			rollBackTransaction(session);
			throw e;
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return result;
	}

	/**
	 * JDBC update work.
	 */
	private static class JDBCUpdateWork implements Work {
		/**
		 * Metadata value returned.
		 */
		private int value;

		private String command;
		private Object[] params;

		/**
		 * Constructor.
		 * 
		 * @param command
		 * @param params
		 */
		public JDBCUpdateWork(final String command, Object[] params) {
			this.command = command;
			this.params = params;
		}

		/**
		 * Executes the command to get metadata.
		 * 
		 * @param connection
		 * @throws SQLException
		 */
		public void execute(final Connection connection) throws SQLException {
			PreparedStatement stmt = null;
			try {
				stmt = connection.prepareStatement(command);
				if (params != null) {
					for (int i = 0; i < params.length; i++) {
						Object object = params[i];
            if (object instanceof Long) {
							stmt.setLong(i + 1, (Long) object);
						} else if (object instanceof Integer) {
							stmt.setInt(i + 1, (Integer) object);
						} else if (object instanceof Timestamp) {
							stmt.setTimestamp(i + 1, (Timestamp) object);
						} else if (object instanceof Date) {
							stmt.setDate(i + 1, (Date) object);
						} else if (object instanceof BigDecimal) {
							stmt.setBigDecimal(i + 1, (BigDecimal) object);
						} else if (object instanceof String) {
							stmt.setString(i + 1, (String) object);
						} else if (object instanceof Double) {
							stmt.setDouble(i + 1, (Double) object);
						} else if (object instanceof Float) {
							stmt.setFloat(i + 1, (Float) object);
						} else if (object instanceof Byte) {
							stmt.setByte(i + 1, (Byte) object);
						} else {
							stmt.setObject(i + 1, object);
						}
					}
				}
				value = stmt.executeUpdate();
			} finally {
				if (stmt != null) {
					stmt.close();
				}
			}
		}

		/**
		 * Returns value.
		 * 
		 * @return rows affected.
		 */
		public int getValue() {
			return value;
		}
	}

  public <E> List<E> getAllEntities(String name, Map<String, Object> param, int startPosition,
      int maxResult) {
    return null;
  }

  public <E> List<E> getAllEntities(String name, Map<String, Object> param) {
    return null;
  }

  public <E> E findEntity(Class<E> entityClass, Object primaryKey) throws Exception {
    return null;
  }
  
  public DatabaseType getDatabaseType() {
    return DatabaseType.ORACLE;
  }
}
