/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 6, 2011 11:15:34 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.persistence.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.persistence.entity.SettingEntity;
import com.st.persistence.util.QueryUtils;

/**
 * The Class SettingsInfo.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class SettingService extends JPABaseService<SettingEntity> {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SettingService.class);

  /**
   * Instantiates a new setting service.
   */
  public SettingService() {
  }

  /**
   * Instantiates a new setting service.
   * 
   * @param emf
   *          the {@link EntityManagerFactory} object
   */
  public SettingService(final EntityManagerFactory emf) {
    setEntityManagerFactory(emf);
  }

  /**
   * Convert to setting value.
   * 
   * @param entity
   *          the entity
   * @return the object
   */
  private Object convertToSettingValue(final SettingEntity entity) {
    Object object = null;
    final String value = entity.getParaValue();
    if (value != null) {
      final int dataType = entity.getDataType();
      switch (dataType) {
      case 0:
        try {
          object = Double.valueOf(Double.parseDouble(value));
        } catch (final NumberFormatException e) {
          if (LOG.isDebugEnabled()) {
            LOG.debug(e.getMessage(), e);
          }
        }
        break;

      case 1:
        object = value;
        break;

      case 2:
        try {
          final SimpleDateFormat dateFormat = new SimpleDateFormat(entity.getDataFormat());
          object = new Timestamp(dateFormat.parse(value).getTime());
        } catch (final ParseException e) {
          if (LOG.isDebugEnabled()) {
            LOG.debug(e.getMessage(), e);
          }
        }
        break;

      case 3:
        object = Boolean.valueOf(value);
        break;

      default:
        LOG.warn("Not support SETTING.DATA_TYPE=[{}]", dataType);
        break;
      }
    }
    return object;
  }

  /**
   * Find setting with given key in database.
   * 
   * @param key
   *          the key
   * @return the setting entity
   */
  public SettingEntity find(final String key) {
    EntityManager em = null;
    SettingEntity settingEntity = null;
    try {
      final EntityManagerFactory factory = getEntityManagerFactory();
      em = factory.createEntityManager();
      final TypedQuery<SettingEntity> query =
          em.createNamedQuery(SettingEntity.FIND_BY_KEY, SettingEntity.class);
      query.setParameter(QueryUtils.ID, key);
      List<SettingEntity> list = query.getResultList();
      if (list == null || list.size() == 0) {
        LOG.warn("Could not find setting with key=[{}]", key);
      } else {
        settingEntity = list.get(0);
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (em != null) {
        em.close();
      }
    }
    return settingEntity;
  }

  /**
   * Find all.
   * 
   * @return the map
   * @throws RuntimeException
   *           the runtime exception
   */
  public Map<String, Object> findAll() throws RuntimeException {
    final Map<String, Object> settingMap = new HashMap<String, Object>();
    EntityManager em = null;
    try {
      final EntityManagerFactory factory = getEntityManagerFactory();
      em = factory.createEntityManager();
      final List<SettingEntity> list =
          em.createNamedQuery(SettingEntity.FIND_ALL, SettingEntity.class).getResultList();
      putAll(list, settingMap);
    } catch (final RuntimeException e) {
      throw e;
    } finally {
      if (em != null) {
        em.close();
      }
    }
    return settingMap;
  }

  /**
   * Find value by key.
   * 
   * @param key
   *          the key
   * @return the object
   */
  public Object findValue(final String key) {
    final SettingEntity entity = find(key);
    return convertToSettingValue(entity);
  }

  /**
   * Load all settings in database.
   * 
   * @return the map
   */
  public Map<String, Object> loadAll() {
    final Map<String, Object> settingMap = new HashMap<String, Object>();
    EntityManager em = null;
    try {
      final EntityManagerFactory factory = getEntityManagerFactory();
      em = factory.createEntityManager();
      final List<SettingEntity> list =
          em.createNamedQuery(SettingEntity.FIND_ALL, SettingEntity.class).getResultList();
      putAll(list, settingMap);
    } catch (final Exception e) {
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    } finally {
      if (em != null) {
        em.close();
      }
    }
    return settingMap;
  }

  /**
   * Put all settings to map.
   * 
   * @param list
   *          the list
   * @param settingMap
   *          the setting map
   */
  public void putAll(final List<SettingEntity> list, final Map<String, Object> settingMap) {
    if (list != null) {
      for (final SettingEntity entity : list) {
        final Object object = convertToSettingValue(entity);
        if (object != null) {
          settingMap.put(entity.getParaCode(), object);
        }
      }
    }
  }

  public int deleteSetting(final String key) {
    EntityManager em = null;
    try {
      final EntityManagerFactory factory = getEntityManagerFactory();
      em = factory.createEntityManager();
      em.getTransaction().begin();
      Query query = em.createNamedQuery(SettingEntity.DELETE_KEY);
      query.setParameter("paraCode", key);
      int rs = query.executeUpdate();
      em.getTransaction().commit();
      return rs;
    } catch (Exception e) {
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    } finally {
      if (em != null) {
        em.close();
      }
    }
    return 0;
  }
}
