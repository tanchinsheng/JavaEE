/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 4, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.codecs.Codec;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public interface SQLExecutor {
  
  /**
   * Gets database codec.
   * @return the Codec
   */
  Codec getDBCodec();
  
  /**
   * Gets sysdate from database.
   * 
   * @return sysdate
   */
  Timestamp getSysDate();

  /**
   * Gets value in number.
   * 
   * @param sql
   * @param params
   *          Object[]
   * @return value in number
   */
  BigDecimal getNumberValue(final String sql, Object[] params);

  /**
   * Gets value in number.
   * 
   * @param sql
   * @param params
   *          Map<String, Object>
   * @return value in number
   */
  BigDecimal getNumberValue2(final String sql, final Map<String, Object> params);

  /**
   * Gets value in timestamp.
   * 
   * @param sql
   * @param params
   * @return value in timestamp format
   */
  Timestamp getTimestampValue(final String sql, Object[] params);

  /**
   * Gets scalar value.
   * 
   * @param sql
   *          select command
   * @param params
   * @return value
   */
  Object getScalarValue(final String sql, Object[] params);

  /**
   * Gets scalar value.
   * 
   * @param sql
   * @param params
   * @return scalar value as object.
   */
  Object getScalarValue2(final String sql, Map<String, Object> params);

  /**
   * Gets Next value of sequence.
   * 
   * @param seqName
   * @return next value of sequence
   */
  Long getSequence(final String seqName);

  /**
   * Inserts entities into database.
   * 
   * @param entities
   * @return rows affected
   */
  int addEntities(Object... entities);

  /**
   * Updates entities into database.
   * 
   * @param entities
   * @return rows affected
   */
  int updateEntities(Object... entities);

  /**
   * Merges entities into database.
   * 
   * @param entities
   * @return rows affected
   */
  int mergeEntities(Object... entities);

  /**
   * Deletes entities into database.
   * 
   * @param entities
   * @return rows affected
   */
  int deleteEntities(Object... entities);

  /**
   * Executes update.
   * 
   * @param sql
   *          update command
   * @param params
   *          parameter of sql
   * @return rows affected
   */
  int executeSQL(final String sql, final Object[] params);

  /**
   * Executes update.
   * 
   * @param sql
   * @param params
   * @return
   */
  int executeSQL(final String sql, final Map<String, Object> params);

  /**
   * Executes batch update sql.
   * 
   * @param sqls
   *          update commands
   * @param params
   *          list parameter of sql commands
   * @return rows affected
   */
  int executeSQLs(final List<String> sqls, final List<Object[]> listParams);

  /**
   * Executes batch update sql.
   * 
   * @param sqls
   * @param listParams
   * @return rows affected
   */
  int executeSQL2(final List<String> sqls, final List<Map<String, Object>> listParams);

  /**
   * Gets entity object.
   * 
   * @param sql
   * @param entityClass
   * @param params
   * @return entity object
   */
  Object getEntity(final String sql, final Class entityClass, final Map<String, Object> params);

  /**
   * Executes query.
   * 
   * @param <E>
   * @param sql
   * @param entityClass
   * @param params
   * @return list entity
   */
  <E> List<E> query(String sql, final Class<E> entityClass, final Map<String, Object> params);

  /**
   * Executes query with result from firstResult and get max result is
   * maxResult.
   * 
   * @param <E>
   * @param sql
   * @param entityClass
   * @param params
   * @param firstResult
   * @param maxResult
   * @return list entities.
   */
  <E> List<E> query(String sql, final Class<E> entityClass, final Map<String, Object> params,
      final int firstResult, final int maxResult);

  /**
   * Executes select command.
   * 
   * @param sql
   *          select command
   * @param params
   * @param columnNames
   * @return list array object
   */
  List<Object[]> query(final String sql, final Map<String, Object> params,
      final String[] columnNames);

  /**
   * @param sql
   * @param params
   * @param columnName
   * @return
   */
  @SuppressWarnings("rawtypes")
  List query(final String sql, final Map<String, Object> params, final String columnName);

  List<Object[]> query(final String sql, final Map<String, Object> params,
      final String[] columnNames, int firtResult, int maxResult);
  
  /**
   * Executes in one transaction of entities and sql commands.
   * 
   * @param processors
   * @return rows affected.
   */
  int execTran(final TranProcessor... processors);

  <E> List<E> queryList(List<String> sqls, Class<E> classEntity,
      List<Map<String, Object>> params);

  
  /**
   * Executes jdbc update.
   * 
   * @param sql
   * @param params
   * @return rows affected.
   */
  @Deprecated
  int executeJDBCUpdate(final String sql, Object[] params);

  /**
   * Gets list Entities object from database by a named query.
   * 
   * @param name
   *          of query in NamedQuery or NamedNativeQuery
   * @param param
   *          is map parameters of NamedQuery or NamedNativeQuery
   * @param startPosition
   *          is position of the first result to retrieve
   * @param maxResult
   *          is maximum number of results to retrieve
   * @return list Entities object
   */
  <E> List<E> getAllEntities(String name, Map<String, Object> param, int startPosition,
      int maxResult);

  /**
   * Gets list Entities object from database by a named query.
   * 
   * @param <E>
   * @param name
   * @param param
   * @return
   */
  <E> List<E> getAllEntities(String name, Map<String, Object> param);

  /**
   * Find entity by PK.
   * @param <E>
   * @param entityClass
   * @param primaryKey
   * @return
   * @throws Exception
   */
  <E> E findEntity(Class<E> entityClass, Object primaryKey) throws Exception;
  
  /**
   * Gets the database type.
   *
   * @return the database type
   */
  DatabaseType getDatabaseType();
}
