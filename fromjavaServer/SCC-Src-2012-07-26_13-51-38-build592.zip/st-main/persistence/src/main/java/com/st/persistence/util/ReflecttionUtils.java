/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

public final class ReflecttionUtils {

  private ReflecttionUtils() {
  }

  public static String getTableName(Class< ? > entityClass) {
    String name = null;
    if (entityClass == null) {
      return null;
    }
    Table table = entityClass.getAnnotation(Table.class);
    if (table != null && table.name() != null && !"".equals(table.name().trim())) {
      name = table.name();
    } else {
      name = entityClass.getSimpleName();
    }
    return name;
  }

  /**
   * Gets id fields of entity
   * 
   * @param entityClass
   * @return
   */
  public static Field[] getIdFields(Class< ? > entityClass) {
    if (entityClass == null) {
      return null;
    }
    ArrayList<Field> ids = new ArrayList<Field>();
    Field[] fields = entityClass.getDeclaredFields();
    for (int i = 0; i < fields.length; i++) {
      if (fields[i].getAnnotation(Id.class) != null) {
        ids.add(fields[i]);
      }
    }
    return ids.toArray(new Field[ids.size()]);
  }

  /**
   * Get NamedNativeQuery from Entity
   * 
   * @param name
   *          name of NamedNativeQuery
   * @param classEntity
   *          entity contain NamedNativeQuery
   * @return NamedNativeQuery
   */
  public static NamedNativeQuery getNamedNativeQuery(String name, Class< ? > classEntity) {
    Annotation[] itemAnnotation = classEntity.getAnnotations();
    NamedNativeQuery namedNativeQuery = null;
    for (Annotation a : itemAnnotation) {
      if (a instanceof NamedNativeQueries) {
        NamedNativeQueries itemNamedNativeQueries = (NamedNativeQueries) a;
        NamedNativeQuery[] itemNamedNativeQuery = itemNamedNativeQueries.value();
        for (NamedNativeQuery n : itemNamedNativeQuery) {
          if (n.name() != null && name.equals(n.name())) {
            namedNativeQuery = n;
            break;
          }
        }
        break;
      } else if (a instanceof NamedNativeQuery) {
        namedNativeQuery = (NamedNativeQuery) a;
        break;
      }
    }
    return namedNativeQuery;
  }

  /**
   * @param cls
   * @return
   */
  @SuppressWarnings("rawtypes")
  public static Map<String, Class> getColumns(Class< ? extends Object> cls)
      throws NoSuchFieldException {
    Map<String, Class> result = new HashMap<String, Class>();
    if (cls == null) {
      return result;
    }
    Field[] fields = cls.getDeclaredFields();
    for (int i = 0; i < fields.length; i++) {
      // check if field is there get and set method
      if (getGetMethodFromClass(fields[i].getName(), cls) != null
          && getSetMethodFromClass(fields[i].getName(), cls) != null) {
        Column colAnnotation = fields[i].getAnnotation(Column.class);
        String colName = null;
        if (fields[i].getAnnotation(Transient.class) == null) {
          colName = colAnnotation != null ? colAnnotation.name() : fields[i].getName();
          result.put(colName + ":" + fields[i].getName(), fields[i].getType());
        }
      }
    }
    return result;
  }

  /**
   * Gets getMethod of field.
   * 
   * @param fieldName
   * @param clazz
   * @return the method
   */
  public static Method getGetMethodFromClass(String fieldName, Class< ? extends Object> clazz) {
    if (fieldName == null || clazz == null) {
      return null;
    }
    fieldName = fieldName.trim();
    StringBuffer getMethodName = new StringBuffer("get");
    getMethodName.append(fieldName.substring(0, 1).toUpperCase());
    getMethodName.append(fieldName.substring(1));
    try {
      Method m = clazz.getMethod(getMethodName.toString());
      return m;
    } catch (NoSuchMethodException e) {
      getMethodName = new StringBuffer("is");
      getMethodName.append(fieldName.substring(0, 1).toUpperCase());
      getMethodName.append(fieldName.substring(1));
      try {
        Method m = clazz.getMethod(getMethodName.toString());
        return m;
      } catch (NoSuchMethodException ne) {
        return null;
      }
    }
  }

  /**
   * get setMethod of field.
   * 
   * @param fieldName
   * @param clazz
   * @return
   */
  public static Method getSetMethodFromClass(String fieldName, Class< ? extends Object> clazz)
      throws NoSuchFieldException {
    if (fieldName == null || clazz == null) {
      return null;
    }
    fieldName = fieldName.trim();
    StringBuffer setMethodName = new StringBuffer("set");
    setMethodName.append(fieldName.substring(0, 1).toUpperCase());
    setMethodName.append(fieldName.substring(1));
    Field field = clazz.getDeclaredField(fieldName);
    if (field == null) {
      return null;
    }
    try {
      Method m = clazz.getMethod(setMethodName.toString(), field.getType());
      return m;
    } catch (NoSuchMethodException e) {
      return null;
    }
  }

}
