/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.owasp.esapi.codecs.Codec;
import org.owasp.esapi.codecs.MySQLCodec;
import org.owasp.esapi.codecs.MySQLCodec.Mode;
import org.owasp.esapi.codecs.OracleCodec;

import com.st.persistence.util.Encoder;
import com.st.persistence.util.QueryUtils;
import com.st.persistence.util.ReflecttionUtils;

/**
 * A thread safe class for process entities and execute sql statements.
 */
public final class SQLExecutorJpaImpl implements SQLExecutor {

  /** EntityManagerFactory field EntityManagerFactory instances are thread-safe. */
  private final EntityManagerFactory factory;

  /** The database type. */
  private DatabaseType databaseType;

  /** The codec. */
  private Codec codec;

  /**
   * Gets default instance Constructor.
   * 
   * @param factory
   *          the factory
   */
  public SQLExecutorJpaImpl(final EntityManagerFactory factory) {
    this.factory = factory;

    initialize();
  }

  /**
   * Inserts entities into database.
   * 
   * @param entities
   *          the entities
   * @return rows affected
   */
  public int addEntities(final Object... entities) {
    final TranProcessor processor = new EntityProcessor(entities, EntityProcessor.TYPE_INSERT);
    return execTran(processor);
  }

  /**
   * Commit transction of the em.
   * 
   * @param em
   *          EntityManager
   */
  private void commitTransaction(final EntityManager em) {
    em.getTransaction().commit();
  }

  /**
   * Creates an EntityManager. An EntityManager is an inexpensive,
   * non-threadsafe object that should be used once, for a single business
   * process, a single unit of work, and then discarded. An EntityManager will
   * not obtain a JDBC Connection (or a Datasource) unless it is needed, so you
   * may safely open and close an EntityManager
   * 
   * @return EntityManager
   */
  private EntityManager createNewEntityManager() {
    return factory.createEntityManager();
  }

  /**
   * Creates an EntityManager and begin a transaction.
   * 
   * @return EntityManager
   */
  private EntityManager createNewEntityManagerAndTransaction() {
    final EntityManager em = createNewEntityManager();
    em.getTransaction().begin();
    return em;
  }

  /**
   * Deletes entities into database.
   * 
   * @param entities
   *          the entities
   * @return rows affected
   */
  public int deleteEntities(final Object... entities) {
    final TranProcessor processor = new EntityProcessor(entities, EntityProcessor.TYPE_DELETE);
    return execTran(processor);
  }

  /**
   * Executes in one transaction of entities and sql commands.
   * 
   * @param processors
   *          the processors
   * @return rows affected.
   */
  public int execTran(final TranProcessor... processors) {
    EntityManager em = null;
    int result = 0;
    try {
      em = createNewEntityManagerAndTransaction();
      for (final TranProcessor tp : processors) {
        result += tp.update(em);
      }
      commitTransaction(em);
    } catch (final RuntimeException e) {
      rollBackTransaction(em);
      throw e;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#executeJDBCUpdate(java.lang.String,
   *      java.lang.Object[])
   */
  @Deprecated
  public int executeJDBCUpdate(final String sql, final Object[] params) {
    return 0;
  }

  /**
   * Executes update.
   * 
   * @param sql
   *          the sql
   * @param params
   *          the params
   * @return the int
   */
  @SuppressWarnings("unchecked")
  public int executeSQL(final String sql, final Map<String, Object> params) {
    final TranProcessor tran = new SQLCommandProcessor(new String[]{sql }, new Map[]{params });
    return execTran(tran);
  }

  /**
   * Executes update.
   * 
   * @param sql
   *          update command
   * @param params
   *          parameter of sql
   * @return rows affected
   */
  public int executeSQL(final String sql, final Object[] params) {
    EntityManager em = null;
    int result = 0;
    try {
      em = createNewEntityManagerAndTransaction();
      final Query query = em.createNativeQuery(sql);
      if (params != null) {
        for (int i = 0; i < params.length; i++) {
          query.setParameter(i + 1, params[i]);
        }
      }
      result = query.executeUpdate();
      commitTransaction(em);
    } catch (final RuntimeException e) {
      rollBackTransaction(em);
      throw e;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
    return result;
  }

  /**
   * Executes batch update sql.
   * 
   * @param sqls
   *          the sqls
   * @param listParams
   *          the list params
   * @return rows affected
   */
  public int executeSQL2(final List<String> sqls, final List<Map<String, Object>> listParams) {
    final TranProcessor processor = new SQLCommandProcessor(sqls, listParams);
    return execTran(processor);
  }

  /**
   * Executes batch update sql.
   * 
   * @param sqls
   *          update commands
   * @param listParams
   *          the list params
   * @return rows affected
   */
  public int executeSQLs(final List<String> sqls, final List<Object[]> listParams) {
    EntityManager em = null;
    int result = 0;
    try {
      em = createNewEntityManagerAndTransaction();
      for (int sqlIndex = 0; sqlIndex < sqls.size(); sqlIndex++) {
        final Query query = em.createNativeQuery(sqls.get(sqlIndex));
        final Object[] params = listParams.get(sqlIndex);
        if (params != null) {
          for (int i = 0; i < params.length; i++) {
            query.setParameter(i + 1, params[i]);
          }
        }
        result += query.executeUpdate();
      }
      commitTransaction(em);
    } catch (final RuntimeException e) {
      rollBackTransaction(em);
      throw e;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
    return result;
  }

  /**
   * Find entity by primary key.
   * 
   * @param <E>
   *          the element type
   * @param entityClass
   *          the entity class
   * @param primaryKey
   *          the primary key
   * @return the found entity instance or null if the entity does not exist
   * @throws Exception
   *           the exception
   */
  public <E> E findEntity(final Class<E> entityClass, final Object primaryKey)
      throws Exception {
    E ret = null;
    EntityManager em = null;
    try {
      if (primaryKey == null) {
        throw new RuntimeException("Primary key can't null.");
      }
      em = createNewEntityManager();
      ret = em.find(entityClass, primaryKey);
    } catch (final Exception e) {
      throw e;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
    return ret;
  }

  /**
   * Execute named query.
   * 
   * @param <E>
   *          the element type
   * @param name
   *          the name
   * @param param
   *          the param
   * @return list entities.
   */
  @SuppressWarnings("unchecked")
  public <E> List<E> getAllEntities(final String name, final Map<String, Object> param) {
    List<E> result = Collections.emptyList();
    if (name != null && !"".equals(name.trim())) {
      EntityManager em = null;
      try {
        em = createNewEntityManager();
        final Query query = em.createNamedQuery(name);
        if (query != null) {
          setParameters(query, param);
          result = query.getResultList();
        }
      } finally {
        if (em != null && em.isOpen()) {
          em.close();
        }
      }
    }
    return result;
  }

  /**
   * Gets list Entities object from database by a SELECT query.
   * 
   * @param <E>
   *          the element type
   * @param name
   *          of query in NamedQuery or NamedNativeQuery
   * @param param
   *          is map parameters of NamedQuery or NamedNativeQuery
   * @param startPosition
   *          is position of the first result to retrieve
   * @param maxResult
   *          is maximum number of results to retrieve
   * @return list Entities object
   */
  @SuppressWarnings("unchecked")
  public <E> List<E> getAllEntities(final String name, final Map<String, Object> param,
      final int startPosition, final int maxResult) {
    List<E> result = Collections.emptyList();
    if (name != null && !"".equals(name.trim())) {
      EntityManager em = null;
      try {
        em = createNewEntityManager();
        final Query query = em.createNamedQuery(name);
        if (query != null) {
          setParameters(query, param);
          if (startPosition != -1) {
            query.setFirstResult(startPosition);
          }
          if (maxResult != -1) {
            query.setMaxResults(maxResult);
          }
          result = query.getResultList();
        }
      } finally {
        if (em != null && em.isOpen()) {
          em.close();
        }
      }
    }
    return result;
  }

  /**
   * Gets the database driver.
   * 
   * @return the database driver
   */
  private String getDatabaseDriver() {
    final Map<String, Object> pros = factory.getProperties();
    for (final String key : pros.keySet()) {
      if (key.indexOf("driver_class") != -1
          || key.indexOf("javax.persistence.jdbc.driver") != -1) {
        return (String) pros.get(key);
      }
    }
    return null;
  }

  /**
   * Gets database codec.
   * 
   * @return the Codec
   */
  public Codec getDBCodec() {
    return codec;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#getEntity(java.lang.String,
   *      java.lang.Class, java.util.Map)
   */
  @SuppressWarnings({"unchecked", "rawtypes" })
  public Object getEntity(final String sql, final Class entityClass,
      final Map<String, Object> params) {
    final List ls = query(sql, entityClass, params, 0, 1);
    if (ls != null && ls.size() > 0) {
      return ls.get(0);
    }
    return null;
  }

  /**
   * Gets value in number.
   * 
   * @param sql
   *          the sql
   * @param params
   *          Object[]
   * @return value in number
   */
  public BigDecimal getNumberValue(final String sql, final Object[] params) {
    final Object value = getScalarValue(sql, params);
    return QueryUtils.getBigDecimal(value);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#getNumberValue2(java.lang.String,
   *      java.util.Map)
   */
  public BigDecimal getNumberValue2(final String sql, final Map<String, Object> params) {
    final Object value = getScalarValue2(sql, params);
    return QueryUtils.getBigDecimal(value);
  }

  /**
   * Get query by PK.
   * 
   * @param em
   *          the em
   * @param entityClass
   *          the entity class
   * @return the query pk
   */
  @SuppressWarnings("unused")
  private Query getQueryPK(final EntityManager em, final Class< ? > entityClass) {
    String sql = null;
    if (entityClass == null) {
      throw new RuntimeException("Entity class can't null.");
    }
    if (entityClass.getAnnotation(Entity.class) == null) {
      throw new RuntimeException(entityClass.getName() + " isn't an entity class.");
    }
    final Map<String, String> mapQueryPK = new HashMap<String, String>();

    final String tableName = ReflecttionUtils.getTableName(entityClass);
    sql = mapQueryPK.get(tableName);

    if (sql == null || "".equals(sql.trim())) {
      StringBuilder whereBuf = null;
      String where = null;
      final Field[] fieldId = ReflecttionUtils.getIdFields(entityClass);
      String columnName = null;
      Column column = null;
      if (fieldId != null) {
        whereBuf = new StringBuilder();
        for (final Field element : fieldId) {
          columnName = element.getName();
          column = element.getAnnotation(Column.class);
          if (column != null && column.name() != null && !"".equals(column.name().trim())) {
            columnName = column.name();
          }

          whereBuf.append(" AND ");
          whereBuf.append(columnName);
          whereBuf.append(" = :");
          whereBuf.append(element.getName());
        }
        where = whereBuf.substring(4);
      }
      final StringBuilder sqlBuf = new StringBuilder();
      sqlBuf.append("SELECT * FROM ");
      sqlBuf.append(tableName);
      sqlBuf.append(" WHERE ");
      sqlBuf.append(where);

      sql = sqlBuf.toString();
      mapQueryPK.put(tableName, sql);
    }
    return em.createNativeQuery(sql, entityClass);
  }

  /**
   * Gets scalar value.
   * 
   * @param sql
   *          select command
   * @param params
   *          the params
   * @return value
   */
  public Object getScalarValue(final String sql, final Object[] params) {
    EntityManager em = null;
    try {
      em = createNewEntityManager();
      final Query query = em.createNativeQuery(sql);
      if (params != null) {
        for (int i = 0; i < params.length; i++) {
          query.setParameter(i + 1, params[i]);
        }
      }
      final List< ? > ls = query.getResultList();
      Object result = null;
      if (ls != null && ls.size() > 0) {
        result = ls.get(0);
      }
      return result;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
  }

  /**
   * Gets scalar value.
   * 
   * @param sql
   *          the sql
   * @param params
   *          the params
   * @return scalar value as object.
   */
  public Object getScalarValue2(final String sql, final Map<String, Object> params) {
    EntityManager em = null;
    try {
      em = createNewEntityManager();
      final Query query = em.createNativeQuery(sql);
      if (params != null) {
        setParameters(query, params);
      }
      final List< ? > ls = query.getResultList();
      Object result = null;
      if (ls != null && ls.size() > 0) {
        result = ls.get(0);
      }
      return result;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
  }

  /**
   * Gets Next value of sequence.
   * 
   * @param seqName
   *          the seq name
   * @return next value of sequence
   */
  public Long getSequence(final String seqName) {
    EntityManager em = null;
    Long nextValue = null;
    try {
      // You should be in a JPA transaction to access the Connection.
      // Otherwise, you will be responsible for releasing the connection.
      em = createNewEntityManagerAndTransaction();
      final Object delegate = em.getDelegate();
      if (delegate instanceof Session) {
        final Session session = (Session) delegate;
        final KeysWork keysWork = new KeysWork(seqName);
        session.doWork(keysWork);
        nextValue = keysWork.getNextValue();
        // commit transaction
        em.getTransaction().commit();
      } else {
        final Connection connection = em.unwrap(java.sql.Connection.class);
        final KeyGenerator keyGenerator = new KeyGeneratorImpl(connection, seqName, 1);
        nextValue = keyGenerator.nextKey();
        // commit transaction
        em.getTransaction().commit();
      }
    } catch (final RuntimeException e) {
      rollBackTransaction(em);
      throw e;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
    return nextValue;
  }

  /**
   * Gets sysdate from database.
   * 
   * @return sysdate
   */
  public Timestamp getSysDate() {
    EntityManager em = null;
    try {
      em = createNewEntityManager();
      String sql = "select sysdate from dual";
      if (databaseType == DatabaseType.MYSQL) {
        // MySQL
        sql = "SELECT SYSDATE()";
      }
      final Query query = em.createNativeQuery(sql);
      final Object obj = query.getResultList().get(0);
      return (Timestamp) obj;
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
  }

  /**
   * Gets value in timestamp.
   * 
   * @param sql
   *          the sql
   * @param params
   *          the params
   * @return value in timestamp format
   */
  public Timestamp getTimestampValue(final String sql, final Object[] params) {
    final Object value = getScalarValue(sql, params);
    if (value instanceof Timestamp) {
      return (Timestamp) value;
    }
    return null;
  }

  /**
   * Initialize.
   */
  private void initialize() {
    final String databaseDriver = getDatabaseDriver();
    if (databaseDriver != null && databaseDriver.toLowerCase().indexOf("mysql") != -1) {
      databaseType = DatabaseType.MYSQL;
      codec = new MySQLCodec(Mode.STANDARD);
    } else {
      databaseType = DatabaseType.ORACLE;
      codec = new OracleCodec();
    }
  }

  /**
   * Merges entities into database.
   * 
   * @param entities
   *          the entities
   * @return rows affected
   */
  public int mergeEntities(final Object... entities) {
    final TranProcessor processor = new EntityProcessor(entities, EntityProcessor.TYPE_MERGE);
    return execTran(processor);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#query(java.lang.String,
   *      java.lang.Class, java.util.Map)
   */
  @SuppressWarnings({"unchecked", "rawtypes" })
  public <E> List<E> query(String sql, final Class<E> entityClass,
      final Map<String, Object> params) {
    EntityManager em = null;
    List<E> result = new ArrayList<E>();
    try {
      em = createNewEntityManager();
      Query query = null;
      if (entityClass != null) {
        query = em.createNativeQuery(sql, entityClass);
      } else {
        query = em.createQuery(sql);
      }
      if (params != null) {
        for (final Entry<String, Object> entry : params.entrySet()) {
          final String key = entry.getKey();
          final Object value = entry.getValue();
          if (value instanceof List) {
            StringBuilder valueToPass = new StringBuilder();
            final List ls = (List) value;
            for (final Object obj : ls) {
              if (obj instanceof String) {
                valueToPass.append("'" + Encoder.encodeForSQL(getDBCodec(), obj.toString())
                    + "'");
              } else {
                valueToPass.append(Encoder.encodeForSQL(getDBCodec(), obj.toString()));
              }
              valueToPass.append(",");
            }
            valueToPass = valueToPass.deleteCharAt(valueToPass.length() - 1);
            sql = sql.replaceAll(":" + key, valueToPass.toString());
            if (entityClass != null) {
              query = em.createNativeQuery(sql, entityClass);
            } else {
              query = em.createNativeQuery(sql);
            }
          } else if (value != null && value.getClass().isArray()) {
            StringBuilder valueToPass = new StringBuilder();
            final Object[] arr = (Object[]) value;
            for (final Object obj : arr) {
              if (obj instanceof String) {
                valueToPass.append("'" + Encoder.encodeForSQL(getDBCodec(), obj.toString())
                    + "'");
              } else {
                valueToPass.append(Encoder.encodeForSQL(getDBCodec(), obj.toString()));
              }
              valueToPass.append(",");
            }
            valueToPass = valueToPass.deleteCharAt(valueToPass.length() - 1);
            sql = sql.replaceAll(":" + key, valueToPass.toString());
            if (entityClass != null) {
              query = em.createNativeQuery(sql, entityClass);
            } else {
              query = em.createNativeQuery(sql);
            }
          } else {
            query.setParameter(key, value);
          }
        }
      }
      result = query.getResultList();
    } finally {
      if (em != null && em.isOpen()) {
        em.close();
      }
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#query(java.lang.String,
   *      java.lang.Class, java.util.Map, int, int)
   */
  @SuppressWarnings("unchecked")
  public <E> List<E> query(final String sql, final Class<E> entityClass,
      final Map<String, Object> params, final int startPosition, final int maxResult) {
    List<E> result = Collections.emptyList();
    if (sql != null && !"".equals(sql.trim())) {
      EntityManager em = null;
      try {
        em = createNewEntityManager();
        final Query query = em.createNativeQuery(sql, entityClass);
        if (query != null) {
          setParameters(query, params);
          if (startPosition != -1) {
            query.setFirstResult(startPosition);
          }
          if (maxResult != -1) {
            query.setMaxResults(maxResult);
          }
          result = query.getResultList();
        }
      } finally {
        if (em != null && em.isOpen()) {
          em.close();
        }
      }
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#query(java.lang.String, java.util.Map,
   *      java.lang.String)
   */
  @SuppressWarnings("rawtypes")
  public List query(final String sql, final Map<String, Object> params, final String columnName) {
    return query(sql, params, new String[]{columnName });
  }

  public List<Object[]> query(final String sql, final Map<String, Object> params,
      final String[] columnNames) {
    return query(sql, params, columnNames, -1, -1);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#query(java.lang.String, java.util.Map,
   *      java.lang.String[])
   */
  @SuppressWarnings("unchecked")
  public List<Object[]> query(final String sql, final Map<String, Object> params,
      final String[] columnNames, final int firstResult, final int maxResult) {
    EntityManager em = factory.createEntityManager();
    List<Object[]> result = new ArrayList<Object[]>();
    try {
      final Session session = (Session) em.getDelegate();
      final SQLQuery query = session.createSQLQuery(sql);
      if (params != null) {
        for (final Entry<String, Object> entry : params.entrySet()) {
          query.setParameter(entry.getKey(), entry.getValue());
        }
      }
      for (String colName : columnNames) {
        query.addScalar(colName, Hibernate.STRING);
      }
      if (firstResult > -1 && maxResult > -1) {
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResult);
      }
      result = query.list();
    } catch (RuntimeException e) {
      throw new PersistenceException(e);
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#queryList(java.util.List,
   *      java.lang.Class, java.util.List)
   */
  public <E> List<E> queryList(final List<String> sqls, final Class<E> classEntity,
      final List<Map<String, Object>> params) {
    final List<E> list = new ArrayList<E>();
    if (sqls != null && params != null) {
      final Iterator<String> sqlIter = sqls.iterator();
      final Iterator<Map<String, Object>> paramIter = params.iterator();
      while (sqlIter.hasNext() && paramIter.hasNext()) {
        final String sql = sqlIter.next();
        final Map<String, Object> param = paramIter.next();
        final List<E> resultList = query(sql, classEntity, param);
        if (resultList != null && resultList.size() > 0) {
          list.addAll(resultList);
        }
      }
    }
    return list;
  }

  /**
   * Rolls back the transaction.
   * 
   * @param em
   *          the em
   */
  private void rollBackTransaction(final EntityManager em) {
    if (em != null && em.getTransaction() != null && em.getTransaction().isActive()) {
      em.getTransaction().rollback();
    }
  }

  /**
   * Bind arguments to a named parameters of query.
   * 
   * @param query
   *          for executing a named query
   * @param param
   *          map an arguments of named parameters
   */
  private void setParameters(final Query query, final Map<String, Object> param) {
    if (query != null && param != null) {
      for (final Entry<String, Object> entry : param.entrySet()) {
        query.setParameter(entry.getKey(), entry.getValue());
      }
    }
  }

  /**
   * Updates entities into database.
   * 
   * @param entities
   *          the entities
   * @return rows affected
   */
  public int updateEntities(final Object... entities) {
    final TranProcessor processor = new EntityProcessor(entities, EntityProcessor.TYPE_UPDATE);
    return execTran(processor);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.persistence.SQLExecutor#getDatabaseType()
   */
  public DatabaseType getDatabaseType() {
    return databaseType;
  }
}
