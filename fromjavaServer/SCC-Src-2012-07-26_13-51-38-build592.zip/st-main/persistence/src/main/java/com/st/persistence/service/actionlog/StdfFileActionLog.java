/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 14, 2011 3:53:59 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.persistence.service.actionlog;

/**
 * The Class StdfFileActionLog.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class StdfFileActionLog {

  /** The Constant STDF_FILE_ACTION_LOG_KEY. */
  public static final String STDF_FILE_ACTION_LOG_KEY = "StdfFileActionLog";
  
  /** The Constant EXTRACTOR_NAME_KEY. */
  public static final String EXTRACTOR_NAME_KEY = "ExtractorName";

  /** The file name. */
  private String fileName;

  /** The file size. */
  private long fileSize;

  /** The wafer id. */
  private String waferId;

  /** The product id. */
  private String productId;

  /** The version. */
  private String version;

  /** The operation. */
  private String operation;

  /** The tester. */
  private String tester;

  /** The test prog name. */
  private String testProgName;

  /** The parsed result. */
  private String parsedResult;

  /** The error message. */
  private String errorMessage;

  /**
   * Gets the error message.
   * 
   * @return the error message
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * Gets the file name.
   * 
   * @return the file name
   */
  public String getFileName() {
    return fileName;
  }

  /**
   * Gets the file size.
   * 
   * @return the file size
   */
  public long getFileSize() {
    return fileSize;
  }

  /**
   * Gets the operation.
   * 
   * @return the operation
   */
  public String getOperation() {
    return operation;
  }

  /**
   * Gets the parsed result.
   * 
   * @return the parsed result
   */
  public String getParsedResult() {
    return parsedResult;
  }

  /**
   * Gets the product id.
   * 
   * @return the product id
   */
  public String getProductId() {
    return productId;
  }

  /**
   * Gets the tester.
   * 
   * @return the tester
   */
  public String getTester() {
    return tester;
  }

  /**
   * Gets the test prog name.
   * 
   * @return the test prog name
   */
  public String getTestProgName() {
    return testProgName;
  }

  /**
   * Gets the version.
   * 
   * @return the version
   */
  public String getVersion() {
    return version;
  }

  /**
   * Gets the wafer id.
   * 
   * @return the wafer id
   */
  public String getWaferId() {
    return waferId;
  }

  /**
   * Sets the error message.
   * 
   * @param errorMessage
   *          the new error message
   */
  public void setErrorMessage(final String errorMessage) {
    this.errorMessage = errorMessage;
  }

  /**
   * Sets the file name.
   * 
   * @param fileName
   *          the new file name
   */
  public void setFileName(final String fileName) {
    this.fileName = fileName;
  }

  /**
   * Sets the file size.
   * 
   * @param fileSize
   *          the new file size
   */
  public void setFileSize(final long fileSize) {
    this.fileSize = fileSize;
  }

  /**
   * Sets the operation.
   * 
   * @param operation
   *          the new operation
   */
  public void setOperation(final String operation) {
    this.operation = operation;
  }

  /**
   * Sets the parsed result.
   * 
   * @param parsedResult
   *          the new parsed result
   */
  public void setParsedResult(final String parsedResult) {
    this.parsedResult = parsedResult;
  }

  /**
   * Sets the product id.
   * 
   * @param productId
   *          the new product id
   */
  public void setProductId(final String productId) {
    this.productId = productId;
  }

  /**
   * Sets the tester.
   * 
   * @param tester
   *          the new tester
   */
  public void setTester(final String tester) {
    this.tester = tester;
  }

  /**
   * Sets the test prog name.
   * 
   * @param testProgName
   *          the new test prog name
   */
  public void setTestProgName(final String testProgName) {
    this.testProgName = testProgName;
  }

  /**
   * Sets the version.
   * 
   * @param version
   *          the new version
   */
  public void setVersion(final String version) {
    this.version = version;
  }

  /**
   * Sets the wafer id.
   * 
   * @param waferId
   *          the new wafer id
   */
  public void setWaferId(final String waferId) {
    this.waferId = waferId;
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder(256);
    sb.append(fileName);
    sb.append(", size: ").append(fileSize);
    if (waferId != null) {
      sb.append(", WAFER ID: ").append(waferId);
    }
    if (productId != null) {
      sb.append(", Product: ").append(productId);
    }
    if (version != null) {
      sb.append(", Version: ").append(version);
    }
    if (operation != null) {
      sb.append(", Operation: ").append(operation);
    }
    if (tester != null) {
      sb.append(", Tester: ").append(tester);
    }
    if (testProgName != null) {
      sb.append(", Test Program Name=").append(testProgName);
    }
    sb.append(", ").append(parsedResult);
    if (errorMessage != null) {
      sb.append(", Error Message: ").append(errorMessage);
    }
    return sb.toString();
  }

}
