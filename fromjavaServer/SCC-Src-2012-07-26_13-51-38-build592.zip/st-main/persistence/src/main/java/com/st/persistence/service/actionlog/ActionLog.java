/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 10, 2011 4:59:18 PM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence.service.actionlog;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.persistence.DatabaseType;
import com.st.persistence.SQLExecutor;
import com.st.persistence.entity.ActionTrackingEntity;

/**
 * The Class ActionLogUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ActionLog {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ActionLog.class);

  /** The Constant TRACKING_TABLE_NAME. */
  private static final String TRACKING_TABLE_NAME = "USABILITY_TRACKING";

  /** The Constant TRACKING_TABLE_SEQ. */
  private static final String TRACKING_TABLE_SEQ = "SEQ_TRACKING_ID";

  /** The Constant INSTANCE. */
  private static final ActionLog INSTANCE = new ActionLog();

  private static final int MAX_SIZE_PARAMETERS = 1024;
  
  /**
   * Gets the single instance of ActionLog.
   * 
   * @return single instance of ActionLog
   */
  public static ActionLog getInstance() {
    return INSTANCE;
  }

  /** The map exist. */
  private final Map<String, Boolean> mapExist = new HashMap<String, Boolean>(10);

  /** The action tracking thread pool. */
  private final ExecutorService actionTrackingThreadPool;

  /**
   * Instantiates a new action log.
   */
  private ActionLog() {
    actionTrackingThreadPool = Executors.newFixedThreadPool(2);
  }

  /**
   * Check tracking table exist or not.
   * 
   * @param exe
   *          the exe
   * @return true if the table is exist in db, otherwise return false.
   */
  private boolean checkTrackingTable(final SQLExecutor exe) {
    String sql = null;
    if(exe == null){
      LOG.info("Don't write action becaulse SQLExecutor is null");
      return false;
    }
    if (exe.getDatabaseType() == DatabaseType.ORACLE) {
      sql =
          "select count(*) from user_tables where upper(table_name) = '" + TRACKING_TABLE_NAME
              + "' ";
    } else {
      sql =
          "SELECT COUNT(*) FROM information_schema.tables where UPPER(table_name) = '"
              + TRACKING_TABLE_NAME + "'";
    }
    final BigDecimal result = exe.getNumberValue(sql, new Object[0]);
    if (result != null) {
      if (result.longValue() > 0) {
        return true;
      }
    }
    return false;
  }

  /**
   * Check tracking table exist or not.
   * 
   * @param exe
   *          the exe
   * @param dbName
   *          the db name
   * @return true if the table is exist in db, otherwise return false.
   */
  private synchronized boolean checkTrackingTable(final SQLExecutor exe, final String dbName) {
    if (dbName != null && dbName.trim().length() > 0) {
      if (mapExist.get(dbName) == null) {
        final boolean exist = checkTrackingTable(exe);
        mapExist.put(dbName, exist);
        return exist;
      } else {
        return mapExist.get(dbName);
      }
    } else {
      return checkTrackingTable(exe);
    }
  }

  /**
   * Close tracking thread pool.
   */
  public void closeTracking() {
    if (actionTrackingThreadPool != null) {
      actionTrackingThreadPool.shutdown();
      try {
        actionTrackingThreadPool.awaitTermination(2, TimeUnit.SECONDS);
      } catch (final InterruptedException e) {
        // Ignore exception
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
  }

  /**
   * insert data into tracking table.
   * 
   * @param dbName
   *          the db name
   * @param exe
   *          the exe
   * @param action
   *          the action
   */
  public void insertTracking(final String dbName, final SQLExecutor exe,
      final ActionTrackingEntity action) {
    final Runnable task = new Runnable() {
      public void run() {
        try {
          if (checkTrackingTable(exe, dbName)) {
            final Long id = exe.getSequence(TRACKING_TABLE_SEQ);
            action.setTrackingId(id);
            action.setUpdatedOn(exe.getSysDate());
            String param = checkLengthParameter(action.getParameters());
            action.setParameters(param);
            exe.addEntities(action);
          }
        } catch (final Throwable e) {
          LOG.error(e.getMessage(), e);
        }
      }
    };
    try {
      actionTrackingThreadPool.execute(task);
    } catch (final Exception e) {
      // Ignore exception
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    }
  }

  /**
   * insert data into tracking table.
   * 
   * @param dbName
   *          the db name
   * @param exe
   *          the exe
   * @param author
   *          the author
   * @param action
   *          the action
   * @param elapsedTime
   *          the elapsed time
   * @param parameters
   *          the parameters
   */
  public void insertTracking(final String dbName, final SQLExecutor exe, final String author,
      final String action, final long elapsedTime, final String parameters) {

    final Runnable task = new Runnable() {
      public void run() {
        try {
          if (checkTrackingTable(exe, dbName)) {
            final StringBuilder sql = new StringBuilder();
            String param = checkLengthParameter(parameters);
            
            sql.append("insert into ").append(TRACKING_TABLE_NAME);
            sql.append("(tracking_id, author, action, elapsed_time, parameters, updated_on) ");
            sql.append(" values(?,?,?,?,?,?)");
            exe.executeSQL(sql.toString(), new Object[]{exe.getSequence(TRACKING_TABLE_SEQ),
                author, action, elapsedTime, param, exe.getSysDate() });
          }
        } catch (final Throwable e) {
          LOG.error(e.getMessage(), e);
        }
      }
    };
    try {
      actionTrackingThreadPool.execute(task);
    } catch (final Exception e) {
      // Ignore exception
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    }
  }

  /**
   * Update tracking.
   * 
   * @param dbName
   *          the db name
   * @param exe
   *          the exe
   * @param action
   *          the action
   */
  public void updateTracking(final String dbName, final SQLExecutor exe,
      final ActionTrackingEntity action) {
    final Runnable task = new Runnable() {
      public void run() {
        try {
          if (checkTrackingTable(exe, dbName)) {
            String param = checkLengthParameter(action.getParameters());
            action.setParameters(param);
            exe.mergeEntities(action);
          }
        } catch (final Throwable e) {
          LOG.error(e.getMessage(), e);
        }
      }
    };
    try {
      actionTrackingThreadPool.execute(task);
    } catch (final Exception e) {
      // Ignore exception
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    }
  }

  private static String checkLengthParameter(final String param) {
    if (param != null) {
      if (param.length() > MAX_SIZE_PARAMETERS) {
        return param.substring(0, MAX_SIZE_PARAMETERS);
      }
    }
    return param;
  }
}
