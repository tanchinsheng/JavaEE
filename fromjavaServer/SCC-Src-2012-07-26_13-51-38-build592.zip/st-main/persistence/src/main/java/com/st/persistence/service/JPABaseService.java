/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 17, 2011 9:01:56 AM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.st.persistence.SQLExecutor;
import com.st.persistence.SQLExecutorJpaImpl;

/**
 * The Class JPA base service.
 * 
 * @param <T>
 *          the generic type
 */
public class JPABaseService<T> {

  /** The entity manager factory. */
  private EntityManagerFactory entityManagerFactory;

  /**
   * Creates the SQL executor.
   * 
   * @return the SQL executor
   */
  public SQLExecutor createSQLExecutor() {
    return new SQLExecutorJpaImpl(entityManagerFactory);
  }

  /**
   * Gets the entity manager factory.
   * 
   * @return the entity manager factory
   */
  public EntityManagerFactory getEntityManagerFactory() {
    return entityManagerFactory;
  }

  /**
   * Merge the object to {@link EntityManager} context.
   * 
   * @param object
   *          the object
   * @return the t
   */
  public T merge(final T object) {
    T entity = null;
    final EntityManager em = entityManagerFactory.createEntityManager();
    try {
      em.getTransaction().begin();
      entity = em.merge(object);
      em.getTransaction().commit();
    } catch (final PersistenceException e) {
      em.getTransaction().rollback();
      throw e;
    } finally {
      em.close();
    }
    return entity;
  }

  /**
   * Persist entity.
   * 
   * @param entity
   *          the entity
   */
  public void persist(final T entity) {
    final EntityManager em = entityManagerFactory.createEntityManager();
    try {
      em.getTransaction().begin();
      em.persist(entity);
      em.getTransaction().commit();
    } catch (final PersistenceException e) {
      em.getTransaction().rollback();
      throw e;
    } finally {
      em.close();
    }
  }

  /**
   * Query list.
   * 
   * @param queryName
   *          the query name
   * @param parameters
   *          the parameters
   * @param startPosition
   *          the start position
   * @param maxResult
   *          the max result
   * @return the list
   */
  @SuppressWarnings("unchecked")
  public List<T> queryList(final String queryName, final Map<String, Object> parameters,
      final int startPosition, final int maxResult) {
    List<T> list = new ArrayList<T>();
    final EntityManager em = getEntityManagerFactory().createEntityManager();
    final Query query = em.createNamedQuery(queryName);
    if (startPosition > -1) {
      query.setFirstResult(startPosition);
    }
    if (maxResult > -1) {
      query.setMaxResults(maxResult);
    }
    if (parameters != null && parameters.size() > 0) {
      for (final Entry<String, Object> entry : parameters.entrySet()) {
        query.setParameter(entry.getKey(), entry.getValue());
      }
    }
    list = query.getResultList();
    em.clear();
    em.close();
    return list;
  }

  /**
   * Removes the entity from database.
   * 
   * @param entity
   *          the entity
   */
  public void remove(final T entity) {
    final EntityManager em = entityManagerFactory.createEntityManager();
    try {
      em.getTransaction().begin();
      em.remove(entity);
      em.getTransaction().commit();
    } catch (final PersistenceException e) {
      em.getTransaction().rollback();
      throw e;
    } finally {
      em.close();
    }
  }

  /**
   * Sets the entity manager factory.
   * 
   * @param entityManagerFactory
   *          the new entity manager factory
   */
  public void setEntityManagerFactory(final EntityManagerFactory entityManagerFactory) {
    this.entityManagerFactory = entityManagerFactory;
  }
}
