/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 2, 2011 10:49:01 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.persistence.util;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * The Class EntityManagerUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class EntityManagerUtils {

  /** The map entity manager factory. */
  private static Map<String, EntityManagerFactory> mapEntityManagerFactory =
      new HashMap<String, EntityManagerFactory>();

  /** The Constant MAX_FACTORY. */
  private static final int MAX_FACTORY = 10;

  /**
   * Get entity manager from an EntityManagerFactory.
   * 
   * @param factory
   *          entity manager factory.
   * @return the entity manager
   */
  public static EntityManager createEntityManager(final EntityManagerFactory factory) {
    return factory.createEntityManager();
  }

  /**
   * Create an new EntityManagerFactory.
   * 
   * @param persistenceUnitName
   *          the persistence unit name
   * @param map
   *          the map
   * @return the entity manager factory
   */
  private static EntityManagerFactory createEntityManagerFactory(
      final String persistenceUnitName, final Map<String, String> map) {
    EntityManagerFactory factory = null;
    if (map != null) {
      factory = Persistence.createEntityManagerFactory(persistenceUnitName, map);
    } else {
      factory = Persistence.createEntityManagerFactory(persistenceUnitName);
    }
    if (mapEntityManagerFactory.size() < MAX_FACTORY) {
      // Store factory of persistence name.
      mapEntityManagerFactory.put(persistenceUnitName, factory);
    }
    return factory;
  }

  /**
   * Get an EntityManagerFactory of the persistence unit name. If
   * EntityManagerFactory of the persistence unit name was not created before,
   * we will create new object. Otherwise, get the already created object in
   * map.
   * 
   * @param persistenceUnitName
   *          the persistence unit name
   * @return EntityManagerFactory
   */
  public static EntityManagerFactory getEntityManagerFactory(final String persistenceUnitName) {
    return getEntityManagerFactory(persistenceUnitName, null);
  }

  /**
   * Gets the entity manager factory.
   * 
   * @param persistenceUnitName
   *          the persistence unit name
   * @param map
   *          the map
   * @return the entity manager factory
   */
  public static EntityManagerFactory getEntityManagerFactory(final String persistenceUnitName,
      final Map<String, String> map) {
    EntityManagerFactory factory = mapEntityManagerFactory.get(persistenceUnitName);
    if (factory == null) {
      synchronized (EntityManagerUtils.class) {
        factory = mapEntityManagerFactory.get(persistenceUnitName);
        if (factory == null) {
          factory = createEntityManagerFactory(persistenceUnitName, map);
        }
      }
    }
    return factory;
  }

  /**
   * Instantiates a new entity manager utils.
   */
  private EntityManagerUtils() {

  }
}
