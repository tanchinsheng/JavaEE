/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 10, 2011 11:56:24 AM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.st.persistence.entity.enums.FileStatus;
import com.st.persistence.entity.enums.FileTypeEntityEnum;

/**
 * The persistent class for the PARSE_FILE_STATUS database table.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
@MappedSuperclass
public class ParseFileStatus implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 8310349604460294265L;

  /** The file id. */
  @Id
  @Column(name = "PARSE_FILE_ID")
  private Long fileId;

  /** The path root. */
  @Column(name = "PATH_ROOT")
  private String pathRoot;

  /** The path file name. */
  @Column(name = "PATH_FILE_NAME")
  private String pathFileName;

  /** The status. */
  @Column(name = "FILE_STATUS")
  @Enumerated(EnumType.STRING)
  private FileStatus status;

  /** The description. */
  @Column(name = "STATUS_DESCRIPTION")
  private String description;

  /** The modified date. */
  @Column(name = "MODIFIED_DATE")
  private Timestamp modifiedDate;

  /** The file type. */
  @Column(name = "SOURCE_FILE_TYPE")
  @Enumerated(EnumType.STRING)
  private FileTypeEntityEnum fileType;

  /** The host. */
  @Column(name = "SOURCE_HOST")
  private String host;

  /** The user name. */
  @Column(name = "SOURCE_USERNAME")
  private String userName;

  /** The password. */
  @Column(name = "SOURCE_PASSWORD")
  private String password;

  /** The port. */
  @Column(name = "SOURCE_PORT")
  private Integer port;

  /** The updated on. */
  @Column(name = "UPDATED_ON")
  private Timestamp updatedOn;

  /** The server id. */
  @Column(name = "SERVER_ID")
  private String serverId;

  /** The version. */
  @Version
  private int version;

  /** The force update. */
  @Transient
  private boolean forceUpdate;

  /**
   * Instantiates a new STDF parse status.
   */
  public ParseFileStatus() {
  }

  /**
   * Gets the description.
   * 
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets the file id.
   * 
   * @return the file id
   */
  public Long getFileId() {
    return fileId;
  }

  /**
   * Gets the file type.
   * 
   * @return the file type
   */
  public FileTypeEntityEnum getFileType() {
    return fileType;
  }

  /**
   * Gets the host.
   * 
   * @return the host
   */
  public String getHost() {
    return host;
  }

  /**
   * Gets the modified date.
   * 
   * @return the modified date
   */
  public Timestamp getModifiedDate() {
    return modifiedDate;
  }

  /**
   * Gets the password.
   * 
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * Gets the path file name.
   * 
   * @return the path file name
   */
  public String getPathFileName() {
    return pathFileName;
  }

  /**
   * Gets the path root.
   * 
   * @return the path root
   */
  public String getPathRoot() {
    return pathRoot;
  }

  /**
   * Gets the port.
   * 
   * @return the port
   */
  public Integer getPort() {
    return port;
  }

  /**
   * Gets the server id.
   * 
   * @return the server id
   */
  public String getServerId() {
    return serverId;
  }

  /**
   * Gets the status.
   * 
   * @return the status
   */
  public FileStatus getStatus() {
    return status;
  }

  /**
   * Gets the updated on.
   * 
   * @return the updated on
   */
  public Timestamp getUpdatedOn() {
    return updatedOn;
  }

  /**
   * Gets the user name.
   * 
   * @return the user name
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Gets the version.
   * 
   * @return the version
   */
  protected int getVersion() {
    return version;
  }

  /**
   * Checks if is force update.
   * 
   * @return true, if is force update
   */
  public boolean isForceUpdate() {
    return forceUpdate;
  }

  /**
   * Sets the description.
   * 
   * @param description
   *          the new description
   */
  public void setDescription(final String description) {
    this.description = description;
  }

  /**
   * Sets the file id.
   * 
   * @param fileId
   *          the new file id
   */
  public void setFileId(final Long fileId) {
    this.fileId = fileId;
  }

  /**
   * Sets the file type.
   * 
   * @param fileType
   *          the new file type
   */
  public void setFileType(final FileTypeEntityEnum fileType) {
    this.fileType = fileType;
  }

  /**
   * Sets the force update.
   * 
   * @param forceUpdate
   *          the new force update
   */
  public void setForceUpdate(final boolean forceUpdate) {
    this.forceUpdate = forceUpdate;
  }

  /**
   * Sets the host.
   * 
   * @param host
   *          the new host
   */
  public void setHost(final String host) {
    this.host = host;
  }

  /**
   * Sets the modified date.
   * 
   * @param modifiedDate
   *          the new modified date
   */
  public void setModifiedDate(final Timestamp modifiedDate) {
    this.modifiedDate = modifiedDate;
  }

  /**
   * Sets the password.
   * 
   * @param password
   *          the new password
   */
  public void setPassword(final String password) {
    this.password = password;
  }

  /**
   * Sets the path file name.
   * 
   * @param pathFileName
   *          the new path file name
   */
  public void setPathFileName(final String pathFileName) {
    this.pathFileName = pathFileName;
  }

  /**
   * Sets the path root.
   * 
   * @param pathRoot
   *          the new path root
   */
  public void setPathRoot(final String pathRoot) {
    this.pathRoot = pathRoot;
  }

  /**
   * Sets the port.
   * 
   * @param port
   *          the new port
   */
  public void setPort(final Integer port) {
    this.port = port;
  }

  /**
   * Sets the server id.
   * 
   * @param serverId
   *          the new server id
   */
  public void setServerId(final String serverId) {
    this.serverId = serverId;
  }

  /**
   * Sets the status.
   * 
   * @param status
   *          the new status
   */
  public void setStatus(final FileStatus status) {
    this.status = status;
  }

  /**
   * Sets the updated on.
   * 
   * @param updatedOn
   *          the new updated on
   */
  public void setUpdatedOn(final Timestamp updatedOn) {
    this.updatedOn = updatedOn;
  }

  /**
   * Sets the user name.
   * 
   * @param userName
   *          the new user name
   */
  public void setUserName(final String userName) {
    this.userName = userName;
  }

  /**
   * Sets the version.
   * 
   * @param version
   *          the new version
   */
  protected void setVersion(final int version) {
    this.version = version;
  }
}
