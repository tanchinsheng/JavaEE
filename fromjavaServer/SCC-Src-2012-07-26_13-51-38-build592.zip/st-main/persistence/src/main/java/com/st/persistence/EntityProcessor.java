/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 29, 2011 9:42:09 AM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All rights reserved.
 *
 */
public final class EntityProcessor implements TranProcessor {

	public static final int TYPE_MERGE = 1;
	public static final int TYPE_INSERT = 2;
	public static final int TYPE_UPDATE = 3;
	public static final int TYPE_DELETE = 4;

	private Object[] entities;
	private int type;

	/**
	 * Constructor init entities to merge into database.
	 * @param entities
	 */
	public EntityProcessor(final Object[] entities) {
		if (entities == null) {
			throw new NullPointerException(
					"Entities pass into constructor must not null");
		}
		this.entities = entities;
		this.type = TYPE_MERGE;
	}

	/**
	 * 
	 * Constructor
	 * @param entities
	 * @param type
	 */
	public EntityProcessor(final Object[] entities, final int type) {
		if (entities == null) {
			throw new NullPointerException(
					"Entities pass into constructor must not null");
		}
		this.entities = entities;
		this.type = type;
	}

	/**
	 * 
	 * Constructor
	 * @param entities
	 */
	public EntityProcessor(final List<Object> entities) {
		if (entities == null) {
			throw new NullPointerException(
					"Entities pass into constructor must not null");
		}
		this.entities = entities.toArray();
		this.type = TYPE_MERGE;
	}

	/**
	 * 
	 * Constructor
	 * @param entities
	 * @param type
	 */
	public EntityProcessor(final List<Object> entities, final int type) {
		if (entities == null) {
			throw new NullPointerException(
					"Entities pass into constructor must not null");
		}
		this.entities = entities.toArray();
		this.type = type;
	}
	/**
	 * {@inheritDoc}
	 * @see com.st.persistence.TranProcessor#update(org.hibernate.Session)
	 */
	public int update(final Session session) {
		int result = 0;
		if (entities != null && entities.length > 0) {
			for (Object obj : entities) {
				if (type == TYPE_INSERT) {
					session.save(obj);
				} else if (type == TYPE_DELETE) {
					session.delete(obj);
				} else if (type == TYPE_UPDATE) {
					session.update(obj);
				} else {
					session.merge(obj);
				}
				result += 1;
			}
		}
		return result;
	}
	
	 public int update(final EntityManager em) {
	    int result = 0;
	    if (entities != null && entities.length > 0) {
	      for (Object obj : entities) {
	        if (type == TYPE_INSERT) {
	          em.persist(obj);
	        } else if (type == TYPE_DELETE) {
	          em.remove(obj);
	        } else {
	          em.merge(obj);
	        }
	        result += 1;
	      }
	    }
	    return result;
	  }
}
