/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 10, 2011 11:56:24 AM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence.util;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The Class QueryParam.
 */
public final class QueryUtils {

  /** The Constant ID. */
  public static final String ID = "id";

  /** The Constant NAME. */
  public static final String NAME = "name";

  /**
   * Gets the big decimal.
   * 
   * @param val
   *          the value
   * @return the big decimal
   */
  public static BigDecimal getBigDecimal(final Object val) {
    BigDecimal retVal = null;
    if (val instanceof BigInteger) {
      retVal = new BigDecimal(((BigInteger) val));
    } else if (val instanceof BigDecimal) {
      retVal = (BigDecimal) val;
    } else if (val instanceof Number) {
      retVal = new BigDecimal(((Number) val).longValue());
    }
    return retVal;
  }

  /**
   * Instantiates a new query parameter.
   */
  private QueryUtils() {

  }
}
