/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 12, 2011 8:47:41 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.persistence.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The Class ActionTrackingEntity.
 */
@Entity
@Table(name = "USABILITY_TRACKING")
@NamedQueries({
    @NamedQuery(
        name = ActionTrackingEntity.SELECT_ALL_ORDER_BY_ID, 
        query = "FROM ActionTrackingEntity at ORDER BY at.trackingId DESC"),
    @NamedQuery(name = ActionTrackingEntity.SELECT_ALL, query = "FROM ActionTrackingEntity at") })
public class ActionTrackingEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 795109204495264454L;

  /** The Constant SELECT_ALL. */
  public static final String SELECT_ALL = "ActionTrackingEntity.SelectAll";

  /** The Constant SELECT_ALL_ORDER_BY_ID. */
  public static final String SELECT_ALL_ORDER_BY_ID =
      "ActionTrackingEntity.SelectAllOrderById";

  /** The tracking id. */
  @Id
  @Column(name = "TRACKING_ID")
  private Long trackingId;

  /** The author. */
  private String author;

  /** The action. */
  private String action;

  /** The elapsed time. */
  @Column(name = "ELAPSED_TIME")
  private Long elapsedTime;

  /** The parameters. */
  private String parameters;

  /** The updated on. */
  @Column(name = "UPDATED_ON")
  private Timestamp updatedOn;

  /**
   * Gets the action.
   * 
   * @return the action
   */
  public String getAction() {
    return action;
  }

  /**
   * Gets the author.
   * 
   * @return the author
   */
  public String getAuthor() {
    return author;
  }

  /**
   * Gets the elapsed time.
   * 
   * @return the elapsed time
   */
  public Long getElapsedTime() {
    return elapsedTime;
  }

  /**
   * Gets the parameters.
   * 
   * @return the parameters
   */
  public String getParameters() {
    return parameters;
  }

  /**
   * Gets the tracking id.
   * 
   * @return the tracking id
   */
  public Long getTrackingId() {
    return trackingId;
  }

  /**
   * Gets the updated on.
   * 
   * @return the updated on
   */
  public Timestamp getUpdatedOn() {
    return updatedOn;
  }

  /**
   * Sets the action.
   * 
   * @param action
   *          the new action
   */
  public void setAction(final String action) {
    this.action = action;
  }

  /**
   * Sets the author.
   * 
   * @param author
   *          the new author
   */
  public void setAuthor(final String author) {
    this.author = author;
  }

  /**
   * Sets the elapsed time.
   * 
   * @param elapsedTime
   *          the new elapsed time
   */
  public void setElapsedTime(final long elapsedTime) {
    this.elapsedTime = elapsedTime;
  }

  /**
   * Sets the parameters.
   * 
   * @param parameters
   *          the new parameters
   */
  public void setParameters(final String parameters) {
    this.parameters = parameters;
  }

  /**
   * Sets the tracking id.
   * 
   * @param trackingId
   *          the new tracking id
   */
  public void setTrackingId(final Long trackingId) {
    this.trackingId = trackingId;
  }

  /**
   * Sets the updated on.
   * 
   * @param updatedOn
   *          the new updated on
   */
  public void setUpdatedOn(final Timestamp updatedOn) {
    this.updatedOn = updatedOn;
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder(128);
    sb.append("ActionTrackingEntity [trackingId=").append(trackingId);
    sb.append(", author=").append(author);
    sb.append(", action=").append(action);
    sb.append(", elapsedTime=").append(elapsedTime);
    sb.append(", parameters=").append(parameters).append("]");
    return sb.toString();
  }

}
