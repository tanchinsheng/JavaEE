/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class KeyGeneratorImpl.
 */
public class KeyGeneratorImpl implements KeyGenerator {
  
  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(KeyGeneratorImpl.class);

  /** The conn. */
  private Connection conn;
  
  /** The key name. */
  private String keyName;
  
  /** The next id. */
  private long nextId;
  
  /** The max id. */
  private long maxId;
  
  /** The increment by. */
  private int incrementBy;

  /**
   * Instantiates a new key generator.
   *
   * @param conn the Connection
   * @param keyName the key name
   * @param incrementBy the increment by
   */
  public KeyGeneratorImpl(Connection conn, String keyName, int incrementBy) {
    this.conn = conn;
    this.keyName = keyName;
    // if incrementBy equals 5 then we can use nextKey method 5 times with only
    // one query database.
    this.incrementBy = incrementBy;
    this.nextId = this.maxId = 0;

    try {
      this.conn.setAutoCommit(false);
    } catch (SQLException e) {
      throw new RuntimeException("Cannot turn of auto commit");
    }
  }

  /**
   * Instantiates a new key generator.
   *
   * @param conn the Connection
   */
  public KeyGeneratorImpl(Connection conn) {
    this(conn, null, 1);
  }

  /**
   * {@inheritDoc}
   * @see com.st.persistence.KeyGenerator#nextKey()
   */
  public synchronized long nextKey() {
    if (this.keyName == null) {
      throw new NullPointerException("Key name is null.");
    }
    if (nextId == maxId) {
      try {
        reserveIds();
      } catch (SQLException e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return (nextId++);
  }

  /**
   * Reserve ids.
   *
   * @throws SQLException
   */
  private void reserveIds() throws SQLException{
    PreparedStatement ps = null;
    PreparedStatement insertPS = null;
    ResultSet rs = null;
    long newNextId = 0;
    try {
      // Locks set by FOR UPDATE reads is released when the transaction is
      // committed or rolled back.
      ps = conn.prepareStatement("select NEXT_VALUE from KEY_GENERATOR where KEY_NAME=? for update");
      ps.setString(1, this.keyName);
      rs = ps.executeQuery();

      if (rs.next()) {
        newNextId = rs.getLong(1);
      } else {
        // insert KEY_NAME into KEY_GENERATOR table.
        String insertCommand = "insert into KEY_GENERATOR(KEY_NAME, NEXT_VALUE) values(?, 1)";
        insertPS = conn.prepareStatement(insertCommand);
        insertPS.setString(1, this.keyName);
        insertPS.executeUpdate();
        
        newNextId = 1;
      }
    } finally {
      cleanup(ps, rs);
      cleanup(insertPS, null);
    }

    long newMaxId = newNextId + incrementBy;

    try {
      ps = conn.prepareStatement("update KEY_GENERATOR set NEXT_VALUE=? where KEY_NAME=?");
      ps.setLong(1, newMaxId);
      ps.setString(2, this.keyName);
      ps.executeUpdate();
      // commit connection
      conn.commit();

      nextId = newNextId;
      maxId = newMaxId;
    } finally {
      cleanup(ps, null);
    }
  }

  /**
   * Cleanup.
   *
   * @param statement the Statement
   * @param rs the ResultSet
   */
  private void cleanup(Statement statement, ResultSet rs) {
    try {
      if (statement != null) {
        statement.close();
      }
    } catch (SQLException e) {
    }
    try {
      if (rs != null) {
        rs.close();
      }
    } catch (SQLException e) {
    }
  }

  /**
   * {@inheritDoc}
   * @see com.st.persistence.KeyGenerator#setKeyName(java.lang.String)
   */
  public void setKeyName(String keyName) {
    this.keyName = keyName;
  }

  /**
   * {@inheritDoc}
   * @see com.st.persistence.KeyGenerator#setIncrementBy(int)
   */
  public void setIncrementBy(int incrementBy) {
    this.incrementBy = incrementBy;
  }

}
