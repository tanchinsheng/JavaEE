/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Apr 19, 2012 5:46:20 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.common.web.filter;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class URLFilter implements Filter {
  private static final Logger LOGGER = LoggerFactory.getLogger(URLFilter.class);
  
  private static String[] JS_SCRIPT_KEY = new String[]{"alert", "prompt", "confirm" };

  /*
   * These parameters do not check '<' and '>'
   */
  private static String[] PARAM_LIST_NOT_CHECK_LESS_GREATER = new String[]{"EXPRESSION_txt1" };
  
  private static String[] PARAM_LIST_NOT_CHECK_URL = new String[]{"umUrl_txt", "sc_url",
    "currentUrl",
    
    /*LiotroX parameter*/
    "lx_origURL" };

  private static String[] LX_PARAM_USE_EVENT = new String[]{"liotrox_event", "LX_BKM_EVT",
      "liotrox_page_event" };
  
  public String getComponentErrorPagePath() {
    return "";
  }

  public String getSecurityErrorPagePath() {
    return "";
  }
  
  /**
   * Check url is valid or not.
   * 
   * @param url
   * @return true if valid, otherwise false
   */
  private boolean checkURL(String url) {
    if (LOGGER.isDebugEnabled()) {
      LOGGER.debug("checkURL(), Url=" + url);
    }
    if (url == null || url.trim().length() == 0) {
      return false;
    }
    url = url.trim();
    // check URL extension
    if (url.indexOf(".lxp") != -1) {
      // make sure url extension is .lxp, not .lxpxxx
      if (!(url.endsWith(".lxp") || url.indexOf(".lxp?") != -1)) {
        return false;
      }
    }
    // check URL characters is valid or not
    char[] arr = url.toCharArray();
    boolean valid = true;
    int dotCount = 0;
    for (char c : arr) {
      if (c == '.') {
        dotCount++;
      }
      if (!Character.isLetterOrDigit(c)) {
        if (c != '/' && c != '.') {
          valid = false;
          break;
        }
      }
    }
    if (dotCount > 1 || valid == false) {
      return false;
    }
    return true;
  }
  
  private boolean checkEachCharacter(final char[] arr) {
    boolean valid = true;
    boolean startScript = false;
    boolean endScript = false;
    for (int i = 0; i < arr.length; i++) {
      char c = arr[i];      
      switch (c) {
      case '-':
        // check case: SQL injection: ex: delete from table --.
        // "--" is comment in SQL, it will comment all SQL after it.
        if (i + 1 < arr.length && arr[i + 1] == '-') {
          valid = false;
          LOGGER.info("The request contains value '--', which may cause to SQL injection.");
        }
        break;
      case '\'':
        valid = false;
        LOGGER.info("The request contains value \"'\", which may cause to SQL injection.");
        break;
      case '<':
        startScript = true;
        break;
      case '>':
        endScript = true;
        break;
      }
      if (startScript & endScript) {
        valid = false;
        LOGGER
            .info("The request contains value '<' and '>', which may cause to XSS security.");
      }

      //if request invalid, do not continue check.
      if (!valid) {
        break;
      }
    }
    return valid;
  }
  
  private boolean checkJSScript(String params) {
    if (params != null) {
      for (String v : JS_SCRIPT_KEY) {
        if (params.toLowerCase().indexOf(v) > -1) {
          LOGGER.info("The request contains word '" + v
              + "', which may cause to XSS security.");
          return false;
        }
      }
    }
    return true;
  }

  
  private boolean checkSecurityParameter(final String paramName, final String[] paramValues) {
    // step2: check value contain url or not
    boolean checkUrl = true;
    for (String name : PARAM_LIST_NOT_CHECK_URL) {
      if (name.equals(paramName)) {
        checkUrl = false;
        break;
      }
    }
    boolean notCheckGreaterAndLess = false;
    for (String name : PARAM_LIST_NOT_CHECK_LESS_GREATER) {
      if (name.equals(paramName)) {
        // do not check '<' , '>', we will remove them from value.
    	notCheckGreaterAndLess = true;       
        break;
      }
    }
    boolean valid = true;
    for (String v : paramValues) {
		if(notCheckGreaterAndLess){
			// do not check '<' , '>', 
			// we will remove them before call checkEachCharacter().
			 v = v.replace(">", "");
	         v = v.replace("<", "");
		}
      valid = checkEachCharacter(v.toCharArray()) & checkJSScript(v);
      if (!valid) {
        valid = false;
        break;
      }
      //check Url
      if(checkUrl){
        if (v.contains("http://") || v.contains("https://")) {
          valid = false;
          LOGGER.info("The request contains 'http' or 'https', which may cause to Link injection.");
          break;
        }
      }
    }
    if (!valid) {
      String s = "";
      for (int i = 0; i < paramValues.length; i++) {
        s += paramValues[i];
        if (i < paramValues.length - 1) {
          s += ";";
        }
      }
      LOGGER.info("Invalid request parameter : " + paramName + " = " + s);
    }
    return valid;
  }

  private boolean filterValueOfPostRequest(HttpServletRequest request, WRequest wRequest) {
    Map parameterMap = request.getParameterMap();
    boolean valid = true;
    if (parameterMap != null) {
      Set<Entry<String, String[]>> entrySet = parameterMap.entrySet();
      for (Entry<String, String[]> entry : entrySet) {
        String paramName = entry.getKey();
        // Step 1: check this parameter whether liotrox event or not
        String eventValue = null;
        for(String name : LX_PARAM_USE_EVENT){
          if (name.equals(paramName)) {
            eventValue = request.getParameter(name);
            break;
          }
        }
        if (eventValue != null) {
          Event e = Event.createFromString(wRequest, eventValue);
          Map<String, String> eventParams = e.getParameters();
          Set<Entry<String, String>> entrySet2 = eventParams.entrySet();
          for (Entry<String, String> entry2 : entrySet2) {
            valid = checkSecurityParameter(entry2.getKey(), new String[]{entry2.getValue() });
            if (!valid) {
              break;
            }
          }
        } else {
          valid = checkSecurityParameter(paramName, entry.getValue());
        }
        // the link is wrong, don't continue check
        if (!valid) {
          break;
        }
      }
    }
    return valid;
  }

  /**
   * Process invalid URL.
   * 
   * @param response
   */
  private void processInvalidURL(HttpServletResponse response, final String url) {
    LOGGER.info("Redirect to error page :" + url);
    try {
      response.sendRedirect(url);
    } catch (IOException e) {
      LOGGER.error(e.getMessage());
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.scc.webapp.filter.TemplateFilter#doPostProcessing(javax.servlet.ServletRequest,
   *      javax.servlet.ServletResponse)
   */
  public int doPostProcessing(ServletRequest request, ServletResponse response) {
    return 0;
  }

  /**
   * {@inheritDoc}
   * 
   * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
   */
  public void init(FilterConfig filterConfig) throws ServletException {
  }

  /**
   * {@inheritDoc}
   * 
   * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
   *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
   */
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    HttpServletRequest req = (HttpServletRequest) request;
    HttpServletResponse res = (HttpServletResponse) response;
    // Gets url from request
    String url = req.getRequestURI();
    String params = req.getQueryString();
    WRequest wRequest = new WRequest(req, (HttpServletResponse) response);
    // check url is valid or not
    boolean urlValid = checkURL(url);
    if (!urlValid) {
      LOGGER.error("URL is invalid: " + url + (params != null ? "?" + params : ""));
      // process invalid url
      processInvalidURL(res, getComponentErrorPagePath());
      return;
    }
    boolean securityValid = filterValueOfPostRequest(req, wRequest);
    if (!securityValid) {
      // process invalid url
      processInvalidURL(res, getSecurityErrorPagePath());
      return;
    }
    chain.doFilter(request, response);
  }
  
    
  /**
   * {@inheritDoc}
   * 
   * @see javax.servlet.Filter#destroy()
   */
  public void destroy() {
  }

}
