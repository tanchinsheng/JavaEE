/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 21, 2011 1:34:59 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common.web.util;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.Event;
import st.liotrox.WRequest;

/**
 * The Class ServletUtils.
 *
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 * rights reserved.
 */
public final class ServletUtils {
  
  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ServletUtils.class);

	/**
	 * Instantiates a new servlet utils.
	 */
	private ServletUtils() {
	}

	/**
	 * Escape text.
	 *
	 * @param str the str
	 * @return escaped text.
	 */
	public static String escapeText(final String str) {
		if (str == null || str.trim().length() == 0) {
			return "";
		}
		return StringEscapeUtils.escapeXml(str);
	}

  /**
   * Encode url.
   * 
   * @param url
   *          the url
   * @return the string
   */
  public static String encodeUrlParam(final Object url) {
    if (url == null) {
      return null;
    }
    try {
      return URLEncoder.encode(url.toString(), "UTF-8");
    } catch (UnsupportedEncodingException e) {
      LOG.error(e.getMessage(), e);
    }
    return "";
  }

  /**
   * Decode url.
   * 
   * @param url
   *          the url
   * @return the string
   */
  public static String decodeUrlParam(final Object url) {
    if (url == null) {
      return null;
    }
    try {
      return URLDecoder.decode(url.toString(), "UTF-8");
    } catch (UnsupportedEncodingException e) {
      LOG.error(e.getMessage(), e);
    }
    return "";
  }  

  /**
   * Write text content to PrintWriter.
   * 
   * @param writer
   *          the writer
   * @param tagName
   *          the tag name
   * @param content
   *          the content
   */
  public static void writeText(final PrintWriter writer, final String tagName, String content) {
    if (content == null) {
      content = "";
		}
		writer.write("<" + tagName + ">");
		writer.write(escapeText(content.trim()));
		writer.write("</" + tagName + ">");
	}

  /**
   * Write html content to PrintWriter.
   * 
   * @param writer
   *          the writer
   * @param tagName
   *          the tag name
   * @param content
   *          the content
   */
  public static void writeHTML(final PrintWriter writer, final String tagName, String content) {
		if (content == null) {
			content = "";
		}
		writer.write("<" + tagName + "><![CDATA[ ");
		writer.write(content.trim());
		writer.write(" ]]></" + tagName + ">");
	}

  /**
   * Generate page flow scope key.
   * 
   * @param request
   *          the request
   * @return page flow id
   * @throws NoSuchAlgorithmException
   *           the no such algorithm exception
   */
  public static synchronized String generatePageFlowId(final HttpServletRequest request)
      throws NoSuchAlgorithmException {
    HttpSession session = request.getSession();

    byte id[] = session.getId().getBytes();
    long current = System.currentTimeMillis();
    byte now[] = new Long(current).toString().getBytes();
    MessageDigest md = MessageDigest.getInstance("MD5");
    md.update(id);
    md.update(now);
    return TokenProcessor.toHex(md.digest());
  }

  /**
   * Redirect to chart page and attach page flow id to url parameter.
   * 
   * @param request
   *          the request
   * @param event
   *          the event
   * @param url
   *          the url
   */
  public static void redirectChartPage(final WRequest request, final Event event, String url) {
		if (url.indexOf("pageFlowId") == -1) {
			// add page flow scope key to url
      String pageFlowId = request.getParameter("pageFlowId");
      if (pageFlowId == null) {
        pageFlowId = event.getParameter("pageFlowId");
        if (pageFlowId == null) {
					//create new page flow scope id
					try {
						pageFlowId = generatePageFlowId(request.getHttpRequest());
					} catch (NoSuchAlgorithmException e) {
					  LOG.error(e.getMessage(), e);
					}
				}
			}
			url += "&pageFlowId=" + pageFlowId;
		}
		request.redirectTo(url);
	}

  /**
   * Gets value from pageFlowScope.
   * 
   * @param request
   *          the request
   * @param pageFlowId
   *          the page flow id
   * @param key
   *          the key
   * @return Object
   */
  public static Object getPageFlowScope(final HttpServletRequest request,
      final String pageFlowId, final String key) {
    String sessionKey = (pageFlowId == null ? "" : pageFlowId.trim()) + key;
    return request.getSession().getAttribute(sessionKey);
  }

  /**
   * Set value into pageFlowScope.
   * 
   * @param request
   *          the request
   * @param pageFlowId
   *          the page flow id
   * @param key
   *          the key
   * @param value
   *          the value
   */
  public static void setPageFlowScope(final HttpServletRequest request,
      final String pageFlowId, final String key, final Object value) {
    String sessionKey = (pageFlowId == null ? "" : pageFlowId.trim()) + key;
    request.getSession().setAttribute(sessionKey, value);
  }

  /**
   * Gets the view name.
   * 
   * @return the view name
   */
  public static String getViewName() {
    return getViewName(WRequest.getCurrentInstance().getSession());
  }

  /**
   * Gets the view name.
   * 
   * @param session
   *          the session
   * @return the view name
   */
  public static String getViewName(final HttpSession session) {
    String viewName = "V_TMP_" + session.getId();

    if (viewName.length() > 30) {
      viewName = viewName.substring(0, 30);
    }
    return viewName.toUpperCase();
  }

  /**
   * Gets the server IP.
   *
   * @return the server IP
   */
  public static String getServerIp() {
    try {
      InetAddress inet = InetAddress.getLocalHost();
      return inet.getHostAddress();
    } catch (UnknownHostException e) {
      LOG.error(e.getMessage(), e);
    }
    return "SERVER_ID";
  }
}
