/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 11, 2011 2:37:08 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common.web.util;

import java.text.ParseException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.web.LiotroxContants;
import com.st.persistence.DatabaseType;
import com.st.scc.common.utils.DateUtils;

/**
 * The Class DBFunctionConverter.
 */
public final class DBFunctionConverter {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(DBFunctionConverter.class);

  /** The Constant INSTANCE. */
  private static final DBFunctionConverter INSTANCE = new DBFunctionConverter();

  /** The Constant ORACLE_DATE_FORMAT. */
  private static final String ORACLE_DATE_FORMAT = "DD/MM/YYYY HH24:MI:SS";

  private static final String MYSQL_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

  /** The Constant JAVA_2_ORACLE_DATE_FORMAT. */
  private static final String JAVA_2_ORACLE_DATE_FORMAT = "dd/MM/yyyy HH:mm:ss";

  /** The Constant JAVA_2_MYSQL_DATE_FORMAT. */
  private static final String JAVA_2_MYSQL_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

  /** The Constant ONE_DAY_SECONDS. */
  public static final String ONE_DAY_SECONDS = "86400";

  /**
   * Gets the single instance of DBFunctionConverter.
   * 
   * @return single instance of DBFunctionConverter
   */
  public static DBFunctionConverter getInstance() {
    return INSTANCE;
  }

  /** The database type. */
  private DatabaseType databaseType;

  /**
   * Instantiates a new dB function converter.
   */
  private DBFunctionConverter() {
  }

  /**
   * Returns the number of days between two dates.
   * 
   * @param date1
   *          the date1
   * @param date2
   *          the date2
   * @return the string
   */
  public String dateDiff(String date1, String date2) {
    if (databaseType == DatabaseType.ORACLE) {
      if (date1.startsWith("'") && date1.endsWith("'")) {
        date1 = "to_date(" + date1 + ",'" + ORACLE_DATE_FORMAT + "')";
      }
      if (date2.startsWith("'") && date2.endsWith("'")) {
        date2 = "to_date(" + date2 + ",'" + ORACLE_DATE_FORMAT + "')";
      }
      return date1 + " - " + date2;
    } else {
      return "DATEDIFF(" + date1 + "," + date2 + ")";
    }
  }

  /**
   * Date to string.
   * 
   * @param date
   *          the date
   * @return the string
   */
  public String dateToString(final Date date) {
    if (databaseType == DatabaseType.ORACLE) {
      return "to_date('" + DateUtils.dateToString(date, JAVA_2_ORACLE_DATE_FORMAT) + "', '"
          + ORACLE_DATE_FORMAT + "')";
    } else {
      return "'" + DateUtils.dateToString(date, JAVA_2_MYSQL_DATE_FORMAT) + "'";
    }
  }

  public String getAppSimpleDateFormat() {
    if (databaseType == DatabaseType.ORACLE) {
      return "dd/MM/yyyy";
    } else {
      return "yyyy-MM-dd";
    }
  }

  /**
   * Gets the current time.
   * 
   * @return the current time
   */
  public String getCurrentTime() {
    if (databaseType == DatabaseType.MYSQL) {
      return "now()";
    }
    return "sysdate";
  }

  /**
   * return date with format of the database
   * 
   * @param date
   * @return formatted date as string.
   */
  public String getDateWithDBFormat(final String date) {
    if (databaseType == DatabaseType.ORACLE) {
      return date;
    } else {
      String dateWithFormat = null;
      try {
        dateWithFormat =
            DateUtils.timestampToString(
                DateUtils.stringToTimeStamp(date, LiotroxContants.DEFAULT_DATE_FORMAT
                    + " HH:mm:ss"), MYSQL_DATE_FORMAT);
      } catch (final ParseException e) {
        LOG.error(e.getMessage(), e);
      }
      return dateWithFormat;
    }
  }

  /**
   * Gets date format of the database.
   * 
   * @return date format.
   */
  public String getDBSimpleDateFormat() {
    if (databaseType == DatabaseType.ORACLE) {
      return "DD/MM/YYYY";
    } else {
      return "%Y-%m-%d";
    }
  }

  /**
   * @param databaseType
   *          the databaseType to set
   */
  public void setDatabaseType(final DatabaseType databaseType) {
    this.databaseType = databaseType;
  }

  /**
   * @param strDate
   * @param format
   * @return
   */
  public String toChar(final String strDate, final String format) {
    if (strDate == null) {
      return null;
    }
    if (databaseType == DatabaseType.ORACLE) {
      return "to_char(" + strDate + ", '" + format + "')";
    } else {
      return "DATE_FORMAT(" + strDate + ", '" + format + "')";
    }
  }

  /**
   * Convert strDate to date with the format.
   * 
   * @param strDate
   * @param format
   * @return formated date.
   */
  public String toDate(final String strDate, final String format) {
    if (strDate == null) {
      return null;
    }
    if (databaseType == DatabaseType.ORACLE) {
      return "to_date(" + strDate + ", '" + format + "')";
    } else {
      return "DATE_FORMAT(" + strDate + ", '" + format + "')";
    }
  }

  /**
   * The SQL function which return seconds since '1970-01-01 00:00:00'.
   * 
   * @param date
   *          the date
   * @return the sql function
   */
  public String toSeconds(final String date) {
    if (databaseType == DatabaseType.ORACLE) {
      if (date.startsWith("'") && date.endsWith("'")) {
        return "to_number(to_date(" + date + ",'" + ORACLE_DATE_FORMAT
            + "') - to_date('01/01/1970 00:00:00','" + ORACLE_DATE_FORMAT
            + "')) * (24 * 60 * 60) ";
      } else {
        return "to_number(to_date(to_char(" + date + ",'" + ORACLE_DATE_FORMAT + "'),'"
            + ORACLE_DATE_FORMAT + "') - to_date('01/01/1970 00:00:00','" + ORACLE_DATE_FORMAT
            + "')) * (24 * 60 * 60) ";
      }
    } else {
      return "UNIX_TIMESTAMP(" + date + ")";
    }
  }
}
