/*
 * $Id: NoCacheFilter.java 90 2011-03-07 22:06:02Z samaxes $
 *
 * Copyright 2011 samaxes.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.st.common.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Completely disable browser caching.
 *
 * @author Samuel Santos
 * @version $Revision$
 */
public class NoCacheFilter implements Filter {

//  private static final long  MAX_COOKIE_AGE = 10; // 10 seconds
//  private static final String OLD_COOKIE_PATTERN = "EEE, dd-MMM-yyyy HH:mm:ss z";
//  private static final ThreadLocal<DateFormat> OLD_COOKIE_FORMAT = new ThreadLocal<DateFormat>() {
//      protected DateFormat initialValue() {
//          final DateFormat df = new SimpleDateFormat(OLD_COOKIE_PATTERN, Locale.US);
//          df.setTimeZone(TimeZone.getTimeZone("GMT"));
//          return df;
//      }
//  };

    /**
     * Place this filter into service.
     *
     * @param filterConfig the filter configuration object used by a servlet container to pass information to a filter
     *        during initialization
     * @throws ServletException to inform the container to not place the filter into service
     */
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    /**
     * Set cache header directives.
     *
     * @param servletRequest provides data including parameter name and values, attributes, and an input stream
     * @param servletResponse assists a servlet in sending a response to the client
     * @param filterChain gives a view into the invocation chain of a filtered request
     */
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        final HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        final HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;


        // set cache directives
        httpServletResponse.setHeader(HTTPCacheHeader.CACHE_CONTROL.getName(), "no-cache, no-store, must-revalidate");
        httpServletResponse.setHeader(HTTPCacheHeader.PRAGMA.getName(), "no-cache");
        httpServletResponse.setDateHeader(HTTPCacheHeader.EXPIRES.getName(), 0L);

        // set cookie directives
        final HttpSession session = httpServletRequest.getSession();
        if (session != null) {
          final String sessionID = session.getId();

          if (sessionID != null && sessionID.trim().length() > 0) {
            final StringBuilder cookieBuilder = new StringBuilder(256);
            cookieBuilder.append("JSESSIONID=").append(sessionID);

//            final Date expiresDate = new Date(System.currentTimeMillis() + MAX_COOKIE_AGE*1000L);
//            final String strExpires = OLD_COOKIE_FORMAT.get().format(expiresDate);
//            cookieBuilder.append ("; Expires=").append(strExpires);

            cookieBuilder.append("; Path=").append(httpServletRequest.getContextPath());

            cookieBuilder.append("; HttpOnly");
            if (httpServletRequest.isSecure()) {
              cookieBuilder.append("; Secure");
            }

            httpServletResponse.setHeader("Set-Cookie", cookieBuilder.toString());
          }
        }

        filterChain.doFilter(servletRequest, servletResponse);
    }

    /**
     * Take this filter out of service.
     */
    public void destroy() {
    }
}

