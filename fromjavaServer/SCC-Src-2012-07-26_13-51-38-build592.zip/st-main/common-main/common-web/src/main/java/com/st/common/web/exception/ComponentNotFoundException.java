/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 30, 2011 6:39:16 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common.web.exception;


/**
 * The Class ComponentNotFoundException.
 *
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All rights reserved.
 */
public class ComponentNotFoundException extends RuntimeException {

	/** The Constant serialVersionUID. */
  private static final long serialVersionUID = 4704201540705672715L;

  /**
   * Instantiates a new component not found exception.
   */
  public ComponentNotFoundException() {
  }

  /**
   * Instantiates a new component not found exception.
   * 
   * @param message
   *            the message
   */
  public ComponentNotFoundException(final String message) {
    super(message);
  }

  /**
   * Instantiates a new component not found exception.
   * 
   * @param message
   *            the message
   * @param cause
   *            the cause
   */
  public ComponentNotFoundException(final String message, final Throwable cause) {
    super(message, cause);
  }

  /**
   * Instantiates a new component not found exception.
   * 
   * @param cause
   *            the cause
   */
  public ComponentNotFoundException(final Throwable cause) {
    super(cause);
  }
}
