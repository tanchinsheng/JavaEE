/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 28, 2012 6:25:40 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.web.liotrox.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.LiotroRuntimeException;
import st.liotrox.WRequest;
import st.liotrox.component.Component;
import st.liotrox.component.ComponentPath;
import st.liotrox.component.DefaultComponentManager;

import com.st.common.web.exception.ComponentNotFoundException;

/**
 * The Class CustomComponentManager.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class CustomComponentManager extends DefaultComponentManager {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(CustomComponentManager.class);

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.component.DefaultComponentManager#resolveComponent(st.liotrox.WRequest,
   *      st.liotrox.component.ComponentPath)
   */
  @Override
  public Component resolveComponent(final WRequest request, final ComponentPath cp) {
    try {
      return super.resolveComponent(request, cp);
    } catch (final LiotroRuntimeException e) {
      LOG.error(e.getMessage());
      throw new ComponentNotFoundException(e);
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.component.DefaultComponentManager#resolveComponent(st.liotrox.WRequest,
   *      java.lang.String)
   */
  @Override
  public Component resolveComponent(final WRequest request, final String path) {
    try {
      return super.resolveComponent(request, path);
    } catch (final LiotroRuntimeException e) {
      LOG.error(e.getMessage());
      throw new ComponentNotFoundException(e);
    }

  }
}
