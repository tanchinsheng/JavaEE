/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 8, 2011 2:11:45 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common.web.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import st.liotrox.WRequest;

/**
 * TokenProcessor is responsible for handling all token related functionality.
 * The methods in this class are synchronized to protect token processing from
 * multiple threads. Servlet containers are allowed to return a different
 * HttpSession object for two threads accessing the same session so it is not
 * possible to synchronize on the session.
 */
public class TokenProcessor {

	public static final String TRANSACTION_TOKEN_KEY = "TRANSACTION_TOKEN_KEY";
	public static final String TOKEN_KEY = "tokenKeyParam";
	public static final String TOKEN_IGNORE_VALUE = "token_ignore";
	public static final String TOKEN_IGNORE_KEY = "token_ignore_key";

	/**
	 * The singleton instance of this class.
	 */
	private static TokenProcessor instance = new TokenProcessor();

	/**
	 * Retrieves the singleton instance of this class.
	 */
	public static TokenProcessor getInstance() {
		return instance;
	}

	/**
	 * Protected constructor for TokenProcessor. Use
	 * TokenProcessor.getInstance() to obtain a reference to the processor.
	 */
	protected TokenProcessor() {
		super();
	}

	/**
	 * The timestamp used most recently to generate a token value.
	 */
	private long previous;

	/**
	 * Return <code>true</code> if there is a transaction token stored in the
	 * user's current session, and the value submitted as a request parameter
	 * with this action matches it. Returns <code>false</code> under any of the
	 * following circumstances:
	 * <ul>
	 * <li>No session associated with this request</li>
	 * <li>No transaction token saved in the session</li>
	 * <li>No transaction token included as a request parameter</li>
	 * <li>The included transaction token value does not match the transaction
	 * token in the user's session</li>
	 * </ul>
	 * 
	 * @param request
	 *            The servlet request we are processing
	 */
	public synchronized boolean isTokenValid(HttpServletRequest request) {
		return this.isTokenValid(request, false);
	}

	/**
	 * Return <code>true</code> if there is a transaction token stored in the
	 * user's current session, and the value submitted as a request parameter
	 * with this action matches it. Returns <code>false</code>
	 * <ul>
	 * <li>No session associated with this request</li>
	 * <li>No transaction token saved in the session</li>
	 * <li>No transaction token included as a request parameter</li>
	 * <li>The included transaction token value does not match the transaction
	 * token in the user's session</li>
	 * </ul>
	 * 
	 * @param request
	 *            The servlet request we are processing
	 * @param reset
	 *            Should we reset the token after checking it?
	 */
	public synchronized boolean isTokenValid(HttpServletRequest request,
			boolean reset) {

		return isTokenValid(request, TRANSACTION_TOKEN_KEY, reset);
	}

	public synchronized boolean isTokenValid(HttpServletRequest request,
			String tranTokenKey, boolean reset) {
		// Retrieve the current session for this request
		HttpSession session = request.getSession(false);
		if (session == null) {
			return false;
		}
		// Retrieve the transaction token from this session, and
		// reset it if requested
		String saved = (String) session.getAttribute(tranTokenKey);
		if (saved == null) {
			return false;
		}
		if (reset) {
			this.resetToken(request);
		}
		// Retrieve the transaction token included in this request
		String token = request.getParameter(TOKEN_KEY);
		if (token == null) {
			return false;
		}
		return saved.equals(token);
	}

	/**
	 * Return <code>true</code> if there is a transaction token stored in the
	 * user's current session, and the value submitted as a request parameter
	 * with this action matches it. Returns <code>false</code>
	 * <ul>
	 * <li>No session associated with this request</li>
	 * <li>No transaction token saved in the session</li>
	 * <li>No transaction token included as a request parameter</li>
	 * <li>The included transaction token value does not match the transaction
	 * token in the user's session</li>
	 * </ul>
	 * 
	 * @param tokenParam
	 * @param reset
	 * @return
	 */
	public synchronized boolean isTokenValid(String tokenParam, boolean reset) {
		return isTokenValid(tokenParam, TRANSACTION_TOKEN_KEY, reset);
	}

	/**
	 * Return <code>true</code> if there is a transaction token stored in the
	 * user's current session, and the value submitted as a request parameter
	 * with this action matches it. Returns <code>false</code>
	 * <ul>
	 * <li>No session associated with this request</li>
	 * <li>No transaction token saved in the session</li>
	 * <li>No transaction token included as a request parameter</li>
	 * <li>The included transaction token value does not match the transaction
	 * token in the user's session</li>
	 * </ul>
	 * 
	 * @param tokeParam
	 * @param tranTokenKey
	 * @param reset
	 * @return
	 */
	public synchronized boolean isTokenValid(String tokeParam,
			String tranTokenKey, boolean reset) {
		if (tranTokenKey == null) {
			tranTokenKey = TRANSACTION_TOKEN_KEY;
		}
		HttpServletRequest request = WRequest.getCurrentInstance()
				.getHttpRequest();
		// Retrieve the current session for this request
		HttpSession session = request.getSession(false);
		if (session == null) {
			return false;
		}
		//Check ignore token
		String ignoreToken = (String)session.getAttribute(TOKEN_IGNORE_KEY);
		session.removeAttribute(TOKEN_IGNORE_KEY);		
		if (TOKEN_IGNORE_VALUE.equals(ignoreToken)){
			return true;
		}
		// Retrieve the transaction token from this session, and
		// reset it if requested
		String saved = (String) session.getAttribute(tranTokenKey);
		if (saved == null) {
			return false;
		}

		if (reset) {
			this.resetToken(request, tranTokenKey);
		}
		if (tokeParam == null) {
			return false;
		}

		return saved.equals(tokeParam);
	}

	public synchronized boolean isTokenValid(String tokenValue) {
		return isTokenValid(tokenValue, false);
	}

	/**
	 * Reset the saved transaction token in the user's session. This indicates
	 * that transactional token checking will not be needed on the next request
	 * that is submitted.
	 * 
	 * @param request
	 *            The servlet request we are processing
	 */
	public synchronized void resetToken(HttpServletRequest request) {

		HttpSession session = request.getSession(false);
		if (session == null) {
			return;
		}
		session.removeAttribute(TRANSACTION_TOKEN_KEY);
	}

	public synchronized void resetToken(HttpServletRequest request, String keyToReset) {

		HttpSession session = request.getSession(false);
		if (session == null) {
			return;
		}
		if(keyToReset == null){
			keyToReset = TRANSACTION_TOKEN_KEY;
		}
		session.removeAttribute(keyToReset);
	}
	/**
	 * Save a new transaction token in the user's current session, creating a
	 * new session if necessary.
	 * 
	 * @param request
	 *            The servlet request we are processing
	 */
	public synchronized void saveToken(HttpServletRequest request) {

		HttpSession session = request.getSession();
		String token = generateToken(request);
		if (token != null) {
			session.setAttribute(TRANSACTION_TOKEN_KEY, token);
		}
	}

	/**
	 * 
	 * @param tranTokenKey
	 */
	public synchronized void saveToken(String tranTokenKey) {
		HttpServletRequest request = WRequest.getCurrentInstance()
				.getHttpRequest();
		HttpSession session = request.getSession();
		String token = generateToken(request);
		if (tranTokenKey == null) {
			tranTokenKey = TRANSACTION_TOKEN_KEY;
		}
		if (token != null) {
			session.setAttribute(tranTokenKey, token);
		}
	}

	/**
	 * Generate a new transaction token, to be used for enforcing a single
	 * request for a particular transaction.
	 * 
	 * @param request
	 *            The request we are processing
	 */
	public synchronized String generateToken(HttpServletRequest request) {
		HttpSession session = request.getSession();
		try {
			byte id[] = session.getId().getBytes();
			long current = System.currentTimeMillis();
			if (current == previous) {
				current++;
			}
			previous = current;
			byte now[] = new Long(current).toString().getBytes();
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(id);
			md.update(now);
			return toHex(md.digest());
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
	}

	/**
	 * Convert a byte array to a String of hexadecimal digits and return it.
	 * 
	 * @param buffer
	 *            The byte array to be converted
	 */
	public static String toHex(byte buffer[]) {
		StringBuffer sb = new StringBuffer(buffer.length * 2);
		for (int i = 0; i < buffer.length; i++) {
			sb.append(Character.forDigit((buffer[i] & 0xf0) >> 4, 16));
			sb.append(Character.forDigit(buffer[i] & 0x0f, 16));
		}
		return sb.toString();
	}

}
