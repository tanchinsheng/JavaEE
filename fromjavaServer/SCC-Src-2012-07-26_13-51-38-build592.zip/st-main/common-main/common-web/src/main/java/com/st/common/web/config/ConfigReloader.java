/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 27, 2012 3:16:38 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.web.config;

import java.sql.Timestamp;
import java.util.Map;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.config.ConfigLoader;
import com.st.common.exception.SccException;
import com.st.persistence.entity.SettingEntity;
import com.st.persistence.service.SettingService;

/**
 * The Class ConfigReloader.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public final class ConfigReloader {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ConfigReloader.class);

  /**
   * Reload data by using given setting service.
   * 
   * @param settingService
   *          the setting service
   * @return the config loader
   */
  public static ConfigLoader reload(final SettingService settingService) {
    final ConfigLoader configLoader = ConfigLoader.getInstance();
    if (settingService != null) {
      final SettingEntity settingEntity = settingService.find(ConfigLoader.KEY_CONFIG_TIME);
      final Timestamp configTime = settingEntity != null ? settingEntity.getUpdatedOn() : null;
      final boolean checkReload = configLoader.checkReload(configTime);
      if (checkReload) {
        Map<String, Object> dataMap;
        try {
          dataMap = settingService.findAll();
        } catch (final PersistenceException e) {
          LOG.error(e.getMessage(), e);
          return configLoader;
        }
        try {
          configLoader.reload(dataMap, configTime);
        } catch (final SccException e) {
          LOG.error(e.getMessage(), e);
        }
      }
    }
    return configLoader;
  }

  /**
   * Instantiates a new config reloader.
   */
  private ConfigReloader() {

  }
}
