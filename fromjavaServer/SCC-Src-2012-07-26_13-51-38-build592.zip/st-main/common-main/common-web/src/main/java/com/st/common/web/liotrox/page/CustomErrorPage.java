/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Mar 2, 2012 1:59:35 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.web.liotrox.page;

import st.liotrox.WRequest;
import st.liotrox.component.ComponentPath;
import st.liotrox.page.DefaultWPage;
import st.liotrox.util.XmlConfiguration;

/**
 * The Class CustomErrorPage.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class CustomErrorPage extends DefaultWPage {

  /** The error message. */
  private String errorMessage;

  /**
   * Gets the error message.
   * 
   * @return the error message
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.page.DefaultWPage#initialize(st.liotrox.WRequest,
   *      st.liotrox.component.ComponentPath, st.liotrox.util.XmlConfiguration)
   */
  @Override
  public void initialize(final WRequest request, final ComponentPath path,
      final XmlConfiguration config) throws Exception {
    super.initialize(request, path, config);

    final Exception exception =
        (Exception) request.getSessionAttribute("lx_last_user_exception");
    if (exception != null) {
      errorMessage = exception.getMessage();
    }
  }

  /**
   * Sets the error message.
   * 
   * @param errorMessage
   *          the new error message
   */
  public void setErrorMessage(final String errorMessage) {
    this.errorMessage = errorMessage;
  }

}
