/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Mar 2, 2012 3:31:44 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.common.web.login;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.WRequest;
import st.liotrox.login.LoginLevel;
import st.liotrox.profile.DefaultUserProfile;
import st.liotrox.profile.UserProfile;

import com.st.common.DBUtil;
import com.st.common.exception.SccException;
import com.st.common.exception.ServiceException;
import com.st.common.web.WebConstants;
import com.st.um.entity.UserEntity;
import com.st.um.enums.UserTypeEnum;
import com.st.um.exception.UserServiceException;
import com.st.um.service.UserService;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class LoginUtil {

  private static final Logger LOGGER = LoggerFactory.getLogger(LoginUtil.class);

  /**
   * Authenticate user name and password of local and LDAP users.
   * 
   * @param request
   * @param username
   * @param curPassword
   * @param userService
   * @param setting
   * @param bundleName
   *          Name of bundle, ex: 'app/um/login'.
   * @return error message, if null, login successfully.
   */
  public static String authenticate(final WRequest request, final String username,
      final String curPassword, final UserService userService, final LDAPSetting setting,
      final String bundleName) {
    request.setAttribute(WebConstants.CAS_LOGIN_ERROR, null);

    LOGGER.debug("authenticate");
    try {
      if (username == null || username.length() == 0 || curPassword == null
          || curPassword.length() == 0) {
        return request.getI18NMessage(bundleName, "login_typeCredentialsMessage");
      }

      UserEntity user = null;
      try {
        user = userService.getUserByUserName(username);
      } catch (UserServiceException ex) {
        LOGGER.error(ex.getMessage());
        return ex.getMessage();
      }
      // User name does not exist
      if (user == null) {
        return request.getI18NMessage(bundleName, "login_error_account_does_not_exist");
      }
      UserTypeEnum userType = user.getUserType();
      if (userType == UserTypeEnum.LOCAL_USER) {
        String hashPassword = DBUtil.hashPassword(curPassword);
        if (!hashPassword.equals(user.getPassword())) {
          return request.getI18NMessage(bundleName, "login_error_account_wrong_password");
        }
      } else if (userType == UserTypeEnum.LDAP_USER) {
        // Ldap login local
        LOGGER.debug("user is LDAP user");

        LDAPService ldapService =
            new LDAPService(setting.getLdapHost(), setting.getLdapHostPort(),
                setting.getLdapScope(), setting.getLdapVersion());

        String ldapUserName = user.getDomain();
        LOGGER.info("ldapUserName to login: " + ldapUserName);

        int flag = LDAPService.LDAP_FAILED_AUTHENTICATION;
        if (ldapUserName != null) {
          flag = ldapService.authenticateAccount(ldapUserName, curPassword);
          LOGGER.info("LDAP authenticate result: " + flag);
        }
        if (flag == LDAPService.LDAP_FAILED_AUTHENTICATION) {
          return request.getI18NMessage(bundleName, "login_error_account_not_authenticate");
        } else if (flag == LDAPService.LDAP_NO_CONNECTION) {
          return request.getI18NMessage(bundleName, "login_error_no_connection_ldap");
        }
      }
      // --------------Login successful---------------------------.

      UserProfile userProfile = new DefaultUserProfile();
      userProfile.setAttribute("liotrox.steduid", username);
      userProfile.setAttribute("liotrox.user", username);
      userProfile.setAttribute("liotrox.fullname", user.getFullName());
      userProfile.setAttribute("liotrox.email", user.getEmail());
      if (user.getUserType() != null) {
        userProfile.setAttribute("liotrox.usertype", user.getUserType().name());
      }
      //store password to compare when changing password.
      userProfile.setAttribute("liotrox.password", curPassword);
      
      // important: must set for login
      userProfile.setAttribute("LX_LOGIN_LEVEL", LoginLevel.AUTHENTICATED);
      userProfile.setAttribute("liotrox.role", user.getRoleName());
      userProfile.setAttribute("liotrox.roles", new String[]{user.getRoleName() });

      st.liotrox.login.LoginUtil.bindUserProfile(request, userProfile);

      Timestamp lastLogin = user.getLastLoginDate();
      if (lastLogin == null && user.getUserType() == UserTypeEnum.LOCAL_USER) {
        return null;
      }

      // update last login date of the user
      user.setLastLoginDate(userService.createSQLExecutor().getSysDate());
      userService.update(user);
    } catch (ServiceException e) {
      LOGGER.error(e.getMessage(), e);
      return request.getI18NMessage(bundleName, "db_common_error");
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      return e.getMessage();
    }
    return null;
  }

  /**
   * Change password of the first login of user.
   * 
   * @param request
   * @param service
   * @param bundleName
   *          Name of bundle, ex: 'app/um/login'.
   * @return error message, if null, login successfully.
   */
  public static String changePassword(WRequest request, final UserService service,
      final String bundleName) {
    try {
      LOGGER.debug("changePassword");
      UserProfile up = request.getUserProfile();
      String username = up.getAttribute("liotrox.user");
      String newPassword = request.getHttpRequest().getParameter("newPassword");

      UserEntity user = service.getUserByUserName(username);
      if (user != null) {
        String passwordHash = DBUtil.hashPassword(newPassword);
        user.setLastLoginDate(service.createSQLExecutor().getSysDate());
        user.setPassword(passwordHash);
        // Update to DB.
        service.update(user);

        // Update role
        String roleName = user.getRoleName();
        up.setAttribute("liotrox.role", roleName);
        up.setAttribute("liotrox.roles", new String[]{roleName });
        st.liotrox.login.LoginUtil.bindUserProfile(request, up);
      } else {
        return request.getI18NMessage(bundleName, "user_already_deleted");
      }
    } catch (ServiceException e) {
      LOGGER.error(e.getMessage(), e);
      return request.getI18NMessage(bundleName, "db_common_error");
    } catch (Exception e) {
      LOGGER.error(e.getMessage(), e);
      return e.getMessage();
    }
    return null;
  }

  /**
   * Check user already login with first login.
   * 
   * @param request
   * @param service
   * @return true if user are login firt time.
   */
  public static boolean isFirstTimeLogin(WRequest request, final UserService service) {
    UserProfile profile = request.getUserProfile();
    String loginUserName = null;
    Timestamp lastLogin = null;
    if (profile != null) {
      loginUserName = profile.getAttribute("liotrox.user");

      lastLogin = getLastLogin(loginUserName, service);
    }

    return loginUserName != null && lastLogin == null;
  }

  /**
   * 
   */
  private static Timestamp getLastLogin(final String userName, final UserService service) {
    // query new info of login user
    try {
      UserEntity user = service.getUserByUserName(userName);
      if (user != null) {
        // If LDAP user, don't show change password, therefore, we return
        // current time.
        if (user.getUserType() == UserTypeEnum.LDAP_USER) {
          return new Timestamp(System.currentTimeMillis());
        }
        return user.getLastLoginDate();
      }
    } catch (SccException e) {
      LOGGER.error(e.getMessage(), e);
    }
    // return not NULL to different with case: first login is NULL.
    return new Timestamp(System.currentTimeMillis());
  }
}
