/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is private by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 15, 2011 4:26:49 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common.web.login;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import netscape.ldap.LDAPAttribute;
import netscape.ldap.LDAPAttributeSet;
import netscape.ldap.LDAPConnection;
import netscape.ldap.LDAPEntry;
import netscape.ldap.LDAPException;
import netscape.ldap.LDAPSearchResults;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.util.ldap.LDAPScope;
import st.liotrox.util.ldap.LDAPSearchQuery;
import st.liotrox.util.ldap.LDAPSearchQuery.LDAPParameters;

import com.st.common.EncryptionUtils;
import com.st.common.exception.LDAPAuthenticationException;
import com.st.common.exception.LDAPConnectException;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class LDAPService {

  private static final Logger LOGGER = LoggerFactory.getLogger(LDAPService.class);

  private int ldapport = 389;
  private String binddn;
  private String ldaphost;
  private String passwd;
  private int version = 3;
  private int scope = 2;
  private String base;

  public static final String USER_NAME = "username";
  public static final String EMAIL = "email";
  public static final String FULL_NAME = "fullname";
  public static final String DOMAIN = "domain";

  public static final String DEFAULT_USERNAME = "cn";
  public static final String DEFAULT_FULLNAME = "cn";
  public static final String DEFAULT_MAIL = "mail";
  public static final String DEFAULT_DOMAIN = "dn";

  private static final String LDAP_ATRIBUTE[] = {"cn", "sAMAccountName", "distinguishedName",
      "mail" };

  public static final String LDAP_ATRIBUTES_MAPPING[] = {"cn", "sAMAccountName",
      "distinguishedName", "mail", "dn" };

  public static final int LDAP_SUCCESSFULL_AUTHENTICATION = 0;
  public static final int LDAP_FAILED_AUTHENTICATION = 1;
  public static final int LDAP_NO_CONNECTION = 2;

  public static final String USERNAME_FIELD = "USERNAME";
  public static final String FULLNAME_FIELD = "FULL_NAME";
  public static final String EMAIL_FIELD = "EMAIL";
  public static final String ROLE_FIELD = "ROLE_NAME";
  public static final String SHOW_ALL = "ALL";

  /**
   * Initialize LdapSevice with no user name and password to authenticate.
   * 
   * @param host
   * @param port
   *          If port is null, get default port is 389.
   * @param scope
   *          If scope is null, get default scope is 2.
   * @param version
   *          If version is null, get default version is 3.
   */
  public LDAPService(final String host, final Integer port, final Integer scope,
      final Integer version) {
    ldaphost = host;
    if (port != null) {
      ldapport = port;
    }
    if (scope != null) {
      this.scope = scope;
    }
    if (version != null) {
      this.version = version;
    }
  }

  /**
   * Initialize LdapSevice with full information to query data in LDAP.
   * Constructor
   * 
   * @param host
   * @param port
   *          If port is null, get default port is 389.
   * @param scope
   *          If scope is null, get default scope is 2.
   * @param version
   *          If version is null, get default version is 3.
   * @param userName
   * @param password
   * @param base
   *          condition to query data.
   */
  public LDAPService(final String host, final Integer port, final Integer scope,
      final Integer version, final String userName, final String password, final String base) {
    this(host, port, scope, version);
    binddn = userName;
    passwd = password;
    this.base = base;
  }

  /**
   * Validates LDAP information
   * 
   * @throws LDAPException
   */
  private void validate() throws LDAPException {
    if (ldaphost == null) {
      LOGGER.error("LDAP host is null.");
      throw new LDAPException("LDAP host cannot null");
    }
    if (ldapport == 0) {
      LOGGER.error("LDAP port is null.");
      throw new LDAPException("LDAP port cannot zero");
    }
    if (version == 0) {
      version = 3;
    }
    if (scope < 0) {
      LOGGER.info("LDAP search scope is less than zero, use default scope (2).");
      scope = 2;
    }
  }

  public int authenticateAccount(String userName, String password) throws LDAPException {
    LOGGER.info("authenticateAccount with bindn: " + userName + "; password: ******");
    validate();

    LDAPConnection client = new LDAPConnection();
    try {
      try {
        LOGGER.info("Start connect to LDAP server with host: " + ldaphost + " and port: "
            + ldapport);
        client.connect(ldaphost, ldapport);
        LOGGER.info("Connect to LDAP server successful.");
      } catch (LDAPException e) {
        LOGGER.error("Connect to LDAP server failed.");
        return LDAP_NO_CONNECTION;
      }
      if (userName != null && userName.trim().length() > 0 && password != null
          && password.trim().length() != 0) {
        try {
          LOGGER.info("Authenticate LDAP server with version: " + version + ", bindn: "
              + userName + " and password: ******");
          client.authenticate(version, userName, password);
          LOGGER.info("Authenticate LDAP successful.");
          return LDAP_SUCCESSFULL_AUTHENTICATION;
        } catch (LDAPException e) {
          LOGGER.error("Authenticate LDAP server error.");
          return LDAP_FAILED_AUTHENTICATION;
        }
      }
    } finally {
      if (client != null && client.isConnected()) {
        client.disconnect();
        LOGGER.info("Disconnect LDAP server succesfful.");
      }
    }
    return LDAP_FAILED_AUTHENTICATION;
  }

  /**
   * Gets list account from LDAP server
   * 
   * @return list map of account.
   * @throws LDAPConnectException
   * @throws BadPaddingException
   * @throws IllegalBlockSizeException
   * @throws UnsupportedEncodingException
   * @throws NoSuchPaddingException
   * @throws NoSuchAlgorithmException
   * @throws InvalidKeyException
   * @throws LDAPAuthenticationException
   * @throws LDAPException
   */
  public List<Map<String, String>> getAccounts(String filterType, String filterValue,
      final LDAPSetting setting) throws LDAPConnectException, InvalidKeyException,
      NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException,
      IllegalBlockSizeException, BadPaddingException, LDAPAuthenticationException,
      LDAPException {
    validate();

    LDAPConnection client = new LDAPConnection();
    try {
      try {
        LOGGER.info("Start connect to LDAP server with host: " + ldaphost + " and port: "
            + ldapport);
        client.connect(ldaphost, ldapport);
        LOGGER.info("Connect to LDAP server successful.");
      } catch (LDAPException e) {
        LOGGER.error("Connect to LDAP server error.");
        throw new LDAPConnectException(e);
      }
      if (binddn != null && binddn.trim().length() > 0 && passwd != null
          && passwd.trim().length() != 0) {
        try {
          LOGGER.info("Authenticate LDAP server with version: " + version + ", bindn: "
              + binddn + " and passwd: ******");
          client.authenticate(version, binddn, EncryptionUtils.decrypt(passwd));
          LOGGER.info("Authenticate LDAP successful.");
        } catch (LDAPException e) {
          LOGGER.error("Authenticate LDAP server failed.");
          throw new LDAPAuthenticationException(e);
        }
      } else {
        LOGGER.info("Skip authenticate LDAP server because bindn/password is null.");
      }

      List<Map<String, String>> ls = new ArrayList<Map<String, String>>();
      try {
        ls = dosearch(client, filterType, filterValue, setting);
      } catch (LDAPException e) {
        LOGGER.error("Search LDAP error (Cause: search scope, filter, base is wrong ...).");
        throw e;
      }
      LOGGER.info("LDAP search result: " + ls.size());
      return ls;
    } finally {
      if (client != null && client.isConnected()) {
        client.disconnect();
        LOGGER.info("Disconnect LDAP server succesfful.");
      }
    }
  }

  /**
   * Process search and get result from LDAP server.
   * 
   * @return search result
   * @throws LDAPException
   * @throws LDAPAuthenticationException
   */
  private List<Map<String, String>> dosearch(LDAPConnection client, String filterType,
      String filterValue, final LDAPSetting setting) throws LDAPException,
      LDAPAuthenticationException {

    StringBuilder log = new StringBuilder();
    log.append("Begin search LDAP with base: ");
    log.append(base);
    log.append(", scope: ");
    log.append(scope);
    LOGGER.info(log.toString());

    // create filter condition
    String filter = "(objectClass=*)";
    String attrName = null;
    if (filterValue != null && filterValue.trim().length() > 0) {
      if (USERNAME_FIELD.equals(filterType)) {
        attrName = setting.getLdapAttributeUserName();
      } else if (FULLNAME_FIELD.equals(filterType)) {
        attrName = setting.getLdapAttributeFullName();
      } else if (EMAIL_FIELD.equals(filterType)) {
        attrName = setting.getLdapAttributeMail();
      }
    }
    if (attrName != null) {
      filter = "(" + attrName + "=$(paramPass))";
    }
    LDAPSearchQuery query = new LDAPSearchQuery(base, filter);

    LDAPScope ldapScope = null;
    if (scope == 0) {
      ldapScope = LDAPScope.SCOPE_BASE;
    } else if (scope == 1) {
      ldapScope = LDAPScope.SCOPE_ONE;
    } else {
      ldapScope = LDAPScope.SCOPE_SUB;
    }
    query.setScope(ldapScope);
    query.setAttributes(LDAP_ATRIBUTE);

    LDAPParameters params = query.createParameters();
    if (attrName != null) {
      filterValue = "*" + filterValue + "*";
      params.setParameterValue("paramPass", filterValue);
    }

    LDAPSearchResults result = null;
    try {
      result = query.executeQuery(client, params);
    } catch (Exception e) {
      if (e.toString().indexOf("DSID-0C0906DC") != -1) {
        throw new LDAPAuthenticationException(e);
      } else {
        throw new LDAPException(e.getMessage());
      }
    }
    return getResults(result, setting);
  }

  /**
   * Gets result from LDAPSearchResults
   * 
   * @param searchResults
   * @return result in list of map format
   * @throws LDAPException
   */
  private List<Map<String, String>> getResults(LDAPSearchResults searchResults,
      final LDAPSetting setting) {

    List<Map<String, String>> result = new ArrayList<Map<String, String>>();
    if (searchResults == null) {
      LOGGER.info("LDAP search result is null.");
      return result;
    }
    while (searchResults.hasMoreElements()) {
      try {
        LDAPEntry entry = (LDAPEntry) searchResults.nextElement();
        String dn = entry.getDN();
        LDAPAttributeSet set = entry.getAttributeSet();

        Map<String, String> account = new HashMap<String, String>(4);
        LDAPAttribute att = null;
        // Get username
        String userNameAttr = setting.getLdapAttributeUserName();
        if (userNameAttr == null) {
          userNameAttr = DEFAULT_USERNAME;
        }
        if (DEFAULT_DOMAIN.equals(userNameAttr)) {
          account.put(USER_NAME, dn);
        } else {
          att = set.getAttribute(userNameAttr);
          if (att != null) {
            String[] listName = att.getStringValueArray();
            // Get last user name.
            if (listName.length > 0) {
              account.put(USER_NAME, listName[listName.length - 1]);
            }
          }
        }
        // Get email
        String emailAttr = setting.getLdapAttributeMail();
        if (emailAttr == null) {
          emailAttr = DEFAULT_MAIL;
        }
        if (DEFAULT_DOMAIN.equals(emailAttr)) {
          account.put(EMAIL, dn);
        } else {
          att = set.getAttribute(emailAttr);
          if (att != null) {
            account.put(EMAIL, att.getStringValueArray()[0]);
          }
        }
        // Get full name
        String fullNameAttr = setting.getLdapAttributeFullName();
        if (fullNameAttr == null) {
          fullNameAttr = DEFAULT_FULLNAME;
        }
        if (DEFAULT_DOMAIN.equals(fullNameAttr)) {
          account.put(FULL_NAME, dn);
        } else {
          att = set.getAttribute(fullNameAttr);
          if (att != null) {
            account.put(FULL_NAME, att.getStringValueArray()[0]);
          }
        }
        // Get domain
        String domainAttr = setting.getLdapAttributeDomain();
        if (domainAttr == null) {
          domainAttr = DEFAULT_DOMAIN;
        }
        if (DEFAULT_DOMAIN.equals(domainAttr)) {
          account.put(DOMAIN, dn);
        } else {
          att = set.getAttribute(domainAttr);
          if (att != null) {
            account.put(DOMAIN, att.getStringValueArray()[0]);
          }
        }
        if (account.size() > 0) {
          result.add(account);
        }
      } catch (Exception e) {
        continue;
      }
    }
    return result;
  }

  public void setLdapport(int ldapport) {
    this.ldapport = ldapport;
  }

  public void setBinddn(String binddn) {
    this.binddn = binddn;
  }

  public void setLdaphost(String ldaphost) {
    this.ldaphost = ldaphost;
  }

  public void setPasswd(String passwd) {
    this.passwd = passwd;
  }

  public void setVersion(int version) {
    this.version = version;
  }

  public void setScope(int scope) {
    this.scope = scope;
  }

  public void setBase(String base) {
    this.base = base;
  }

}
