/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 2, 2011 6:38:32 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.common.web.filter;

import java.io.IOException;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jasig.cas.client.authentication.AuthenticationFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.cas.client.filter.CASConfiguration;
import st.liotrox.LiotroRuntimeException;
import st.liotrox.WRequest;
import st.liotrox.login.LoginLevel;
import st.liotrox.login.LoginUtil;
import st.liotrox.profile.DefaultUserProfile;
import st.liotrox.profile.UserProfile;

import com.st.common.exception.ServiceException;
import com.st.common.web.WebConstants;
import com.st.common.web.util.ServletUtils;
import com.st.persistence.SQLExecutor;
import com.st.persistence.entity.ActionTrackingEntity;
import com.st.persistence.service.actionlog.ActionLog;
import com.st.scc.common.utils.DateUtils;
import com.st.um.entity.UserEntity;
import com.st.um.service.UserService;

/**
 * The Class RequestFilter.
 */
public abstract class RequestFilter extends AuthenticationFilter {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(RequestFilter.class);

  /** The Constant MAX_PERCENT_HEAP. */
  private static final double MAX_PERCENT_HEAP = 0.8;

  /**
   * Check overload.
   * 
   * @param request
   *          the request
   * @param response
   *          the response
   * @return true, if successful
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  private boolean checkOverload(final HttpServletRequest request,
      final HttpServletResponse response) throws IOException {
    // Get current size of heap in bytes
    final long heapSize = Runtime.getRuntime().totalMemory();

    // Get maximum size of heap in bytes. The heap cannot grow beyond this size.
    // Any attempt will result in an OutOfMemoryException.
    final long heapMaxSize = Runtime.getRuntime().maxMemory();
    // Get amount of free memory within the heap in bytes. This size will
    // increase
    // after garbage collection and decrease as new objects are created.
    final long heapFreeSize = Runtime.getRuntime().freeMemory();
    final long heapUsed = heapSize - heapFreeSize;

    if (heapUsed >= heapMaxSize * MAX_PERCENT_HEAP) {
      LOG.info("Max memory allow: " + heapMaxSize);
      LOG.info("Current total memory: " + heapSize);
      LOG.info("Memory used: " + heapUsed);
      LOG.info("Server is busy, stop serve request.");
      final String url = request.getRequestURI();
      // allow serverBusy and loginPage access.
      if (url.indexOf("serverBusy") == -1 && url.indexOf("loginPage") == -1) {
        final HttpSession session = request.getSession(false);
        // clear session of the current user
        if (session != null) {
          // request.setAttribute("__LX_INVALIDATE_SESSION__", Boolean.TRUE);
          session.removeAttribute(WebConstants.LOGIN_USER);
        }
        Runtime.getRuntime().gc();
        response.sendRedirect(request.getContextPath() + "/serverBusy.html");
        return true;
      }
    }
    return false;
  }

  /**
   * {@inheritDoc}
   * 
   * @see org.jasig.cas.client.authentication.AuthenticationFilter#doFilter(javax.servlet.ServletRequest,
   *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
   */
  @Override
  public void doFilter(final ServletRequest servletRequest,
      final ServletResponse servletResponse, final FilterChain filterChain)
      throws IOException, ServletException {

    if (checkOverload((HttpServletRequest) servletRequest,
        (HttpServletResponse) servletResponse)) {
      return;
    }

    try {
      processCASRequest(servletRequest, servletResponse, filterChain);
    } catch (final ServletException e) {
      LOG.error(e.getMessage(), e);
      throw e;
    } catch (final LiotroRuntimeException e) {
      LOG.error(e.getMessage(), e);
    } catch (final Throwable e) {
      LOG.error(e.getMessage(), e);
    }
  }

  protected abstract String getErrorNotImportedURL();

  /**
   * Gets the user service.
   * 
   * @return the user service
   */
  protected abstract UserService getUserService();

  protected abstract SQLExecutor getSQLExecutorOfActionTracking();
  protected abstract String getDBName();
  /**
   * Process CAS request.
   * 
   * @param servletRequest
   *          the servlet request
   * @param servletResponse
   *          the servlet response
   * @param filterChain
   *          the filter chain
   * @throws ServletException
   *           the servlet exception
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  private void processCASRequest(final ServletRequest servletRequest,
      final ServletResponse servletResponse, final FilterChain filterChain)
      throws ServletException, IOException {
    final HttpServletRequest request = (HttpServletRequest) servletRequest;
    final String requestURI = request.getRequestURI();

    if (requestURI.startsWith(request.getContextPath() + WebConstants.LIOTROX_APP_URL)) {
      initInternalST(servletRequest);

      final WRequest wrequest = new WRequest(request, (HttpServletResponse) servletResponse);
      final UserProfile userProfile = wrequest.getUserProfile();
      final String casUser =
          (String) request.getSession().getAttribute(CASConfiguration.CAS_FILTER_USER);

      setCASLoginURL(request);
      if (userProfile != null) {
        if (casUser != null) {
          if (!casUser.equals(userProfile.getLogin())) {
            validateCASUser(wrequest, casUser);
            filterChain.doFilter(servletRequest, servletResponse);
            return;
          }
        }
      } else {
        if (casUser != null) {
          validateCASUser(wrequest, casUser);
          filterChain.doFilter(servletRequest, servletResponse);
          return;
        }
      }
    }

    filterChain.doFilter(servletRequest, servletResponse);
  }

  /**
   * Sets the CAS login URL.
   * 
   * @param request
   *          the new cAS login URL
   * @throws ServletException
   *           the servlet exception
   */
  private void setCASLoginURL(final HttpServletRequest request) throws ServletException {
    final HttpSession session = request.getSession();
    if (session.getAttribute(WebConstants.CAS_LOGIN_URL) == null) {
      final CASConfiguration cfg = configuration.getDomainConfiguration(request);
      final String requestURL = request.getRequestURL().toString();
      String casRedirectPage = "";
      final String requestURI = request.getRequestURI();
//      if (requestURI.equalsIgnoreCase(getLoginURL())
//          || requestURI.equalsIgnoreCase(getLogoutURL())) {
//        casRedirectPage =
//            requestURL.substring(0, requestURL.indexOf(requestURI)) + request.getContextPath()
//                + "/";
//      } else {
//        casRedirectPage = requestURL;
//        final String params = request.getQueryString();
//        if (params != null && params.length() > 0
//            && params.indexOf(WPage.BOOKMARK_PAGE_EVENT_PARAMETER) == -1) {
//          casRedirectPage += "?" + params;
//        }
//      }
      casRedirectPage =
          requestURL.substring(0, requestURL.indexOf(requestURI)) + request.getContextPath()
              + "/";
      LOG.info("Redirect URL after login=" + casRedirectPage);
      final String casLoginUrl =
          cfg.getCasServerLoginUrl() + "?service="
              + ServletUtils.encodeUrlParam(casRedirectPage);
      session.setAttribute(WebConstants.CAS_LOGIN_URL, casLoginUrl);
      session.setAttribute(WebConstants.CAS_LOGOUT_URL, cfg.getCasLogout());
    }
  }

  /**
   * Validate CAS user.
   * 
   * @param request
   *          the request
   * @param casUser
   *          the CAS user name
   */
  private void validateCASUser(final WRequest request, final String casUser) {
    UserEntity user = null;
    long startLogin = System.currentTimeMillis();
    try {
      user = getUserService().isValidLdapUser(casUser);
    } catch (final ServiceException e) {
      LOG.error(e.getMessage(), e);
      // set error message
      request.setAttribute(WebConstants.CAS_LOGIN_ERROR,
          "Cannot connect to User Management database.");
    }
    if (user != null) {
      final UserProfile up = new DefaultUserProfile();
      up.setAttribute("liotrox.steduid", casUser);
      up.setAttribute("liotrox.user", casUser);
      up.setAttribute("liotrox.fullname", user.getFullName());
      up.setAttribute("liotrox.email", user.getEmail());
      if (user.getUserType() != null) {
        up.setAttribute("liotrox.usertype", user.getUserType().name());
      }
      up.setAttribute("liotrox.role", user.getRoleName());
      up.setAttribute("liotrox.roles", new String[]{user.getRoleName() });
      up.setAttribute("LX_LOGIN_LEVEL", LoginLevel.AUTHENTICATED);
      LoginUtil.bindUserProfile(request, up);
      LOG.info("SSO login successfully, user=" + casUser);
      // Store this value to check when logout SSO.
      request.getSession().setAttribute(WebConstants.KEY_SESSION_LOGIN_TYPE,
          WebConstants.LOGIN_TYPE_SSO);

      // Action tracking for login action
      ActionTrackingEntity actionEntity = new ActionTrackingEntity();
      actionEntity.setAction("Login SSO");
      actionEntity.setAuthor(casUser);
      actionEntity.setParameters("Login at: "
          + DateUtils.dateToString(new Date(), "yyyy-MM-dd HH:mm:ss"));
      actionEntity.setElapsedTime(System.currentTimeMillis() - startLogin);
      ActionLog.getInstance().insertTracking(getDBName(), getSQLExecutorOfActionTracking(),
          actionEntity);
    } else {
      // set error message
      String errorMsg =
          "Account " + casUser + " is not imported to system.<br/><a href=\""
              + request.getSession().getAttribute(WebConstants.CAS_LOGOUT_URL)
              + "\">Click here </a> to sign out from CAS.";
      LOG.error("Account " + casUser + " is not imported to system");
      request.getSession().setAttribute(WebConstants.CAS_LOGIN_ERROR, errorMsg);

      // create a profile to access error page when user is not imported.
      final UserProfile up = new DefaultUserProfile();
      up.setAttribute("liotrox.steduid", "any");
      up.setAttribute("liotrox.user", "any");
      up.setAttribute("liotrox.role", "anonymous");
      up.setAttribute("liotrox.roles", new String[]{"anonymous" });
      up.setAttribute("LX_LOGIN_LEVEL", LoginLevel.AUTHENTICATED);
      LoginUtil.bindUserProfile(request, up);
      //redirect to error page.
      if (request.getHttpRequest().getRequestURI().indexOf(getErrorNotImportedURL()) == -1) {
        request.redirectTo(getErrorNotImportedURL());
      }
    }
  }

}
