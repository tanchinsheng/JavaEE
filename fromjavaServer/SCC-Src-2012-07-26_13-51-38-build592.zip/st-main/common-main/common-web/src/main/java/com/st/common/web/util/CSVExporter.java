/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 25, 2012 6:22:27 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.web.util;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import st.liotrox.LiotroRuntimeException;
import st.liotrox.dataview.BoundColumn;
import st.liotrox.dataview.Column;
import st.liotrox.dataview.DataView;
import st.liotrox.db.CSVDataSetAdapter;
import st.liotrox.db.DataSet;
import st.liotrox.util.ArrayUtil;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class CSVExporter {

  /** The Constant CSV_SEPARATOR. */
  public static final String CSV_SEPARATOR = ",";

  /** The Constant CSV_QUOTE_ESCAPE. */
  private static final char CSV_QUOTE_ESCAPE = '"';

  /**
   * Write CSV.
   * 
   * @param view
   *          the view
   * @param stream
   *          the stream
   * @param fileName
   *          the file name
   * @param compliancyScore
   *          the compliancy score
   * @param ruleSetName
   *          the rule set name
   * @param ruleSetVersion
   *          the rule set version
   * @param checkingTime
   *          the checking time
   */
  public static void writeCSV(final DataView view, final OutputStream stream) {
    try {
      final int nc = view.getModel().getColumns().getCount();
      final List<String> columnNames = new ArrayList<String>();
      for (int c = 1; c <= nc; c++) {
        final Column column = view.getModel().getColumns().get(c);
        if (!column.isBound() || !column.isVisible() || column.isCollapsed()) {
          continue;
        }
        final String text = ((BoundColumn) column).getLabel();
        columnNames.add(CSVDataSetAdapter.quoteString(text, CSV_SEPARATOR, CSV_QUOTE_ESCAPE));
      }

      stream.write(ArrayUtil.join(columnNames.toArray(), CSV_SEPARATOR).getBytes());
      stream.write("\n".getBytes());

      final DataSet ds = view.getModel().getDataSet();
      if (ds != null && view.getModel().getColumns().getLastVisibleColumnIndex() > 0) {
        final int nr = ds.getRowCount();
        for (int r = 1; r <= nr; r++) {
          writeDataRow(view, stream, r);
        }
      }
    } catch (final Exception e) {
      final String msg = CSVExporter.class.getName() + ": error exporting data";
      throw new LiotroRuntimeException(msg, e);
    }
  }

  /**
   * Write data row.
   * 
   * @param view
   *          the view
   * @param stream
   *          the stream
   * @param row
   *          the row
   * @throws Exception
   *           the exception
   */
  private static void writeDataRow(final DataView view, final OutputStream stream,
      final int row) throws Exception {
    final DataSet ds = view.getModel().getDataSet();
    final int nc = view.getModel().getColumns().getCount();
    for (int c = 1; c <= nc; c++) {
      final Column column = view.getModel().getColumns().get(c);
      if (!column.isBound() || !column.isVisible() || column.isCollapsed()) {
        continue;
      }
      final BoundColumn bc = (BoundColumn) column;
      writeValue(view, stream, row, bc.getName(), c, ds.getValue(row, bc.getDatasetColumn()));
    }

    stream.write("\n".getBytes());
  }

  /**
   * Write value.
   * 
   * @param view
   *          the view
   * @param stream
   *          the stream
   * @param row
   *          the row
   * @param columnName
   *          the column name
   * @param columnIndex
   *          the column index
   * @param value
   *          the value
   * @throws Exception
   *           the exception
   */
  private static void writeValue(final DataView view, final OutputStream stream,
      final int row, final String columnName, final int columnIndex, final Object value)
      throws Exception {
    final BoundColumn bc = (BoundColumn) view.getModel().getColumns().get(columnName);
    String data =
        bc.getDataType().equals("date") ? bc.formatValue(value) : value == null ? "" : value
            .toString();

    data = CSVDataSetAdapter.quoteString(data, CSV_SEPARATOR, CSV_QUOTE_ESCAPE);

    stream.write(data.getBytes());

    if (columnIndex != view.getModel().getColumns().getLastVisibleBoundColumnIndex()) {
      stream.write(CSV_SEPARATOR.getBytes());
    }
  }
}
