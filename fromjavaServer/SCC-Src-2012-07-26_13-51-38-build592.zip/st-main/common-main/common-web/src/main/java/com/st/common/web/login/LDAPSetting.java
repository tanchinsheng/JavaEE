/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Mar 2, 2012 3:53:57 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.common.web.login;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class LDAPSetting {

  private String ldapHost;

  private Integer ldapHostPort;

  private Integer ldapVersion;

  private Integer ldapScope;

  private String ldapAttributeUserName;
  private String ldapAttributeFullName;
  private String ldapAttributeMail;
  private String ldapAttributeDomain;

  public LDAPSetting() {

  }

  public LDAPSetting(String host, Integer port, Integer version, Integer scope) {
    ldapHost = host;
    ldapHostPort = port;
    ldapVersion = version;
    ldapScope = scope;
  }

  /**
   * @return the ldapHost
   */
  public String getLdapHost() {
    return ldapHost;
  }

  /**
   * @param ldapHost
   *          the ldapHost to set
   */
  public void setLdapHost(String ldapHost) {
    this.ldapHost = ldapHost;
  }

  /**
   * @return the ldapHostPort
   */
  public Integer getLdapHostPort() {
    return ldapHostPort;
  }

  /**
   * @param ldapHostPort
   *          the ldapHostPort to set
   */
  public void setLdapHostPort(Integer ldapHostPort) {
    this.ldapHostPort = ldapHostPort;
  }

  /**
   * @return the ldapVersion
   */
  public Integer getLdapVersion() {
    return ldapVersion;
  }

  /**
   * @param ldapVersion
   *          the ldapVersion to set
   */
  public void setLdapVersion(Integer ldapVersion) {
    this.ldapVersion = ldapVersion;
  }

  /**
   * @return the ldapScope
   */
  public Integer getLdapScope() {
    return ldapScope;
  }

  /**
   * @param ldapScope
   *          the ldapScope to set
   */
  public void setLdapScope(Integer ldapScope) {
    this.ldapScope = ldapScope;
  }

  /**
   * @return the ldapAttributeUserName
   */
  public String getLdapAttributeUserName() {
    return ldapAttributeUserName;
  }

  /**
   * @param ldapAttributeUserName
   *          the ldapAttributeUserName to set
   */
  public void setLdapAttributeUserName(String ldapAttributeUserName) {
    this.ldapAttributeUserName = ldapAttributeUserName;
  }

  /**
   * @return the ldapAttributeFullName
   */
  public String getLdapAttributeFullName() {
    return ldapAttributeFullName;
  }

  /**
   * @param ldapAttributeFullName
   *          the ldapAttributeFullName to set
   */
  public void setLdapAttributeFullName(String ldapAttributeFullName) {
    this.ldapAttributeFullName = ldapAttributeFullName;
  }

  /**
   * @return the ldapAttributeMail
   */
  public String getLdapAttributeMail() {
    return ldapAttributeMail;
  }

  /**
   * @param ldapAttributeMail
   *          the ldapAttributeMail to set
   */
  public void setLdapAttributeMail(String ldapAttributeMail) {
    this.ldapAttributeMail = ldapAttributeMail;
  }

  /**
   * @return the ldapAttributeDomain
   */
  public String getLdapAttributeDomain() {
    return ldapAttributeDomain;
  }

  /**
   * @param ldapAttributeDomain
   *          the ldapAttributeDomain to set
   */
  public void setLdapAttributeDomain(String ldapAttributeDomain) {
    this.ldapAttributeDomain = ldapAttributeDomain;
  }

}
