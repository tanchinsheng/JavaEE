/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 29, 2012 5:54:40 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.web.liotrox.servlet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import st.liotrox.LiotroRuntimeException;
import st.liotrox.WRequest;
import st.liotrox.servlet.DefaultErrorHandler;
import st.liotrox.util.ExceptionUtil;

import com.st.common.exception.ServiceException;
import com.st.common.mail.EmailNotification;
import com.st.common.mail.EmailNotification.ErrorMailEnum;
import com.st.common.web.exception.ComponentNotFoundException;
import com.st.scc.common.utils.StringUtil;

/**
 * The Class CustomErrorHandler.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class CustomErrorHandler extends DefaultErrorHandler {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(CustomErrorHandler.class);

  /**
   * {@inheritDoc}
   * 
   * @see st.liotrox.servlet.DefaultErrorHandler#handleError(st.liotrox.WRequest,
   *      java.lang.Throwable)
   */
  @Override
  public void handleError(final WRequest request, final Throwable error) {
    final String message = error.getMessage();
    if (error instanceof LiotroRuntimeException) {
      if (message.indexOf("WApplication.handleRequest") > -1) {
        super.handleError(request, new ComponentNotFoundException(error));
        LOG.error(message);
        return;
      }
      if (message
          .indexOf("LiotroRuntimeException error: cannot find event definition in incoming request") > -1) {
        LOG.error("Cannot find event definition in incoming request, redirect to home page");
        request.redirectTo(request.getContextPath() + "/");
        return;
      }
      final Throwable[] exceptions = ExceptionUtil.getNestedExceptions(error);
      if (exceptions.length > 0) {
        final Throwable exception = exceptions[exceptions.length - 1];
        final String strackStraceString = StringUtil.toString(exception);
        if (strackStraceString.indexOf("javax.persistence.PersistenceException") > -1) {
          EmailNotification.getInstance().sendOTM(ErrorMailEnum.DB_ERROR);
          super
              .handleError(request, new ServiceException("Cannot connect to database", error));
          LOG.error(exception.getMessage(), exception);
          return;
        }
      }

      super.handleError(request, error);
      LOG.error(message, error);
    } else {
      super.handleError(request, error);
      LOG.error(message, error);
    }
  }
}
