package st.liotrox.dataview.toolbar;
/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 15, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/


import st.liotrox.Event;
import st.liotrox.WRequest;
import st.liotrox.dataview.DataView;
import st.liotrox.dataview.toolbar.PageRowsElement;
import st.liotrox.web.html.JavaScriptAPI;
import st.liotrox.web.html.Select;
import st.liotrox.web.html.Table;

/**
 * The Class SCPageRowsElement.
 */
public class SCPageRowsElement extends PageRowsElement {

  /**
   * {@inheritDoc}
   * @see st.liotrox.dataview.toolbar.PageRowsElement#render(st.liotrox.WRequest)
   */
  public Object render(final WRequest request) {
    DataView dv = getDataView();

    if (dv.getPageRows() == -1) {
      return "";
    }
    Select comboBox = new Select(getUniqueName() + "PageRows", false);

    String v = "" + getDataView().getPageRows();
    comboBox.addItem("10", v.equals("10"));
    comboBox.addItem("20", v.equals("20"));
    comboBox.addItem("30", v.equals("30"));
    comboBox.addItem("40", v.equals("40"));
    comboBox.addItem("50", v.equals("50"));
    comboBox.addItem("60", v.equals("60"));
    comboBox.addItem("70", v.equals("70"));
    comboBox.addItem("80", v.equals("80"));
    comboBox.addItem("90", v.equals("90"));
    comboBox.addItem("100", v.equals("100"));
    comboBox.addItem("200", v.equals("200"));
    comboBox.addItem("300", v.equals("300"));
    comboBox.addItem("400", v.equals("400"));
    comboBox.addItem("500", v.equals("500"));

    Event e = createToolbarEvent(request, "setPageRows");
    comboBox.onChange(JavaScriptAPI.convertEventEncode2HandleActionControl(e));

    Table t = new Table(0).cellPadding(0).cellSpacing(2);
    t.setAttribute("TITLE", getTitle());

    t.newRow();
    t.cell(getLabel(), true);
    t.cell(comboBox, true);

    return t;
  }
}
