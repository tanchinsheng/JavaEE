/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 1, 2011 11:34:20 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.executor;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class CompletionExecutor.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class CompletionExecutor extends ExecutorCompletionService<Object> {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(CompletionExecutor.class);

  /** The callables. */
  private List<Callable<Object>> callables;

  /** The executor service. */
  private ExecutorService executorService;

  /**
   * Instantiates a new completion executor.
   * 
   * @param executorService
   *          the executor service
   */
  public CompletionExecutor(final ExecutorService executorService) {
    super(executorService);
    this.executorService = executorService;
    callables = new CopyOnWriteArrayList<Callable<Object>>();
  }

  /**
   * Execute.
   * 
   * @param runnable
   *          the runnable
   */
  public void execute(final Runnable runnable) {
    final Callable<Object> callable = Executors.callable(runnable);
    if (callables != null) {
      callables.add(callable);
    }
    super.submit(callable);
  }

  /**
   * Gets the number of tasks.
   * 
   * @return the number of tasks
   */
  public int getNumOfTasks() {
    final int size = callables != null ? callables.size() : 0;
    return size;
  }

  /**
   * Shutdown the thread pool.
   */
  public void shutdown() {
    if (executorService != null) {
      executorService.shutdown();
      try {
        executorService.awaitTermination(2, TimeUnit.SECONDS);
      } catch (final InterruptedException e) {
        // Ignore exception
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
      executorService = null;
    }
    if (callables != null) {
      callables.clear();
      callables = null;
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.concurrent.ExecutorCompletionService#submit(java.util.concurrent.Callable)
   */
  @Override
  public Future<Object> submit(final Callable<Object> task) {
    if (callables != null) {
      callables.add(task);
    }
    return super.submit(task);
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.util.concurrent.ExecutorCompletionService#submit(java.lang.Runnable,
   *      java.lang.Object)
   */
  @Override
  public Future<Object> submit(final Runnable task, final Object result) {
    if (callables != null) {
      callables.add(Executors.callable(task));
    }
    return super.submit(task, result);
  }

  /**
   * Wait for tasks completed.
   */
  public void waitForTasksCompleted() {
    if (callables != null) {
      try {
        while (callables.size() > 0) {
          final Future<Object> future = super.take();
          future.get();
          callables.remove(0);
        }
      } catch (final Throwable e) {
        // Ignore exception
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
  }

  /**
   * Wait for tasks completed.
   * 
   * @param timeout
   *          the timeout
   * @param unit
   *          the unit
   */
  public void waitForTasksCompleted(final long timeout, final TimeUnit unit) {
    if (callables != null) {
      try {
        while (callables.size() > 0) {
          final Future<Object> future = super.take();
          future.get(timeout, unit);
          callables.remove(0);
        }
      } catch (final Throwable e) {
        // Ignore exception
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
  }
}
