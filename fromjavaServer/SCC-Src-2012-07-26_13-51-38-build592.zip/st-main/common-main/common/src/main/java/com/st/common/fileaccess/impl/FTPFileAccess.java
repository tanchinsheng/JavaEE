/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 28, 2011 2:45:15 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.compress.Compressors;
import com.st.scc.common.utils.ComparisonUtils;
import com.st.scc.common.utils.FTPUtil;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class FTPFileAccess extends AbsFileAccess {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FTPFileAccess.class);

  /** The FTP connection. */
  private FTPClient ftp;

  /**
   * Instantiates a new FTP file access.
   * 
   * @param fileInfo
   *          the file info
   */
  public FTPFileAccess(final FileInfo fileInfo) {
    setSourceFile(fileInfo);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#checkAvailable()
   */
  public boolean checkAvailable() {
    return FTPUtil.checkAvailable(getSourceFile(), ftp);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#delete()
   */
  public boolean delete() {
    return FTPUtil.deleteFileFTP(ftp, getSourceFile().getPathFileName());
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#disconnect()
   */
  public void disconnect() {
    FTPUtil.disconnectFTP(ftp);
    ftp = null;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#download(java.lang.String)
   */
  public File download(final String localFile) {
    final FileInfo fileInfo = getSourceFile();
    File retVal = null;
    try {
      final File fileLocal = new File(localFile);
      ftp.setFileType(FTP.BINARY_FILE_TYPE);
      final String tmpPath = fileLocal.getAbsolutePath();
      if (FTPUtil.downloadFile(ftp, fileInfo.getPathFileName(), tmpPath)) {
        LOG.info("download file FTP from {} to local {} successfully",
            fileInfo.getPathFileName(), tmpPath);
        retVal = fileLocal;
      } else {
        LOG.info("download file FTP from {} to local {} is fail", fileInfo.getPathFileName(),
            tmpPath);
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#exists()
   */
  public boolean exists() {
    return FTPUtil.exists(getSourceFile(), ftp);
  }

  /**
   * Gets the FTP connection.
   * 
   * @return the FTP connection
   */
  public FTPClient getFtp() {
    return ftp;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#move(com.st.common.beans.FileInfo)
   */
  public boolean move(final FileInfo destFile) {
    boolean upload = false;
    if (destFile != null) {
      final FileTypeEnum destFileType = destFile.getFileType();
      if (destFileType != null) {
        switch (destFileType) {
        case NFS:
          upload = moveFTPToNFS(getSourceFile(), destFile);
          break;
        case FTP:
          upload = moveFTPToFTP(getSourceFile(), destFile);
          break;
        case SFTP:
          upload = moveFTPToSFTP(getSourceFile(), destFile);
          break;

        default:
          // do nothing
          break;
        }
      }
    }
    return upload;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#moveCompress(com.st.common.beans.FileInfo)
   */
  public boolean moveCompress(final FileInfo destFile) {
    boolean upload = false;
    final FileInfo source = getSourceFile();
    if (source != null && source.getPathFileName() != null
        && source.getPathFileName().endsWith(".Z")) {
      upload = move(destFile);
    } else if (destFile != null) {
      final FileTypeEnum destFileType = destFile.getFileType();
      if (destFileType != null) {
        switch (destFileType) {
        case FTP:
          upload = moveCompressFTPToFTP(source, destFile);
          break;
        case NFS:
          upload = moveCompressFTPToNFS(source, destFile);
          break;
        case SFTP:
          upload = moveCompressFTPToSFTP(source, destFile);
          break;
        }
      }
    }
    return upload;
  }

  /**
   * Move compress FTP to FTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveCompressFTPToFTP(final FileInfo srcFile, final FileInfo destFile) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("move file from FTP to FTP");
    }
    boolean upload = false;
    if (srcFile != null && destFile != null) {
      final FileInfo file = copyFileToDir(srcFile);
      upload = moveFTPToNFS(srcFile, file, false);
      if (upload) {
        final String compressZ = file.getPathFileName() + ".Z";
        final String fileUncompress = file.getPathFileName();
        upload = Compressors.compressZ(fileUncompress, compressZ, true);
        if (upload) {
          final File fileTemp = new File(fileUncompress);
          fileTemp.delete();
          file.setPathFileName(compressZ);
          file.setPathRootToFile(file.getPathRootToFile() + ".Z");
          upload = moveNFSToFTP(file, destFile);
        }
      }
      if (upload) {
        FTPUtil.deleteFileFTP(ftp, srcFile.getPathFileName());
      }
    }
    return upload;
  }

  /**
   * Move compress FTP to NFS.
   * 
   * @param sourceFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveCompressFTPToNFS(final FileInfo sourceFile, final FileInfo destFile) {
    return moveCompressFTPToNFS(sourceFile, destFile, true);
  }

  /**
   * Move compress FTP to NFS.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @param delete
   *          the delete
   * @return true, if successful
   */
  private boolean moveCompressFTPToNFS(final FileInfo srcFile, final FileInfo destFile,
      final boolean delete) {
    boolean uploadSuccess = false;
    if (srcFile != null && destFile != null) {
      String temp = "";
      try {
        ftp.setFileType(2);
        if (!destFile.getPathRoot().endsWith("/")) {
          temp = destFile.getPathRoot() + "/" + srcFile.getPathRootToFile();
        } else {
          temp = destFile.getPathRoot() + srcFile.getPathRootToFile();
        }
        destFile.setPathRootToFile(srcFile.getPathRootToFile());
        destFile.setPathFileName(temp);
        final File fileDest = new File(temp);
        if (!fileDest.getParentFile().exists()) {
          fileDest.getParentFile().mkdirs();
        }
        if (FTPUtil.downloadFile(ftp, srcFile.getPathFileName(), fileDest.getPath())) {
          if (LOG.isDebugEnabled()) {
            LOG.debug("Download file {} to local successfully", srcFile.getPathFileName());
          }
          final String fileIn = fileDest.getAbsolutePath();
          final String fileOut = fileIn + ".Z";
          final boolean compress = Compressors.compressZ(fileIn, fileOut, true);
          if (compress && delete) {
            if (ftp.deleteFile(srcFile.getPathFileName())) {
              uploadSuccess = true;
              if (LOG.isDebugEnabled()) {
                LOG.debug(
                    "Download to local successfully and delete file successfully path file {}",
                    srcFile.getPathFileName());
              }
            } else {
              LOG.warn(
                  "Download to local successfully but no permission to delete FTP file {}",
                  srcFile.getPathFileName());
            }
          }
        } else {
          final StringBuilder str = new StringBuilder();
          str.append("download FTP to Local is failed ");
          str.append("file source = ").append(srcFile.getPathFileName());
          str.append(" file dest").append(fileDest.getPath());
          LOG.warn(str.toString());
        }
      } catch (final Exception e) {
        final StringBuilder str = new StringBuilder();
        str.append("download file from FTP to local source = ");
        str.append(srcFile.getPathFileName());
        str.append("; dest = ").append(destFile.getPathFileName());
        str.append(" error: ").append(e.getMessage());
        LOG.error(str.toString(), e);
      }
    }
    return uploadSuccess;
  }

  /**
   * Move compress FTP to SFTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveCompressFTPToSFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null && destFile != null) {
      final FileInfo file = copyFileToDir(srcFile);
      retVal = moveFTPToNFS(srcFile, file, false);
      if (retVal) {
        final String source = file.getPathFileName();
        final String dest = file.getPathFileName() + ".Z";
        retVal = Compressors.compressZ(source, dest, true);
        if (retVal) {
          file.setPathFileName(dest);
          file.setPathRootToFile(file.getPathRootToFile() + ".Z");
          retVal = moveNFSToSFTP(file, destFile);
        }
      }
      if (retVal) {
        FTPUtil.deleteFileFTP(ftp, srcFile.getPathFileName());
      }
    }
    return retVal;
  }

  /**
   * Move the file with different FTP servers.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveDifferentFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean upload = false;
    if (srcFile != null && destFile != null) {
      final StringBuilder str = new StringBuilder();
      final String temp = System.getProperty("user.dir");
      str.append(temp).append("/tmp/");
      final String path = str.toString();
      final String tmpFilePath = str.append(srcFile.getPathRootToFile()).toString();
      final long currentTime = System.currentTimeMillis();
      final FileInfo file = new FileInfo(tmpFilePath, path, currentTime);
      file.setFileType(FileTypeEnum.NFS);
      upload = moveFTPToNFS(srcFile, file, false);
      if (upload) {
        upload = moveNFSToFTP(file, destFile);
      }
      if (upload) {
        FTPUtil.deleteFileFTP(ftp, srcFile.getPathFileName());
      }
      final File tmpFile = new File(tmpFilePath);
      if (tmpFile.exists()) {
        tmpFile.delete();
      }
    }
    return upload;
  }

  /**
   * Move FTP to FTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveFTPToFTP(final FileInfo srcFile, final FileInfo destFile) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("move file from FTP to FTP");
    }
    boolean upload = false;
    if (ComparisonUtils.compareSameServer(srcFile, destFile)) {
      upload = moveSameFTP(srcFile, destFile);
    } else {
      upload = moveDifferentFTP(srcFile, destFile);
    }
    return upload;
  }

  /**
   * Move FTP to NFS.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveFTPToNFS(final FileInfo srcFile, final FileInfo destFile) {
    return moveFTPToNFS(srcFile, destFile, true);
  }

  /**
   * Move FTP to NFS.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @param delete
   *          the delete
   * @return true, if successful
   */
  private boolean moveFTPToNFS(final FileInfo srcFile, final FileInfo destFile,
      final boolean delete) {
    boolean uploadSuccess = false;
    if (srcFile != null && destFile != null) {
      String temp = "";
      try {
        ftp.setFileType(FTP.BINARY_FILE_TYPE);
        if (!destFile.getPathRoot().endsWith("/")) {
          temp = destFile.getPathRoot() + "/" + srcFile.getPathRootToFile();
        } else {
          temp = destFile.getPathRoot() + srcFile.getPathRootToFile();
        }
        destFile.setPathRootToFile(srcFile.getPathRootToFile());
        destFile.setPathFileName(temp);
        final File fileDest = new File(temp);
        if (!fileDest.getParentFile().exists()) {
          fileDest.getParentFile().mkdirs();
        }
        if (FTPUtil.downloadFile(ftp, srcFile.getPathFileName(), fileDest.getPath())) {
          if (LOG.isDebugEnabled()) {
            LOG.debug("Download file {} to local successfully", srcFile.getPathFileName());
          }
          if (delete) {
            if (ftp.deleteFile(srcFile.getPathFileName())) {
              uploadSuccess = true;
              if (LOG.isDebugEnabled()) {
                LOG.debug(
                    "Download to local successfully and delete file successfully path file {}",
                    srcFile.getPathFileName());
              }
            } else {
              LOG.warn(
                  "Download to local successfully but no permission to delete FTP file {}",
                  srcFile.getPathFileName());
            }
          } else {
            uploadSuccess = true;
          }
        } else {
          final StringBuilder str = new StringBuilder();
          str.append("download FTP to Local is failed ");
          str.append("file source = ").append(srcFile.getPathFileName());
          str.append(" file dest").append(fileDest.getPath());
          LOG.warn(str.toString());
        }
      } catch (final Exception e) {
        final StringBuilder str = new StringBuilder();
        str.append("download file from FTP to local source = ");
        str.append(srcFile.getPathFileName());
        str.append("; dest = ").append(destFile.getPathFileName());
        str.append(" error: ").append(e.getMessage());
        LOG.error(str.toString(), e);
      }
    }
    return uploadSuccess;
  }

  /**
   * Move FTP to SFTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveFTPToSFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null && destFile != null) {
      final StringBuilder sb = new StringBuilder();
      final String temp = System.getProperty("user.dir");
      sb.append(temp).append("/tmp/");
      final String path = sb.toString();
      final String tmpFilePath = sb.append(srcFile.getPathRootToFile()).toString();
      final long currentTime = System.currentTimeMillis();
      final FileInfo file = new FileInfo(tmpFilePath, path, currentTime);
      file.setFileType(FileTypeEnum.NFS);
      retVal = moveFTPToNFS(srcFile, file, false);
      if (retVal) {
        retVal = moveNFSToSFTP(file, destFile);
      }
      if (retVal) {
        FTPUtil.deleteFileFTP(ftp, srcFile.getPathFileName());
      }
      final File tmpFile = new File(tmpFilePath);
      if (tmpFile.exists()) {
        tmpFile.delete();
      }
    }
    return retVal;
  }

  /**
   * Move the file in the same FTP server.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveSameFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean success = false;
    if (srcFile != null && destFile != null) {
      final String dest = destFile.getPathRoot();
      try {
        String newPath = "";
        if (dest.endsWith("/")) {
          newPath = dest + srcFile.getPathRootToFile();
        } else {
          newPath = dest + "/" + srcFile.getPathRootToFile();
        }
        if (ftp != null) {
          if (!FTPUtil.createPathFTP(ftp, newPath, false)) {
            FTPUtil.createFolder(ftp, newPath);
          }
          try {
            FTPUtil.deleteFileFTP(ftp, newPath);
          } finally {
            if (FTPUtil.moveFileOnFTP(ftp, srcFile.getPathFileName(), newPath)) {
              LOG.info("Move file FTP from {} to {} successfully", srcFile.getPathFileName(),
                  newPath);
              success = true;
            } else {
              LOG.warn("Move file FTP from {} to {} is failed", srcFile.getPathFileName(),
                  newPath);
            }
          }
        }
      } catch (final Exception e) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Move file from FTP to FTP source = ").append(srcFile.getPathFileName());
        sb.append("; dest = ").append(destFile.getPathFileName()).append(" is failed");
        LOG.error(sb.toString(), e);
      }
    }
    return success;
  }

  /**
   * Sets the FTP connection.
   * 
   * @param ftp
   *          the new FTP connection
   */
  public void setFtp(final FTPClient ftp) {
    this.ftp = ftp;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#upload(java.lang.String)
   */
  public boolean upload(final String localFile) {
    boolean retVal = false;
    InputStream fileStream = null;
    try {
      fileStream = new FileInputStream(localFile);
      retVal = FTPUtil.uploadToFTP(ftp, getSourceFile().getPathFileName(), fileStream);
    } catch (final FileNotFoundException e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (fileStream != null) {
        try {
          fileStream.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#upload(java.lang.String,
   *      java.lang.String)
   */
  public boolean upload(final String localFile, final String destFile) {
    boolean retVal = false;
    InputStream fileStream = null;
    if (destFile != null) {
      final String dest = getSourceFile().getPathRoot();
      try {
        String newPath = "";
        if (dest.endsWith("/")) {
          newPath = dest + destFile;
        } else {
          newPath = dest + "/" + destFile;
        }
        fileStream = new FileInputStream(localFile);
        retVal = FTPUtil.uploadToFTP(ftp, newPath, fileStream);
      } catch (final FileNotFoundException e) {
        LOG.error(e.getMessage(), e);
      } finally {
        if (fileStream != null) {
          try {
            fileStream.close();
          } catch (final IOException e) {
            LOG.error("Failed to close stream", e);
          }
        }
      }
    }
    return retVal;
  }

}
