/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 10, 2011 10:23:15 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.channels.Channel;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class FileUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class FileUtils {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileUtils.class);

  /**
   * Check if file access is available or not.
   * 
   * @param file
   *          the file
   * @return true, if successful
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static boolean checkAvailable(final File file) throws IOException {
    final String fileName = file.getAbsolutePath();

    if (!file.canRead()) {
      LOG.warn("File {} can't be read", fileName);
      return false;
    }
    if (!file.canWrite()) {
      LOG.warn("File {} can't be written", fileName);
      return false;
    }

    return true;
  }

  /**
   * Check if file access is available or not.
   * 
   * @param fileName
   *          the file name
   * @return true, if successful
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static boolean checkAvailable(final String fileName) throws IOException {
    return checkAvailable(new File(fileName));
  }

  /**
   * close file channel. if exception then write log
   * 
   * @param channel
   *          the file channel
   */
  public static void close(final Channel channel) {
    if (channel != null) {
      try {
        channel.close();
      } catch (final IOException e) {
        LOG.error("close channel failure", e);
      }
    }
  }

  /**
   * Close.
   * 
   * @param stream
   *          the stream
   */
  public static void close(final InputStream stream) {
    if (stream != null) {
      try {
        stream.close();
      } catch (final IOException e) {
        LOG.error("close input stream failure", e);
      }
    }
  }

  /**
   * Close.
   * 
   * @param stream
   *          the stream
   */
  public static void close(final OutputStream stream) {
    if (stream != null) {
      try {
        stream.close();
      } catch (final IOException e) {
        LOG.warn("Close output stream failure");
        LOG.debug(e.getMessage(), e);
      }
    }
  }

  /**
   * Copy file from source to destination.
   * 
   * @param source
   *          the source
   * @param dest
   *          the destination
   * @return true, if successful
   */
  public static boolean copyFile(final File source, final File dest) {
    if (!dest.exists()) {
      try {
        dest.getParentFile().mkdirs();
        dest.createNewFile();
      } catch (final IOException e) {
        LOG.error("Failed to create file " + dest.getAbsolutePath(), e);
        return false;
      }
    }

    boolean retVal = false;
    final int bufferSize = 8192;
    final byte[] buf = new byte[bufferSize];
    InputStream in = null;
    OutputStream out = null;
    try {
      in = new BufferedInputStream(new FileInputStream(source));
      out = new BufferedOutputStream(new FileOutputStream(dest));
      int len;
      while ((len = in.read(buf)) != -1) {
        out.write(buf, 0, len);
      }
      out.flush();
      retVal = true;
      LOG.info("Copy from {} to {} successfully", source.getAbsolutePath(),
          dest.getAbsolutePath());
    } catch (final IOException e) {
      retVal = false;
      final StringBuilder sb = new StringBuilder();
      sb.append("Failed to copy file from ").append(source.getAbsoluteFile());
      sb.append(" to ").append(dest.getAbsolutePath());
      LOG.error(sb.toString(), e);
    } finally {
      close(in);
      close(out);
    }
    return retVal;
  }

  /**
   * Creates the parent path.
   * 
   * @param file
   *          the file
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static synchronized void createParentPath(final File file) throws IOException {
    if (file != null) {
      final File parentFile = file.getParentFile();
      if (!parentFile.exists()) {
        parentFile.mkdirs();
      }
    }
  }

  /**
   * delete from file resource on NFS.
   * 
   * @param resource
   *          the resource
   * @return true, if successful
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static boolean delete(final File resource) throws IOException {
    if (resource.isDirectory()) {
      final File[] childFiles = resource.listFiles();
      for (final File child : childFiles) {
        delete(child);
      }
    }
    return resource.delete();
  }

  /**
   * Gets the file name.
   * 
   * @param pathFile
   *          the path file
   * @return the file name
   */
  public static String getFileName(final String pathFile) {
    String retVal = "";
    if (pathFile != null && pathFile.length() > 0) {
      final String tmpPath = pathFile;
      String separator = "/";
      if (tmpPath.contains("\\")) {
        separator = "\\";
      }
      if (!tmpPath.endsWith(separator)) {
        final int slash = tmpPath.lastIndexOf(separator);
        if (slash != -1) {
          retVal = tmpPath.substring(slash + 1);
        } else {
          retVal = tmpPath;
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the map id.
   * 
   * @param fileName
   *          the file name
   * @return the map id
   */
  public static String getMapId(final String fileName) {
    String mapId = null;
    if (fileName != null) {
      String[] strings = fileName.split("\\.");
      strings = strings[0].split("_");
      mapId = strings[0];
    }
    return mapId;
  }

  /**
   * Gets the parent.
   * 
   * @param pathFile
   *          the path file
   * @return the parent
   */
  public static String getParent(final String pathFile) {
    String retVal = "";
    if (pathFile != null && pathFile.length() > 0) {
      final String tmpPath = pathFile;
      String separator = "/";
      if (tmpPath.contains("\\")) {
        separator = "\\";
      }
      final int slash = tmpPath.lastIndexOf(separator);
      if (slash != -1) {
        retVal = tmpPath.substring(0, slash);
      }
    }
    return retVal;
  }

  /**
   * get tail file name to lower case example filename is test.StDf
   * getTailFileName(fileName) return .stdf.
   * 
   * @param fileName
   *          the file name
   * @return the tail file name
   */
  public static String getTailFileName(final String fileName) {
    final Pattern p = Pattern.compile("\\.");
    final String[] tokens = p.split(fileName);
    final String temp = "." + tokens[tokens.length - 1];
    if (temp.endsWith(".Z")) {
      return temp;
    }
    return temp.toLowerCase();
  }

  /**
   * Instantiates a new file utility.
   */
  private FileUtils() {

  }
}
