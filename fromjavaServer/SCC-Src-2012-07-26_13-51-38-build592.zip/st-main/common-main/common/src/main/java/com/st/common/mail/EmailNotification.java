/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 13, 2011 6:34:59 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.mail;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class EmailNotification.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class EmailNotification {
  /**
   * The Enum ErrorMailEnum.
   */
  public static enum ErrorMailEnum {

    /** The RMI_ERROR. */
    RMI_ERROR("RMI connection is error"),

    /** The DB_ERROR. */
    DB_ERROR("Database connection is error"),

    /** The DB_SM_ERROR. */
    DB_SM_ERROR("Connection to extractor database is error"),

    /** The DB_SCC_ERROR. */
    DB_SCC_ERROR("Connection to SCC database is error"),

    /** The DB_WMR_ERROR. */
    DB_WMR_ERROR("Connection to WMR database is error"),

    /** The FILE_ACCESS_ERROR. */
    FILE_ACCESS_ERROR("File access is error"),

    /** The FILE_ACCESS_CONNECTION_ERROR. */
    FILE_ACCESS_CONNECTION_ERROR("File access connection is error");

    /** The message. */
    private String message;

    /**
     * Instantiates a new error mail enum.
     * 
     * @param message
     *          the message
     */
    ErrorMailEnum(final String message) {
      this.message = message;
    }

    /**
     * Gets the message.
     * 
     * @return the message
     */
    public String getMessage() {
      return message;
    }

  }

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(EmailNotification.class);

  /** The Constant MAIL_INTERVAL. */
  private static final long MAIL_INTERVAL = 10 * 60000; // 10 minutes

  /** The Constant CLEAN_UP_MAIL_INTERVAL. */
  private static final long CLEAN_UP_MAIL_INTERVAL = 30 * 60000; // 30 minutes

  /** The Constant instance. */
  private static final EmailNotification INSTANCE = new EmailNotification();

  /**
   * Gets the single instance of EmailNotification.
   * 
   * @return single instance of EmailNotification
   */
  public static EmailNotification getInstance() {
    return INSTANCE;
  }

  /** The one time mail map. */
  private final Map<String, Long> oneTimeMailMap = new ConcurrentHashMap<String, Long>();

  /** The message mail map. */
  private final Map<String, Long> messageMailMap = new ConcurrentHashMap<String, Long>();

  /** The last cleanup time. */
  private long lastCleanupTime;

  /** The server info. */
  private SMTPServerInfo serverInfo;

  /** The admin email. */
  private String adminEmail;

  /** The default from. */
  private String defaultFrom;

  /** The default subject. */
  private String defaultSubject;

  /** The default from display name. */
  private String defaultFromDisplayName;

  /**
   * Instantiates a new email notification.
   */
  private EmailNotification() {
    lastCleanupTime = System.currentTimeMillis();
  }

  /**
   * Cleanup old mail.
   */
  private void cleanupOldMails() {
    final long currentTime = System.currentTimeMillis();
    if (currentTime - lastCleanupTime > CLEAN_UP_MAIL_INTERVAL) {
      cleanupOldMails(oneTimeMailMap, currentTime);
      cleanupOldMails(messageMailMap, currentTime);
      lastCleanupTime = currentTime;
    }
  }

  /**
   * Cleanup old mails.
   * 
   * @param mailMap
   *          the mail map
   * @param currentTime
   *          the current time
   */
  private void cleanupOldMails(final Map<String, Long> mailMap, final long currentTime) {
    if (mailMap != null) {
      final Set<Entry<String, Long>> entrySet = mailMap.entrySet();
      for (final Entry<String, Long> entry : entrySet) {
        final String key = entry.getKey();
        final Long value = entry.getValue();
        if (value != null && currentTime - value.longValue() > MAIL_INTERVAL) {
          mailMap.remove(key);
        }
      }
    }
  }

  /**
   * Clear all mail data.
   */
  public void clearMails() {
    messageMailMap.clear();
    oneTimeMailMap.clear();
  }

  /**
   * Clear server information.
   */
  public void clearServerInfo() {
    adminEmail = null;
    defaultFrom = null;
    defaultSubject = null;
    serverInfo = null;
  }

  /**
   * Gets the admin email.
   * 
   * @return the admin email
   */
  public String getAdminEmail() {
    return adminEmail;
  }

  /**
   * Gets the default from.
   * 
   * @return the default from
   */
  public String getDefaultFrom() {
    return defaultFrom;
  }

  /**
   * Gets the default from display name.
   * 
   * @return the default from display name
   */
  public String getDefaultFromDisplayName() {
    return defaultFromDisplayName;
  }

  /**
   * Gets the default subject.
   * 
   * @return the default subject
   */
  public String getDefaultSubject() {
    return defaultSubject;
  }

  /**
   * Gets the server info.
   * 
   * @return the server info
   */
  public SMTPServerInfo getServerInfo() {
    return serverInfo;
  }

  /**
   * Reset sending one message mail.
   * 
   * @param message
   *          the message
   */
  public void resetOMM(final String message) {
    if (message != null && message.length() > 0) {
      messageMailMap.remove(message);
    }
  }

  /**
   * Reset sending one time mail.
   * 
   * @param errorMail
   *          the error mail
   */
  public void resetOTM(final ErrorMailEnum errorMail) {
    if (errorMail != null) {
      oneTimeMailMap.remove(errorMail);
    }
  }

  /**
   * Send mail.
   * 
   * @param mailItem
   *          the mail item
   */
  public void sendMail(final MailItem mailItem) {
    if (mailItem != null) {
      try {
        if (serverInfo != null) {
          MailUtil.sendMail(mailItem, serverInfo);
        } else {
          org.apache.log4j.Logger smtpLogger =
              org.apache.log4j.Logger.getLogger("st.scc.mail");
          smtpLogger.error(mailItem.getMessage());
        }
      } catch (final Exception e) {
        LOG.error("Failed to send e-mail", e);
      }
    }
//    if (serverInfo != null && mailItem != null) {
//      try {
//        MailUtil.sendMail(mailItem, serverInfo);
//      } catch (final Exception e) {
//        LOG.error("Failed to send e-mail", e);
//      }
//    }
  }

  /**
   * Send mail.
   * 
   * @param message
   *          the message
   */
  public void sendMail(final String message) {
    final MailItem mailItem = new MailItem();
    mailItem.setFrom(defaultFrom);
    if (defaultFromDisplayName != null && defaultFromDisplayName.length() > 0) {
      mailItem.setFrom(defaultFromDisplayName);
    }
    mailItem.setTo(adminEmail);
    mailItem.setSubject(defaultSubject);
    mailItem.setMessage(message);
    sendMail(mailItem);
  }

  /**
   * Send one message mail.
   * 
   * @param message
   *          the message
   */
  public void sendOneMessageMail(final String message) {
    if (message != null && message.length() > 0) {
      final long currentTime = System.currentTimeMillis();
      final Long lastSend = messageMailMap.get(message);
      if (lastSend == null) {
        messageMailMap.put(message, currentTime);
        sendMail(message);
      } else if (currentTime - lastSend.longValue() > MAIL_INTERVAL) {
        messageMailMap.put(message, currentTime);
        sendMail(message);
      }
    }
    cleanupOldMails();
  }

  /**
   * Send one message mail.
   * 
   * @param message
   *          the message
   * @param interval
   *          the interval
   */
  public void sendOneMessageMail(final String message, final long interval) {
    if (message != null && message.length() > 0) {
      final long currentTime = System.currentTimeMillis();
      final Long lastSend = messageMailMap.get(message);
      if (lastSend == null) {
        messageMailMap.put(message, currentTime);
        sendMail(message);
      } else if (currentTime - lastSend.longValue() > interval) {
        messageMailMap.put(message, currentTime);
        sendMail(message);
      }
    }
    cleanupOldMails();
  }

  /**
   * Send one time mail with default message.
   * 
   * @param errorMail
   *          the error mail
   */
  public void sendOTM(final ErrorMailEnum errorMail) {
    if (errorMail != null) {
      sendOTM(errorMail, errorMail.getMessage());
    }
  }

  /**
   * Send one time mail.
   * 
   * @param errorMail
   *          the error mail
   * @param message
   *          the message
   */
  public void sendOTM(final ErrorMailEnum errorMail, final String message) {
    if (errorMail != null && message != null && message.length() > 0) {
      final long currentTime = System.currentTimeMillis();
      final String key = errorMail.name();
      final Long lastSend = oneTimeMailMap.get(key);
      if (lastSend == null) {
        oneTimeMailMap.put(key, currentTime);
        sendMail(message);
      } else if (currentTime - lastSend.longValue() > MAIL_INTERVAL) {
        oneTimeMailMap.put(key, currentTime);
        sendMail(message);
      }
    }
    cleanupOldMails();
  }

  /**
   * Sets the admin email.
   * 
   * @param adminEmail
   *          the new admin email
   */
  public void setAdminEmail(final String adminEmail) {
    this.adminEmail = adminEmail;
  }

  /**
   * Sets the default from.
   * 
   * @param defaultFrom
   *          the new default from
   */
  public void setDefaultFrom(final String defaultFrom) {
    this.defaultFrom = defaultFrom;
  }

  /**
   * Sets the default from display name.
   * 
   * @param defaultFromDisplayName
   *          the new default from display name
   */
  public void setDefaultFromDisplayName(final String defaultFromDisplayName) {
    this.defaultFromDisplayName = defaultFromDisplayName;
  }

  /**
   * Sets the default subject.
   * 
   * @param defaultSubject
   *          the new default subject
   */
  public void setDefaultSubject(final String defaultSubject) {
    this.defaultSubject = defaultSubject;
  }

  /**
   * Sets the server info.
   * 
   * @param serverInfo
   *          the new server info
   */
  public void setServerInfo(final SMTPServerInfo serverInfo) {
    this.serverInfo = serverInfo;
  }

}
