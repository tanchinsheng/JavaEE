/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 14, 2011 11:16:13 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.scc.common.utils.FileUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class NFSFileScanner extends AbsFileScanner {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(NFSFileScanner.class);

  /**
   * Instantiates a new NFS file scanner.
   */
  public NFSFileScanner() {
    setFileType(FileTypeEnum.NFS);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.FileScanner#disconnect()
   */
  public void disconnect() {
    // do nothing
  }

  /**
   * Get STDF files from path with given depth.
   * 
   * @param path
   *          is path not string file:/
   * @param depth
   *          the depth
   * @param listFile
   *          the list file
   * @param maxSizeFile
   *          the max size file
   */
  private void getListNewFileNFS(final String path, final int depth,
      final List<FileInfo> listFile, final int maxSizeFile) {
    // If depth of file exceed the limit DEPTHMINIMUM then return
    // DEPTHMINIMUM.
    if (depth < 0) {
      return;
    }
    if (maxSizeFile > 0 && listFile.size() >= maxSizeFile) {
      return;
    }
    final File filePath = new File(path);
    // If path is not exist then return PATHNOTEXIST.
    if (!filePath.exists()) {
      return;
    }

    // arrayChilrdenPath is path to folder children.
    final String[] arrayChildrenPath = filePath.list();
    StringBuilder sb = null;
    if (arrayChildrenPath != null && arrayChildrenPath.length > 0) {
      for (final String element : arrayChildrenPath) {
        sb = new StringBuilder();
        sb.append(path);
        if (!path.endsWith("/")) {
          sb.append("/");
        }
        sb.append(element);
        final String childPath = sb.toString();
        final File childFile = new File(childPath);
        // select all files
        if (childFile.isDirectory()) {
          getListNewFileNFS(childPath, depth - 1, listFile, maxSizeFile);
        } else {
          final FileInfo fileInfo =
              new FileInfo(childPath, getMonitorFolder(), childFile.lastModified());
          final List<String> filePatternList = getFilePatternList();
          if (filePatternList != null) {
            // if type of directory has in listFileType then add this
            // file into list.
            for (final String fileType : filePatternList) {
              if (Pattern.matches(fileType, FileUtils.getTailFileName(childFile.getName()))) {
                fileInfo.setFileType(getFileType());
                fileInfo.setSize(childFile.length());
                listFile.add(fileInfo);
                break;
              }
            }
          }
        }
        if (maxSizeFile > 0 && listFile.size() >= maxSizeFile) {
          break;
        }
      }
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.FileScanner#scan(java.lang.String, int, int)
   */
  public List<FileInfo> scan(final String filePath, final int depth, final int maxSize) {
    List<FileInfo> list = null;
    final File file = new File(filePath);
    if (file.exists()) {
      list = new ArrayList<FileInfo>();
      getListNewFileNFS(filePath, depth, list, maxSize);
      if (LOG.isDebugEnabled()) {
        LOG.debug("Scanned files successfully");
      }
    } else {
      LOG.error("path of monitor folder does not exist or no permission");
    }
    return list;
  }

}
