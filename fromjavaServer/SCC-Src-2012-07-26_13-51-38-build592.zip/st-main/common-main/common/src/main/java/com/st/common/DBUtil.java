/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Apr 6, 2011 5:29:22 PM - nguyensn - Initialize version
/********************************************************************************/
package com.st.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class DBUtil {

  private DBUtil() {

  }

  private static final int BYTE_0FF = 0xff;
  /** the Logger */
  static final Logger LOGGER = LoggerFactory.getLogger(DBUtil.class);

  /**
   * Hash password.
   * 
   * @param password
   *            the password
   * @return the string
   */
  public static String hashPassword(String password) {
    if (password == null) {
      password = "";
    }
    password = password.trim();
    MessageDigest messageDigest = null;
    try {
      messageDigest = MessageDigest.getInstance("MD5");
    } catch (NoSuchAlgorithmException e) {
      LOGGER.error(e.getMessage());
    }
    messageDigest.update(password.getBytes());

    byte[] byteData = messageDigest.digest();
    StringBuffer hexString = new StringBuffer();
    for (int i = 0; i < byteData.length; i++) {
      String hex = Integer.toHexString(BYTE_0FF & byteData[i]);
      if (hex.length() == 1) {
        hexString.append('0');
      }
      hexString.append(hex);
    }
    return hexString.toString();
  }

  /**
   * Gets the dB config properties.
   * 
   * @param propertiesFile
   *            the properties file
   * @return the dB config properties
   */
  public static Properties getDBConfigProperties(String propertiesFile) {
    Properties properties = new Properties();
    InputStream fis;
    try {
      fis = new FileInputStream(new File(propertiesFile));
      properties.load(fis);
    } catch (FileNotFoundException e) {
      LOGGER.error(e.getMessage());
    } catch (IOException e) {
      LOGGER.error(e.getMessage());
    }
    return properties;
  }
}
