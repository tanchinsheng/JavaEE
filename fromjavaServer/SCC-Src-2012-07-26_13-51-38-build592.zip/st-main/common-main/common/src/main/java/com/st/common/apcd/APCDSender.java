/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 11, 2011 10:40:38 AM - nhatvn - Initialize version
/********************************************************************************/
package com.st.common.apcd;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class APCDSender.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class APCDSender {

  /**
   * The Class HandlerConnection.
   */
  class HandlerConnection implements Runnable {

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Runnable#run()
     */
    public void run() {
      connect();
      while (!isConnected) {
        if (connectDelayTime == 0) {
          connectDelayTime = DEFAULT_DELAY_TIME;
        }
        try {
          Thread.sleep(connectDelayTime * 1000);
        } catch (final InterruptedException e) {
          if (LOG.isDebugEnabled()) {
            LOG.debug(e.getMessage(), e);
          }
        }
        connect();
      }
    }
  }
  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(APCDSender.class);

  /** The Constant KEY_REMOTE_HOST. */
  public static final String KEY_REMOTE_HOST = "RemoteHost";

  /** The Constant KEY_PORT. */
  public static final String KEY_PORT = "Port";

  /** The Constant KEY_MAIL_BOX. */
  public static final String KEY_MAIL_BOX = "MailBox";

  /** The Constant KEY_MBX. */
  public static final String KEY_MBX = "MBX";

  /** The Constant DEFAULT_DELAY_TIME. */
  private static final int DEFAULT_DELAY_TIME = 20;

  /** The Constant TIME_OUT_CONNECT. */
  private static final int TIME_OUT_CONNECT = 1000 * 5; // 5 SECONDS.

  /** The port. */
  private int port;

  /** The remote host. */
  private String remoteHost;

  /** The inet address. */
  private InetAddress inetAddress;

  /** The MBX. */
  private String MBX;

  /** The mail box. */
  private String mailBox;

  /** The connect delay time. */
  private int connectDelayTime;

  /** The socket. */
  private Socket socket;

  /** The is connected. */
  private boolean isConnected;

  /** The output stream. */
  private DataOutputStream outputStream;

  /** The input stream. */
  private DataInputStream inputStream;

  /**
   * Instantiates a new APCD sender.
   */
  public APCDSender() {
  }

  /**
   * Check error.
   * 
   * @param reply
   *          the reply
   * @return true, if successful
   */
  private boolean checkError(final String reply) {
    return reply.startsWith("ERROR,0");
  }

  /**
   * Close socket.
   */
  private void closeSocket() {
    if (outputStream != null) {
      try {
        outputStream.close();
      } catch (final IOException e) {
        LOG.error("Can not close output stream.Exception:" + e.getMessage());
      }
    }
    if (inputStream != null) {
      try {
        inputStream.close();
      } catch (final IOException e) {
        LOG.error("Can not input stream.Exception:" + e.getMessage());
      }
    }
    try {
      if (socket != null) {
        socket.close();
      }
      isConnected = false;
      LOG.info("Close socket successfully.");
    } catch (final Exception e) {
      LOG.error("Error when close socket. Exception:" + e.getMessage());
    }
  }

  /**
   * Try to connect to server.
   */
  private void connect() {
    if (remoteHost == null || remoteHost.length() == 0) {
      LOG.error("Remote host is not configured.");
      return;
    }
    try {
      if (inetAddress == null) {
        inetAddress = getAddressByName(remoteHost);
      }
      connect(inetAddress, port);
      isConnected = true;
    } catch (final Exception e) {
      isConnected = false;
      LOG.error("Cannot connect to server: " + remoteHost + ", port: " + port
          + ". Cannot send message through APCD server.");
    }
  }

  /**
   * Connect to server with address of server and port.
   * 
   * @param address
   *          the address
   * @param port
   *          the port
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   * @throws SocketTimeoutException
   *           the socket timeout exception
   */
  private void connect(final InetAddress address, final int port) throws IOException,
      SocketTimeoutException {
    // socket = new Socket(address, port);
    socket = new Socket();
    final InetSocketAddress socketAddr = new InetSocketAddress(address, port);
    socket.connect(socketAddr, TIME_OUT_CONNECT);
    socket.setSoTimeout(TIME_OUT_CONNECT);

    LOG.info("Create socket sucessfully connect to host= " + address.getHostName()
        + ", port= " + port);
    // Get inputStream and ouputStream of socket.
    outputStream = new DataOutputStream(socket.getOutputStream());
    inputStream = new DataInputStream(socket.getInputStream());
  }

  /**
   * Get Address by hostName.
   * 
   * @param hostName
   *          the host name
   * @return the address by name
   */
  private InetAddress getAddressByName(final String hostName) {
    try {
      return InetAddress.getByName(hostName);
    } catch (final Exception ex) {
      LOG.error("Host name=" + hostName + "." + ex.getMessage());
      return null;
    }
  }

  /**
   * Read reply message from server.
   * 
   * @return reply message,if null, there is a error when read.
   */
  private String readReply() {
    short s;
    char[] t;
    String result = null;
    try {
      s = inputStream.readShort();
      if (s > 0) {
        int c;
        t = new char[s];

        for (int j = 0; j < s; j++) {
          c = inputStream.readUnsignedByte();
          t[j] = (char) c;
        }
        result = new String(t);
      }
    } catch (final IOException e) {
      LOG.error("Error when read reply from server.");
      LOG.error(e.getMessage(), e);
    }
    return result;
  }

  /**
   * Send and receive message between client and server.
   * 
   * @param message
   *          the message
   * @return true, if successful
   */
  private boolean sendAndReceive(final String message) {
    boolean isSuccessAll = true;
    try {
      if (MBX == null || MBX.length() == 0) {
        LOG.error("Not config MBX name,can't open MBX,can't send message.");
        return false;
      }
      if (mailBox == null || mailBox.length() == 0) {
        LOG.error("Not config mailbox,can't send message.");
        return false;
      }

      final String openMBX = "MBX_OPEN," + MBX;
      isSuccessAll = sendCommand(openMBX);
      if (isSuccessAll) {
        // Read reply message from server.
        String replyMsg = readReply();
        boolean isOpenSuccess = false;
        if (replyMsg != null) {
          if (checkError(replyMsg)) {
            isOpenSuccess = true;
            LOG.info("Send succesfully:" + openMBX);

            final StringBuilder builder = new StringBuilder();
            builder.append("MBX_PUTR,").append(mailBox).append(",0,");
            builder.append(message);
            final String putMsg = builder.toString();
            isSuccessAll = sendCommand(putMsg);
            if (isSuccessAll) {
              // Read reply message from server.
              replyMsg = readReply();
              boolean isPutSuccess = false;
              if (replyMsg != null) {
                if (checkError(replyMsg)) {
                  isPutSuccess = true;
                  LOG.info("Send succesfully:" + putMsg);
                }
              }
              if (!isPutSuccess) {
                isSuccessAll = false;
                LOG.info("Rely error when put message MBX_PUTR. Reply message=" + replyMsg);
              }
            }
          }
        }
        if (!isOpenSuccess) {
          isSuccessAll = false;
          LOG.info("Rely error when open MBX. Reply message=" + replyMsg);
        }
      }
      final String closeMsg = "MBX_CLOSE";
      isSuccessAll = sendCommand(closeMsg);

      LOG.info("Send succesfully MBX_CLOSE.");
    } catch (final Exception e) {
      isSuccessAll = false;
      LOG.error(e.getMessage(), e);
    }
    return isSuccessAll;
  }

  /**
   * Send a command to server.
   * 
   * @param command
   *          the command
   * @return true, if successful
   */
  private boolean sendCommand(final String command) {
    final int length = command.length();
    boolean isSucess = false;
    try {
      outputStream.writeShort(length);
      outputStream.writeBytes(command);
      outputStream.flush();
      isSucess = true;
    } catch (final IOException e) {
      LOG.error("Error when send message :" + command);
      LOG.error(e.getMessage(), e);
    }
    return isSucess;
  }

  /**
   * Send message.
   * 
   * @param message
   *          the message
   * @return true, if successful
   */
  public boolean sendMessage(final String message) {
    boolean isSendSucessful = false;
    connect();
    if (!isConnected) {
      // //Try connect again to server
      // Thread thread = new Thread(new HandlerConnection());
      // thread.start();
      return false;
    }
    // Send message
    isSendSucessful = sendAndReceive(message);
    // close socket
    closeSocket();
    return isSendSucessful;
  }

  /**
   * Send message to server.
   * 
   * @param message
   *          the message
   * @param map
   *          the map
   * @return true if message is sent successfully.
   */
  public boolean sendMessage(final String message, final Map<String, String> map) {
    boolean isSendSucessful = setConfigValues(map);
    if (isSendSucessful) {
      // Connect to server.
      connect();
      if (!isConnected) {
        // //Try connect again to server
        // Thread thread = new Thread(new HandlerConnection());
        // thread.start();
        return false;
      }
      // Send message
      isSendSucessful = sendAndReceive(message);
      // close socket
      closeSocket();
    }
    return isSendSucessful;
  }

  /**
   * Set value read from config file to local variables.
   * 
   * @param map
   *          the map
   * @return true if get data successfully.
   */
  public boolean setConfigValues(final Map<String, String> map) {
    boolean success = false;
    try {
      if (map != null) {
        remoteHost = map.get(KEY_REMOTE_HOST);
        try {
          port = Integer.parseInt(map.get(KEY_PORT));
        } catch (final NumberFormatException nfe) {
          LOG.error("APCD Port is not an integer.", nfe);
          return false;
        }
        mailBox = map.get(KEY_MAIL_BOX);
        MBX = map.get(KEY_MBX);
        success = true;
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    }
    return success;
  }
}