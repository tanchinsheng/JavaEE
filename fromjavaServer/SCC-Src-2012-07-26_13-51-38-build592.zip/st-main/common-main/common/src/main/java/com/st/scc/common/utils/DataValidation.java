/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 25, 2012 11:13:53 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The Class DataValidation.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public final class DataValidation {

  /** The Constant EMAIL_REGEX. */
  public static final String EMAIL_REGEX =
      "([\\w-+]+(?:\\.[\\w-+]+)*@(?:[\\w-]+\\.)+[a-zA-Z]{2,7})";

  /** The Constant HTTP_URL_REGEX. */
  public static final String HTTP_URL_REGEX =
      "((?:http|https)(?::\\/{2}[\\w]+)(?:[\\/|\\.]?)(?:[^\\s\"]*))";

  /**
   * Check good mail.
   * 
   * @param email
   *          the email
   * @return true, if successful
   */
  public static boolean checkGoodMail(final String email) {
    return match(email, EMAIL_REGEX);
  }

  /**
   * Check good URL.
   * 
   * @param url
   *          the URL
   * @return true, if successful
   */
  public static boolean checkGoodUrl(final String url) {
    return match(url, HTTP_URL_REGEX);
  }

  /**
   * Check if the given string matches the regular expression.
   * 
   * @param string
   *          the string
   * @param regex
   *          the regular expression
   * @return true, if successful
   */
  public static boolean match(final String string, final String regex) {
    boolean retVal = false;
    if (string != null) {
      final Pattern p = Pattern.compile(regex);
      final Matcher m = p.matcher(string);
      retVal = m.matches();
    }
    return retVal;
  }

  /**
   * Instantiates a new data validation.
   */
  private DataValidation() {

  }
}
