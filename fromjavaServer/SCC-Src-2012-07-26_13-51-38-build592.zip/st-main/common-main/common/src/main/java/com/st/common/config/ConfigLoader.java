/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 11, 2011 2:38:39 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.config;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.EncryptionUtils;
import com.st.common.beans.FileTypeEnum;
import com.st.common.exception.SccException;
import com.st.common.filewatcher.FileWatcherInfo;
import com.st.common.mail.EmailNotification;
import com.st.common.mail.SMTPServerInfo;

/**
 * The Class ConfigLoader.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ConfigLoader {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ConfigLoader.class);

  /** The Constant KEY_INTERVAL_TIME. */
  public static final String KEY_INTERVAL_TIME = "INTERVAL_TIME";

  public static final String KEY_XML_INTERVAL_TIME = "XML_INTERVAL_TIME";

  /** The Constant KEY_MAX_SIZE_NOTIFY. */
  public static final String KEY_MAX_SIZE_NOTIFY = "MAX_FILE_NOTIFIED";

  public static final String KEY_XML_MAX_SIZE_NOTIFY = "XML_MAX_FILE_NOTIFIED";

  /** The Constant KEY_CONFIG_TIME. */
  public static final String KEY_CONFIG_TIME = "CONFIG_TIME";

  /** The Constant FOLDER_NAME_STDF. */
  public static final String FOLDER_NAME_STDF = "STDF_FOLDER";

  /** The Constant FOLDER_NAME_STDF_ARCHIVE. */
  public static final String FOLDER_NAME_STDF_ARCHIVE = "STDF_ARCHIVE_FOLDER";

  /** The Constant FOLDER_NAME_STDF_ERROR. */
  public static final String FOLDER_NAME_STDF_ERROR = "STDF_ERROR_FOLDER";

  /** The Constant FOLDER_NAME_XML. */
  public static final String FOLDER_NAME_XML = "XML_FOLDER";

  /** The Constant FOLDER_NAME_XML_ARCHIVE. */
  public static final String FOLDER_NAME_XML_ARCHIVE = "XML_ARCHIVE_FOLDER";

  /** The Constant FOLDER_NAME_XML_ERROR. */
  public static final String FOLDER_NAME_XML_ERROR = "XML_ERROR_FOLDER";

  /** The Constant CONF_FOLDER_TYPE. */
  private static final String CONF_FOLDER_TYPE = ".FOLDER_TYPE";

  /** The Constant CONF_FOLDER. */
  private static final String CONF_FOLDER = ".FOLDER";

  /** The Constant CONF_FILE_TYPE. */
  private static final String CONF_FILE_TYPE = ".FILE_TYPE";

  /** The Constant CONF_FILE_SERVER. */
  private static final String CONF_FILE_SERVER = ".FILE_SERVER";

  /** The Constant CONF_USER_NAME. */
  private static final String CONF_USER_NAME = ".USER_NAME";

  /** The Constant CONF_PASSWORD. */
  private static final String CONF_PASSWORD = ".PASSWORD";

  /** The Constant CONF_PORT. */
  private static final String CONF_PORT = ".PORT";

  /** The Constant CONF_DEPTH_FOLDER. */
  private static final String CONF_DEPTH_FOLDER = ".FOLDER_DEPTH";

  /** The Constant CONF_EXPIRED_TIME. */
  private static final String CONF_EXPIRED_TIME = ".EXPIRED_TIME";

  /** The Constant STDF_FOLDER_TYPE. */
  public static final String STDF_FOLDER_TYPE = FOLDER_NAME_STDF + CONF_FOLDER_TYPE;

  /** The Constant STDF_FOLDER. */
  public static final String STDF_FOLDER = FOLDER_NAME_STDF + CONF_FOLDER;

  /** The Constant STDF_FILE_TYPE. */
  public static final String STDF_FILE_TYPE = FOLDER_NAME_STDF + CONF_FILE_TYPE;

  /** The Constant STDF_FILE_SERVER. */
  public static final String STDF_FILE_SERVER = FOLDER_NAME_STDF + CONF_FILE_SERVER;

  /** The Constant STDF_USER_NAME. */
  public static final String STDF_USER_NAME = FOLDER_NAME_STDF + CONF_USER_NAME;

  /** The Constant STDF_PASSWORD. */
  public static final String STDF_PASSWORD = FOLDER_NAME_STDF + CONF_PASSWORD;

  /** The Constant STDF_PORT. */
  public static final String STDF_PORT = FOLDER_NAME_STDF + CONF_PORT;

  /** The Constant STDF_DEPTH_FOLDER. */
  public static final String STDF_DEPTH_FOLDER = FOLDER_NAME_STDF + CONF_DEPTH_FOLDER;

  /** The Constant STDF_ARCHIVE_FOLDER_TYPE. */
  public static final String STDF_ARCHIVE_FOLDER_TYPE = FOLDER_NAME_STDF_ARCHIVE
      + CONF_FOLDER_TYPE;

  /** The Constant STDF_ARCHIVE_FOLDER. */
  public static final String STDF_ARCHIVE_FOLDER = FOLDER_NAME_STDF_ARCHIVE + CONF_FOLDER;

  /** The Constant STDF_ARCHIVE_FILE_TYPE. */
  public static final String STDF_ARCHIVE_FILE_TYPE = FOLDER_NAME_STDF_ARCHIVE
      + CONF_FILE_TYPE;

  /** The Constant STDF_ARCHIVE_FILE_SERVER. */
  public static final String STDF_ARCHIVE_FILE_SERVER = FOLDER_NAME_STDF_ARCHIVE
      + CONF_FILE_SERVER;

  /** The Constant STDF_ARCHIVE_USER_NAME. */
  public static final String STDF_ARCHIVE_USER_NAME = FOLDER_NAME_STDF_ARCHIVE
      + CONF_USER_NAME;

  /** The Constant STDF_ARCHIVE_PASSWORD. */
  public static final String STDF_ARCHIVE_PASSWORD = FOLDER_NAME_STDF_ARCHIVE + CONF_PASSWORD;

  /** The Constant STDF_ARCHIVE_PORT. */
  public static final String STDF_ARCHIVE_PORT = FOLDER_NAME_STDF_ARCHIVE + CONF_PORT;

  /** The Constant STDF_ARCHIVE_DEPTH_FOLDER. */
  public static final String STDF_ARCHIVE_DEPTH_FOLDER = FOLDER_NAME_STDF_ARCHIVE
      + CONF_DEPTH_FOLDER;

  /** The Constant STDF_ARCHIVE_EXPIRED_TIME. */
  public static final String STDF_ARCHIVE_EXPIRED_TIME = FOLDER_NAME_STDF_ARCHIVE
      + CONF_EXPIRED_TIME;

  /** The Constant STDF_ERROR_FOLDER_TYPE. */
  public static final String STDF_ERROR_FOLDER_TYPE = FOLDER_NAME_STDF_ERROR
      + CONF_FOLDER_TYPE;

  /** The Constant STDF_ERROR_FOLDER. */
  public static final String STDF_ERROR_FOLDER = FOLDER_NAME_STDF_ERROR + CONF_FOLDER;

  /** The Constant STDF_ERROR_FILE_TYPE. */
  public static final String STDF_ERROR_FILE_TYPE = FOLDER_NAME_STDF_ERROR + CONF_FILE_TYPE;

  /** The Constant STDF_ERROR_FILE_SERVER. */
  public static final String STDF_ERROR_FILE_SERVER = FOLDER_NAME_STDF_ERROR
      + CONF_FILE_SERVER;

  /** The Constant STDF_ERROR_USER_NAME. */
  public static final String STDF_ERROR_USER_NAME = FOLDER_NAME_STDF_ERROR + CONF_USER_NAME;

  /** The Constant STDF_ERROR_PASSWORD. */
  public static final String STDF_ERROR_PASSWORD = FOLDER_NAME_STDF_ERROR + CONF_PASSWORD;

  /** The Constant STDF_ERROR_PORT. */
  public static final String STDF_ERROR_PORT = FOLDER_NAME_STDF_ERROR + CONF_PORT;

  /** The Constant XML_FOLDER_TYPE. */
  public static final String XML_FOLDER_TYPE = FOLDER_NAME_XML + CONF_FOLDER_TYPE;

  /** The Constant XML_FOLDER. */
  public static final String XML_FOLDER = FOLDER_NAME_XML + CONF_FOLDER;

  /** The Constant XML_FILE_TYPE. */
  public static final String XML_FILE_TYPE = FOLDER_NAME_XML + CONF_FILE_TYPE;

  /** The Constant XML_FILE_SERVER. */
  public static final String XML_FILE_SERVER = FOLDER_NAME_XML + CONF_FILE_SERVER;

  /** The Constant XML_USER_NAME. */
  public static final String XML_USER_NAME = FOLDER_NAME_XML + CONF_USER_NAME;

  /** The Constant XML_PASSWORD. */
  public static final String XML_PASSWORD = FOLDER_NAME_XML + CONF_PASSWORD;

  /** The Constant XML_PORT. */
  public static final String XML_PORT = FOLDER_NAME_XML + CONF_PORT;

  /** The Constant XML_DEPTH_FOLDER. */
  public static final String XML_DEPTH_FOLDER = FOLDER_NAME_XML + CONF_DEPTH_FOLDER;

  /** The Constant XML_ARCHIVE_FOLDER_TYPE. */
  public static final String XML_ARCHIVE_FOLDER_TYPE = FOLDER_NAME_XML_ARCHIVE
      + CONF_FOLDER_TYPE;

  /** The Constant XML_ARCHIVE_FOLDER. */
  public static final String XML_ARCHIVE_FOLDER = FOLDER_NAME_XML_ARCHIVE + CONF_FOLDER;

  /** The Constant XML_ARCHIVE_FILE_TYPE. */
  public static final String XML_ARCHIVE_FILE_TYPE = FOLDER_NAME_XML_ARCHIVE + CONF_FILE_TYPE;

  /** The Constant XML_ARCHIVE_FILE_SERVER. */
  public static final String XML_ARCHIVE_FILE_SERVER = FOLDER_NAME_XML_ARCHIVE
      + CONF_FILE_SERVER;

  /** The Constant XML_ARCHIVE_USER_NAME. */
  public static final String XML_ARCHIVE_USER_NAME = FOLDER_NAME_XML_ARCHIVE + CONF_USER_NAME;

  /** The Constant XML_ARCHIVE_PASSWORD. */
  public static final String XML_ARCHIVE_PASSWORD = FOLDER_NAME_XML_ARCHIVE + CONF_PASSWORD;

  /** The Constant XML_ARCHIVE_PORT. */
  public static final String XML_ARCHIVE_PORT = FOLDER_NAME_XML_ARCHIVE + CONF_PORT;

  /** The Constant XML_ARCHIVE_DEPTH_FOLDER. */
  public static final String XML_ARCHIVE_DEPTH_FOLDER = FOLDER_NAME_XML_ARCHIVE
      + CONF_DEPTH_FOLDER;

  /** The Constant XML_ARCHIVE_EXPIRED_TIME. */
  public static final String XML_ARCHIVE_EXPIRED_TIME = FOLDER_NAME_XML_ARCHIVE
      + CONF_EXPIRED_TIME;

  /** The Constant XML_ERROR_FOLDER_TYPE. */
  public static final String XML_ERROR_FOLDER_TYPE = FOLDER_NAME_XML_ERROR + CONF_FOLDER_TYPE;

  /** The Constant XML_ERROR_FOLDER. */
  public static final String XML_ERROR_FOLDER = FOLDER_NAME_XML_ERROR + CONF_FOLDER;

  /** The Constant XML_ERROR_FILE_TYPE. */
  public static final String XML_ERROR_FILE_TYPE = FOLDER_NAME_XML_ERROR + CONF_FILE_TYPE;

  /** The Constant XML_ERROR_FILE_SERVER. */
  public static final String XML_ERROR_FILE_SERVER = FOLDER_NAME_XML_ERROR + CONF_FILE_SERVER;

  /** The Constant XML_ERROR_USER_NAME. */
  public static final String XML_ERROR_USER_NAME = FOLDER_NAME_XML_ERROR + CONF_USER_NAME;

  /** The Constant XML_ERROR_PASSWORD. */
  public static final String XML_ERROR_PASSWORD = FOLDER_NAME_XML_ERROR + CONF_PASSWORD;

  /** The Constant XML_ERROR_PORT. */
  public static final String XML_ERROR_PORT = FOLDER_NAME_XML_ERROR + CONF_PORT;

  /** The Constant XML_ERROR_DEPTH_FOLDER. */
  public static final String XML_ERROR_DEPTH_FOLDER = FOLDER_NAME_XML_ERROR
      + CONF_DEPTH_FOLDER;

  /** The Constant NUM_OF_RETRY. */
  private static final String NUM_OF_RETRY = "RETRY_TIME";

  /** The Constant COMPRESS_ARCHIVE. */
  public static final String COMPRESS_ARCHIVE = "COMPRESS_ARCHIVE";

  /** The Constant CLEAR_ALL_VIEWS. */
  public static final String CLEAR_ALL_VIEWS = "CLEAR_ALL_VIEWS";

  /** The Constant INTERVAL_OF_RETRY. */
  private static final String INTERVAL_OF_RETRY = "RETRY_INTERVAL";

  /** The Constant FILE_TIMEOUT. */
  public static final String FILE_TIMEOUT = "FILE_TIMEOUT";

  /** The Constant FIND_MIR. */
  public static final String FIND_MIR = "FIND_MIR";

  /** The Constant LIMIT_FAIL_VALUES. */
  public static final String LIMIT_FAIL_VALUES = "LIMIT_FAIL_VALUES";

  /* ----------SC GENERAL SETTING---------- */
  /** The Constant DEFAULT_ALARM_THRESHOLD. */
  public static final String DEFAULT_ALARM_THRESHOLD = "DEFAULT_ALARM_THRESHOLD";

  /** The Constant PLANT_CODE. */
  public static final String PLANT_CODE = "PLANT_CODE";

  /** The Constant UM_URL. */
  public static final String UM_URL = "UM_URL";
  /* ----------End SC GENERAL SETTING---------- */

  /* ----------SC REPORT SETTING---------- */
  /** The Constant MAX_NUM_OF_COMPLIANCY_SCORE_RANGE. */
  public static final String MAX_NUM_OF_COMPLIANCY_SCORE_RANGE =
      "MAX_NUM_OF_COMPLIANCY_SCORE_RANGE";

  /** The Constant ONLINE_REPORT_TIME. */
  public static final String ONLINE_REPORT_TIME = "ONLINE_REPORT_TIME_RANGE";

  /** The Constant KEY_MAX_ROW_ON_DATAVIEW. */
  public static final String KEY_MAX_ROW_ON_DATAVIEW = "MAX_ROW_ON_DATAVIEW";
  
  /** The Constant OFLINE_REPORT_TIMEOUT. The unit is minute */
  public static final String KEY_OFLINE_REPORT_TIMEOUT = "OFLINE_REPORT_TIMEOUT";
  /* ----------End SC REPORT SETTING---------- */

  /* ----------SC APCD SETTING---------- */
  /** The Constant APCD_HOST. */
  public static final String APCD_HOST = "APCD.HOST";

  /** The Constant APCD_PORT. */
  public static final String APCD_PORT = "APCD.PORT";

  /** The Constant APCD_MAILBOX. */
  public static final String APCD_MAILBOX = "APCD.MAILBOX";

  /** The Constant APCD_MBX. */
  public static final String APCD_MBX = "APCD.MBX";
  /* ----------End SC APCD SETTING---------- */

  /* ----------SC FAIL VALUES FOLDER SETTING---------- */
  /** The Constant FOLDER_NAME_FAIL_VALUES. */
  public static final String FOLDER_NAME_FAIL_VALUES = "FAIL_VALUES_FOLDER";

  /** The Constant FAIL_VALUES_FOLDER_TYPE. */
  public static final String FAIL_VALUES_FOLDER_TYPE = FOLDER_NAME_FAIL_VALUES
      + CONF_FOLDER_TYPE;

  /** The Constant FAIL_VALUES_FOLDER. */
  public static final String FAIL_VALUES_FOLDER = FOLDER_NAME_FAIL_VALUES + CONF_FOLDER;

  /** The Constant FAIL_VALUES_FILE_TYPE. */
  public static final String FAIL_VALUES_FILE_TYPE = FOLDER_NAME_FAIL_VALUES + CONF_FILE_TYPE;

  /** The Constant FAIL_VALUES_FILE_SERVER. */
  public static final String FAIL_VALUES_FILE_SERVER = FOLDER_NAME_FAIL_VALUES
      + CONF_FILE_SERVER;

  /** The Constant FAIL_VALUES_USER_NAME. */
  public static final String FAIL_VALUES_USER_NAME = FOLDER_NAME_FAIL_VALUES + CONF_USER_NAME;

  /** The Constant FAIL_VALUES_PASSWORD. */
  public static final String FAIL_VALUES_PASSWORD = FOLDER_NAME_FAIL_VALUES + CONF_PASSWORD;

  /** The Constant FAIL_VALUES_PORT. */
  public static final String FAIL_VALUES_PORT = FOLDER_NAME_FAIL_VALUES + CONF_PORT;

  /** The Constant FAIL_VALUES_DEPTH_FOLDER. */
  public static final String FAIL_VALUES_DEPTH_FOLDER = FOLDER_NAME_FAIL_VALUES
      + CONF_DEPTH_FOLDER;

  /** The Constant FAIL_VALUES_EXPIRED_TIME. */
  public static final String FAIL_VALUES_EXPIRED_TIME = FOLDER_NAME_FAIL_VALUES
      + CONF_EXPIRED_TIME;
  /* ----------END SC FAIL VALUES FOLDER SETTING---------- */

  /* ----------PURGE SETTINGS---------- */
  /** The Constant PURGE_INTERVAL_TIME. */
  public static final String PURGE_INTERVAL_TIME = "PURGE_INTERVAL_TIME";

  /** The Constant PURGE_INTERVAL_UNIT. */
  public static final String PURGE_INTERVAL_UNIT = "PURGE_INTERVAL_UNIT";

  /** The Constant PURGE_START_TIME. */
  public static final String PURGE_START_TIME = "PURGE_START_TIME";

  /** The Constant PURGE_SCCDB_EXPIRED_TIME. */
  public static final String PURGE_SCCDB_EXPIRED_TIME = "PURGE_SCCDB" + CONF_EXPIRED_TIME;

  /** The Constant PURGE_UMDB_EXPIRED_TIME. */
  public static final String PURGE_UMDB_EXPIRED_TIME = "PURGE_UMDB" + CONF_EXPIRED_TIME;

  /** The Constant PURGE_COMPLIANCY_RESULT. */
  public static final String PURGE_COMPLIANCY_RESULT_EXPIRED_TIME = "PURGE_COMPLIANCY_RESULT"
      + CONF_EXPIRED_TIME;

  /** The Constant PURGE_FILE_STS_EXPIRED_TIME. */
  public static final String PURGE_FILE_STS_EXPIRED_TIME = "PURGE_FILE_STS"
      + CONF_EXPIRED_TIME;

  /** The Constant PURGE_CHANGE_HISTORY_EXPIRED_TIME. */
  public static final String PURGE_CHANGE_HISTORY_EXPIRED_TIME = "PURGE_CHANGE_HISTORY"
      + CONF_EXPIRED_TIME;

  /** The Constant PURGE_OFFLINE_REPORT_EXPIRED_TIME. */
  public static final String PURGE_OFFLINE_REPORT_EXPIRED_TIME = "PURGE_OFFLINE_REPORT"
      + CONF_EXPIRED_TIME;
  
  /** The Constant PURGE_TEMP_MAPS_EXPIRED_TIME. */
  public static final String PURGE_TEMP_MAPS_EXPIRED_TIME = "PURGE_TEMP_MAPS"
      + CONF_EXPIRED_TIME;

  public static final String PURGE_WAFER_CHART_EXPIRED_TIME = "PURGE_WAFER_CHART"
      + CONF_EXPIRED_TIME;
  /* ----------END PURGE SETTINGS---------- */

  /** The Constant DEFAULT_NUM_OF_RETRY. */
  private static final int DEFAULT_NUM_OF_RETRY = 1;

  /** The Constant DEFAULT_COMPRESS. */
  private static final boolean DEFAULT_COMPRESS = true;

  /** The Constant DEFAULT_INTERVAL_OF_RETRY. */
  private static final long DEFAULT_INTERVAL_OF_RETRY = 300000;

  /** The Constant DEFAULT_FILE_TIMEOUT. */
  private static final long DEFAULT_FILE_TIMEOUT = 18000000L;

  /** The Constant DEFAULT_INTERVAL_TIME. */
  public static final int DEFAULT_INTERVAL_TIME = 10;

  /** The Constant DEFAULT_LIMIT_FAIL_VALUES. */
  public static final int DEFAULT_LIMIT_FAIL_VALUES = 1000;

  /*----------------------------------SC EMAIL SETTINGS-----------------*/
  /** The Constant KEY_EMAIL_ADMIN. */
  public static final String KEY_EMAIL_ADMIN = "EMAIL_ADMIN";

  /** The Constant KEY_EMAIL_FROM. */
  public static final String KEY_EMAIL_FROM = "EMAIL_FROM";

  /** The Constant KEY_EMAIL_FROM_DISPLAY_NAME. */
  public static final String KEY_EMAIL_FROM_DISPLAY_NAME = "EMAIL_FROM_DISPLAY_NAME";

  /** The Constant KEY_EMAIL_SUBJECT. */
  public static final String KEY_EMAIL_SUBJECT = "EMAIL_SUBJECT";

  /** The Constant KEY_SMTP_HOST. */
  public static final String KEY_SMTP_HOST = "SMTP_HOST";

  /** The Constant KEY_SMTP_PORT. */
  public static final String KEY_SMTP_PORT = "SMTP_PORT";

  /** The Constant KEY_SMTP_USERNAME. */
  public static final String KEY_SMTP_USERNAME = "SMTP_USERNAME";

  /** The Constant KEY_SMTP_PASSWORD. */
  public static final String KEY_SMTP_PASSWORD = "SMTP_PASSWORD";

  /** The Constant KEY_SMTP_PROTOCOL. */
  public static final String KEY_SMTP_PROTOCOL = "SMTP_PROTOCOL";

  /*----------------------------------END SC EMAIL SETTINGS-----------------*/

  /*----------------------------------UM SETTINGS-----------------*/
  public static final String LDAP_HOST = "LDAP_HOST";
  public static final String LDAP_HOST_PORT = "LDAP_HOST_PORT";
  public static final String LDAP_VERSION = "LDAP_VERSION";
  public static final String LDAP_SCOPE = "LDAP_SCOPE";
  public static final String LDAP_USERNAME = "LDAP_USERNAME";
  public static final String LDAP_PASSWORD = "LDAP_PASSWORD";
  public static final String LDAP_BASE = "LDAP_BASE";
  public static final String DEFAULT_USER_PASSWORD = "DEFAULT_USER_PASSWORD";

  public static final String LDAP_USERNAME_ATTRIBUTE = "LDAP_USERNAME_ATTRIBUTE";
  public static final String LDAP_FULLNAME_ATTRIBUTE = "LDAP_FULLNAME_ATTRIBUTE";
  public static final String LDAP_MAIL_ATTRIBUTE = "LDAP_MAIL_ATTRIBUTE";
  public static final String LDAP_DOMAIN_ATTRIBUTE = "LDAP_DOMAIN_ATTRIBUTE";

  public static final String SC_URL = "SC_URL";
  /*----------------------------------END UM SETTINGS-----------------*/

  /** The Constant INSTANCE. */
  private static final ConfigLoader INSTANCE = new ConfigLoader();

  /**
   * Gets the single instance of ConfigLoader.
   * 
   * @return single instance of ConfigLoader
   */
  public static ConfigLoader getInstance() {
    return INSTANCE;
  }

  /** The setting map. */
  private final Map<String, Object> settingMap = new HashMap<String, Object>();

  /** The retry interval. */
  private long retryInterval;

  /** The retry time. */
  private int retryTime;

  /** The compress. */
  private boolean compress = true;

  /** The file time out. */
  private long fileTimeOut;

  /** The config path. */
  private String configPath;

  /** The configuration folder map. */
  private final Map<String, FolderInfo> folderMap;

  /** The file watcher info. */
  private final FileWatcherInfo fileWatcherInfo;

  /** The extractor config time. */
  private long extractorConfigTime = 0;

  /** The interval time. */
  private int intervalTime = DEFAULT_INTERVAL_TIME;

  /** The version. */
  private String version = "";

  /** The find MIR. */
  private boolean findMir = true;

  /** The webapp home dir. */
  private String webappHomeDir;

  /**
   * Instantiates a new configuration loader.
   */
  private ConfigLoader() {
    folderMap = new HashMap<String, FolderInfo>();
    fileWatcherInfo = new FileWatcherInfo();
    initWebAppHomeDir();
    version = readVersion();
  }

  /**
   * Check reload.
   * 
   * @param configTime
   *          the config time
   * @return true, if successful
   */
  public boolean checkReload(final Timestamp configTime) {
    final boolean flag = configTime == null || configTime.getTime() != extractorConfigTime;
    return flag;
  }

  /**
   * Sets the default port.
   * 
   * @param fileType
   *          the new default port
   * @return the default port
   */
  private int getDefaultPort(final FileTypeEnum fileType) {
    int port = 0;
    switch (fileType) {
    case NFS:
      port = 0;
      break;
    case FTP:
      port = 21;
      break;
    case SFTP:
      port = 22;
      break;
    default:
      break;
    }
    LOG.info("set port gets default is " + port);
    return port;
  }

  /**
   * Gets the file.
   * 
   * @param fileName
   *          the file name
   * @return the file
   */
  public File getFile(final String fileName) {
    final File file = new File(configPath + File.separator + fileName);
    return file;
  }

  /**
   * Gets the file time out.
   * 
   * @return the file time out
   */
  public long getFileTimeOut() {
    return fileTimeOut;
  }

  /**
   * Gets the file watcher info.
   * 
   * @return the file watcher info
   */
  public FileWatcherInfo getFileWatcherInfo() {
    return fileWatcherInfo;
  }

  /**
   * Gets the configuration folder.
   * 
   * @param name
   *          the name
   * @return the folder
   */
  public FolderInfo getFolder(final String name) {
    return folderMap.get(name);
  }

  /**
   * Gets the interval time.
   * 
   * @return the interval time
   */
  public int getIntervalTime() {
    return intervalTime;
  }

  /**
   * Gets the retry interval.
   * 
   * @return the retry interval
   */
  public long getRetryInterval() {
    return retryInterval;
  }

  /**
   * Gets the retry time.
   * 
   * @return the retry time
   */
  public int getRetryTime() {
    return retryTime;
  }

  /**
   * Gets the setting map.
   * 
   * @return the setting map
   */
  public Map<String, Object> getSettingMap() {
    return settingMap;
  }

  /**
   * Gets the value.
   * 
   * @param key
   *          the key
   * @return the value
   */
  public Object getValue(final String key) {
    return settingMap.get(key);
  }

  /**
   * Gets the value.
   * 
   * @param key
   *          the key
   * @param defaultValue
   *          the default value
   * @return the value
   */
  public Object getValue(final String key, final Object defaultValue) {
    Object object = settingMap.get(key);
    if (object == null) {
      object = defaultValue;
    }
    return object;
  }

  /**
   * Gets the version.
   * 
   * @return the version
   */
  public String getVersion() {
    return version;
  }

  /**
   * Gets the web application home directory.
   * 
   * @return the webappHomeDir
   */
  public String getWebappHomeDir() {
    return webappHomeDir;
  }

  /**
   * Initializes the web application home directory.
   */
  private void initWebAppHomeDir() {
    final String jbossDir = System.getProperty("jboss.server.home.dir");
    if (jbossDir != null) {
      webappHomeDir = jbossDir;
    } else {
      final String tomcatDir = System.getProperty("catalina.base", "");
      webappHomeDir = tomcatDir;
    }
  }

  /**
   * Checks if is compress.
   * 
   * @return true, if is compress
   */
  public boolean isCompress() {
    return compress;
  }

  /**
   * Checks if is find MIR.
   * 
   * @return true, if is find MIR
   */
  public boolean isFindMir() {
    return findMir;
  }

  /**
   * Load configuration.
   * 
   * @throws SccException
   *           the scc exception
   */
  public synchronized void load() throws SccException {
    loadConfigure(settingMap);
  }

  /**
   * Load configure.
   * 
   * @param map
   *          the map
   * @throws SccException
   *           the SCC exception
   */
  private void loadConfigure(final Map<String, Object> map) throws SccException {
    LOG.info("Loading configuration in database");

    final Number intervalSecond = (Number) map.get(KEY_INTERVAL_TIME);
    // get interval-second from file *.xml
    if (intervalSecond == null) {
      // return default value
      intervalTime = DEFAULT_INTERVAL_TIME;
    } else {
      intervalTime = intervalSecond.intValue();
    }

    updateSettings();

    updateFolders(map);

    updateMailInformation(map);
  }

  /**
   * Read version.
   * 
   * @return the string
   */
  private String readVersion() {
    final Properties properties = new Properties();
    InputStream inputStream = null;
    try {
      inputStream = getClass().getClassLoader().getResourceAsStream("version.properties");
      properties.load(inputStream);
    } catch (final Exception e) {
      LOG.error("Failed to load version.properties");
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
    }
    final String retVal = properties.getProperty("version", "");
    return retVal;
  }

  /**
   * Reload configuration.
   * 
   * @param map
   *          the map
   * @param timestamp
   *          the timestamp
   * @throws SccException
   *           the SCC exception
   */
  public synchronized void reload(final Map<String, Object> map, final Timestamp timestamp)
      throws SccException {
    settingMap.clear();
    folderMap.clear();
    EmailNotification.getInstance().clearServerInfo();

    settingMap.putAll(map);
    loadConfigure(settingMap);
    if (timestamp != null) {
      extractorConfigTime = timestamp.getTime();
    }
  }

  /**
   * Sets the config path.
   * 
   * @param configPath
   *          the new config path
   */
  public void setConfigPath(final String configPath) {
    this.configPath = configPath;
  }

  /**
   * To folder info.
   * 
   * @param map
   *          the map
   * @param prefix
   *          the prefix
   * @return the folder info
   */
  private FolderInfo toFolderInfo(final Map<String, Object> map, final String prefix) {
    final FileTypeEnum folderType =
        FileTypeEnum.fromValue((String) map.get(prefix + CONF_FOLDER_TYPE));
    FolderInfo folderInfo = null;
    final String folder = (String) map.get(prefix + CONF_FOLDER);
    if (folderType != null && folder != null) {
      folderInfo = new FolderInfo(folderType, folder);
      final String fileType = (String) map.get(prefix + CONF_FILE_TYPE);
      folderInfo.setFileType(fileType);
      final Number depthFolder = (Number) map.get(prefix + CONF_DEPTH_FOLDER);
      if (depthFolder != null) {
        folderInfo.setDepthFolder(depthFolder.intValue());
      }
      if (folderType != FileTypeEnum.NFS) {
        folderInfo.setFileServer((String) map.get(prefix + CONF_FILE_SERVER));
        folderInfo.setUserName((String) map.get(prefix + CONF_USER_NAME));
        String encryptedPass = (String) map.get(prefix + CONF_PASSWORD);
        // decrypt password
        String password = decryptPassword(encryptedPass, prefix + CONF_PASSWORD);
        folderInfo.setPassword(password);
        final Number port = (Number) map.get(prefix + CONF_PORT);
        if (port != null) {
          folderInfo.setPort(port.intValue());
        } else {
          folderInfo.setPort(getDefaultPort(folderType));
        }
      }
    }
    return folderInfo;
  }

  /**
   * Update folders.
   * 
   * @param map
   *          the map
   * @throws SccException
   *           the scc exception
   */
  private void updateFolders(final Map<String, Object> map) throws SccException {
    final String folderName = fileWatcherInfo.getFolderName();
    final Number d = (Number) map.get(KEY_MAX_SIZE_NOTIFY);
    String maxSizeNotify = "";
    if (d != null) {
      maxSizeNotify = String.valueOf(d.intValue());
    }

    final String[] names =
        {FOLDER_NAME_STDF, FOLDER_NAME_STDF_ARCHIVE, FOLDER_NAME_STDF_ERROR, FOLDER_NAME_XML,
            FOLDER_NAME_XML_ARCHIVE, FOLDER_NAME_XML_ERROR, FOLDER_NAME_FAIL_VALUES };
    for (final String name : names) {
      final FolderInfo folderInfo = toFolderInfo(map, name);
      if (folderInfo != null) {
        folderMap.put(name, folderInfo);
        if (name.equals(folderName)) {
          fileWatcherInfo.loadConfigureWatcher(folderInfo, maxSizeNotify);
        }
      }
    }
  }

  /**
   * Update mail information.
   * 
   * @param map
   *          the map
   */
  private void updateMailInformation(final Map<String, Object> map) {
    final EmailNotification emailNotification = EmailNotification.getInstance();
    String str = (String) map.get(KEY_EMAIL_ADMIN);
    emailNotification.setAdminEmail(str);
    str = (String) map.get(KEY_EMAIL_FROM);
    emailNotification.setDefaultFrom(str);
    str = (String) map.get(KEY_EMAIL_FROM_DISPLAY_NAME);
    emailNotification.setDefaultFromDisplayName(str);
    str = (String) map.get(KEY_EMAIL_SUBJECT);
    emailNotification.setDefaultSubject(str);
    final String host = (String) map.get(KEY_SMTP_HOST);
    LOG.info("SMTP host="+ host);
    if (host != null && host.length() > 0) {
      final SMTPServerInfo serverInfo = new SMTPServerInfo();
      serverInfo.setHost(host);
      final Number port = (Number) map.get(KEY_SMTP_PORT);
      if (port != null) {
        serverInfo.setPort(port.intValue());
      }
      final String userName = (String) map.get(KEY_SMTP_USERNAME);
      serverInfo.setUserName(userName);
      final String encrypted = (String) map.get(KEY_SMTP_PASSWORD);
      String password = decryptPassword(encrypted, " email config");
      serverInfo.setPassword(password);
      final String protocol = (String) map.get(KEY_SMTP_PROTOCOL);
      if ("smtps".equals(protocol)) {
        serverInfo.setSecure(true);
      }
      emailNotification.setServerInfo(serverInfo);
    }

  }
  
  /**
   * Decrypt password.
   * 
   * @param encryptedPass password was encrypted.
   * @param errorMsg
   *          message use to log when error.
   * @return
   */
  private String decryptPassword(final String encryptedPass, final String errorMsg) {
    String decrypt = null;
    // decrypt password
    if (encryptedPass != null && encryptedPass.length() > 0) {
      try {
        decrypt = EncryptionUtils.decrypt(encryptedPass);
      } catch (Exception e) {
        LOG.error("Cannot decrypt password of " + errorMsg, e);
      }
    }
    return decrypt;
  }


  /**
   * Update settings.
   */
  private void updateSettings() {
    int tmpRetryTime = DEFAULT_NUM_OF_RETRY;
    if (settingMap.size() > 0) {
      final Object obj = settingMap.get(NUM_OF_RETRY);
      if (obj instanceof Number) {
        tmpRetryTime = ((Number) obj).intValue();
      }
    }
    retryTime = tmpRetryTime;

    boolean tmpCompress = DEFAULT_COMPRESS;
    if (settingMap.size() > 0) {
      final Object obj = settingMap.get(COMPRESS_ARCHIVE);
      if (obj instanceof Boolean) {
        tmpCompress = ((Boolean) obj).booleanValue();
      }
    }
    compress = tmpCompress;

    boolean tmpFindMir = true;
    if (settingMap.size() > 0) {
      final Object obj = settingMap.get(FIND_MIR);
      if (obj instanceof Boolean) {
        tmpFindMir = ((Boolean) obj).booleanValue();
      }
    }
    findMir = tmpFindMir;

    long tmpRetryInterval = DEFAULT_INTERVAL_OF_RETRY;
    if (settingMap.size() > 0) {
      final Object obj = settingMap.get(INTERVAL_OF_RETRY);
      if (obj instanceof Number) {
        tmpRetryInterval = ((Number) obj).longValue() * 1000;
      }
    }
    retryInterval = tmpRetryInterval;

    long tmpFileTimeout = DEFAULT_FILE_TIMEOUT;
    if (settingMap.size() > 0) {
      final Object obj = settingMap.get(FILE_TIMEOUT);
      if (obj instanceof Number) {
        tmpFileTimeout = ((Number) obj).longValue() * 1000;
      }
    }
    fileTimeOut = tmpFileTimeout;

    if (LOG.isDebugEnabled()) {
      LOG.debug("Number of retry time: {}", retryTime);
      LOG.debug("Interval of retry: {} ms", retryInterval);
      LOG.debug("Timeout for processing file: {} ms", fileTimeOut);
    }
  }
}
