/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - Mar 25, 2011 11:34:56 AM - nguyensn - Initialize version
/******************************************************************************/
package com.st.common.convertbyteutil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class ConvertByteUtilCommon {

	/** The Constant BYTE_LENGTH. */
	public static final int BYTE_LENGTH = 8;

	/** The Constant BYTE_INTEGER_LENGTH. */
	public static final int BYTE_INTEGER_LENGTH = 4;

	/** the byte array char unicode length. */
	public static final int BYTE_CHAR_UNICODE_LENGTH = 2;

	/** The Constant BYTE_SHORT_LENGTH. */
	public static final int BYTE_SHORT_LENGTH = 2;

	/** The Constant BYTE_ONE_LENGTH. */
	public static final int BYTE_ONE_LENGTH = 1;

	/** The Constant LONG_LENGTH. */
	public static final int BYTE_LONG_LENGTH = 8;
	/** The Constant FLOAT_LENGTH. */
	public static final int BYTE_FLOAT_LENGTH = 4;

	/** The Constant DOUBLE_LENGTH. */
	public static final int BYTE_DOUBLE_LENGTH = 8;

	/** The Constant VAX_BASE. */
	public static final int VAX_BASE = 128;

	/** The Vax exponent length. */
	protected static final int VAX_EXPONENT_LENGTH = 8;

	/** The Constant VAX_MANTISA. */
	protected static final float VAX_MANTISA = (float) 0.5;

	/** The Constant VAX_BIT_START_MANTISA. */
	protected static final int VAX_BIT_START_MANTISA = 9;

	/** the Byte 0xff. */
	protected static final int BYTE_0FF = 0xff;

	/** The Constant VAX_MANTISA_FLOAT_BYTE_ARRAY. */
	public static final byte[] VAX_MANTISA_FLOAT_BYTE_ARRAY = { 1, 0, 0, 0 };

	/** The Constant VAX_MANTISA_DOUBLE_BYTE_ARRAY. */
	public static final byte[] VAX_MANTISA_DOUBLE_BYTE_ARRAY = { 1, 0, 0, 0, 0
		, 0, 0, 0 };

	/**
	 * calculate inverse of power n of x.
	 * 
	 * @param x
	 *            : integer
	 * @param n
	 *            : integer
	 * @return double value of (1/x)^n
	 */
	protected static double inversePower(final int x, final int n) {
		if (x == 0) {
			return 0;
		}
		double result = 1.0;
		for (int i = 0; i < n; i++) {
			result /= x;
		}
		return result;
	}

	/**
	 * calculate power n of x.
	 * 
	 * @param x
	 *            : integer
	 * @param n
	 *            : integer
	 * @return long value of x^n
	 */
	protected static long power(final int x, final int n) {
		if (x == 0) {
			return 0;
		}

		long result = 1;
		for (int i = 0; i < n; i++) {
			result *= x;
		}
		return result;
	}

	/**
	 * swap byte[x] and byte[y].
	 * 
	 * @param byteArray
	 *            the byte
	 * @param x
	 *            the x
	 * @param y
	 *            the y
	 */
	protected static void swapByte(byte[] byteArray, final int x, final int y) {
		byte temp = byteArray[x];
		byteArray[x] = byteArray[y];
		byteArray[y] = temp;
	}

	/**
	 * Inverse byte.
	 * 
	 * @param byteArray
	 *            the byte
	 */
	public static void inverseByte(byte[] byteArray) {
		int length = byteArray.length;
		for (int i = 0; i < length / 2; i++) {
			swapByte(byteArray, i, length - i - 1);
		}
	}

	/**
	 * Copy byte from source.
	 * 
	 * @param source
	 *            the source : the array byte source
	 * @param start
	 *            the start : starting point
	 * @param end
	 *            the end : end point
	 * @return the byte[], if source is null or end less than start or start
	 *         less than zero or length of source less than end point method
	 *         return null
	 */
	protected static byte[] copyByte(final byte[] source, final int start,
			final int end) {

		int len = end - start + 1;
    byte[] dest = new byte[len];
		System.arraycopy(source, start, dest, 0, len);
		return dest;
	}

	/**
	 * Gets the char big_endian.
	 * 
	 * @param byteArray
	 *            the array byte of char
	 * @return the char what get from byte array, order byte big_endian
	 */
	protected static char getCharBigEndian(final byte[] byteArray) {
		ByteBuffer bf = ByteBuffer.wrap(byteArray);
		char result = bf.order(ByteOrder.BIG_ENDIAN).getChar();
		return result;
	}

	/**
	 * Gets the char little_endian.
	 * 
	 * @param byteArray
	 *            the array byte of char
	 * @return the char what get from byte array, order byte big_endian
	 */
	protected static char getCharLittleEndian(final byte[] byteArray) {
		ByteBuffer bf = ByteBuffer.wrap(byteArray);
		char result = bf.order(ByteOrder.LITTLE_ENDIAN).getChar();
		return result;
	}

	/**
	 * Gets the float big endian.
	 * 
	 * @param byteArray
	 *            the byte
	 * @return the float, what get from byte array, order byte big_endian
	 */
	protected static float getFloatBigEndian(final byte[] byteArray) {
		ByteBuffer bf = ByteBuffer.wrap(byteArray);
		float result = bf.order(ByteOrder.BIG_ENDIAN).getFloat();
		return result;
	}

	/**
	 * Gets the double big endian.
	 * 
	 * @param byteArray
	 *            the byte array
	 * @return the double, what get from byte array, order byte big_endian
	 */
	protected static double getDoubleBigEndian(final byte[] byteArray) {
		ByteBuffer bf = ByteBuffer.wrap(byteArray);
		double result = bf.order(ByteOrder.BIG_ENDIAN).getDouble();
		return result;
	}

	/**
	 * Gets the float little endian.
	 * 
	 * @param byteArray
	 *            the byte
	 * @return the float, what get from byte array, order byte little_endian
	 */
	protected static float getFloatLittleEndian(final byte[] byteArray) {
		ByteBuffer bf = ByteBuffer.wrap(byteArray);
		float result = bf.order(ByteOrder.LITTLE_ENDIAN).getFloat();
		return result;
	}

	/**
	 * Gets the double little endian.
	 * 
	 * @param byteArray
	 *            the byte
	 * @return the double, what get from byte array, order byte little_endian
	 */
	protected static double getDoubleLittleEndian(final byte[] byteArray) {
		ByteBuffer bf = ByteBuffer.wrap(byteArray);
		double result = bf.order(ByteOrder.LITTLE_ENDIAN).getDouble();
		return result;
	}

	/**
	 * Gets the value of first bit.
	 * 
	 * @param byteInput
	 *            the byte input
	 * @return the value of first bit
	 */
	protected static int getValueOfFirstBit(byte byteInput) {
		short byteValue = (short) ((short) byteInput & BYTE_0FF);
		int result = (byteValue >> BYTE_LENGTH - 1);
		return result;
	}

	/**
	 * Gets the value of next bit.
	 * 
	 * @param byteInput
	 *            the byte input
	 * @param firstBit
	 *            the first bit
	 * @return the value of next bit
	 */
	protected static short getValueOfNextBit(final byte byteInput,
			final int firstBit) {
		short byteValue = (short) ((short) byteInput & BYTE_0FF);
		short result = (short) (byteValue - firstBit * VAX_BASE);
		return (short) (result);
	}

	/**
	 * Swap vax byte. swap byte get from Vax_processor
	 * 
	 * @param byteArray
	 *            the byte
	 */
	protected static void swapVAXByte(byte[] byteArray) {
		for (int i = 0; i < byteArray.length; i += 2) {
			swapByte(byteArray, i, i + 1);
		}
	}
}
