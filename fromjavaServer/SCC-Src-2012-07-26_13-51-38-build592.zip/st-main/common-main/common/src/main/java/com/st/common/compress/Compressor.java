/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 11, 2011 10:31:24 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.common.compress;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;

import com.st.common.compress.base.CodeTable;
import com.st.common.compress.base.Constant;
import com.st.common.compress.base.HashTable;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class Compressor {

  /** Ratio check interval. */
  private static final int CHECK_GAP = 10000;

  /** Number of bits/code. */
  private int nBits;

  /** User settable max # bits/code. */
  private int maxBits;
  /** Maximum code, given n_bits. */
  private int maxCode;
  /** Should NEVER generate this code. */
  private final int maxMaxCode;
  /** Offset inheritance. */
  private int offset;
  /** Compress follow block. */
  private final int blockCompress;
  /** First unused entry. */
  private int freeEnt;
  /** Flag for clearing. */
  private int clearFlg;
  /** Buffer. */
  private final byte[] buf;
  /** Buffer input stream. */
  private final BufferedInputStream buffIn;
  /** Buffer output stream. */
  private final BufferedOutputStream buffOut;
  /** Ratio. */
  private long ratio;

  /** Check point. */
  private long checkPoint;

  /** Length of input. */
  private long inCount;

  /** Of codes output. */
  private long outCount;

  /** Length of compressed output. */
  private int bytesOut;

  /** Buffer max. */
  private static final int MAX_BUFFER = 512 * 1024;

  /** Buffer for writing. */
  private final byte[] buffer = new byte[MAX_BUFFER];

  /** Point current of buffer. */
  private int currentBuffer = 0;

  /** Hash table. */
  private final HashTable hashTable;

  /** Code table. */
  private final CodeTable codeTable;

  /** Data buffer read. */
  private final byte[] data = new byte[8192];

  /**
   * Constructor
   * 
   * @param in
   *          is input buffer stream
   * @param out
   *          is output buffer stream.
   * @throws IOException
   *           is IOException if null.
   */
  public Compressor(final BufferedInputStream in, final BufferedOutputStream out)
      throws IOException {
    buffIn = in;
    buffOut = out;
    maxBits = Constant.BITS;
    blockCompress = Constant.BLOCK_MASK;
    buf = new byte[Constant.BITS];
    if (maxBits < Constant.INIT_BITS) {
      maxBits = Constant.INIT_BITS;
    }
    if (maxBits > Constant.BITS) {
      maxBits = Constant.BITS;
    }
    maxMaxCode = 1 << maxBits;
    nBits = Constant.INIT_BITS;
    maxCode = maxCode();

    offset = 0;
    bytesOut = 3; /* includes 3-byte header mojo */
    outCount = 0;
    clearFlg = 0;
    ratio = 0;
    inCount = 1;
    checkPoint = CHECK_GAP;
    freeEnt = blockCompress != 0 ? Constant.FIRST : 256;

    hashTable = new HashTable(); // dm/kmd 4/10/98
    codeTable = new CodeTable();
    final byte bitThird = (byte) (maxBits | blockCompress);
    write(Constant.MAGIC_HEADER, 0, 2);
    write(bitThird);
  }

  /** Table clear for block compress. */
  private void clearBlock() throws IOException {
    long rat;
    checkPoint = inCount + CHECK_GAP;
    if (inCount > 0x007fffff) {
      /** Shift will overflow. */
      rat = bytesOut >> 8;
      if (rat == 0) {
        /** Don't divide by zero. */
        rat = 0x7fffffff;
      } else {
        rat = inCount / rat;
      }
    } else {
      /** 8 fractional bits. */
      rat = (inCount << 8) / bytesOut;
    }
    if (rat > ratio) {
      ratio = rat;
    } else {
      ratio = 0;
      hashTable.clear();
      freeEnt = Constant.FIRST;
      clearFlg = 1;
      output(Constant.CLEAR);
    }
  }

  public void compress() throws IOException {
    int fCode;
    int i = 0;
    int len;
    int ent;
    int disp;
    int hSizeReg;
    int hShift;
    int c;
    // ent = Input.getbyte();
    // buffIn.read();
    ent = buffIn.read();

    hShift = 0;
    for (fCode = hashTable.getSize(); fCode < 65536; fCode *= 2) {
      hShift++;
    }
    hShift = 8 - hShift; /* set hash code range bound */

    hSizeReg = hashTable.getSize();
    hashTable.clear(); /* clear hash table */

    while ((len = buffIn.read(data)) != -1) {
      for (int j = 0; j < len; j++) {
        c = data[j] & 0x00FF;
        inCount++;
        fCode = (c << maxBits) + ent;
        i = c << hShift ^ ent; /* xor hashing */
        int temphtab = hashTable.get(i); // dm/kmd 4/15
        // dm kmd if ( htab.of (i) == fcode ) { // dm/kmd 4/15
        if (temphtab == fCode) {
          ent = codeTable.get(i);
          continue;
        }

        // dm kmd 4/15 if ( htab.of (i) >= 0 ) { /* non-empty slot */
        if (temphtab >= 0) { /* non-empty slot dm kmd 4/15 */
          disp = hSizeReg - i; /* secondary hash (after G. Knott) */
          if (i == 0) {
            disp = 1;
          }
          boolean stopLoop = false;
          do {
            i -= disp;
            if (i < 0) {
              i += hSizeReg;
            }

            temphtab = hashTable.get(i); // dm/kmd 4/15

            // dm/kmd 4/15 if ( htab.of (i) == fcode ) {
            if (temphtab == fCode) {
              ent = codeTable.get(i);
              stopLoop = true;
              break;
            }
            // dm/kmd 4/15 } while ( htab.of (i) > 0 );
          } while (temphtab > 0); // dm kmd 4/15
          if (stopLoop) {
            continue;
          }
        }

        output(ent);
        outCount++;
        ent = c;
        if (freeEnt < maxMaxCode) {
          codeTable.set(i, freeEnt++); /* code -> hashtable */
          hashTable.set(i, fCode);
        } else if (inCount >= checkPoint && blockCompress != 0) {
          clearBlock();
        }
      }
    }
    /*
     * Put out the final code.
     */
    output(ent);
    outCount++;
    output(-1);
    writenEnd();
    return;
  }

  /**
   * get max code.
   * 
   * @return value.
   */
  public int maxCode() {
    return (1 << nBits) - 1;
  }

  /**
   * Output the given code. Inputs: code: A n_bits-bit integer. If == -1, then
   * EOF. This assumes that n_bits =< (long)wordsize - 1. Outputs: Outputs code
   * to the file. Assumptions: Chars are 8 bits long. Algorithm: Maintain a BITS
   * character long buffer (so that 8 codes will fit in it exactly).
   */
  private void output(int code) throws IOException {
    int rOff = offset, bits = nBits;
    int bp = 0;
    if (code >= 0) {
      /** Get to the first byte. */
      bp += rOff >> 3;
      rOff &= 7;
      /**
       * Since code is always >= 8 bits, only need to mask the first hunk on the
       * left.
       */
      buf[bp] = (byte) (buf[bp] & Constant.RMASK[rOff] | code << rOff & Constant.LMASK[rOff]);
      bp++;
      bits -= 8 - rOff;
      code >>= 8 - rOff;
      /** Get any 8 bit parts in the middle (<=1 for up to 16 bits). */
      if (bits >= 8) {
        buf[bp++] = (byte) code;
        code >>= 8;
        bits -= 8;
      }
      /** Last bits. */
      if (bits != 0) {
        buf[bp] = (byte) code;
      }
      offset += nBits;
      if (offset == nBits << 3) {
        bp = 0;
        bits = nBits;
        bytesOut += bits;
        write(buf, bp, bits);
        // output.write(buf, bp, bits);
        bp += bits;
        bits = 0;
        offset = 0;
      }

      /**
       * If the next entry is going to be too big for the code size, then
       * increase it, if possible.
       */
      if (freeEnt > maxCode || clearFlg > 0) {
        /**
         * Write the whole buffer, because the input side won't discover the
         * size increase until after it has read it.
         */
        if (offset > 0) {
          write(buf, 0, nBits);
          bytesOut += nBits;
        }
        offset = 0;

        if (clearFlg != 0) {
          nBits = Constant.INIT_BITS;
          maxCode = maxCode();
          clearFlg = 0;
        } else {
          nBits++;
          if (nBits == maxBits) {
            maxCode = maxMaxCode;
          } else {
            maxCode = maxCode();
          }
        }
      }
    } else {
      /** At EOF, write the rest of the buffer. */
      if (offset > 0) {
        write(buf, 0, ((offset + 7) / 8));
        // output.write(buf, 0, ((offset + 7) / 8));
      }
      bytesOut += (offset + 7) / 8;
      offset = 0;
    }
  }

  /**
   * Insert b into buffer.
   * 
   * @param b
   *          is value.
   * @throws IOException
   *           if buffer is null.
   */
  private void write(final byte b) throws IOException {
    buffer[currentBuffer++] = b;
    if (currentBuffer == MAX_BUFFER) {
      buffOut.write(buffer);
      currentBuffer = 0;
    }
  }

  /**
   * Insert buff into buffer.
   * 
   * @param buff
   *          is buffer.
   * @param from
   *          is start.
   * @param len
   *          is length of buffer is written.
   * @throws IOException
   *           if buff is null.
   */
  private void write(final byte[] buff, final int from, final int len) throws IOException {
    final int leng = from + len;
    for (int i = from; i < leng; i++) {
      buffer[currentBuffer++] = buff[i];
      if (currentBuffer == MAX_BUFFER) {
        buffOut.write(buffer);
        currentBuffer = 0;
      }
    }
  }

  /**
   * Write in buffer out file.
   * 
   * @throws IOException
   *           if buffer is null.
   */
  private void writenEnd() throws IOException {
    buffOut.write(buffer, 0, currentBuffer);
  }
}
