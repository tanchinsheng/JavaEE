/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 14, 2011 11:30:10 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.util.List;

import com.st.common.beans.FileTypeEnum;
import com.st.common.fileaccess.FileScanner;

/**
 * The Class AbsFileScanner.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public abstract class AbsFileScanner implements FileScanner {

  /** The monitor folder. */
  private String monitorFolder;

  /** The file pattern list. */
  private List<String> filePatternList;

  /** The file type. */
  private FileTypeEnum fileType;

  /** The host. */
  private String host;

  /** The user name. */
  private String userName;

  /** The password. */
  private String password;

  /** The port. */
  private int port;

  /**
   * Gets the file pattern list.
   * 
   * @return the file pattern list
   */
  public List<String> getFilePatternList() {
    return filePatternList;
  }

  /**
   * Gets the file type.
   * 
   * @return the file type
   */
  public FileTypeEnum getFileType() {
    return fileType;
  }

  /**
   * Gets the host.
   * 
   * @return the host
   */
  public String getHost() {
    return host;
  }

  /**
   * Gets the monitor folder.
   * 
   * @return the monitor folder
   */
  public String getMonitorFolder() {
    return monitorFolder;
  }

  /**
   * Gets the password.
   * 
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * Gets the port.
   * 
   * @return the port
   */
  public int getPort() {
    return port;
  }

  /**
   * Gets the user name.
   * 
   * @return the user name
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Sets the file pattern list.
   * 
   * @param filePatternList
   *          the new file pattern list
   */
  public void setFilePatternList(final List<String> filePatternList) {
    this.filePatternList = filePatternList;
  }

  /**
   * Sets the file type.
   * 
   * @param fileType
   *          the new file type
   */
  public void setFileType(final FileTypeEnum fileType) {
    this.fileType = fileType;
  }

  /**
   * Sets the host.
   * 
   * @param host
   *          the new host
   */
  public void setHost(final String host) {
    this.host = host;
  }

  /**
   * Sets the monitor folder.
   * 
   * @param monitorFolder
   *          the new monitor folder
   */
  public void setMonitorFolder(final String monitorFolder) {
    this.monitorFolder = monitorFolder;
  }

  /**
   * Sets the password.
   * 
   * @param password
   *          the new password
   */
  public void setPassword(final String password) {
    this.password = password;
  }

  /**
   * Sets the port.
   * 
   * @param port
   *          the new port
   */
  public void setPort(final int port) {
    this.port = port;
  }

  /**
   * Sets the user name.
   * 
   * @param userName
   *          the new user name
   */
  public void setUserName(final String userName) {
    this.userName = userName;
  }

}
