/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 4, 2011 1:47:34 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.st.common.exception.SccException;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 * 
 */
public class XMLReaderUtil {

	private Document doc;

	public XMLReaderUtil(String xmlFile) throws SccException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			doc = builder.parse(xmlFile);
		} catch (Exception e) {
			throw new SccException(e);
		}
	}

	/**
	 * Gets nodes of tag
	 * 
	 * @param tagName
	 * @return NodeList
	 * @throws Exception
	 */
	public NodeList getTagNodes(String tagName) throws SccException {
		NodeList nodes = doc.getElementsByTagName(tagName);
		return nodes;
	}

	/**
	 * Gets value of tag
	 * 
	 * @param tagName
	 * @param deep
	 * @return tag value
	 * @throws Exception
	 */
	public String getTagValue(String tagName) throws SccException {
	  String retVal = "";
		NodeList nodes = doc.getElementsByTagName(tagName);
		if (nodes != null && nodes.getLength() > 0) {
		  nodes = nodes.item(0).getChildNodes();
		}
		if (nodes != null && nodes.getLength() > 0) {
		  retVal = nodes.item(0).getNodeValue();
		}
		return retVal;
	}
}
