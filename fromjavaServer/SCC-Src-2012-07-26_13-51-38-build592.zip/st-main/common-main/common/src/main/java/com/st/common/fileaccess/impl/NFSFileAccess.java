/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 28, 2011 11:27:58 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.io.File;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.compress.Compressors;
import com.st.scc.common.utils.FileUtils;

/**
 * The Class NFSFileAccess.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class NFSFileAccess extends AbsFileAccess {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(NFSFileAccess.class);

  /** The file. */
  private File file;

  /**
   * Instantiates a new NFS file access.
   * 
   * @param fileInfo
   *          the file info
   */
  public NFSFileAccess(final FileInfo fileInfo) {
    setSourceFile(fileInfo);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#checkAvailable()
   */
  public boolean checkAvailable() {
    boolean result = file.exists();
    if (result) {
      try {
        result = FileUtils.checkAvailable(file);
        if (result) {
          result = file.length() == getSourceFile().getSize();
        }
      } catch (final IOException e) {
        LOG.error(e.getMessage(), e);
        result = false;
      }
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#delete()
   */
  public boolean delete() {
    return file.delete();
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#disconnect()
   */
  public void disconnect() {
    // do nothing
    file = null;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#download()
   */
  public File download() {
    return file;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#download(java.lang.String)
   */
  public File download(final String localFile) {
    return file;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#exists()
   */
  public boolean exists() {
    return file.exists();
  }

  /**
   * Gets the file.
   * 
   * @return the file
   */
  public File getFile() {
    return file;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#move(com.st.common.beans.FileInfo)
   */
  public boolean move(final FileInfo destFile) {
    boolean upload = false;
    if (destFile != null) {
      final FileTypeEnum destFileType = destFile.getFileType();
      if (destFileType != null) {
        switch (destFileType) {
        case NFS:
          upload = moveNFSToNFS(getSourceFile(), destFile);
          break;
        case FTP:
          upload = moveNFSToFTP(getSourceFile(), destFile);
          break;
        case SFTP:
          upload = moveNFSToSFTP(getSourceFile(), destFile);
          break;

        default:
          // do nothing
          break;
        }
      }
    }
    return upload;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#moveCompress(com.st.common.beans.FileInfo)
   */
  public boolean moveCompress(final FileInfo destFile) {
    boolean upload = false;
    final FileInfo source = getSourceFile();
    if (source == null) {
      LOG.warn("fileSource move file is null");
      return false;
    }
    final StringBuilder sb = new StringBuilder();
    final FileInfo sourceCopy = copyFileToDirSetZ(source);

    if (destFile != null && sourceCopy != null && sourceCopy.getPathFileName() != null) {
      if (destFile.getFileType() == null) {
        LOG.warn("File type of dest is null so can't move file " + sb);
        return false;
      }
      if (!source.getPathFileName().endsWith(".Z")) {
        if (!Compressors.compressZ(source.getPathFileName(), sourceCopy.getPathFileName())) {
          final File file = new File(sb.toString());
          if (file.exists()) {
            file.delete();
          }
          return false;
        } else {
          switch (destFile.getFileType()) {
          case NFS:
            upload = moveNFSToNFS(sourceCopy, destFile);
            break;
          case FTP:
            upload = moveNFSToFTP(sourceCopy, destFile);
            break;
          case SFTP:
            upload = moveNFSToSFTP(sourceCopy, destFile);
            break;
          default:
            // do nothing
            break;
          }
          if (upload) {
            final File file = new File(source.getPathFileName());
            if (file.exists()) {
              file.delete();
            }
          }
        }

      } else {
        upload = move(destFile);
      }
    }
    return upload;
  }

  /**
   * Move NFS to NFS.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveNFSToNFS(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null) {
      String temp;
      final File fileSource = new File(srcFile.getPathFileName());
      if (destFile.getPathRoot().endsWith("/")) {
        temp = destFile.getPathRoot() + srcFile.getPathRootToFile();
      } else {
        temp = destFile.getPathRoot() + "/" + srcFile.getPathRootToFile();
      }
      temp = temp.replaceAll("\\\\", "/");
      final File fileDest = new File(temp);
      if (fileSource.exists()) {
        retVal = FileUtils.copyFile(fileSource, fileDest);
        if (retVal) {
          if (fileSource.delete()) {
            LOG.info("Delete file {} successfully", fileSource.getAbsolutePath());
          } else {
            LOG.info("Delete file {} failure", fileSource.getAbsolutePath());
            retVal = false;
          }
        }
      }
    }
    return retVal;
  }

  /**
   * Sets the file.
   * 
   * @param file
   *          the new file
   */
  public void setFile(final File file) {
    this.file = file;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#upload(java.lang.String)
   */
  public boolean upload(final String localFile) {
    boolean retVal = false;
    if (file != null) {
      retVal = FileUtils.copyFile(new File(localFile), file);
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#upload(java.lang.String,
   *      java.lang.String)
   */
  public boolean upload(final String localFile, final String destFile) {
    boolean retVal = false;
    if (destFile != null) {
      final String dest = getSourceFile().getPathRoot();
      String newPath = "";
      if (dest.endsWith("/")) {
        newPath = dest + destFile;
      } else {
        newPath = dest + "/" + destFile;
      }
      retVal = FileUtils.copyFile(new File(localFile), new File(newPath));
    }
    return retVal;
  }

}
