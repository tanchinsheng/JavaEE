/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 11, 2011 6:16:31 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.config;

import com.st.common.beans.FileTypeEnum;

/**
 * The Class FolderInfo.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class FolderInfo {

  /** The folder type. */
  private FileTypeEnum folderType;

  /** The folder. */
  private String folder;

  /** The file type. */
  private String fileType;

  /** The file server. */
  private String fileServer;

  /** The user name. */
  private String userName;

  /** The password. */
  private String password;

  /** The port. */
  private int port;

  /** The depth folder. */
  private int depthFolder;

  /**
   * Instantiates a new folder info.
   * 
   * @param folderType
   *          the folder type
   * @param folder
   *          the folder
   */
  public FolderInfo(final FileTypeEnum folderType, final String folder) {
    super();
    this.folderType = folderType;
    this.folder = folder;
  }

  /**
   * Gets the depth folder.
   * 
   * @return the depth folder
   */
  public int getDepthFolder() {
    return depthFolder;
  }

  /**
   * Gets the file server.
   * 
   * @return the file server
   */
  public String getFileServer() {
    return fileServer;
  }

  /**
   * Gets the file type.
   * 
   * @return the file type
   */
  public String getFileType() {
    return fileType;
  }

  /**
   * Gets the folder.
   * 
   * @return the folder
   */
  public String getFolder() {
    return folder;
  }

  /**
   * Gets the folder type.
   * 
   * @return the folder type
   */
  public FileTypeEnum getFolderType() {
    return folderType;
  }

  /**
   * Gets the password.
   * 
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * Gets the port.
   * 
   * @return the port
   */
  public int getPort() {
    return port;
  }

  /**
   * Gets the user name.
   * 
   * @return the user name
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Sets the depth folder.
   * 
   * @param depthFolder
   *          the new depth folder
   */
  public void setDepthFolder(final int depthFolder) {
    this.depthFolder = depthFolder;
  }

  /**
   * Sets the file server.
   * 
   * @param fileServer
   *          the new file server
   */
  public void setFileServer(final String fileServer) {
    this.fileServer = fileServer;
  }

  /**
   * Sets the file type.
   * 
   * @param fileType
   *          the new file type
   */
  public void setFileType(final String fileType) {
    this.fileType = fileType;
  }

  /**
   * Sets the folder.
   * 
   * @param folder
   *          the new folder
   */
  public void setFolder(final String folder) {
    this.folder = folder;
  }

  /**
   * Sets the folder type.
   * 
   * @param folderType
   *          the new folder type
   */
  public void setFolderType(final FileTypeEnum folderType) {
    this.folderType = folderType;
  }

  /**
   * Sets the password.
   * 
   * @param password
   *          the new password
   */
  public void setPassword(final String password) {
    this.password = password;
  }

  /**
   * Sets the port.
   * 
   * @param port
   *          the new port
   */
  public void setPort(final int port) {
    this.port = port;
  }

  /**
   * Sets the user name.
   * 
   * @param userName
   *          the new user name
   */
  public void setUserName(final String userName) {
    this.userName = userName;
  }

}
