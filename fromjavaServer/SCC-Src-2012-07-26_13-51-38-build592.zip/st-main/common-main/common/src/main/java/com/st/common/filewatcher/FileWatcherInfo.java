/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 26, 2011 9:49:51 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.common.filewatcher;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileTypeEnum;
import com.st.common.config.FolderInfo;
import com.st.common.exception.SccException;
import com.st.scc.common.utils.ConvertUtils;

/**
 * The Class ConfigureUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class FileWatcherInfo {

  /** The LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileWatcherInfo.class);

  /** The Constant FOLDER_LEVEL. */
  private static final int FOLDER_LEVEL = 2;

  /** MAX_FILE_SIZE = 0 , it will get all files in folder. */
  private static final int MAX_SIZE_FILE = 50;

  /** The Constant FILE_Z. */
  private static final String FILE_Z = ".Z";

  /** The port for connection FTP or SFTP. */
  private int port;

  /** max size file per one time notify. */
  private int maxSizeFile;

  /** The monitor type. */
  private FileTypeEnum monitorType;

  /** The monitor folder. */
  private String monitorFolder;

  /** The monitor file type. */
  private String monitorFileType;

  /**
   * The list file type. listFileType is array string. example configure
   * .std*;.Z<br>
   * listFileType[0] = .std* and listFileType[1] = .Z
   */
  private List<String> listFileType;

  /** The host. */
  private String host;

  /** The user name. */
  private String userName;

  /** The password. */
  private String password;

  /** The depth folder. */
  private int depthFolder;

  /** The String. */
  private String folderName;

  /**
   * Gets the depth folder.
   * 
   * @return the depthFolder
   */
  public int getDepthFolder() {
    return depthFolder;
  }

  /**
   * Gets the folder name.
   * 
   * @return the folder name
   */
  public String getFolderName() {
    return folderName;
  }

  /**
   * Gets the host.
   * 
   * @return the host
   */
  public String getHost() {
    return host;
  }

  /**
   * Gets the list file type.
   * 
   * @return the listFileType
   */
  public List<String> getListFileType() {
    return listFileType;
  }

  /**
   * Gets the max size file.
   * 
   * @return the maxSizeFile
   */
  public int getMaxSizeFile() {
    return maxSizeFile;
  }

  /**
   * Gets the monitor file type.
   * 
   * @return the monitorFileType
   */
  public String getMonitorFileType() {
    return monitorFileType;
  }

  /**
   * Gets the monitor folder.
   * 
   * @return the monitorFolder
   */
  public String getMonitorFolder() {
    return monitorFolder;
  }

  /**
   * Gets the monitor type.
   * 
   * @return the monitorType
   */
  public FileTypeEnum getMonitorType() {
    return monitorType;
  }

  /**
   * Gets the password.
   * 
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * Gets the port.
   * 
   * @return the port
   */
  public int getPort() {
    return port;
  }

  /**
   * Gets the user name.
   * 
   * @return the userName
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Load config from folder info.
   * 
   * @param folderInfo
   *          the folder info
   * @param maxSizeNotify
   *          the max size notify
   * @throws SccException
   *           the SCC exception
   */
  public void loadConfigureWatcher(final FolderInfo folderInfo, final String maxSizeNotify)
      throws SccException {

    monitorType = folderInfo.getFolderType();
    if (monitorType == null) {
      throw new SccException("Un-supported monitor type");
    }
    LOG.info("load monitor type is " + monitorType);

    final String tempPathSTDF = folderInfo.getFolder();
    if (tempPathSTDF == null || tempPathSTDF.length() == 0) {
      throw new SccException("Error. monitor_folder is null");
    } else {
      LOG.info("Monitor folder is " + tempPathSTDF);
      monitorFolder = tempPathSTDF;
    }
    // get max_size_notify from file *.xml
    updateMaxSizeNotify(maxSizeNotify);

    // get monitor_file_type from file *.xml

    monitorFileType = folderInfo.getFileType();
    LOG.info("load monitorFileType is " + monitorFileType);

    if (monitorFileType != null) {
      monitorFileType = monitorFileType.replaceAll(",", ";");
    } else {
      monitorFileType = "";
    }
    listFileType = new ArrayList<String>();
    final Pattern p = Pattern.compile(";");
    final String[] tokens = p.split(monitorFileType);
    String temp = "";
    // LOG.info("read FileType is " + monitorFileType);
    for (int i = 0; i < tokens.length; i++) {
      if (!tokens[i].equals(FILE_Z)) {
        temp = tokens[i].toLowerCase().replaceAll("\\*", "[_a-zA-Z0-9]*");
      } else {
        temp = tokens[i].trim();
      }
      listFileType.add(temp);
    }

    if (monitorType != FileTypeEnum.NFS) {
      // get host from file *.xml
      host = folderInfo.getFileServer();
      // get ftp_username from file *.xml
      userName = folderInfo.getUserName();
      // get ftp_password from file *.xml
      password = folderInfo.getPassword();
      LOG.info("load host is " + host);
      LOG.info("load username is " + userName);
      // get port from file *.xml
      port = folderInfo.getPort();
    }

    // get depth_folder from file *.xml
    depthFolder = folderInfo.getDepthFolder();
    if (depthFolder > 5 || depthFolder < 0) {
      depthFolder = FOLDER_LEVEL;
    }
    LOG.info("depth_folder is " + depthFolder);
  }

  /**
   * Sets the folder name.
   * 
   * @param folderName
   *          the new folder name
   */
  public void setFolderName(final String folderName) {
    this.folderName = folderName;
  }

  /**
   * Sets the max size file.
   * 
   * @param maxSizeFile
   *          the maxSizeFile to set
   */
  public void setMaxSizeFile(final int maxSizeFile) {
    this.maxSizeFile = maxSizeFile;
  }

  /**
   * Update max size notify.
   * 
   * @param maxSizeNotify
   *          the max size notify
   */
  private void updateMaxSizeNotify(final String maxSizeNotify) {
    maxSizeFile = ConvertUtils.getInt(maxSizeNotify);
    if (maxSizeFile < 0 || maxSizeFile > MAX_SIZE_FILE) {
      maxSizeFile = MAX_SIZE_FILE;
    }
    LOG.info("max size file is " + maxSizeFile + " files");
  }
}
