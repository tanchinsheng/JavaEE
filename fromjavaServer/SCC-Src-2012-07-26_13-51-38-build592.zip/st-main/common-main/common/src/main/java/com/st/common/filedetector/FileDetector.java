/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 28, 2011 4:51:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.filedetector;

import java.io.File;
import java.io.InputStream;
import java.io.PushbackInputStream;

/**
 * Base interface for all file detectors.
 * 
 * @author trungtb
 */
public interface FileDetector {

  /**
   * Gets the file type.
   * 
   * @param byteBuf
   *          the byte buf
   * @return the file type
   */
  FileFormatEnum getFileType(byte[] byteBuf);

  /**
   * Use to detect file type.
   * 
   * @param file
   *          the file
   * @return FileTypeEnum
   */
  FileFormatEnum getFileType(File file);

  /**
   * Use to detect file type.
   * 
   * @param file
   *          the file
   * @return FileTypeEnum
   */
  FileFormatEnum getFileType(PushbackInputStream file);

  /**
   * Use to detect file type.
   * 
   * @param fileName
   *          the file name
   * @return FileTypeEnum
   */
  FileFormatEnum getFileType(String fileName);

  /**
   * Gets the file type from CPU type.
   * 
   * @param file
   *          the file
   * @return the file type from CPU type
   */
  FileFormatEnum getFileTypeFromCpuType(File file);

  /**
   * Use to detect file type.
   * 
   * @param inputStream
   *          the input stream
   * @return FileTypeEnum
   */
  FileFormatEnum getFileTypeFromOtherStream(InputStream inputStream);

}
