/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 14, 2011 11:16:39 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.common.utils.SFTPUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class SFTPFileScanner extends AbsFileScanner {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SFTPFileScanner.class);

  /** The session. */
  private Session session;

  /**
   * Instantiates a new SFTP file scanner.
   */
  public SFTPFileScanner() {
    setFileType(FileTypeEnum.SFTP);
  }

  /**
   * Change directory.
   * 
   * @param channel
   *          the channel
   * @param folder
   *          the folder listing files
   * @return true, if successful
   */
  private boolean cd(final ChannelSftp channel, final String folder) {
    boolean result = false;
    if (channel != null && folder != null) {
      try {
        channel.cd(folder);
        result = true;
      } catch (final SftpException e) {
        LOG.error("Error occurred when changing direction to monitor to folder = " + folder, e);
      }
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.FileScanner#disconnect()
   */
  public void disconnect() {
    SFTPUtils.disconnect(session);
  }

  /**
   * Gets the list SFTP files.
   * 
   * @param channel
   *          the channel
   * @param depth
   *          the depth
   * @param path
   *          the path
   * @param list
   *          the list
   * @param maxSizeFile
   *          the max size file
   */
  @SuppressWarnings("unchecked")
  private void getListNewFileSFTP(final ChannelSftp channel, final int depth,
      final String path, final List<FileInfo> list, final int maxSizeFile) {
    if (depth < 0) {
      return;
    }
    if (maxSizeFile > 0 && list.size() >= maxSizeFile) {
      return;
    }
    try {
      final List<LsEntry> vector = SFTPUtils.listFiles(channel, path); //channel.ls(path);
      for (final LsEntry entry : vector) {
        final String fileName = entry.getFilename();
        final SftpATTRS attrs = entry.getAttrs();
        final StringBuilder sb = new StringBuilder();
        if (path.endsWith("/")) {
          sb.append(path).append(fileName);
        } else {
          sb.append(path).append("/").append(fileName);
        }
        final String pathFileName = sb.toString();

        if (!attrs.isDir()) {
          final List<String> extensionFile = getFilePatternList();
          if (extensionFile != null) {
            for (final String entension : extensionFile) {
              if (Pattern.matches(entension, FileUtils.getTailFileName(fileName))) {
                final long mTime = (long) attrs.getMTime() * 1000;
                final long size = attrs.getSize();
                final FileInfo fileInfo =
                    new FileInfo(pathFileName, getMonitorFolder(), mTime);
                fileInfo.setFileType(getFileType());
                fileInfo.setHost(getHost());
                fileInfo.setUserName(getUserName());
                fileInfo.setPassWord(getPassword());
                fileInfo.setPort(getPort());
                fileInfo.setSize(size);
                list.add(fileInfo);
                break;
              }
            }
          }
        } else {
          getListNewFileSFTP(channel, depth - 1, pathFileName, list, maxSizeFile);
        }
        if (maxSizeFile > 0 && list.size() >= maxSizeFile) {
          break;
        }
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    }
  }

  /**
   * Gets the session.
   * 
   * @return the session
   */
  public Session getSession() {
    return session;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.FileScanner#scan(java.lang.String, int, int)
   */
  public List<FileInfo> scan(final String filePath, final int depth, final int maxSize) {
    List<FileInfo> list = null;
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (channel != null) {
      if (cd(channel, filePath)) {
        list = new ArrayList<FileInfo>();
        getListNewFileSFTP(channel, depth, filePath, list, maxSize);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Scanned files successfully");
        }
      } else {
        LOG.error("monitor to folder {} does not exist or no permission", getMonitorFolder());
      }
      channel.disconnect();
    } else {
      LOG.error("Could not open channel to SFTP host={}", getHost());
    }
    return list;
  }

  /**
   * Sets the session.
   * 
   * @param session
   *          the new session
   */
  public void setSession(final Session session) {
    this.session = session;
  }

}
