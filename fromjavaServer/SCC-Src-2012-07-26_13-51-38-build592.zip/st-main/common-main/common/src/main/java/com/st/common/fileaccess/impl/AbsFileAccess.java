/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 28, 2011 1:52:08 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.fileaccess.SccFileAccess;
import com.st.scc.common.utils.FTPUtil;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.common.utils.SFTPUtils;

/**
 * The Class AbsFileAccess.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public abstract class AbsFileAccess implements SccFileAccess {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(AbsFileAccess.class);

  /** The Constant DIR. */
  protected static final String DIR = System.getProperty("user.dir").replaceAll("\\\\", "/");

  /** The src file. */
  private FileInfo srcFile;

  /**
   * Copy and repair path root to file = user.dir and return is fileType = NFS
   * and LastModified = current time.
   * 
   * @param file
   *          the file
   * @return the file info
   */
  protected FileInfo copyFileToDir(final FileInfo file) {
    final FileInfo fileTemp = FileInfo.copyFileInfo(file);
    if (fileTemp != null) {
      fileTemp.setFileType(FileTypeEnum.NFS);
      final String temp = DIR;
      final StringBuilder sb = new StringBuilder();
      sb.append(temp);
      if (!temp.endsWith("/")) {
        sb.append("/");
      }
      sb.append("tmp/move");
      fileTemp.setPathRoot(sb.toString());
      sb.append("/");
      sb.append(fileTemp.getPathRootToFile());
      fileTemp.setPathFileName(sb.toString());
      fileTemp.setLastModified(System.currentTimeMillis());
    }

    return fileTemp;
  }

  /**
   * Copy and repair path root to file = user.dir+"/tmp/" set name file is last
   * name file+".Z" and return is fileType = NFS and LastModified = current
   * time.
   * 
   * @param file
   *          the file
   * @return the file info
   */
  protected FileInfo copyFileToDirSetZ(final FileInfo file) {
    final FileInfo fileTemp = copyFileToDir(file);
    if (fileTemp != null) {
      fileTemp.setPathFileName(fileTemp.getPathFileName() + ".Z");
      fileTemp.setPathRootToFile(fileTemp.getPathRootToFile() + ".Z");
    }
    return fileTemp;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#getSourceFile()
   */
  public FileInfo getSourceFile() {
    return srcFile;
  }

  /**
   * Move NFS to FTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  protected boolean moveNFSToFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean uploadSuccess = false;
    if (srcFile != null) {
      // get information of where moving file FTP
      final String host = destFile.getHost();
      final String userName = destFile.getUserName();
      final String password = destFile.getPassWord();
      final int port = destFile.getPort();
      final String dest = destFile.getPathRoot();
      File file = null;
      InputStream in = null;
      final FTPClient ftp = FTPUtil.connectFTP(host, userName, password, port);
      if (ftp == null) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Connection to FTP with host = ").append(host);
        sb.append(" username = ").append(userName);
        sb.append(" password = ").append(password).append(" is failed");
        LOG.warn(sb.toString());
        return uploadSuccess;
      }

      try {
        String temp = "";
        if (dest.endsWith("/")) {
          temp = dest + srcFile.getPathRootToFile();
        } else {
          temp = dest + "/" + srcFile.getPathRootToFile();
        }
        temp = temp.replaceAll("\\\\", "/");
        if (!FTPUtil.createPathFTP(ftp, temp, false)) {
          FTPUtil.createFolder(ftp, temp);
        }
        file = new File(srcFile.getPathFileName());
        if (file.exists()) {
          in = new FileInputStream(file);
          if (FTPUtil.uploadToFTP(ftp, temp, in)) {
            uploadSuccess = true;
          } else {
            final StringBuilder sb = new StringBuilder();
            sb.append("upload file from Local to FTP source = ");
            sb.append(srcFile.getPathFileName());
            sb.append("; dest = ").append(destFile.getPathFileName()).append(" is failed ");
            LOG.warn(sb.toString());
          }
        }
      } catch (final Exception e) {
        final StringBuilder sb = new StringBuilder();
        sb.append("upload file from Local to FTP source = ").append(srcFile.getPathFileName());
        sb.append("; dest = ").append(destFile.getPathFileName()).append(" is failed ");
        sb.append(e.getMessage());
        LOG.error(sb.toString(), e);
      } finally {
        FTPUtil.disconnectFTP(ftp);
        FileUtils.close(in);
        if (uploadSuccess && file != null) {
          if (file.delete()) {
            if (LOG.isDebugEnabled()) {
              LOG.debug("deleted file local {}", file.getAbsolutePath());
            }
          } else {
            uploadSuccess = false;
            LOG.warn("Could not delete file {}", file.getAbsolutePath());
          }
        }
      }
    }
    return uploadSuccess;
  }

  /**
   * Move NFS to SFTP and delete source.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  protected boolean moveNFSToSFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null && destFile != null) {
      final Session session =
          SFTPUtils.createSession(destFile.getHost(), destFile.getUserName(),
              destFile.getPassWord(), destFile.getPort());
      final String dest = destFile.getPathRoot();
      File file = null;
      final ChannelSftp channel = SFTPUtils.openChannel(session);
      if (channel != null) {
        String temp = "";
        if (dest.endsWith("/")) {
          temp = dest + srcFile.getPathRootToFile();
        } else {
          temp = dest + "/" + srcFile.getPathRootToFile();
        }
        temp = temp.replaceAll("\\\\", "/");
        if (!SFTPUtils.createPath(channel, temp, false)) {
          SFTPUtils.createFolder(channel, temp);
        }
        file = new File(srcFile.getPathFileName());
        if (file.exists()) {
          if (SFTPUtils.upload(channel, srcFile.getPathFileName(), temp)) {
            file.delete();
            retVal = true;
          } else {
            final StringBuilder sb = new StringBuilder();
            sb.append("upload file to SFTP source = ");
            sb.append(srcFile.getPathFileName());
            sb.append("; dest = ").append(destFile.getPathFileName()).append(" failed ");
            LOG.warn(sb.toString());
          }
        }
        channel.disconnect();
      }
      SFTPUtils.disconnect(session);
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#setSourceFile(com.st.common.beans.FileInfo)
   */
  public void setSourceFile(final FileInfo srcFile) {
    this.srcFile = srcFile;
  }

}
