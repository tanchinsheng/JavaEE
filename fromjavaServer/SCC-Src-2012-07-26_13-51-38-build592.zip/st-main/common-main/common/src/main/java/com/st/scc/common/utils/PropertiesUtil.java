/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Oct 13, 2011 1:52:28 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class PropertiesUtil.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class PropertiesUtil {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(PropertiesUtil.class);

  /**
   * Load properties file to map.
   * 
   * @param file
   *          the file
   * @return the map
   */
  public static Map<String, String> load(final File file) {
    InputStream inputStream = null;
    final Map<String, String> map = new HashMap<String, String>();
    try {
      inputStream = new FileInputStream(file);
      final Properties properties = new Properties();
      properties.load(inputStream);
      final Set<Entry<Object, Object>> entrySet = properties.entrySet();
      for (final Entry<Object, Object> entry : entrySet) {
        map.put((String) entry.getKey(), (String) entry.getValue());
      }
    } catch (final IOException e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
    }
    return map;
  }

  /**
   * Load from XML to map.
   * 
   * @param file
   *          the file
   * @return the map
   */
  public static Map<String, String> loadFromXML(final File file) {
    InputStream inputStream = null;
    final Map<String, String> map = new HashMap<String, String>();
    try {
      inputStream = new FileInputStream(file);
      final Properties properties = new Properties();
      properties.loadFromXML(inputStream);
      final Set<Entry<Object, Object>> entrySet = properties.entrySet();
      for (final Entry<Object, Object> entry : entrySet) {
        map.put((String) entry.getKey(), (String) entry.getValue());
      }
    } catch (final IOException e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
    }
    return map;
  }

  /**
   * Load properties file.
   * 
   * @param properties
   *          the properties
   * @param file
   *          the file
   */
  public static void load(final Properties properties, final File file) {
    InputStream inputStream = null;
    try {
      inputStream = new FileInputStream(file);
      properties.load(inputStream);
    } catch (final IOException e) {
      LOG.error(e.getMessage(), e);
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          LOG.error("Failed to close stream", e);
        }
      }
    }
  }

  /**
   * Instantiates a new properties utility.
   */
  private PropertiesUtil() {

  }
}
