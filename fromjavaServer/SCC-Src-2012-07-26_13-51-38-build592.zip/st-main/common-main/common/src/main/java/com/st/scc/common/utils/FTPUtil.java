/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 16, 2011 2:46:44 PM - nhatvn - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.net.ProtocolCommandEvent;
import org.apache.commons.net.ProtocolCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.io.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileInfo;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class FTPUtil {

  /**
   * The listener interface for receiving printCommand events. The class that is
   * interested in processing a printCommand event implements this interface,
   * and the object created with that class is registered with a component using
   * the component's <code>addPrintCommandListener</code> method. When the
   * printCommand event occurs, that object's appropriate method is invoked.
   * 
   * @see PrintCommandEvent
   */
  private static class PrintCommandListener implements ProtocolCommandListener {

    /**
     * Instantiates a new prints the command listener.
     */
    public PrintCommandListener() {
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.apache.commons.net.ProtocolCommandListener#protocolCommandSent(org.apache.commons.net.ProtocolCommandEvent)
     */
    public void protocolCommandSent(final ProtocolCommandEvent event) {
      if (LOG.isDebugEnabled()) {
        final String ev = event.getMessage();
        if (ev != null && ev.startsWith("PASS")) {
          return;
        }
        final StringBuilder sb = new StringBuilder(256);
        sb.append("Sent:").append(event.getMessage());
        LOG.debug(sb.toString());
      }
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.apache.commons.net.ProtocolCommandListener#protocolReplyReceived(org.apache.commons.net.ProtocolCommandEvent)
     */
    public void protocolReplyReceived(final ProtocolCommandEvent event) {
      if (LOG.isDebugEnabled()) {
        final StringBuilder sb = new StringBuilder(256);
        sb.append("Response:").append(event.getMessage());
        LOG.debug(sb.toString());
      }
    }

  }

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FTPUtil.class);

  /** The Constant DEFAULT_DATA_TIMEOUT. */
  private static final int DEFAULT_DATA_TIMEOUT = 5000;

  /** The Constant DEFAULT_FTP_PORT. */
  private static final int DEFAULT_FTP_PORT = 21;

  /**
   * Check available.
   * 
   * @param fileInfo
   *          the file info
   * @param ftp
   *          the FTP connection
   * @return true, if successful
   */
  public static boolean checkAvailable(final FileInfo fileInfo, final FTPClient ftp) {
    boolean retVal = false;
    if (fileInfo != null && ftp != null) {
      try {
        String parent = "";
        String fileName = "";
        final String path = fileInfo.getPathFileName();
        if (path.length() > 0) {
          final int slashIndex = path.lastIndexOf("/");
          if (slashIndex > -1) {
            parent = path.substring(0, slashIndex);
            fileName = path.substring(slashIndex + 1);
          }
        }
        if (parent.length() > 0 && fileName.length() > 0) {
          ftp.changeWorkingDirectory(parent);
          final FTPFile[] listFile = FTPUtil.listFiles(ftp);
          for (final FTPFile ftpFile : listFile) {
            if (ftpFile.getName().equals(fileName) && ftpFile.isFile()
                && ftpFile.getSize() > 0 && ftpFile.getSize() == fileInfo.getSize()) {
              retVal = true;
              break;
            }
          }
        }
      } catch (final Exception e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return retVal;
  }

  /**
   * Connect ftp.
   * 
   * @param hostName
   *          the host name
   * @param userName
   *          the user name
   * @param password
   *          the password
   * @return the fTP client
   */
  public static FTPClient connectFTP(final String hostName, final String userName,
      final String password) {
    return connectFTP(hostName, userName, password, DEFAULT_FTP_PORT);
  }

  /**
   * Connect to FTP.
   * 
   * @param hostName
   *          : host name
   * @param userName
   *          : user name
   * @param password
   *          : password
   * @param port
   *          the port
   * @return the fTP client
   */
  public static FTPClient connectFTP(final String hostName, final String userName,
      final String password, final int port) {
    final FTPClient ftpClient = new FTPClient();
    if (port > 0) {
      ftpClient.setDefaultPort(port);
    } else {
      ftpClient.setDefaultPort(DEFAULT_FTP_PORT);
    }
    ftpClient.addProtocolCommandListener(new PrintCommandListener());
    try {
      ftpClient.connect(hostName);
      ftpClient.setDataTimeout(DEFAULT_DATA_TIMEOUT);
      final int reply = ftpClient.getReplyCode();
      if (!FTPReply.isPositiveCompletion(reply)) {
        ftpClient.disconnect();
        LOG.warn("FTP server refused connection, host=" + hostName + ",port="
            + ftpClient.getDefaultPort());
        return null;
      }
    } catch (final Exception e) {
      LOG.error("Can not connect to FTP, host=" + hostName, e);
      return null;
    }
    try {
      if (!ftpClient.login(userName, password)) {
        ftpClient.logout();
        final StringBuilder sb = new StringBuilder();
        sb.append("Login fail to FTP:").append("username=").append(userName);
        LOG.warn(sb.toString());
        return null;
      }

      ftpClient.enterLocalPassiveMode();
    } catch (final IOException e) {
      final StringBuilder sb = new StringBuilder();
      sb.append("Can not login to FTP: ").append("username=").append(userName);
      LOG.error(sb.toString(), e);
      return null;
    }
    final StringBuilder sb = new StringBuilder();
    sb.append("Login successfully: ").append("username=").append(userName);
    LOG.info(sb.toString());

    return ftpClient;
  }

  /**
   * Create parent directory of file name if parent directory doesn't exist.
   * 
   * @param ftpClient
   *          the ftp client
   * @param filePath
   *          : path contains file name.
   * @return true, if successful
   */
  public static boolean createFolder(final FTPClient ftpClient, final String filePath) {
    if (filePath == null || "".equals(filePath)) {
      LOG.error("Crete path on FTP failed,path=" + filePath);
      return false;
    }
    final int index = filePath.lastIndexOf("/");
    String parentPath = "";
    if (index > -1) {
      parentPath = filePath.substring(0, index);
    } else {
      LOG.error("Path doesn't exist on FTP, path=" + filePath);
      return false;
    }
    boolean exist = false;
    try {
      exist = ftpClient.changeWorkingDirectory(parentPath);
    } catch (final IOException e) {
      LOG.error("Error create folder " + parentPath, e);
    }
    if (!exist) {
      final boolean parentExist = createFolder(ftpClient, parentPath);
      if (parentExist) {
        try {
          if (ftpClient.makeDirectory(parentPath)) {
            if (LOG.isDebugEnabled()) {
              LOG.debug("Create sucessfully directory=" + parentPath);
            }
            return true;
          }
        } catch (final IOException e) {
          LOG.error("Create path on FTP failed, path=" + parentPath);
        }
        return false;
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  /**
   * create folder on ftp server pathFolder is path of server. if create success
   * then return true else return false.
   * 
   * @param ftp
   *          the ftp
   * @param pathFolder
   *          the path folder
   * @param directory
   *          the directory
   * @return true, if successful
   */
  public static boolean createPathFTP(final FTPClient ftp, final String pathFolder,
      final boolean directory) {
    final Pattern pa = Pattern.compile("/");
    final String[] tokens = pa.split(pathFolder);
    boolean result = true;
    int size = 0;
    if (directory) {
      size = tokens.length;
    } else {
      size = tokens.length - 1;
    }
    for (int i = 0; i < size; i++) {
      if (tokens[i] != null && !"".equals(tokens[i])) {
        boolean change = true;
        try {
          if (change) {
            if (ftp.changeWorkingDirectory("/" + tokens[i])) {
              change = true;

            } else {
              change = false;
            }
            result = true;
          }
        } catch (final IllegalStateException e) {
          change = false;
        } catch (final IOException e) {
          change = false;
        }
        if (!change) {
          try {
            ftp.makeDirectory(tokens[i]);
            ftp.changeWorkingDirectory(tokens[i]);
            result = true;
          } catch (final IOException e) {
            result = false;
            LOG.error(e.getMessage(), e);
          }
        }
      }
      if (!result) {
        return result;
      }
    }
    return result;
  }

  /**
   * Delete file on FTP.
   * 
   * @param ftpClient
   *          the ftp client
   * @param remoteFile
   *          the remote file
   * @return true, if successful
   */
  public static boolean deleteFileFTP(final FTPClient ftpClient, final String remoteFile) {
    try {
      if (ftpClient.deleteFile(remoteFile)) {
        if (LOG.isDebugEnabled()) {
          LOG.debug("Delete file=" + remoteFile + " successfully");
        }
        return true;
      }
    } catch (final IOException e) {
      LOG.error("Error occured while deleting file,remote file=" + remoteFile, e);
    }
    return false;
  }

  /**
   * Delete file on FTP.
   * 
   * @param ftpClient
   *          the FTP client
   * @param remoteFile
   *          the remote file
   * @param writeLog
   *          the write log
   * @return true, if successful
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static boolean deleteFileFTP(final FTPClient ftpClient, final String remoteFile,
      final boolean writeLog) throws IOException {
    boolean result = false;
    if (writeLog) {
      result = deleteFileFTP(ftpClient, remoteFile);
    } else {
      if (ftpClient.deleteFile(remoteFile)) {
        result = true;
      }
    }
    return result;
  }

  /**
   * Delete non-empty folder.
   * 
   * @param ftpClient
   *          the ftp client
   * @param remotePath
   *          the remote path
   */
  public static void deleteFolder(final FTPClient ftpClient, final String remotePath) {
    try {
      if (ftpClient.changeWorkingDirectory(remotePath)) {
        final FTPFile[] ftpFiles = FTPUtil.listFiles(ftpClient);
        for (final FTPFile ftpFile : ftpFiles) {
          if (ftpFile.isFile()) {
            deleteFileFTP(ftpClient, remotePath + "/" + ftpFile.getName());
          } else if (ftpFile.isDirectory()) {
            deleteFolder(ftpClient, remotePath + "/" + ftpFile.getName());
          }
        }
        ftpClient.changeToParentDirectory();
        if (ftpClient.removeDirectory(remotePath)) {
          if (LOG.isDebugEnabled()) {
            LOG.debug("Delete folder=" + remotePath + " successfully");
          }
        }
      }
    } catch (final IOException e) {
      LOG.error("Error occured while deleting folder, remote path=" + remotePath, e);
    }
  }

  /**
   * Logout and disconnect to FTP Server.
   * 
   * @param ftpClient
   *          the ftp client
   */
  public static void disconnectFTP(final FTPClient ftpClient) {
    if (ftpClient != null) {
      try {
        ftpClient.logout();
        LOG.debug("Logout successfully");
      } catch (final IOException e) {
        LOG.error("Logout is fail " + e.getMessage(), e);
      } finally {
        try {
          ftpClient.disconnect();
          LOG.info("Disconnect FTP successfully.");
        } catch (final IOException e) {
          LOG.error("Error disconnection " + e.getMessage(), e);
        }

      }
    }
  }

  /**
   * Download file remoteFile and save to localFile.
   * 
   * @param ftpClient
   *          the ftp client
   * @param remoteFile
   *          the remote file
   * @param localFile
   *          the local file
   * @return true, if successful
   */
  public static boolean downloadFile(final FTPClient ftpClient, final String remoteFile,
      final String localFile) {
    boolean retVal = false;

    BufferedOutputStream buffer = null;
    try {
      final File file = new File(localFile);
      FileUtils.createParentPath(file);
      buffer = new BufferedOutputStream(new FileOutputStream(file));
    } catch (final FileNotFoundException e) {
      LOG.error("Output file is not found, path={}", localFile);
      return retVal;
    } catch (final IOException e) {
      LOG.error(e.getMessage(), e);
      return retVal;
    }

    InputStream fileStream = null;
    try {
      fileStream = ftpClient.retrieveFileStream(remoteFile);
      if (buffer != null && fileStream != null) {
        Util.copyStream(fileStream, buffer);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Download file successfully, remoteFile = " + remoteFile
              + ", localFile = " + localFile);
        }
      } else {
        LOG.info("Download file failure, remoteFile = " + remoteFile + ", localFile = "
            + localFile);
      }
    } catch (final IOException e) {
      LOG.error("Error when downloading file from FTP, file=" + remoteFile, e);
    } finally {
      if (buffer != null) {
        try {
          buffer.close();
        } catch (final IOException e) {
          LOG.error("Fail to close stream", e);
        }
      }
      //we must close the stream before call completePendingCommand().
      //Otherwise, it will hang.
      if (fileStream != null) {
        try {
          fileStream.close();
        } catch (final IOException e) {
          LOG.error("Fail to close stream", e);
        }
      }
      try {
        // If you already close stream successfully, we must send complete command.
        // Otherwise, code will wait (hang) at here for long time, and throw
        // exception.
        if (fileStream != null) {
          retVal = ftpClient.completePendingCommand();
        }
      } catch (final IOException e) {
        LOG.error("File transfer failed", e);
      }
    }
    return retVal;
  }

  /**
   * Exists ignore checking file size.
   * 
   * @param fileInfo
   *          the file info
   * @param ftp
   *          the ftp
   * @return true, if successful
   */
  public static boolean exists(final FileInfo fileInfo, final FTPClient ftp) {
    boolean retVal = false;
    if (fileInfo != null && ftp != null) {
      try {
        String parent = "";
        String fileName = "";
        final String path = fileInfo.getPathFileName();
        if (path.length() > 0) {
          final int slashIndex = path.lastIndexOf("/");
          if (slashIndex > -1) {
            parent = path.substring(0, slashIndex);
            fileName = path.substring(slashIndex + 1);
          }
        }
        if (parent.length() > 0 && fileName.length() > 0) {
          ftp.changeWorkingDirectory(parent);
          final FTPFile[] listFile = FTPUtil.listFiles(ftp);
          for (final FTPFile ftpFile : listFile) {
            if (ftpFile.getName().equals(fileName) && ftpFile.isFile()) {
              retVal = true;
              break;
            }
          }
        }
      } catch (final Exception e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return retVal;
  }

  /**
   * Check the file path exists or not.
   * 
   * @param path
   *          the path
   * @param ftp
   *          the FTP
   * @return true, if successful
   */
  public static boolean exists(final String path, final FTPClient ftp) {
    boolean retVal = false;
    if (path != null && ftp != null) {
      try {
        String parent = "";
        String fileName = "";
        if (path.length() > 0) {
          final int slashIndex = path.lastIndexOf("/");
          if (slashIndex > -1) {
            parent = path.substring(0, slashIndex);
            fileName = path.substring(slashIndex + 1);
          }
        }
        if (parent.length() > 0 && fileName.length() > 0) {
          ftp.changeWorkingDirectory(parent);
          final FTPFile[] listFile = FTPUtil.listFiles(ftp);
          for (final FTPFile ftpFile : listFile) {
            if (ftpFile.getName().equals(fileName) && ftpFile.isFile()) {
              retVal = true;
              break;
            }
          }
        }
      } catch (final Exception e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return retVal;
  }

  /**
   * Move file from ftp 'from' to ftp 'to'.
   * 
   * @param from
   *          the from
   * @param to
   *          the to
   * @param filePathFrom
   *          the file path from
   * @param filePathTo
   *          the file path to
   * @return true, if successful
   */
  public static boolean moveFileFTP(final FTPClient from, final FTPClient to,
      final String filePathFrom, final String filePathTo) {
    try {
      // Let's just assume success for now.
      to.enterRemotePassiveMode();

      from.enterRemoteActiveMode(InetAddress.getByName(to.getPassiveHost()),
          to.getPassivePort());

      if (from.remoteRetrieve(filePathFrom) && to.remoteStore(filePathTo)) {
        // if(ftp1.remoteRetrieve(file1) && ftp2.remoteStore(file2)) {
        // We have to fetch the positive completion reply.
        from.completePendingCommand();
        to.completePendingCommand();
      } else {
        final StringBuilder builder = new StringBuilder();
        builder.append("Fail move file from ftp1:").append(from.getPassiveHost())
            .append(" to ftp2:").append(to.getPassiveHost());
        LOG.error(builder.toString());
        return false;
      }
    } catch (final Exception ex) {
      final StringBuilder builder = new StringBuilder();
      builder.append("Fail move file from ftp1:").append(from.getPassiveHost())
          .append(" to ftp2:").append(to.getPassiveHost())
          .append(" .Error message : " + ex.getMessage());
      LOG.error(builder.toString());
      return false;
    }
    return true;
  }

  /**
   * Move file from sourceFile to destFile.
   * 
   * @param ftpClient
   *          the ftp client
   * @param sourceFile
   *          the source file
   * @param destFile
   *          the dest file
   * @return true, if successful
   */
  public static boolean moveFileOnFTP(final FTPClient ftpClient, final String sourceFile,
      final String destFile) {
    int i = 0;
    int posOfPath = 0;
    // Get the same position of 2 file path.
    for (i = 0; i < sourceFile.length() && i < destFile.length(); i++) {
      if (sourceFile.charAt(i) != destFile.charAt(i)) {
        break;
      } else {
        if (sourceFile.charAt(i) == '/') {
          posOfPath = i;
        }
      }

    }
    final String newSourcePath = sourceFile.substring(posOfPath + 1);
    // Count number parent directory
    int numberParent = 0;
    for (i = 0; i < newSourcePath.length(); i++) {
      if (newSourcePath.charAt(i) == '/') {
        numberParent++;
      }
    }
    final String newDestPath = destFile.substring(posOfPath + 1);
    final StringBuilder newPath = new StringBuilder();
    for (i = 0; i < numberParent; i++) {
      newPath.append("../");
    }
    newPath.append(newDestPath);
    final int lastPath = sourceFile.lastIndexOf("/");
    final String currentPath = sourceFile.substring(0, lastPath);
    try {
      final String destPath = newPath.toString();
      if (exists(destPath, ftpClient)) {
        deleteFileFTP(ftpClient, destPath);
      }
      if (ftpClient.changeWorkingDirectory(currentPath)) {
        if (ftpClient.rename(sourceFile.substring(lastPath + 1), destPath)) {
          if (LOG.isDebugEnabled()) {
            final StringBuilder builder = new StringBuilder();
            builder.append("Move file successfully from:").append(sourceFile).append(" to:")
                .append(destFile);
            LOG.debug(builder.toString());
          }
          return true;
        } else {
          final StringBuilder builder = new StringBuilder();
          builder.append("Move file fail from:").append(sourceFile).append(" to:")
              .append(destFile);
          LOG.info(builder.toString());
          return false;
        }
      }
    } catch (final IOException e) {
      final StringBuilder builder = new StringBuilder();
      builder.append("Move file fail from:").append(sourceFile).append(";to:")
          .append(destFile);
      LOG.error(builder.toString(), e);
    }
    return false;
  }

  /**
   * Read file from server.
   * 
   * @param ftpClient
   *          the ftp client
   * @param remoteFile
   *          the remote file
   * @return the input stream
   */
  public static InputStream readFileFromFTP(final FTPClient ftpClient, final String remoteFile) {
    try {
      final InputStream in = ftpClient.retrieveFileStream(remoteFile);
      return in;
    } catch (final IOException e) {
      LOG.error("Error when read file from FTP,file=" + remoteFile, e);
    }
    return null;
  }

  /**
   * Upload file with inputStream to FTP server at remoteFile.
   * 
   * @param ftpClient
   *          the ftp client
   * @param remoteFile
   *          the remote file
   * @param in
   *          the in
   * @return true, if successful
   */
  public static boolean uploadToFTP(final FTPClient ftpClient, final String remoteFile,
      final InputStream in) {
    try {
      createFolder(ftpClient, remoteFile);
      ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
      if (ftpClient.storeFile(remoteFile, in)) {
        if (LOG.isDebugEnabled()) {
          LOG.debug("Upload file successfully, remote file=" + remoteFile);
        }
        return true;
      }
    } catch (final IOException e) {
      LOG.error("Error occurred while uploading file, remote file=" + remoteFile, e);
    }
    return false;
  }

  /**
   * Zip from inputStream and upload output of zip to FTP.
   * 
   * @param ftpClient
   *          the ftp client
   * @param inputStream
   *          the input stream
   * @param fileInZip
   *          the file in zip
   * @return the input stream
   */
  public static InputStream zipFileFTP(final FTPClient ftpClient,
      final InputStream inputStream, final String fileInZip) {
    ZipOutputStream out;
    final int size = 1024 * 32;
    final ByteArrayOutputStream byteOut = new ByteArrayOutputStream(size);
    // BufferedOutputStream bufferOut = new BufferedOutputStream(tempOut);
    final BufferedOutputStream bufferOut = new BufferedOutputStream(byteOut);
    out = new ZipOutputStream(bufferOut);

    final byte[] data = new byte[1024];

    int count;
    try {
      out.putNextEntry(new ZipEntry(fileInZip));
      // Zip input stream.
      while ((count = inputStream.read(data, 0, 1024)) != -1) {
        out.write(data, 0, count);
      }
      // Close out stream.
      out.flush();
      try {
        // Must close output stream before get byte array.
        if (out != null) {
          out.close();
        }
      } catch (final IOException e) {
        LOG.error(e.getMessage(), e);
      }
      // return new FileInputStream(tempZipFile);
      final ByteArrayInputStream byteInputStream =
          new ByteArrayInputStream(byteOut.toByteArray());

      LOG.info("File is zipped successfully.");
      return byteInputStream;
    } catch (final IOException e) {
      LOG.error("Error when zip file:" + e.getMessage(), e);
    } finally {
      try {
        if (byteOut != null) {
          byteOut.close();
        }
      } catch (final IOException e) {
        LOG.error(e.getMessage(), e);
      }
      try {
        if (bufferOut != null) {
          bufferOut.close();
        }
      } catch (final IOException e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return null;
  }
  
  /**
   * List all files or folder in the current working directory.
   * 
   * @param ftp
   * @return
   * @throws IOException
   */
  public static FTPFile[] listFiles(final FTPClient ftp) throws IOException {
    if (ftp != null) {
      FTPFile[] list = ftp.listFiles();
      if (list != null && list.length > 0) {
        ArrayList<FTPFile> returnList = new ArrayList<FTPFile>(list.length);
        for (FTPFile ftpFile : list) {
          if (!checkIgnoreFile(ftpFile.getName())) {
            returnList.add(ftpFile);
          }
        }
        list = null;
        return returnList.toArray(new FTPFile[0]);
      } else {
        return list;
      }
    }
    return null;
  }
  
  /**
   * Check this file whether is ignored. Folder has name is '.' or '..', must
   * ignore it.
   * 
   * @param fileName
   * @return
   */
  public static boolean checkIgnoreFile(String fileName) {
    // on some OS, when list folder, have '.' and '..', must skip them
    if (".".equals(fileName) || "..".equals(fileName)) {
      return true;
    }
    return false;
  }

  /**
   * Instantiates a new FTP utility.
   */
  private FTPUtil() {
  }
}
