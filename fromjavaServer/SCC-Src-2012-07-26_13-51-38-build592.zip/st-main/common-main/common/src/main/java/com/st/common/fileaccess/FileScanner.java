/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 14, 2011 11:10:51 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess;

import java.util.List;

import com.st.common.beans.FileInfo;

/**
 * The Interface FileScanner.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public interface FileScanner {

  /**
   * Disconnect and release resources.
   */
  void disconnect();

  /**
   * Scan the input file path.
   * 
   * @param filePath
   *          the file path
   * @param depth
   *          the depth
   * @param maxSize
   *          the max size
   * @return the list
   */
  List<FileInfo> scan(String filePath, int depth, int maxSize);

  /**
   * Sets the file pattern list.
   * 
   * @param filePatternList
   *          the new file pattern list
   */
  void setFilePatternList(List<String> filePatternList);

  /**
   * Sets the monitor folder.
   * 
   * @param monitorFolder
   *          the new monitor folder
   */
  void setMonitorFolder(String monitorFolder);
}
