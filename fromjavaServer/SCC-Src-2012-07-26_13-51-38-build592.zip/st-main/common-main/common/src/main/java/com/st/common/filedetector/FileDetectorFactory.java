/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 28, 2011 4:51:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.filedetector;

import java.io.InputStream;
import java.io.PushbackInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.filedetector.impl.MagicNumberFileDetector;
import com.st.common.filedetector.impl.SimpleFileDetector;

/**
 * Provide methods to create different kinds of the file detector.
 * 
 * @author trungtb
 */
public final class FileDetectorFactory {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileDetectorFactory.class);

  /** The simple detector. */
  private static FileDetector simpleDetector;

  /** The magic detector. */
  private static FileDetector magicDetector;
  
  static {
    LOG.debug("Create an instance of MagicNumberFileDetector");
    magicDetector = new MagicNumberFileDetector();
    LOG.debug("Create an instance of SimpleFileDetector");
    simpleDetector = new SimpleFileDetector();
  }

  /**
   * Creates a new FileDetector object. Using magic number to detect
   * 
   * @return the file detector
   */
  public static FileDetector createMagicDetector() {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Return an instance of MagicNumberFileDetector");
    }
    return magicDetector;
  }

  /**
   * Creates a new FileDetector object.
   * 
   * @param inputStream
   *          the input stream
   * @return the pushback input stream
   */
  public static PushbackInputStream createPushbackInputStream(final InputStream inputStream) {
    PushbackInputStream retStream = null;
    if (inputStream instanceof PushbackInputStream) {
      retStream = (PushbackInputStream) inputStream;
    } else if (inputStream != null) {
      retStream =
          new PushbackInputStream(inputStream, MagicNumberFileDetector.MAGIC_BYTES_MAX_NUMBER);
    }
    return retStream;
  }

  /**
   * Creates a new FileDetector object. Using file name to detect
   * 
   * @return the file detector
   */
  public static FileDetector createSimpleDetector() {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Return an instance of SimpleFileDetector");
    }
    return simpleDetector;
  }

  /**
   * Instantiates a new file detector factory.
   */
  private FileDetectorFactory() {

  }
}
