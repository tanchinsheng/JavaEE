/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - Apr 1, 2011 11:34:56 AM - nguyensn - Initialize version
/******************************************************************************/
package com.st.common;

import com.st.common.convertbyteutil.ConvertByteUtilCommon;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011.
 *  All rights reserved.
 *
 */

/**
 * The Class FloatConvertUtil.
 */
public class ConvertByteUtil extends ConvertByteUtilCommon {
	/** The Constant CPU_TYPE_VAX_0. */
	public static final int CPU_TYPE_VAX_0 = 0;

	/** The Constant CPU_TYPE_SUN_1. */
	public static final int CPU_TYPE_SUN_1 = 1;

	/** The Constant CPU_TYPE_IBM_2. */
	public static final int CPU_TYPE_IBM_2 = 2;

	/**
	 * get character ASCII from byteArray.
	 * 
	 * @param byteArray
	 *            byte array will be convert
	 * @return return a ASCII character
	 */
	private static char getCharAscii(final byte byteArray) {
		char a = (char) (byteArray & BYTE_0FF);
		return a;
	}

	/**
	 * Gets the two byte char.
	 * 
	 * @param byteArray
	 *            the byte array has two byte.
	 * @param cpuType
	 *            the cpu type
	 * @return the char, if range of byte not equal char byte length throw
	 *         exception
	 */
	private static char getCharUnicode(final byte[] byteArray, final int cpuType) {

		char result = 0;
		if (cpuType == CPU_TYPE_IBM_2 || cpuType == CPU_TYPE_VAX_0) {
			result = getCharLittleEndian(byteArray);
		} else if (cpuType == CPU_TYPE_SUN_1) {
			result = getCharBigEndian(byteArray);
		}
		return result;
	}

	/**
	 * get ASCII string from byte array.
	 * 
	 * @param byteArray
	 *            byte array
	 * @return String ASCII
	 */
	private static String getStringAscii(final byte[] byteArray) {
		if (byteArray == null) {
			return "";
		}
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < byteArray.length; i++) {
			stringBuffer.append(getCharAscii(byteArray[i]));
		}
		return stringBuffer.toString();
	}

	/**
	 * 
	 * get String ASCII of byte array between start and end.
	 * 
	 * @param byteArray
	 *            byte array
	 * @param start
	 *            integer of start point in byte array
	 * @param end
	 *            integer of end point in byte array
	 * @return ASCII string
	 */
	public static String getStringAscii(final byte[] byteArray,
			final int start, final int end) {

		byte[] actualByte = copyByte(byteArray, start, end);
		return getStringAscii(actualByte);
	}

	/**
	 * get unicode String from byte array.
	 * 
	 * @param byteArray
	 *            byte array
	 * @param cpuType
	 *            : type of cpu is integer 0, 1 or 2
	 * @return throw out of bound exception if length of byte array is odd
	 * 
	 */
	private static String getStringUnicode(final byte[] byteArray,
			final int cpuType) {
		if (byteArray == null) {
			return "";
		}

		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < byteArray.length; i = i + 2) {
			stringBuffer.append(getCharUnicode(byteArray, i, i + 1, cpuType));
		}
		return stringBuffer.toString();
	}

	/**
	 * Gets the unsigned one.
	 * 
	 * @param byteArray
	 *            the byte array has one byte
	 * @param cpuType
	 *            the cpu type
	 * @return the short, if range of byte not equal one throw out of bound
	 *         exception
	 */
	private static short getUnsignedOne(final byte[] byteArray,
			final int cpuType) {
		return (short) getLong(byteArray, 0, 0, cpuType);
	}

	/**
	 * Gets the unsigned short.
	 * 
	 * @param byteArray
	 *            the byte array has two byte
	 * @param cpuType
	 *            the cPU type
	 * @return the integer, if range of byte not equal short range throw out of
	 *         bound exception
	 */
	private static int getUnsignedShort(final byte[] byteArray,
			final int cpuType) {
		return (int) getLong(byteArray, 0, 1, cpuType);
	}

	/**
	 * Gets the unsigned integer.
	 * 
	 * @param byteArray
	 *            the byte array has four byte
	 * @param cpuType
	 *            the cPU type
	 * @return the long, if range of byte not equal integer range throw out of
	 *         bound exception
	 */
	private static long getUnsignedInteger(final byte[] byteArray,
			final int cpuType) {
		return getLong(byteArray, 0, BYTE_INTEGER_LENGTH - 1, cpuType);
	}

	/**
	 * Gets the float with cpu_type.
	 * 
	 * @param byteArray
	 *            the byte array has four byte
	 * @param cpuType
	 *            the cPU_type
	 * @return the float it depend on Cpu_type to get result
	 */
	private static float getFloatWithcpuType(byte[] byteArray, final int cpuType) {

		float result = 0;
		if (cpuType == CPU_TYPE_SUN_1) {
			result = getFloatBigEndian(byteArray);
		} else if (cpuType == CPU_TYPE_IBM_2) {
			result = getFloatLittleEndian(byteArray);
		} else if (cpuType == CPU_TYPE_VAX_0) {
			swapVAXByte(byteArray);
			result = getFloatVAX(byteArray, VAX_MANTISA_FLOAT_BYTE_ARRAY);
		}
		return result;
	}

	/**
	 * Gets the double with cpu_type.
	 * 
	 * @param byteArray
	 *            the byte array has eight byte
	 * @param cpuType
	 *            the cPU type
	 * @return the double, the result depend on the cpu_type throw out of bound
	 *         exception if byte array is null or cpuType does not exist
	 */
	private static double getDoubleWithcpuType(byte[] byteArray,
			final int cpuType) {

		double result = 0;
		if (cpuType == CPU_TYPE_SUN_1) {
			result = getDoubleBigEndian(byteArray);
		} else if (cpuType == CPU_TYPE_IBM_2) {
			result = getDoubleLittleEndian(byteArray);
		} else if (cpuType == CPU_TYPE_VAX_0) {
			swapVAXByte(byteArray);
			result = getFloatVAX(byteArray, VAX_MANTISA_DOUBLE_BYTE_ARRAY);
		}
		return result;
	}

	/**
	 * Gets the char.
	 * 
	 * @param byteArray
	 *            the byte array has two byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the char, get char from array byte, start in start and end with
	 *         end
	 */
	public static char getCharUnicode(final byte[] byteArray, final int start,
			final int end, final int cpuType) {

		byte[] byteActual = copyByte(byteArray, start, end);
		char result = getCharUnicode(byteActual, cpuType);
		return result;
	}

	/**
	 * get char in byte array.
	 * 
	 * @param byteArray
	 *            : byte array source
	 * @param position
	 *            : position of byte in byte array will return
	 * @return ASCII character
	 */
	public static char getCharAscii(final byte[] byteArray, final int position) {
		return getCharAscii(byteArray[position]);
	}

	/**
	 * get unicode string from byte array.
	 * 
	 * @param byteArray
	 *            byte array
	 * @param start
	 *            start point in byte array
	 * @param end
	 *            end point in byte array
	 * @param cpuType
	 *            type of cpu
	 * @return unicode string
	 */
	public static String getStringUnicode(final byte[] byteArray,
			final int start, final int end, final int cpuType) {
		byte[] byteArrayActual = copyByte(byteArray, start, end);
		String result = getStringUnicode(byteArrayActual, cpuType);
		return result;
	}

	/**
	 * Gets the unsigned one.
	 * 
	 * @param byteArray
	 *            the byte array has one byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the short, throw out of bound exception if end point not equal
	 *         start point
	 */
	public static short getUnsignedOne(final byte[] byteArray, final int start,
			final int end, final int cpuType) {

		byte[] byteArrayActual = copyByte(byteArray, start, end);
		short result = getUnsignedOne(byteArrayActual, cpuType);
		return result;
	}

	/**
	 * Gets the unsigned short.
	 * 
	 * @param byteArray
	 *            the byte array has two byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the integer, throw out of bound exception if number of byte is
	 *         less than short range
	 */
	public static int getUnsignedShort(final byte[] byteArray, final int start,
			final int end, final int cpuType) {

		byte[] byteArrayActual = copyByte(byteArray, start, end);
		int result = getUnsignedShort(byteArrayActual, cpuType);
		return result;
	}

	/**
	 * Gets the unsigned integer.
	 * 
	 * @param byteArray
	 *            the byte array has four byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the long, throw out of bound exception if number of byte source
	 *         is less than number of byte in integer
	 */
	public static long getUnsignedInteger(final byte[] byteArray,
			final int start, final int end, final int cpuType) {

		byte[] byteArrayActual = copyByte(byteArray, start, end);
		long result = getUnsignedInteger(byteArrayActual, cpuType);
		return result;
	}

	/**
	 * Gets the float with cpu_type.
	 * 
	 * @param byteArray
	 *            the byte array has four byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the float
	 */
	public static float getFloatWithcpuType(final byte[] byteArray,
			final int start, final int end, final int cpuType) {

		byte[] byteArrayActual = copyByte(byteArray, start, end);
		float result = getFloatWithcpuType(byteArrayActual, cpuType);
		return result;
	}

	/**
	 * Gets the double with cpu_type. it get double from array byte, and it get
	 * from range start and end
	 * 
	 * @param byteArray
	 *            the byte array has eight byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the double
	 */
	public static double getDoubleWithcpuType(final byte[] byteArray,
			final int start, final int end, final int cpuType) {

		byte[] byteArrayActual = copyByte(byteArray, start, end);
		double result = getDoubleWithcpuType(byteArrayActual, cpuType);
		return result;
	}

	/**
	 * get type short from array byte.
	 * 
	 * @param byteArray
	 *            : array of byte input, it must be contain more than 2
	 * @param start
	 *            : start point in byte array to get short
	 * @param end
	 *            : end point in byte array to get short
	 * @param cpuType
	 *            integer is type of CPU include BigEndian or LittleEndian or
	 *            DEC PDP-11 and VAX processors.
	 * @return short
	 */
	public static short getShort(byte[] byteArray, final int start,
			final int end, final int cpuType) {
		short result = 0;
		if (start > end) {
			return 0;
		}
		byte[] realByte = copyByte(byteArray, start, end);

		if (cpuType == CPU_TYPE_SUN_1) {
			int j = end - start;
			int maxi = end - start + 1;
			for (int i = 0; i < maxi; i++, j--) {
				result += (short) (byte2Short(realByte[i]) << (BYTE_LENGTH * j));
			}
			return result;
		} else {
			if (cpuType == CPU_TYPE_IBM_2 || cpuType == CPU_TYPE_VAX_0) {
				int j = 0;
				int maxi = end - start + 1;
				for (int i = 0; i < maxi; i++, j++) {
					result += (short) (byte2Short(realByte[i]) << (BYTE_LENGTH * j));
				}
				return result;
			}
		}
		return 0;

	}

	/**
	 * Gets the long.
	 * 
	 * @param byteArray
	 *            the byte array has eight byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the long
	 */
	public static long getLong(byte[] byteArray, final int start,
			final int end, final int cpuType) {
		long result = 0;
		if (start > end) {
			return 0;
		}
		byte[] realByte = copyByte(byteArray, start, end);
		if (cpuType == CPU_TYPE_SUN_1) {
			int j = end - start;
			int maxi = end - start + 1;
			for (int i = 0; i < maxi; i++, j--) {
				result += (long) (((long) byte2Short(realByte[i])) << (BYTE_LENGTH * j));
			}
			return result;
		} else {
			if (cpuType == CPU_TYPE_IBM_2 || cpuType == CPU_TYPE_VAX_0) {
				int j = 0;
				int maxi = end - start + 1;
				for (int i = 0; i < maxi; i++, j++) {
					result += (long) (((long) byte2Short(realByte[i])) << (BYTE_LENGTH * j));
				}
				return result;
			}
		}
		return 0;
	}

	/**
	 * Gets the integer.
	 * 
	 * @param byteArray
	 *            the byte array has four byte
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param cpuType
	 *            the cPU type
	 * @return the integer
	 */
	public static int getInteger(byte[] byteArray, int start, int end,
			int cpuType) {
		int result = 0;
		if (start > end) {
			return result;
		}

		byte[] realByte = copyByte(byteArray, start, end);
		if (cpuType == CPU_TYPE_SUN_1) {
			int j = end - start;
			int maxi = end - start + 1;
			for (int i = 0; i < maxi; i++, j--) {
				result += (int) (((int) byte2Short(realByte[i])) << (BYTE_LENGTH * j));
			}
		} else if (cpuType == CPU_TYPE_IBM_2 || cpuType == CPU_TYPE_VAX_0) {
			int j = 0;
			int maxi = end - start + 1;
			for (int i = 0; i < maxi; i++, j++) {
				result += (int) (((int) byte2Short(realByte[i])) << (BYTE_LENGTH * j));
			}
		}
		return result;
	}

	/**
	 * Gets the float vax.
	 * 
	 * @param byteArray
	 *            the byte
	 * @return the float, what get from byte array, order byte vax processor
	 *         throw out of bound exception if byte array length is not equal
	 *         Float length
	 */
	public static float getFloatVAX(byte[] byteArray, byte[] vaxForVaxD) {
		float result = 1;
		int firstByte0 = getValueOfFirstBit(byteArray[0]);
		if (firstByte0 == 1) {
			result *= -1;
		}

		short exponent = getValueOfNextBit(byteArray[0], firstByte0);
		exponent = (short) (exponent << 1);
		byteArray[0] = 0;

		int firstByte1 = getValueOfFirstBit(byteArray[1]);
		byteArray[1] = (byte) getValueOfNextBit(byteArray[1], firstByte1);
		float mantisa = getLong(byteArray, 0, byteArray.length - 1,
				CPU_TYPE_SUN_1);
		mantisa /= getLong(vaxForVaxD, 0, byteArray.length - 1, CPU_TYPE_SUN_1);
		exponent += firstByte1 - VAX_BASE;
		float absExponent = 1;
		if (exponent > -1) {
			absExponent = power(2, exponent);
		} else {
			absExponent = (float) inversePower(2, exponent * (-1));
		}
		result *= absExponent * (mantisa + VAX_MANTISA);
		return result;
	}

	/**
	 * convert from sign byte to unsign byte.
	 * 
	 * @param byteInput
	 *            byte is used to convert
	 * @return short number
	 */
	private static short byte2Short(final byte byteInput) {
		short result = (short) (byteInput & BYTE_0FF);
		return result;
	}
}
