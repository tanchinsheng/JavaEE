/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 29, 2011 5:00:46 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.io.File;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.compress.Compressors;
import com.st.scc.common.utils.ComparisonUtils;
import com.st.scc.common.utils.FileUtils;
import com.st.scc.common.utils.SFTPUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class SFTPFileAccess extends AbsFileAccess {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SFTPFileAccess.class);

  /** The session. */
  private Session session;

  /**
   * Instantiates a new SFTP file access.
   * 
   * @param fileInfo
   *          the file info
   */
  public SFTPFileAccess(final FileInfo fileInfo) {
    setSourceFile(fileInfo);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#checkAvailable()
   */
  public boolean checkAvailable() {
    boolean retVal = false;
    final FileInfo fileInfo = getSourceFile();
    if (fileInfo != null && session != null) {
      final ChannelSftp channel = SFTPUtils.openChannel(session);
      retVal = SFTPUtils.checkAvailable(fileInfo, channel);
      channel.disconnect();
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#delete()
   */
  public boolean delete() {
    boolean retVal = false;
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (channel != null) {
      retVal = SFTPUtils.deleteFile(channel, getSourceFile().getPathFileName());
      channel.disconnect();
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#disconnect()
   */
  public void disconnect() {
    SFTPUtils.disconnect(session);
    session = null;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#download(java.lang.String)
   */
  public File download(final String localFile) {
    File retVal = null;
    final FileInfo fileInfo = getSourceFile();
    if (fileInfo != null && session != null) {
      final ChannelSftp channel = SFTPUtils.openChannel(session);
      if (channel != null) {
        try {
          final File fileLocal = new File(localFile);
          FileUtils.createParentPath(fileLocal);
          channel.get(fileInfo.getPathFileName(), fileLocal.getAbsolutePath());
          retVal = fileLocal;
        } catch (final IOException e) {
          LOG.error(e.getMessage(), e);
        } catch (final SftpException e) {
          LOG.error(e.getMessage(), e);
        } finally {
          channel.disconnect();
        }
      }
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#exists()
   */
  public boolean exists() {
    boolean result = false;
    final FileInfo fileInfo = getSourceFile();
    if (fileInfo != null && session != null) {
      result = SFTPUtils.exists(fileInfo.getPathFileName(), session);
    }
    return result;
  }

  /**
   * Gets the session.
   * 
   * @return the session
   */
  public Session getSession() {
    return session;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#move(com.st.common.beans.FileInfo)
   */
  public boolean move(final FileInfo destFile) {
    boolean upload = false;
    if (destFile != null) {
      final FileTypeEnum destFileType = destFile.getFileType();
      if (destFileType != null) {
        switch (destFileType) {
        case NFS:
          upload = moveSFTPToNFS(getSourceFile(), destFile);
          break;
        case FTP:
          upload = moveSFTPToFTP(getSourceFile(), destFile);
          break;
        case SFTP:
          upload = moveSFTPToSFTP(getSourceFile(), destFile);
          break;

        default:
          // do nothing
          break;
        }
      }
    }
    return upload;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#moveCompress(com.st.common.beans.FileInfo)
   */
  public boolean moveCompress(final FileInfo destFile) {
    boolean upload = false;
    final FileInfo source = getSourceFile();
    if (source != null && source.getPathFileName() != null
        && source.getPathFileName().endsWith(".Z")) {
      upload = move(destFile);
    } else if (destFile != null) {
      final FileTypeEnum destFileType = destFile.getFileType();
      if (destFileType != null) {
        switch (destFileType) {
        case FTP:
          upload = moveCompressSFTPToFTP(getSourceFile(), destFile);
          break;
        case NFS:
          upload = moveCompressSFTPToNFS(getSourceFile(), destFile);
          break;
        case SFTP:
          upload = moveCompressSFTPToSFTP(getSourceFile(), destFile);
          break;
        }

      }

    }

    return upload;
  }

  /**
   * Move compress SFTP to FTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveCompressSFTPToFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null && destFile != null) {
      final FileInfo file = copyFileToDir(srcFile);
      retVal = moveSFTPToNFS(srcFile, file, false);
      if (retVal) {
        final String source = file.getPathFileName();
        final String dest = file.getPathFileName() + ".Z";
        retVal = Compressors.compressZ(source, dest, true);
        if (retVal) {
          file.setPathFileName(dest);
          file.setPathRootToFile(file.getPathRootToFile() + ".Z");
          retVal = moveNFSToFTP(file, destFile);
        }
      }
      if (retVal) {
        final ChannelSftp channel = SFTPUtils.openChannel(session);
        retVal = SFTPUtils.deleteFile(channel, srcFile.getPathFileName());
        if (channel != null) {
          channel.disconnect();
        }
      }
    }
    return retVal;
  }

  /**
   * Move compress SFTP to NFS.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveCompressSFTPToNFS(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (srcFile != null && destFile != null && channel != null) {
      String temp = "";
      try {
        if (!destFile.getPathRoot().endsWith("/")) {
          temp = destFile.getPathRoot() + "/" + srcFile.getPathRootToFile();
        } else {
          temp = destFile.getPathRoot() + srcFile.getPathRootToFile();
        }
        destFile.setPathRootToFile(srcFile.getPathRootToFile());
        destFile.setPathFileName(temp);
        final File fileDest = new File(temp);
        if (!fileDest.getParentFile().exists()) {
          fileDest.getParentFile().mkdirs();
        }
        if (SFTPUtils.download(channel, srcFile.getPathFileName(), fileDest.getPath())) {
          if (LOG.isDebugEnabled()) {
            LOG.debug("Download file {} to local successfully", srcFile.getPathFileName());
          }
          if (Compressors.compressZ(temp, true)) {
            channel.rm(srcFile.getPathFileName());
            retVal = true;
          }
        } else {
          final StringBuilder sb = new StringBuilder();
          sb.append("download SFTP to Local is fail ");
          sb.append("file source = ").append(srcFile.getPathFileName());
          sb.append(" file dest").append(fileDest.getPath());
          LOG.warn(sb.toString());
        }
      } catch (final SftpException e) {
        final StringBuilder str = new StringBuilder();
        str.append("download file from SFTP to local source = ");
        str.append(srcFile.getPathFileName());
        str.append("; dest = ").append(destFile.getPathFileName());
        str.append(" error ").append(e.getMessage());
        LOG.error(str.toString(), e);
      } finally {
        if (channel != null) {
          channel.disconnect();
        }
      }
    }
    return retVal;
  }

  /**
   * Move compress SFTP to SFTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveCompressSFTPToSFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null && destFile != null) {
      final FileInfo file = copyFileToDir(srcFile);
      retVal = moveSFTPToNFS(srcFile, file, false);
      if (retVal) {
        final String source = file.getPathFileName();
        final String dest = file.getPathFileName() + ".Z";
        retVal = Compressors.compressZ(source, dest, true);
        if (retVal) {
          file.setPathRootToFile(file.getPathRootToFile() + ".Z");
          file.setPathFileName(file.getPathFileName() + ".Z");
          retVal = moveNFSToSFTP(file, destFile);
        }
      }
      if (retVal) {
        final ChannelSftp channel = SFTPUtils.openChannel(session);
        retVal = SFTPUtils.deleteFile(channel, srcFile.getPathFileName());
        if (channel != null) {
          channel.disconnect();
        }
      }
    }
    return retVal;
  }

  /**
   * Move different SFTP servers.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveDifferentSFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null && destFile != null) {
      final FileInfo file = copyFileToDir(srcFile);
      retVal = moveSFTPToNFS(srcFile, file, false);
      if (retVal) {
        retVal = moveNFSToSFTP(file, destFile);
      }
      if (retVal) {
        final ChannelSftp channel = SFTPUtils.openChannel(session);
        retVal = SFTPUtils.deleteFile(channel, srcFile.getPathFileName());
        if (channel != null) {
          channel.disconnect();
        }
      }
      final File tmpFile = new File(file.getPathFileName());
      if (tmpFile.exists()) {
        tmpFile.delete();
      }
    }
    return retVal;
  }

  /**
   * Move in the same SFTP server.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveSameSFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean success = false;
    if (srcFile != null && destFile != null) {
      final String dest = destFile.getPathRoot();
      final ChannelSftp channel = SFTPUtils.openChannel(session);
      try {
        String newPath = "";
        if (dest.endsWith("/")) {
          newPath = dest + srcFile.getPathRootToFile();
        } else {
          newPath = dest + "/" + srcFile.getPathRootToFile();
        }
        if (channel != null) {
          if (!SFTPUtils.createPath(channel, newPath, false)) {
            SFTPUtils.createFolder(channel, newPath);
          }
          try {
            if (SFTPUtils.exists(newPath, channel)) {
              SFTPUtils.deleteFile(channel, newPath);
            }
          } finally {
            if (SFTPUtils.moveFileOnSFTP(channel, srcFile.getPathFileName(), newPath)) {
              LOG.info("Move file SFTP from {} to {} successfully", srcFile.getPathFileName(),
                  newPath);
              success = true;
            } else {
              LOG.warn("Move file SFTP from {} to {} is failed", srcFile.getPathFileName(),
                  newPath);
            }
          }
        }
      } catch (final Exception e) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Move file from SFTP to SFTP source = ").append(srcFile.getPathFileName());
        sb.append("; dest = ").append(destFile.getPathFileName()).append(" is failed");
        LOG.error(sb.toString(), e);
      } finally {
        if (channel != null) {
          channel.disconnect();
        }
      }
    }
    return success;
  }

  /**
   * Move SFTP to FTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveSFTPToFTP(final FileInfo srcFile, final FileInfo destFile) {
    boolean retVal = false;
    if (srcFile != null && destFile != null) {
      final FileInfo file = copyFileToDir(srcFile);
      retVal = moveSFTPToNFS(srcFile, file, false);
      if (retVal) {
        retVal = moveNFSToFTP(file, destFile);
      }
      if (retVal) {
        final ChannelSftp channel = SFTPUtils.openChannel(session);
        retVal = SFTPUtils.deleteFile(channel, srcFile.getPathFileName());
        if (channel != null) {
          channel.disconnect();
        }
      }
      final File tmpFile = new File(file.getPathFileName());
      if (tmpFile.exists()) {
        tmpFile.delete();
      }
    }
    return retVal;
  }

  /**
   * Move SFTP to NFS.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveSFTPToNFS(final FileInfo srcFile, final FileInfo destFile) {
    return moveSFTPToNFS(srcFile, destFile, true);
  }

  /**
   * Move SFTP to NFS.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @param delete
   *          the delete
   * @return true, if successful
   */
  private boolean moveSFTPToNFS(final FileInfo srcFile, final FileInfo destFile,
      final boolean delete) {
    boolean retVal = false;
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (srcFile != null && destFile != null && channel != null) {
      String temp = "";
      try {
        if (!destFile.getPathRoot().endsWith("/")) {
          temp = destFile.getPathRoot() + "/" + srcFile.getPathRootToFile();
        } else {
          temp = destFile.getPathRoot() + srcFile.getPathRootToFile();
        }
        destFile.setPathRootToFile(srcFile.getPathRootToFile());
        destFile.setPathFileName(temp);
        final File fileDest = new File(temp);
        if (!fileDest.getParentFile().exists()) {
          fileDest.getParentFile().mkdirs();
        }
        if (SFTPUtils.download(channel, srcFile.getPathFileName(), fileDest.getPath())) {
          if (LOG.isDebugEnabled()) {
            LOG.debug("Download file {} to local successfully", srcFile.getPathFileName());
          }
          if (delete) {
            channel.rm(srcFile.getPathFileName());
          }
          retVal = true;
        } else {
          final StringBuilder sb = new StringBuilder();
          sb.append("download SFTP to Local is fail ");
          sb.append("file source = ").append(srcFile.getPathFileName());
          sb.append(" file dest").append(fileDest.getPath());
          LOG.warn(sb.toString());
        }
      } catch (final SftpException e) {
        final StringBuilder str = new StringBuilder();
        str.append("download file from SFTP to local source = ");
        str.append(srcFile.getPathFileName());
        str.append("; dest = ").append(destFile.getPathFileName());
        str.append(" error ").append(e.getMessage());
        LOG.error(str.toString(), e);
      } finally {
        if (channel != null) {
          channel.disconnect();
        }
      }
    }
    return retVal;
  }

  /**
   * Move SFTP to SFTP.
   * 
   * @param srcFile
   *          the source file
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  private boolean moveSFTPToSFTP(final FileInfo srcFile, final FileInfo destFile) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("move file from SFTP to SFTP");
    }
    boolean retVal = false;
    if (ComparisonUtils.compareSameServer(srcFile, destFile)) {
      retVal = moveSameSFTP(srcFile, destFile);
    } else {
      retVal = moveDifferentSFTP(srcFile, destFile);
    }
    return retVal;
  }

  /**
   * Sets the session.
   * 
   * @param session
   *          the new session
   */
  public void setSession(final Session session) {
    this.session = session;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#upload(java.lang.String)
   */
  public boolean upload(final String localFile) {
    boolean retVal = false;
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (channel != null) {
      retVal = SFTPUtils.upload(channel, localFile, getSourceFile().getPathFileName());
      channel.disconnect();
    }
    return retVal;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.SccFileAccess#upload(java.lang.String,
   *      java.lang.String)
   */
  public boolean upload(final String localFile, final String destFile) {
    boolean retVal = false;
    final ChannelSftp channel = SFTPUtils.openChannel(session);
    if (channel != null) {
      final String dest = getSourceFile().getPathRoot();
      String newPath = "";
      if (dest.endsWith("/")) {
        newPath = dest + destFile;
      } else {
        newPath = dest + "/" + destFile;
      }
      retVal = SFTPUtils.upload(channel, localFile, newPath);
      channel.disconnect();
    }
    return retVal;
  }
}
