/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 28, 2011 4:51:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.filedetector.impl;

import java.io.File;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.filedetector.FileDetector;
import com.st.common.filedetector.FileFormatEnum;

/**
 * This class will detect file type base on file name.
 * 
 * @author duylt
 */
public class SimpleFileDetector implements FileDetector {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SimpleFileDetector.class);

  /** The Constant MAP_FILE_TYPE. */
  private static final Map<String, FileFormatEnum> MAP_FILE_TYPE =
      new HashMap<String, FileFormatEnum>();

  static {
    MAP_FILE_TYPE.put("STDF", FileFormatEnum.STDF_V4_BIG_ENDIAN);
    MAP_FILE_TYPE.put("ATDF", FileFormatEnum.ATDF_BIG_ENDIAN);
    MAP_FILE_TYPE.put("ZIP", FileFormatEnum.ZIP);
    MAP_FILE_TYPE.put("GZIP", FileFormatEnum.GZIP);
    MAP_FILE_TYPE.put("GZ", FileFormatEnum.GZIP);
    MAP_FILE_TYPE.put("TGZ", FileFormatEnum.GZIP);
    MAP_FILE_TYPE.put("BZ2", FileFormatEnum.BZ2);
    MAP_FILE_TYPE.put("TBZ2", FileFormatEnum.BZ2);
    MAP_FILE_TYPE.put("TB2", FileFormatEnum.BZ2);
    MAP_FILE_TYPE.put("TAR", FileFormatEnum.TAR);
    MAP_FILE_TYPE.put("Z", FileFormatEnum.Z);
  }

  /**
   * Use to get file extension in file name.
   * 
   * @param file
   *          the file
   * @return the file extension name
   */
  private String getFileExtensionName(final File file) {
    final String fileName = file.getName();
    return getFileExtensionName(fileName);
  }

  /**
   * Use to get file extension in file name.
   * 
   * @param fileName
   *          the file name
   * @return the file extension name
   */
  private String getFileExtensionName(final String fileName) {
    String res = "";
    final int lastIndex = fileName.lastIndexOf(".");
    if (lastIndex != -1) {
      res = fileName.substring(lastIndex + 1, fileName.length());
    }
    return res;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(byte[])
   */
  public FileFormatEnum getFileType(final byte[] byteBuf) {
    LOG.warn("Cannot get file type because unsupport method");
    // TODO Auto-generated method stub
    return FileFormatEnum.UNKNOWN;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(java.io.File)
   */
  public FileFormatEnum getFileType(final File file) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Get file type for file : " + file != null ? file.getName() : "");
    }
    final String fileExt = getFileExtensionName(file).toUpperCase();
    if (MAP_FILE_TYPE.containsKey(fileExt)) {
      return MAP_FILE_TYPE.get(fileExt);
    } else {
      return FileFormatEnum.UNKNOWN;
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(java.io.PushbackInputStream)
   */
  public FileFormatEnum getFileType(final PushbackInputStream file) {
    LOG.warn("Cannot get file type because unsupport method");
    // TODO Auto-generated method stub
    return FileFormatEnum.UNKNOWN;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(java.lang.String)
   */
  public FileFormatEnum getFileType(final String fileName) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Get file type for file : " + fileName);
    }
    final String fileExt = getFileExtensionName(fileName).toUpperCase();
    if (MAP_FILE_TYPE.containsKey(fileExt)) {
      return MAP_FILE_TYPE.get(fileExt);
    } else {
      return FileFormatEnum.UNKNOWN;
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileTypeFromCpuType(java.io.File)
   */
  public FileFormatEnum getFileTypeFromCpuType(final File file) {
    LOG.warn("Cannot get file type because unsupport method");
    // TODO Auto-generated method stub
    return FileFormatEnum.UNKNOWN;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileTypeFromOtherStream(java.io.InputStream)
   */
  public FileFormatEnum getFileTypeFromOtherStream(final InputStream inputStream) {
    LOG.warn("Cannot get file type because unsupport method");
    // TODO Auto-generated method stub
    return FileFormatEnum.UNKNOWN;
  }

}
