/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is private by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 15, 2011 4:26:49 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common.exception;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class LDAPConnectException extends SccException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8776587954703633308L;

	/**
	 * Instantiates a new LDAP connect exception.
	 */
	public LDAPConnectException() {
	}

	/**
	 * Instantiates a new LDAP Authentication exception.
	 * 
	 * @param message
	 *            the message
	 */
	public LDAPConnectException(final String message) {
		super(message);
	}

	/**
	 * Instantiates a new LDAP Authentication exception.
	 * 
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public LDAPConnectException(final String message,
			final Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new LDAP Authentication exception.
	 * 
	 * @param cause
	 *            the cause
	 */
	public LDAPConnectException(final Throwable cause) {
		super(cause);
	}
}
