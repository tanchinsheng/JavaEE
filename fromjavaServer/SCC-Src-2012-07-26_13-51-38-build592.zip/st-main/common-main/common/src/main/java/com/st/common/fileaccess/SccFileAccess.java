/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 28, 2011 11:05:06 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess;

import java.io.File;

import com.st.common.beans.FileInfo;

/**
 * The Interface SccFileAccess.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public interface SccFileAccess {

  /**
   * Check this file if it is available for processing.
   * 
   * @return true, if the file is ready to access
   */
  boolean checkAvailable();

  /**
   * Delete the current file.
   * 
   * @return true, if successful
   */
  boolean delete();

  /**
   * Disconnect from file server.
   */
  void disconnect();

  /**
   * Download file to local file.
   * 
   * @param localFile
   *          the local file
   * @return the file
   */
  File download(String localFile);

  /**
   * Check this file exists or not.
   * 
   * @return true, if the file exists
   */
  boolean exists();

  /**
   * Gets the source file.
   * 
   * @return the source file
   */
  FileInfo getSourceFile();

  /**
   * Move the current file to destination file.
   * 
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  boolean move(FileInfo destFile);

  /**
   * Move the current file to destination file and compress destination file.
   * 
   * @param destFile
   *          the destination file
   * @return true, if successful
   */
  boolean moveCompress(FileInfo destFile);

  /**
   * Sets the source file.
   * 
   * @param srcFile
   *          the new source file
   */
  void setSourceFile(FileInfo srcFile);

  /**
   * Upload the local file to current file information.
   * 
   * @param localFile
   *          the local file
   * @return true, if successful
   */
  boolean upload(String localFile);

  /**
   * Upload the local file to target path of root folder.
   * 
   * @param localFile
   *          the local file
   * @param destFile
   *          the target path
   * @return true, if successful
   */
  boolean upload(String localFile, String destFile);
}
