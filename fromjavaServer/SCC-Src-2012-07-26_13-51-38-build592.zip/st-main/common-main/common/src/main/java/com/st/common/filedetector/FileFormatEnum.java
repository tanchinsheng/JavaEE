/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 28, 2011 4:51:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.filedetector;

/**
 * Enum for all support file types.
 * 
 * @author trungtb
 */
public enum FileFormatEnum {

  /** The STDF_BIG_EDIAN. */
  STDF_V4_BIG_ENDIAN,
  /** The STDF_V4_LITTLE_ENDIAN_0. */
  STDF_V4_LITTLE_ENDIAN_0,
  /** The STDF_V4_LITTLE_ENDIAN_2. */
  STDF_V4_LITTLE_ENDIAN_2,
  /** The ATDF_BIG_EDIANTDF. */
  ATDF_BIG_ENDIAN,
  /** The ATDF_LITTLE_EDIAN. */
  ATDF_LITTLE_ENDIAN,
  /** The GZIP. */
  GZIP,
  /** The B z2. */
  BZ2,
  /** The TAR. */
  TAR,
  /** The ZIP. */
  ZIP,
  /** The Z. */
  Z,
  /** The UNKNOWN. */
  UNKNOWN;

  /**
   * Checks if is big endian.
   * 
   * @param fileType
   *          the file type
   * @return true, if is big endian
   */
  public static boolean isBigEndian(final FileFormatEnum fileType) {
    return fileType == ATDF_BIG_ENDIAN || fileType == STDF_V4_BIG_ENDIAN;
  }

  /**
   * Checks if is little endian.
   * 
   * @param fileType
   *          the file type
   * @return true, if is little endian
   */
  public static boolean isLittleEndian(final FileFormatEnum fileType) {
    return fileType == ATDF_LITTLE_ENDIAN || fileType == STDF_V4_LITTLE_ENDIAN_0
        || fileType == STDF_V4_LITTLE_ENDIAN_2;
  }
}
