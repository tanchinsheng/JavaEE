/*
 * @(#)UncompressInputStream.java           0.3-2 18/06/1999
 *
 *  This file is part of the HTTPClient package
 *  Copyright (C) 1996-1999  Ronald Tschalr
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free
 *  Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA 02111-1307, USA
 *
 *  For questions, suggestions, bug-reports, enhancement-requests etc.
 *  I may be contacted at:
 *
 *  ronald@innovation.ch
 *
 */

package com.st.common.compress;

import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class decompresses an input stream containing data compressed with the unix "compress" utility (LZC, a LZW
 * variant). This code is based heavily on the <var>unlzw.c</var> code in <var>gzip-1.2.4</var> (written by Peter
 * Jannesen) and the original compress code.
 * 
 * @version 0.3-2 18/06/1999
 * @author Ronald Tschalr
 */
public class UncompressInputStream extends FilterInputStream {
    private static final Logger LOG = LoggerFactory
            .getLogger(UncompressInputStream.class);
    private static final int LZW_MAGIC = 0x1f9d;
    private static final int MAX_BITS = 16;
    private static final int INIT_BITS = 9;
    private static final int HDR_MAXBITS = 0x1f;
    private static final int HDR_EXTENDED = 0x20;
    private static final int HDR_FREE = 0x40;
    private static final int HDR_BLOCK_MODE = 0x80;
    private static final boolean DEBUG = false;
    private final byte[] one = new byte[1];
    // string table stuff
    private static final int TBL_CLEAR = 0x100;
    private static final int TBL_FIRST = TBL_CLEAR + 1;

    private int[] tabPrefix;
    private byte[] tabSuffix;
    private final int[] zeros = new int[256];
    private byte[] stack;

    // various state
    private boolean blockMode;
    private int nBits;
    private int maxbits;
    private int maxMaxCode;
    private int maxCode;
    private int bitMask;
    private int oldCode;
    private byte finChar;
    private int stackp;
    private int freeEnt;

    // input buffer
    private final byte[] data = new byte[10000];
    // set default bitPos = 0;
    private int bitPos;
    // set default end = 0;
    private int end;
    // set default got = 0;
    private int got;
    // set default eof = false
    private boolean eof;
    private static final int EXTRA = 64;


    /**
     * @param is
     *            the input stream to decompress
     * @exception IOException
     *                if the header is malformed
     */
    public UncompressInputStream(final InputStream is) throws IOException {
        super(is);
        parseHeader();
    }

    @Override
    public synchronized int available() throws IOException {
        if (eof) {
            return 0;
        }

        return in.available();
    }

    private void fill() throws IOException {
        got = in.read(data, end, data.length - 1 - end);
        if (got > 0) {
            end += got;
        }
    }

    private void parseHeader() throws IOException {
        // read in and check magic number

        int t = in.read();
        if (t < 0) {
            throw new EOFException("Failed to read magic number");
        }
        int magic = (t & 0xff) << 8;
        t = in.read();
        if (t < 0) {
            throw new EOFException("Failed to read magic number");
        }
        magic += t & 0xff;
        if (magic != LZW_MAGIC) {
            throw new IOException("Input not in compress format (read "
                    + "magic number 0x" + Integer.toHexString(magic) + ")");
        }

        // read in header byte

        final int header = in.read();
        if (header < 0) {
            throw new EOFException("Failed to read header");
        }

        blockMode = (header & HDR_BLOCK_MODE) > 0;
        maxbits = header & HDR_MAXBITS;

        if (maxbits > MAX_BITS) {
            throw new IOException("Stream compressed with " + maxbits
                    + " bits, but can only handle " + MAX_BITS + " bits");
        }

        if ((header & HDR_EXTENDED) > 0) {
            throw new IOException("Header extension bit set");
        }

        if ((header & HDR_FREE) > 0) {
            throw new IOException("Header bit 6 set");
        }

        if (DEBUG) {
            LOG.error("block mode :", blockMode);
            LOG.error("max bits:   " + maxbits);
        }

        // initialize stuff

        maxMaxCode = 1 << maxbits;
        nBits = INIT_BITS;
        maxCode = (1 << nBits) - 1;
        bitMask = maxCode;
        oldCode = -1;
        finChar = 0;
        freeEnt = blockMode ? TBL_FIRST : 256;

        tabPrefix = new int[1 << maxbits];
        tabSuffix = new byte[1 << maxbits];
        stack = new byte[1 << maxbits];
        stackp = stack.length;

        for (int idx = 255; idx >= 0; idx--) {
            tabSuffix[idx] = (byte) idx;
        }
    }

    @Override
    public synchronized int read() throws IOException {
        final int b = in.read(one, 0, 1);
        if (b == 1) {
            return one[0] & 0xff;
        } else {
            return -1;
        }
    }

    @Override
    public synchronized int read(final byte[] buf, int off, int len)
            throws IOException {
        if (eof) {
            return -1;
        }
        final int start = off;

        /*
         * Using local copies of various variables speeds things up by as much as 30% !
         */
        final int[] lTabPrefix = tabPrefix;
        final byte[] lTabSuffix = tabSuffix;
        final byte[] lStack = stack;
        int lnBits = nBits;
        int lMaxCode = maxCode;
        final int lMaxMaxCode = maxMaxCode;
        int lBitMask = bitMask;
        int lOldCode = oldCode;
        byte lFinChar = finChar;
        int lStackp = stackp;
        int lFreeEnt = freeEnt;
        final byte[] lData = data;
        int lBitPos = bitPos;

        // empty stack if stuff still left

        int sSize = lStack.length - lStackp;
        if (sSize > 0) {
            final int num = sSize >= len ? len : sSize;
            System.arraycopy(lStack, lStackp, buf, off, num);
            off += num;
            len -= num;
            lStackp += num;
        }

        if (len == 0) {
            stackp = lStackp;
            return off - start;
        }

        // loop, filling local buffer until enough data has been decompressed

        main_loop: do {
            if (end < EXTRA) {
                fill();
            }

            final int bitIn = got > 0 ? end - end % lnBits << 3 : (end << 3)
                    - (lnBits - 1);

            while (lBitPos < bitIn) {
                // check for code-width expansion
                if (lFreeEnt > lMaxCode) {
                    final int nBytes = lnBits << 3;
                    lBitPos = lBitPos - 1 + nBytes - (lBitPos - 1 + nBytes)
                            % nBytes;

                    lnBits++;
                    lMaxCode = lnBits == maxbits ? lMaxMaxCode
                            : (1 << lnBits) - 1;

                    if (DEBUG) {
                        System.err.println("Code-width expanded to " + lnBits);
                    }

                    lBitMask = (1 << lnBits) - 1;
                    lBitPos = resetbuf(lBitPos);
                    continue main_loop;
                }

                // read next code

                final int pos = lBitPos >> 3;
                int code = (lData[pos] & 0xFF | (lData[pos + 1] & 0xFF) << 8 | (lData[pos + 2] & 0xFF) << 16) >> (lBitPos & 0x7)
                        & lBitMask;
                lBitPos += lnBits;

                // handle first iteration

                if (lOldCode == -1) {
                    if (code >= 256) {
                        throw new IOException("corrupt input: " + code
                                + " > 255");
                    }
                    lOldCode = code;
                    lFinChar = (byte) lOldCode;
                    buf[off++] = lFinChar;
                    len--;
                    continue;
                }

                // handle CLEAR code

                if (code == TBL_CLEAR && blockMode) {
                    System.arraycopy(zeros, 0, lTabPrefix, 0, zeros.length);
                    lFreeEnt = TBL_FIRST - 1;

                    final int nBytes = lnBits << 3;
                    lBitPos = lBitPos - 1 + nBytes - (lBitPos - 1 + nBytes)
                            % nBytes;
                    lnBits = INIT_BITS;
                    lMaxCode = (1 << lnBits) - 1;
                    lBitMask = lMaxCode;

                    if (DEBUG) {
                        System.err.println("Code tables reset");
                    }

                    lBitPos = resetbuf(lBitPos);
                    continue main_loop;
                }

                // setup

                final int incode = code;
                lStackp = lStack.length;

                // Handle KwK case

                if (code >= lFreeEnt) {
                    if (code > lFreeEnt) {
                        throw new IOException("corrupt input: code=" + code
                                + ", free_ent=" + lFreeEnt);
                    }
                    lStack[--lStackp] = lFinChar;
                    code = lOldCode;
                }

                // Generate output characters in reverse order

                while (code >= 256) {
                    lStack[--lStackp] = lTabSuffix[code];
                    code = lTabPrefix[code];
                }
                lFinChar = lTabSuffix[code];
                buf[off++] = lFinChar;
                len--;

                // And put them out in forward order

                sSize = lStack.length - lStackp;
                final int num = sSize >= len ? len : sSize;
                System.arraycopy(lStack, lStackp, buf, off, num);
                off += num;
                len -= num;
                lStackp += num;

                // generate new entry in table

                if (lFreeEnt < lMaxMaxCode) {
                    lTabPrefix[lFreeEnt] = lOldCode;
                    lTabSuffix[lFreeEnt] = lFinChar;
                    lFreeEnt++;
                }

                // Remember previous code

                lOldCode = incode;

                // if output buffer full, then return

                if (len == 0) {
                    nBits = lnBits;
                    maxCode = lMaxCode;
                    bitMask = lBitMask;
                    oldCode = lOldCode;
                    finChar = lFinChar;
                    stackp = lStackp;
                    freeEnt = lFreeEnt;
                    bitPos = lBitPos;

                    return off - start;
                }
            }
            lBitPos = resetbuf(lBitPos);
        } while (got > 0);

        nBits = lnBits;
        maxCode = lMaxCode;
        bitMask = lBitMask;
        oldCode = lOldCode;
        finChar = lFinChar;
        stackp = lStackp;
        freeEnt = lFreeEnt;
        bitPos = lBitPos;

        eof = true;
        return off - start;
    }

    /**
     * Moves the unread data in the buffer to the beginning and resets the pointers.
     */
    private int resetbuf(final int bitPos) {
        final int pos = bitPos >> 3;
        System.arraycopy(data, pos, data, 0, end - pos);
        end -= pos;
        return 0;
    }

    @Override
    public synchronized long skip(final long num) throws IOException {
        final byte[] tmp = new byte[(int) num];
        final int got = read(tmp, 0, (int) num);
        if (got > 0) {
            return got;
        } else {
            return 0L;
        }
    }
}
