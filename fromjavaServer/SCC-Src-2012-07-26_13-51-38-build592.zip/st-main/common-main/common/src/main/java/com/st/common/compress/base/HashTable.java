/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 11, 2011 10:32:35 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.common.compress.base;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class HashTable { // moved 4/15/98 dm/kmd
  /**
   * Use protected instead of private to allow access by parent class of inner
   * class. wnb 4/17/98
   */
  /** For dynamic table sizing. */
  private int[] tab;

  /**
   * Create tab. Constructor.
   */
  public HashTable() {
    tab = new int[Constant.HSIZE];
  }

  /**
   * Get tab[i].
   * 
   * @param i
   *          is element of tab.
   * @return value tab[i].
   */
  public int get(final int i) {
    return tab[i];
  }

  /**
   * Set tab[i] = v.
   * 
   * @param i
   *          is element of tab
   * @param v
   *          value set tab[i] = v.
   */
  public void set(final int i, final int v) {
    tab[i] = v;
  }

  /**
   * get size of tab.
   * 
   * @return size.
   */
  public int getSize() {
    return Constant.HSIZE;
  }

  /**
   * clear tab and assign tab[i] = -1.
   */
  public void clear() {
    int i;
    for (i = 0; i < Constant.HSIZE; i++) {
      tab[i] = -1;
    }
  }
}
