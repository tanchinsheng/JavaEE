/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 28, 2011 4:51:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.filedetector.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.filedetector.FileDetector;
import com.st.common.filedetector.FileDetectorFactory;
import com.st.common.filedetector.FileFormatEnum;
import com.st.common.filedetector.MagicNumberFileDetectorFormat;

/**
 * The Class MagicNumberFileDetector which use MAGIC number to detect file type.
 * Using this class will allow us to detect not only the file type but also the
 * byte order of Sftd and Atdf file
 */
public class MagicNumberFileDetector implements FileDetector {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(MagicNumberFileDetector.class);

  /** The Constant MAGIC_BYTES_MAX_NUMBER. */
  public static final int MAGIC_BYTES_MAX_NUMBER = 16;

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(byte[])
   */
  public FileFormatEnum getFileType(final byte[] byteBuf) {
    return MagicNumberFileDetectorFormat.getInstance().getFileType(byteBuf);
  }

  /**
   * Gets the file type.
   * 
   * @param byteBuf
   *          the byte buffer
   * @param start
   *          the start
   * @return the file type
   */
  private FileFormatEnum getFileType(final byte[] byteBuf, final int start) {
    return MagicNumberFileDetectorFormat.getInstance().getFileType(byteBuf, start);
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(java.io.File)
   */
  public FileFormatEnum getFileType(final File file) {
    final String fileName = file != null ? file.getName() : "";
    if (LOG.isDebugEnabled()) {
      LOG.debug("Get file type for file: " + fileName);
    }
    PushbackInputStream inputStream = null;
    try {
      inputStream = FileDetectorFactory.createPushbackInputStream(new FileInputStream(file));
      return getFileType(inputStream);
    } catch (final FileNotFoundException e) {
      LOG.error("Cannot detect file type", e);
      return FileFormatEnum.UNKNOWN;
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          LOG.error("Failed to stream for file: " + fileName, e);
        }
      }
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(java.io.PushbackInputStream)
   */
  public FileFormatEnum getFileType(final PushbackInputStream inPushBack) {
    LOG.debug("Get file type from stream");

    FileFormatEnum ret = FileFormatEnum.UNKNOWN;
    if (inPushBack == null) {
      return ret;
    }

    final byte[] buffer = new byte[MAGIC_BYTES_MAX_NUMBER];
    try {
      final int numOfRead = inPushBack.read(buffer, 0, MAGIC_BYTES_MAX_NUMBER);
      if (numOfRead == -1) {
        return FileFormatEnum.UNKNOWN;
      }
      ret = getFileType(buffer);
      inPushBack.unread(buffer, 0, numOfRead);
      // read and check file type only, should not close, caller will handle
      // inPushBack.close();
    } catch (final IOException e) {
      LOG.error("Cannot detect file type by using input stream", e);
    }
    return ret;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileType(java.lang.String)
   */
  public FileFormatEnum getFileType(final String fileName) {
    LOG.warn("Cannot get file type because un-supported method");
    // TODO Auto-generated method stub
    return FileFormatEnum.UNKNOWN;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileTypeFromCpuType(java.io.File)
   */
  public FileFormatEnum getFileTypeFromCpuType(final File file) {
    final String fileName = file != null ? file.getName() : "";
    if (LOG.isDebugEnabled()) {
      LOG.debug("Get file type for file: " + fileName);
    }
    InputStream inputStream = null;
    try {
      inputStream = new FileInputStream(file);
      return getFileTypeFromOtherStream(inputStream, 2);
    } catch (final FileNotFoundException e) {
      LOG.error("Cannot detect file type", e);
      return FileFormatEnum.UNKNOWN;
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (final IOException e) {
          LOG.error("Failed to stream for file: " + fileName, e);
        }
      }
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.filedetector.FileDetector#getFileTypeFromOtherStream(java.io.InputStream)
   */
  public FileFormatEnum getFileTypeFromOtherStream(final InputStream inputStream) {
    LOG.debug("Get file type from other stream");

    FileFormatEnum ret = FileFormatEnum.UNKNOWN;
    if (inputStream == null) {
      return ret;
    }

    final byte[] buffer = new byte[MAGIC_BYTES_MAX_NUMBER];
    try {
      inputStream.read(buffer, 0, MAGIC_BYTES_MAX_NUMBER);
      ret = getFileType(buffer);
      // read and check file type only, should not close, caller will handle
      // inPushBack.close();
    } catch (final IOException e) {
      LOG.error("Cannot detect file type by using input stream:", e);
    }
    return ret;
  }

  /**
   * Gets the file type from other stream.
   * 
   * @param inputStream
   *          the input stream
   * @param start
   *          the start
   * @return the file type from other stream
   */
  private FileFormatEnum getFileTypeFromOtherStream(final InputStream inputStream,
      final int start) {
    LOG.debug("Get file type from other stream");

    FileFormatEnum ret = FileFormatEnum.UNKNOWN;
    if (inputStream == null) {
      return ret;
    }

    final byte[] buffer = new byte[MAGIC_BYTES_MAX_NUMBER];
    try {
      inputStream.read(buffer, 0, MAGIC_BYTES_MAX_NUMBER);
      ret = getFileType(buffer, start);
      // read and check file type only, should not close, caller will handle
      // inPushBack.close();
    } catch (final IOException e) {
      LOG.error("Cannot detect file type by using input stream:", e);
    }
    return ret;
  }
}
