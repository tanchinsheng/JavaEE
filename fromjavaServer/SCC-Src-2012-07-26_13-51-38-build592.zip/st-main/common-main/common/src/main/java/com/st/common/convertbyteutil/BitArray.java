/******************************************************************************/
/*                              SCC Package                                   */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore     */
/* STMicroelectronics Ltd 2011.                                               */
/*                                                                            */
/* Warning: This computer program is protected by copyright law and           */
/* international treaties. Unauthorized reproduction or distribution          */
/* of this program, or any portion of it, may result in severe civil          */
/* and criminal penalties, and will be prosecuted of the maximum              */
/* extent possible under the law                                              */
/*                                                                            */
/******************************************************************************/
/*                                DESCRIPTION                                 */
/*                                                                            */
/* SCC package consists of 3 modules:                                         */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader*/
/*   Repair/Enrich with an Administrative Maintenance features                */
/* - 2nd module is the STDF Checker which perform STDF file checking base on  */
/*   user given rule and an Administrative Maintenance features               */
/* - 3rd module is the SCC Web-based application. SCC application is described*/
/*   as a tool to display after the wafer end, a general trend chart for wafer*/
/*   Yield, with some statically limit (average +/- sigma) and display some   */
/*   OCAP in case of OUT of control.                                          */
/******************************************************************************/
/*                                 HISTORY                                    */
//- 1.0.0 - Mar 30, 2011 04:22:56 PM - nguyensn - Initialize version
/******************************************************************************/
package com.st.common.convertbyteutil;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class BitArray {

	/** The sign. */
	private String sign;

	/** The exponent. */
	private String exponent;

	/** The significand. */
	private String significand;

	/**
	 * Instantiates a new bit array.
	 * 
	 * @param signed
	 *            the sign
	 * @param exponen
	 *            the exponent
	 * @param significan
	 *            the significand
	 */
	public BitArray(final char[] signed, final char[] exponen,
			final char[] significan) {
		this.sign = signed.toString();
		this.exponent = exponen.toString();
		this.significand = significan.toString();
	}

	/**
	 * Instantiates a new bit array.
	 * 
	 * @param signed
	 *            the sign
	 * @param exponen
	 *            the exponent
	 * @param significan
	 *            the significand
	 */
	public BitArray(final String signed, final String exponen,
			final String significan) {
		this.sign = signed;
		this.exponent = exponen;
		this.significand = significan;
	}

	/**
	 * Gets the sign.
	 * 
	 * @return the sign
	 */
	public final String getSign() {
		return sign;
	}

	/**
	 * Sets the sign.
	 * 
	 * @param signed
	 *            the new sign
	 */
	public final void setSign(final String signed) {
		this.sign = signed;
	}

	/**
	 * Gets the exponent.
	 * 
	 * @return the exponent
	 */
	public final String getExponent() {
		return exponent;
	}

	/**
	 * Sets the exponent.
	 * 
	 * @param exponen
	 *            the new exponent
	 */
	public final void setExponent(final String exponen) {
		this.exponent = exponen;
	}

	/**
	 * Gets the significand.
	 * 
	 * @return the significand
	 */
	public final String getSignificand() {
		return significand;
	}

	/**
	 * Sets the significand.
	 * 
	 * @param significan
	 *            the new significand
	 */
	public final void setSignificand(final String significan) {
		this.significand = significan;
	}
}
