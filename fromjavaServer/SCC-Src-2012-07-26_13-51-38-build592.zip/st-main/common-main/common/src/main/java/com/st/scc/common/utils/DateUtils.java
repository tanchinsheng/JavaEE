/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 5, 2011 3:33:57 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class DateUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class DateUtils {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(DateUtils.class);

  /** The Constant CONNECTOR_QUATER. */
  public static final String CONNECTOR_QUATER = "/";

  /**
   * Date to string.
   * 
   * @param date
   *          the date
   * @param format
   *          the format
   * @return the string
   */
  public static String dateToString(final Date date, final String format) {
    if (date == null) {
      return null;
    } else {
      final SimpleDateFormat formatter = new SimpleDateFormat(format);
      return formatter.format(date);
    }
  }

  /**
   * Gets the gMT date.
   * 
   * @param localTime
   *          the local time
   * @return the gMT date
   */
  public static Date getGMTDate(final Date localTime) {
    final Calendar calendar = Calendar.getInstance();
    if (localTime != null) {
      calendar.setTimeInMillis(localTime.getTime());
    }

    final TimeZone tz = calendar.getTimeZone();
    final int offset = tz.getRawOffset();
    final int offsetHrs = offset / 1000 / 60 / 60;
    final int offsetMins = offset / 1000 / 60 % 60;

    calendar.add(Calendar.HOUR_OF_DAY, (-offsetHrs));
    calendar.add(Calendar.MINUTE, (-offsetMins));
    return calendar.getTime();
  }

  /**
   * Gets the last day from month number.
   * 
   * @param month
   *          the month
   * @param year
   *          the year
   * @return the last day from month number
   */
  public static Date getLastDayFromMonthNumber(final int month, final int year) {
    final Calendar calendar = Calendar.getInstance();
    calendar.clear();
    calendar.set(Calendar.MONTH, month);
    calendar.set(Calendar.YEAR, year);

    final int ndays = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
    calendar.set(Calendar.DAY_OF_MONTH, ndays);

    final Date date = calendar.getTime();
    return date;
  }

  /**
   * Gets the month date.
   * 
   * @param startDate
   *          the start date
   * @param endDate
   *          the end date
   * @return the month date
   */
  public static String[] getMonthDate(final Date startDate, final Date endDate) {
    final Calendar start = Calendar.getInstance();
    start.setTimeInMillis(startDate.getTime());
    start.set(Calendar.HOUR_OF_DAY, 0);
    start.set(Calendar.MINUTE, 1);

    final Calendar end = Calendar.getInstance();
    end.setTimeInMillis(endDate.getTime());
    end.set(Calendar.HOUR_OF_DAY, 23);
    end.set(Calendar.MINUTE, 59);

    final Set<String> monthDates = new LinkedHashSet<String>();
    long startMili = start.getTimeInMillis();
    final long endMili = end.getTimeInMillis();

    final Calendar tmp = Calendar.getInstance();

    while (startMili < endMili) {
      tmp.setTimeInMillis(startMili);
      String tmpDate = dateToString(tmp.getTime(), "MMM-yyyy");
      monthDates.add(tmpDate);
      tmp.add(Calendar.DATE, 28);
      if (tmp.getTimeInMillis() > endMili) {
        tmp.setTimeInMillis(endMili);
        tmpDate = dateToString(tmp.getTime(), "MMM-yyyy");
        monthDates.add(tmpDate);
        break;
      } else {
        startMili = tmp.getTimeInMillis();
      }
    }
    return monthDates.toArray(new String[0]);
  }

  /**
   * Gets the quarter number.
   * 
   * @param date
   *          the date
   * @return the quarter number
   */
  public static int getQuarterNumber(final Date date) {
    final Calendar cal = Calendar.getInstance();
    cal.setTimeInMillis(date.getTime());
    final int month = cal.get(Calendar.MONTH); /* 0 through 11 */
    final int quarter = month / 3 + 1;
    return quarter;
  }

  /**
   * Gets the quarter numbers.
   * 
   * @param startDate
   *          the start date
   * @param endDate
   *          the end date
   * @return the quarter numbers
   */
  public static String[] getQuarterNumbers(final Date startDate, final Date endDate) {
    final Calendar start = Calendar.getInstance();
    start.setTimeInMillis(startDate.getTime());
    start.set(Calendar.HOUR_OF_DAY, 0);
    start.set(Calendar.MINUTE, 1);

    final Calendar end = Calendar.getInstance();
    end.setTimeInMillis(endDate.getTime());
    end.set(Calendar.HOUR_OF_DAY, 23);
    end.set(Calendar.MINUTE, 59);

    final Set<String> timeUnits = new LinkedHashSet<String>();
    long startMili = start.getTimeInMillis();
    final long endMili = end.getTimeInMillis();

    final Calendar tmp = Calendar.getInstance();

    while (startMili < endMili) {
      tmp.setTimeInMillis(startMili);
      timeUnits.add(getQuarterNumber(tmp.getTime()) + CONNECTOR_QUATER
          + tmp.get(Calendar.YEAR));
      tmp.add(Calendar.DATE, 90);
      if (tmp.getTimeInMillis() > endMili) {
        tmp.setTimeInMillis(endMili);
        timeUnits.add(getQuarterNumber(tmp.getTime()) + CONNECTOR_QUATER
            + tmp.get(Calendar.YEAR));
        break;
      } else {
        startMili = tmp.getTimeInMillis();
      }
    }
    return timeUnits.toArray(new String[0]);
  }

  /**
   * Checks if is valid date.
   * 
   * @param dateStr
   *          the date str
   * @param format
   *          the format
   * @return true, if is valid date
   */
  public static boolean isValidDate(final String dateStr, final String format) {
    if (dateStr == null) {
      return false;
    }
    final SimpleDateFormat dateFormat = new SimpleDateFormat(format);
    Date parseDate = null;
    try {
      parseDate = dateFormat.parse(dateStr);
    } catch (final ParseException e) {
      return false;
    }
    if (parseDate == null || !dateFormat.format(parseDate).equals(dateStr)) {
      return false;
    }
    return true;
  }

  /**
   * Converts Date to Date.
   * 
   * @param str
   *          the str
   * @param format
   *          the format
   * @return the date
   * @throws ParseException
   *           the parse exception
   */
  public static Date stringToDate(final String str, final String format) throws ParseException {
    if (str == null) {
      return null;
    }
    final SimpleDateFormat formatter = new SimpleDateFormat(format);
    final Date date = formatter.parse(str);
    return date;
  }

  /**
   * Converts String to Timestamp.
   * 
   * @param str
   *          the str
   * @param format
   *          the format
   * @return the timestamp
   * @throws ParseException
   *           the parse exception
   */
  public static Timestamp stringToTimeStamp(final String str, final String format)
      throws ParseException {
    if (str == null) {
      return null;
    }
    final SimpleDateFormat dateFormat = new SimpleDateFormat(format);
    final Date parsedDate = dateFormat.parse(str);
    final Timestamp timestamp = new Timestamp(parsedDate.getTime());
    return timestamp;
  }

  /**
   * String to date.
   * 
   * @param str
   *          the string
   * @param format
   *          the format
   * @return the date
   */
  public static Date strToDate(final String str, final String format) {
    if (str == null) {
      return null;
    }
    final SimpleDateFormat formatter = new SimpleDateFormat(format);
    Date date = null;
    try {
      date = formatter.parse(str);
    } catch (final ParseException e) {
      if (LOG.isDebugEnabled()) {
        LOG.debug("Invalid time format");
      }
    }
    return date;
  }

  /**
   * Converts time stamp to string.
   * 
   * @param timestamp
   *          the timestamp
   * @param format
   *          the format
   * @return the string
   */
  public static String timestampToString(final Timestamp timestamp, final String format) {
    if (timestamp == null) {
      return null;
    } else {
      final SimpleDateFormat formatter = new SimpleDateFormat(format);
      return formatter.format(timestamp);
    }
  }

  /**
   * Instantiates a new date utils.
   */
  private DateUtils() {
  }

}
