/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 27, 2011 2:36:16 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess;

import java.io.File;

import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Session;
import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.common.fileaccess.impl.FTPFileAccess;
import com.st.common.fileaccess.impl.NFSFileAccess;
import com.st.common.fileaccess.impl.SFTPFileAccess;
import com.st.scc.common.utils.FTPUtil;
import com.st.scc.common.utils.SFTPUtils;

/**
 * A factory for creating {@link SccFileAccess} objects.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class FileAccessFactory {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileAccessFactory.class);

  /**
   * Re-use the connection from the given {@link SccFileAccess}.
   * 
   * @param fileInfo
   *          the file info
   * @param fileAccess
   *          the file access
   * @return the SCC file access
   */
  public static SccFileAccess copy(final FileInfo fileInfo, final SccFileAccess fileAccess) {
    SccFileAccess retVal = null;
    if (fileInfo != null) {
      final FileTypeEnum fileType = fileInfo.getFileType();
      if (fileType != null) {
        switch (fileType) {
        case NFS:
          final NFSFileAccess nfs = new NFSFileAccess(fileInfo);
          final File file = new File(fileInfo.getPathFileName());
          nfs.setFile(file);
          retVal = nfs;
          break;

        case FTP:
          FTPClient ftpClient = null;
          final FTPFileAccess newFtp = new FTPFileAccess(fileInfo);
          if (fileAccess instanceof FTPFileAccess) {
            final FTPFileAccess ftp = (FTPFileAccess) fileAccess;
            ftpClient = ftp.getFtp();
          }
          if (ftpClient == null) {
            ftpClient =
                FTPUtil.connectFTP(fileInfo.getHost(), fileInfo.getUserName(),
                    fileInfo.getPassWord(), fileInfo.getPort());
          }
          if (ftpClient != null) {
            newFtp.setFtp(ftpClient);
            retVal = newFtp;
          }
          break;

        case SFTP:
          Session session = null;
          final SFTPFileAccess newSftp = new SFTPFileAccess(fileInfo);
          if (fileAccess instanceof SFTPFileAccess) {
            final SFTPFileAccess sftp = (SFTPFileAccess) fileAccess;
            session = sftp.getSession();
          }
          if (session == null) {
            session =
                SFTPUtils.createSession(fileInfo.getHost(), fileInfo.getUserName(),
                    fileInfo.getPassWord(), fileInfo.getPort());
          }
          if (session != null) {
            newSftp.setSession(session);
            retVal = newSftp;
          }
          break;

        default:
          LOG.warn("Un-support file type [{}]", fileType);
          break;
        }
      } else {
        LOG.warn("FileType is null");
      }
    } else {
      LOG.warn("FileInfo is null");
    }
    return retVal;
  }

  /**
   * Creates the new {@link SccFileAccess} object.
   * 
   * @param fileInfo
   *          the file info
   * @return the SCC file access
   */
  public static SccFileAccess create(final FileInfo fileInfo) {
    SccFileAccess fileAccess = null;
    if (fileInfo != null) {
      final FileTypeEnum fileType = fileInfo.getFileType();
      if (fileType != null) {
        switch (fileType) {
        case NFS:
          final NFSFileAccess nfs = new NFSFileAccess(fileInfo);
          final File file = new File(fileInfo.getPathFileName());
          nfs.setFile(file);
          fileAccess = nfs;
          break;

        case FTP:
          final FTPFileAccess ftp = new FTPFileAccess(fileInfo);
          final FTPClient ftpClient =
              FTPUtil.connectFTP(fileInfo.getHost(), fileInfo.getUserName(),
                  fileInfo.getPassWord(), fileInfo.getPort());
          if (ftpClient != null && ftpClient.isConnected()) {
            ftp.setFtp(ftpClient);
            fileAccess = ftp;
          }
          break;

        case SFTP:
          final SFTPFileAccess sftp = new SFTPFileAccess(fileInfo);
          final Session session =
              SFTPUtils.createSession(fileInfo.getHost(), fileInfo.getUserName(),
                  fileInfo.getPassWord(), fileInfo.getPort());
          if (session != null && session.isConnected()) {
            sftp.setSession(session);
            fileAccess = sftp;
          }
          break;

        default:
          LOG.warn("Un-support file type [{}]", fileType);
          break;
        }
      } else {
        LOG.warn("FileType is null");
      }
    } else {
      LOG.warn("FileInfo is null");
    }
    return fileAccess;
  }

  /**
   * Instantiates a new file access factory.
   */
  private FileAccessFactory() {

  }
}
