/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 14, 2011 11:09:32 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess;

import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Session;
import com.st.common.beans.FileTypeEnum;
import com.st.common.fileaccess.impl.FTPFileScanner;
import com.st.common.fileaccess.impl.NFSFileScanner;
import com.st.common.fileaccess.impl.SFTPFileScanner;
import com.st.scc.common.utils.FTPUtil;
import com.st.scc.common.utils.SFTPUtils;

/**
 * A factory for creating FileScanner objects.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class FileScannerFactory {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FileScannerFactory.class);

  /**
   * Creates the.
   * 
   * @param fileType
   *          the file type
   * @param host
   *          the host
   * @param userName
   *          the user name
   * @param password
   *          the password
   * @param port
   *          the port
   * @return the file scanner
   */
  public static FileScanner create(final FileTypeEnum fileType, final String host,
      final String userName, final String password, final int port) {
    FileScanner fileScanner = null;
    if (fileType != null) {
      switch (fileType) {
      case NFS:
        final NFSFileScanner nfs = new NFSFileScanner();
        fileScanner = nfs;
        break;

      case FTP:
        final FTPFileScanner ftp = new FTPFileScanner();
        final FTPClient ftpClient = FTPUtil.connectFTP(host, userName, password, port);
        if (ftpClient != null && ftpClient.isConnected()) {
          ftp.setFtp(ftpClient);
          ftp.setHost(host);
          ftp.setUserName(userName);
          ftp.setPassword(password);
          ftp.setPort(port);
          fileScanner = ftp;
        }
        break;

      case SFTP:
        final SFTPFileScanner sftp = new SFTPFileScanner();
        final Session session = SFTPUtils.createSession(host, userName, password, port);
        if (session != null && session.isConnected()) {
          sftp.setSession(session);
          sftp.setHost(host);
          sftp.setUserName(userName);
          sftp.setPassword(password);
          sftp.setPort(port);
          fileScanner = sftp;
        }
        break;

      default:
        LOG.warn("Un-support file type [{}]", fileType);
        break;
      }
    } else {
      LOG.warn("FileType is null");
    }
    return fileScanner;
  }

  /**
   * Instantiates a new file scanner factory.
   */
  private FileScannerFactory() {

  }
}
