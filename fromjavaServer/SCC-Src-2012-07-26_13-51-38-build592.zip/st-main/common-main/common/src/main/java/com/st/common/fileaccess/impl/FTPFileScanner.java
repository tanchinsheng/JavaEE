/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jul 14, 2011 11:16:27 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.fileaccess.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;
import com.st.scc.common.utils.FTPUtil;
import com.st.scc.common.utils.FileUtils;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class FTPFileScanner extends AbsFileScanner {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(FTPFileScanner.class);

  /** The FTP connection. */
  private FTPClient ftp;

  /**
   * Instantiates a new FTP file scanner.
   */
  public FTPFileScanner() {
    setFileType(FileTypeEnum.FTP);
  }

  /**
   * Change working directory.
   * 
   * @param ftp
   *          the FTP connection
   * @param folder
   *          the folder listing files
   * @return true, if successful
   */
  private boolean changeWorkingDirectory(final FTPClient ftp, final String folder) {
    boolean result = false;
    try {
      result = ftp.changeWorkingDirectory(folder);
    } catch (final IOException e) {
      LOG.error("Error occurred when changing direction to monitor to folder = " + folder, e);
    }
    return result;
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.FileScanner#disconnect()
   */
  public void disconnect() {
    FTPUtil.disconnectFTP(ftp);
  }

  /**
   * Gets the FTP connection.
   * 
   * @return the FTP connection
   */
  public FTPClient getFtp() {
    return ftp;
  }

  /**
   * get list files for FTP.
   * 
   * @param ftp
   *          the ftp
   * @param depth
   *          the depth
   * @param sub
   *          the sub
   * @param listFile
   *          the list file
   * @param maxSizeFile
   *          the max size file
   */
  private void getListNewFileFTP(final FTPClient ftp, final int depth, final String sub,
      final List<FileInfo> listFile, final int maxSizeFile) {
    if (depth < 0) {
      return;
    }
    if (maxSizeFile > 0 && listFile.size() >= maxSizeFile) {
      return;
    }
    FTPFile[] ftpFile = null;
    try {
      if (changeWorkingDirectory(ftp, sub)) {
        ftpFile = FTPUtil.listFiles(ftp);
        for (final FTPFile element : ftpFile) {
          if (listFile.size() == maxSizeFile) {
            return;
          }
          final StringBuffer str = new StringBuffer();
          str.append(sub);
          if (!sub.endsWith("/")) {
            str.append("/");
          }
          str.append(element.getName());
          final String fileName = str.toString();
          if (element.isDirectory()) {
            getListNewFileFTP(ftp, depth - 1, fileName, listFile, maxSizeFile);
          } else {
            final FileInfo fileInfo =
                new FileInfo(fileName, getMonitorFolder(), element.getTimestamp()
                    .getTimeInMillis());
            final List<String> extensionFile = getFilePatternList();
            if (extensionFile != null) {
              for (final String entension : extensionFile) {
                if (Pattern.matches(entension, FileUtils.getTailFileName(element.getName()))) {
                  fileInfo.setFileType(getFileType());
                  fileInfo.setUserName(getUserName());
                  fileInfo.setPassWord(getPassword());
                  fileInfo.setHost(getHost());
                  fileInfo.setPort(getPort());
                  fileInfo.setSize(element.getSize());
                  listFile.add(fileInfo);
                  break;
                }
              }
            }
          }
          if (maxSizeFile > 0 && listFile.size() >= maxSizeFile) {
            break;
          }
        }
      }
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    }
  }

  /**
   * {@inheritDoc}
   * 
   * @see com.st.common.fileaccess.FileScanner#scan(java.lang.String, int, int)
   */
  public List<FileInfo> scan(final String filePath, final int depth, final int maxSize) {
    List<FileInfo> list = null;
    if (ftp != null) {
      if (changeWorkingDirectory(ftp, filePath)) {
        list = new ArrayList<FileInfo>();
        getListNewFileFTP(ftp, depth, filePath, list, maxSize);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Scanned files successfully");
        }
      } else {
        LOG.error("monitor to folder {} does not exist or no permission", getMonitorFolder());
      }
    } else {
      LOG.error("Connection FTP is error because host, username or password is not correct");
    }
    return list;
  }

  /**
   * Sets the FTP connection.
   * 
   * @param ftp
   *          the new FTP connection
   */
  public void setFtp(final FTPClient ftp) {
    this.ftp = ftp;
  }

}
