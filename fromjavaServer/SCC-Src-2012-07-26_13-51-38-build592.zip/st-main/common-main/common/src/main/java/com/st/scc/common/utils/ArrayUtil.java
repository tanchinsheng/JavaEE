/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 28, 2011 4:51:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.util.List;

/**
 * The Class ArrayUtil.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ArrayUtil {

  /**
   * Copy of range.
   * 
   * @param original
   *          the original
   * @param from
   *          the from
   * @param to
   *          the to
   * @return the byte[]
   */
  public static byte[] copyOfRange(final byte[] original, final int from, final int to) {
    final int newLength = to - from;
    if (newLength < 0) {
      throw new IllegalArgumentException(from + " > " + to);
    }
    final byte[] copy = new byte[newLength];
    System.arraycopy(original, from, copy, 0, Math.min(original.length - from, newLength));
    return copy;
  }

  /**
   * Check equality for 2 arrays of bytes from start index.
   * 
   * @param a
   *          the a
   * @param a2
   *          the a2
   * @param start
   *          the start
   * @return true, if successful
   */
  public static boolean equals(final byte[] a, final byte[] a2, final int start) {
    if (a == a2) {
      return true;
    }
    if (a == null || a2 == null) {
      return false;
    }

    final int length = a.length;
    if (a2.length != length) {
      return false;
    }

    for (int i = start; i < length; i++) {
      if (a[i] != a2[i]) {
        return false;
      }
    }

    return true;
  }

  /**
   * Gets the safe value.
   * 
   * @param <T>
   *          the generic type
   * @param list
   *          the list
   * @param index
   *          the index
   * @return the safe value
   */
  public static <T> T getSafeValue(final List<T> list, final int index) {
    T retVal = null;
    if (0 <= index && index < list.size()) {
      retVal = list.get(index);
    }
    return retVal;
  }

  /**
   * Search the index of the given object in the array.
   * 
   * @param <T>
   *          the generic type
   * @param array
   *          the array
   * @param obj
   *          the object
   * @return the found index
   */
  public static <T> int search(final T[] array, final T obj) {
    int index = -1;
    if (array != null && array.length > 0) {
      for (int i = 0; i < array.length; i++) {
        if (array[i] == obj) {
          index = i;
          break;
        }
      }
    }
    return index;
  }

  /**
   * Instantiates a new array utility.
   */
  private ArrayUtil() {

  }
}
