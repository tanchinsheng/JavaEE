/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 11, 2011 10:26:09 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.common.compress.base;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class Constant {
  /**
   * Constructor.
   */
  private Constant() {
  }

  /** Defines two byte. */
  public static final int TWO_BYTE = 16;
  /** Defines one KB. */
  public static final int KB_TO_BYTE = 1024;
  /** Defines five hundred and twelve KB. */
  public static final int FIVE_HUNDRED_TWELVE_KB = 512 * KB_TO_BYTE;
  /** Always set to 16 for SPEC95. */
  public static final int BITS = 16;
  /** Initial number of bits/code. */
  public static final int INIT_BITS = 9;
  /** 95% occupancy. */
  public static final int HSIZE = 69001;
  /** 2**BITS. */
  public static final int SUFFIX_TAB_SZ = 65536;
  /** Decompression stack size. */
  public static final int STACK_SZ = 8000;

  /** Header of file .Z is 1F 9D. */
  public static final byte[] MAGIC_HEADER = {(byte) 037, (byte) 0235 };

  /** Defines for third byte of header. */
  public static final int BIT_MASK = 0x1f;
  /** Defines block mask. */
  public static final int BLOCK_MASK = 0x80;
  /**
   * Masks 0x40 and 0x20 are free. I think 0x20 should mean that there is a
   * fourth header byte (for expansion).
   */

  /**
   * The next two codes should not be changed lightly, as they must not lie
   * within the contiguous general code space.
   */
  /** First free entry. */
  public static final int FIRST = 257;
  /** Table clear output code. */
  public static final int CLEAR = 256;
  /** Defines LMASK. */
  public static final byte[] LMASK = {(byte) 0xff, (byte) 0xfe, (byte) 0xfc, (byte) 0xf8,
      (byte) 0xf0, (byte) 0xe0, (byte) 0xc0, (byte) 0x80, (byte) 0x00 };
  /** Defines RMASK. */
  public static final byte[] RMASK = {(byte) 0x00, (byte) 0x01, (byte) 0x03, (byte) 0x07,
      (byte) 0x0f, (byte) 0x1f, (byte) 0x3f, (byte) 0x7f, (byte) 0xff };
}
