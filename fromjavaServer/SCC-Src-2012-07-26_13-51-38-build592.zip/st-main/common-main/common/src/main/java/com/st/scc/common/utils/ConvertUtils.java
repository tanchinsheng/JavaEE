/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 1, 2011 10:38:32 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.math.BigInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class ConvertUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ConvertUtils {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(ConvertUtils.class);

  /**
   * Gets the big integer.
   * 
   * @param s
   *          the s
   * @return the big integer
   */
  public static BigInteger getBigInteger(final String s) {
    BigInteger retVal = null;
    if (s != null && s.length() > 0) {
      try {
        retVal = new BigInteger(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the byte.
   * 
   * @param data
   *          the data
   * @return the byte
   */
  public static byte getByte(final Object data) {
    byte returnVal = 0;
    if (data == null) {
      return returnVal;
    }
    if (data instanceof Byte) {
      returnVal = (Byte) data;
    } else {
      try {
        returnVal = Byte.parseByte(String.valueOf(data));
      } catch (final NumberFormatException ex) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(ex.getMessage(), ex);
        }
      }
    }
    return returnVal;
  }

  /**
   * Gets the byte object.
   * 
   * @param s
   *          the string
   * @return the byte object
   */
  public static Byte getByteObject(final String s) {
    Byte value = null;
    if (s != null && s.length() > 0) {
      try {
        value = Byte.parseByte(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return value;
  }

  /**
   * Gets the double.
   * 
   * @param s
   *          the s
   * @return the double
   */
  public static double getDouble(final String s) {
    double retVal = 0;
    if (s != null && s.length() > 0) {
      try {
        retVal = Double.parseDouble(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the double object.
   * 
   * @param s
   *          the string
   * @return the double object
   */
  public static Double getDoubleObject(final String s) {
    Double retVal = null;
    if (s != null && s.length() > 0) {
      try {
        retVal = Double.parseDouble(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the enumeration.
   * 
   * @param <T>
   *          the generic type
   * @param enumType
   *          the enum type
   * @param value
   *          the value
   * @return the enum
   */
  public static <T extends Enum<T>> T getEnum(final Class<T> enumType, final String value) {
    T retVal = null;
    if (value != null) {
      try {
        retVal = Enum.valueOf(enumType, value.trim());
      } catch (final IllegalArgumentException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the float.
   * 
   * @param data
   *          the data
   * @return the float
   */
  public static float getFloat(final Object data) {
    float returnVal = 0.0f;
    if (data == null) {
      return returnVal;
    }
    if (data instanceof Float) {
      returnVal = (Float) data;
    } else {
      try {
        returnVal = Float.parseFloat(String.valueOf(data));
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return returnVal;
  }

  /**
   * Gets the float object.
   * 
   * @param s
   *          the string
   * @return the float object
   */
  public static Float getFloatObject(final String s) {
    Float value = null;
    if (s != null && s.length() > 0) {
      try {
        value = Float.parseFloat(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return value;
  }

  /**
   * Gets the integer.
   * 
   * @param s
   *          the string
   * @return the int
   */
  public static int getInt(final String s) {
    int retVal = 0;
    if (s != null && s.length() > 0) {
      try {
        retVal = Integer.parseInt(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the integer.
   * 
   * @param s
   *          the string
   * @return the integer
   */
  public static Integer getInteger(final String s) {
    Integer retVal = null;
    if (s != null && s.length() > 0) {
      try {
        retVal = Integer.valueOf(Integer.parseInt(s));
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the integer.
   * 
   * @param obj
   *          the object
   * @return the integer
   */
  public static Integer getInteger(final Object obj) {
    Integer retVal = null;
    if (obj instanceof String) {
      try {
        retVal = Integer.valueOf(Integer.parseInt((String) obj));
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    } else if (obj instanceof Number) {
      retVal = Integer.valueOf(((Number) obj).intValue());
    }
    return retVal;
  }

  /**
   * Gets the long object.
   * 
   * @param s
   *          the string
   * @return the long
   */
  public static Long getLongObject(final String s) {
    Long retVal = null;
    if (s != null && s.length() > 0) {
      try {
        retVal = Long.parseLong(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the long.
   * 
   * @param s
   *          the string
   * @return the long
   */
  public static long getLong(final String s) {
    long retVal = 0;
    if (s != null && s.length() > 0) {
      try {
        retVal = Long.parseLong(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return retVal;
  }

  /**
   * Gets the short.
   * 
   * @param data
   *          the data
   * @return the short
   */
  public static short getShort(final Object data) {
    short returnVal = 0;
    if (data == null) {
      return returnVal;
    }
    if (data instanceof Short) {
      returnVal = (Short) data;
    } else {
      try {
        returnVal = Short.parseShort(String.valueOf(data));
      } catch (final NumberFormatException ex) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(ex.getMessage(), ex);
        }
      }
    }
    return returnVal;
  }

  /**
   * Gets the short object.
   * 
   * @param s
   *          the string
   * @return the short object
   */
  public static Short getShortObject(final String s) {
    Short value = null;
    if (s != null && s.length() > 0) {
      try {
        value = Short.parseShort(s);
      } catch (final NumberFormatException e) {
        if (LOG.isDebugEnabled()) {
          LOG.debug(e.getMessage(), e);
        }
      }
    }
    return value;
  }

  /**
   * Instantiates a new convert utility.
   */
  private ConvertUtils() {

  }
}
