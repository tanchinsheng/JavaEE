/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Sep 28, 2011 4:51:22 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.filedetector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.st.scc.common.utils.ArrayUtil;

/**
 * The Class MagicNumberFileDetectorFormat.
 */
public final class MagicNumberFileDetectorFormat {
  /** The Constant GZIP. This is magic number for GZIP, TGZ, GZ */
  private static final byte[] GZIP = {0x1F, (byte) 0x8B, 0x08 };

  /** The Constant BZ2. This is magic number for BZ2, TBZ2, TB2 */
  private static final byte[] BZ2 = {0x42, 0x5A, 0x68 };

  /** The Constant ZIP. This is magic number for ZIP */
  private static final byte[] ZIP = {0x50, 0x4B, 0x03, 0x04 };

  /** The Constant TAR. This is magic number for TAR */
  private static final byte[] TAR = {0x75, 0x73, 0x74, 0x61, 0x72 };

  /** The Constant Z_LZW. This is magic number for Z using Lempel-Ziv-Welch */
  private static final byte[] Z_LZW = {0x1F, (byte) 0x9D };

  /**
   * The Constant STDF_CPUTYPE_2. This is magic number for FAR with CPU_TYPE=2,
   * encoded in little-endian (LSB first)
   */
  private static final byte[] STDF_CPUTYPE_2 = {0x02, 0x00, 0x00, 0x0A, 0x02 };

  /**
   * The Constant STDF_CPU_TYPE_1. This is magic number for FAR with CPU_TYPE=1
   * , encoded in Big-endian (MSB first)
   */
  private static final byte[] STDF_CPUTYPE_1 = {0x00, 0x02, 0x00, 0x0A, 0x01 };

  /**
   * The Constant STDF_CPUTYPE_0. This is magic number for FAR with CPU_TYPE=0,
   * encoded in little-endian (LSB first)
   */
  private static final byte[] STDF_CPUTYPE_0 = {0x02, 0x00, 0x00, 0x0A, 0x00 };

  /** The instance. */
  private static MagicNumberFileDetectorFormat instance = new MagicNumberFileDetectorFormat();

  /**
   * Gets the single instance of FileDetectorFormat.
   * 
   * @return single instance of FileDetectorFormat
   */
  public static MagicNumberFileDetectorFormat getInstance() {
    return instance;
  }

  /** The Constant _supportedFormat. */
  private final Map<FileFormatEnum, List<byte[]>> supportedFormats;

  /**
   * Instantiates a new file detector format.
   */
  private MagicNumberFileDetectorFormat() {
    supportedFormats = new HashMap<FileFormatEnum, List<byte[]>>();
//    supportedFormats.put(FileFormatEnum.ZIP, new ArrayList<byte[]>(Arrays.asList(ZIP)));
//    supportedFormats.put(FileFormatEnum.GZIP, new ArrayList<byte[]>(Arrays.asList(GZIP)));
//    supportedFormats.put(FileFormatEnum.BZ2, new ArrayList<byte[]>(Arrays.asList(BZ2)));
//    supportedFormats.put(FileFormatEnum.TAR, new ArrayList<byte[]>(Arrays.asList(TAR)));
//    supportedFormats.put(FileFormatEnum.Z, new ArrayList<byte[]>(Arrays.asList(Z_LZW)));

    supportedFormats.put(FileFormatEnum.STDF_V4_LITTLE_ENDIAN_0,
        new ArrayList<byte[]>(Arrays.asList(STDF_CPUTYPE_0)));
    supportedFormats.put(FileFormatEnum.STDF_V4_BIG_ENDIAN,
        new ArrayList<byte[]>(Arrays.asList(STDF_CPUTYPE_1)));
    supportedFormats.put(FileFormatEnum.STDF_V4_LITTLE_ENDIAN_2,
        new ArrayList<byte[]>(Arrays.asList(STDF_CPUTYPE_2)));
  }

  /**
   * Will get 16 bytes from stream to compare with all supported file type.
   * 
   * @param fileSignature
   *          the file signature
   * @return FileTypeEnum
   */
  public FileFormatEnum getFileType(final byte[] fileSignature) {
    for (final Entry<FileFormatEnum, List<byte[]>> entry : supportedFormats.entrySet()) {
      final FileFormatEnum fileType = entry.getKey();
      final List<byte[]> listOfMagicNum = entry.getValue();
      for (final byte[] magicByte : listOfMagicNum) {
        if (fileSignature.length > magicByte.length) {
          final byte[] magicGzip = ArrayUtil.copyOfRange(fileSignature, 0, magicByte.length);
          if (Arrays.equals(magicByte, magicGzip)) {
            return fileType;
          }
        }
      }
    }

    return FileFormatEnum.UNKNOWN;
  }

  /**
   * Gets the file type.
   * 
   * @param fileSignature
   *          the file signature
   * @param start
   *          the start
   * @return the file type
   */
  public FileFormatEnum getFileType(final byte[] fileSignature, final int start) {
    for (final Entry<FileFormatEnum, List<byte[]>> entry : supportedFormats.entrySet()) {
      final FileFormatEnum fileType = entry.getKey();
      final List<byte[]> listOfMagicNum = entry.getValue();
      for (final byte[] magicByte : listOfMagicNum) {
        if (fileSignature.length > magicByte.length) {
          final byte[] magicGzip = ArrayUtil.copyOfRange(fileSignature, 0, magicByte.length);
          if (ArrayUtil.equals(magicByte, magicGzip, start)) {
            return fileType;
          }
        }
      }
    }

    return FileFormatEnum.UNKNOWN;
  }
}
