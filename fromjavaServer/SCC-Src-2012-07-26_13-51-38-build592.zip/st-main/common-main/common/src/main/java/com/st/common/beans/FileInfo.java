/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 10, 2011 3:43:52 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.common.beans;

import java.sql.Timestamp;

/**
 * The Class FileInfo.
 * 
 * @author nghiatn
 */
public class FileInfo {
  /**
   * copy from fileInfo to new FileInfo.
   * 
   * @param file
   *          the file
   * @return the file info
   */
  public static FileInfo copyFileInfo(final FileInfo file) {
    if (file == null) {
      final FileInfo temp = new FileInfo();
      return temp;
    }
    final FileInfo fileInfo = new FileInfo();
    fileInfo.setFileType(file.getFileType());
    fileInfo.setHost(file.getHost());
    fileInfo.setLastModified(file.getLastModified());
    fileInfo.setPassWord(file.getPassWord());
    fileInfo.setPathFileName(file.getPathFileName());
    fileInfo.setPathRoot(file.getPathRoot());
    fileInfo.setPathRootToFile(file.getPathRootToFile());
    fileInfo.setPort(file.getPort());
    fileInfo.setSize(file.getSize());
    fileInfo.setUserName(file.getUserName());
    return fileInfo;
  }
  /** The modified time. */
  private long lastModified;

  /** The path file name. */
  private String pathFileName;

  /** The path root. */
  private String pathRoot;

  /** The path root to file. */
  private String pathRootToFile;

  /** The host. */
  private String host;

  /** The user name. */
  private String userName;

  /** The pass word. */
  private String passWord;

  /** The file type. */
  private FileTypeEnum fileType;

  /** The size. */
  private long size;

  /** The port of host. */
  private int port;

  /**
   * Instantiates a new file info.
   */
  public FileInfo() {
  }

  /**
   * Instantiates a new file info.
   * 
   * @param pathFileName
   *          the path file name
   * @param pathRoot
   *          the path conf
   * @param lastModified
   *          the modifile time
   */
  public FileInfo(final String pathFileName, final String pathRoot, final long lastModified) {
    String tmpRootToFile;
    final String tmpPathFileName = pathFileName.replaceAll("\\\\", "/");
    String tmpPathRoot = pathRoot.replaceAll("\\\\", "/");
    if (!tmpPathRoot.endsWith("/")) {
      tmpPathRoot += "/";
    }
    tmpRootToFile = tmpPathFileName.replaceFirst(tmpPathRoot, "");
    this.pathFileName = tmpPathFileName;
    this.pathRoot = tmpPathRoot;
    pathRootToFile = tmpRootToFile;
    this.lastModified = lastModified;
  }

  /**
   * Gets the file type.
   * 
   * @return the fileType
   */
  public FileTypeEnum getFileType() {
    return fileType;
  }

  /**
   * Gets the host.
   * 
   * @return the host
   */
  public String getHost() {
    return host;
  }

  /**
   * Gets the last modified.
   * 
   * @return the last modified
   */
  public long getLastModified() {
    return lastModified;
  }

  /**
   * Gets the pass word.
   * 
   * @return the passWord
   */
  public String getPassWord() {
    return passWord;
  }

  /**
   * Gets the path file name.
   * 
   * @return the pathFileName
   */
  public String getPathFileName() {
    return pathFileName;
  }

  /**
   * Gets the path root.
   * 
   * @return the pathRoot
   */
  public String getPathRoot() {
    return pathRoot;
  }

  /**
   * Gets the path root to file.
   * 
   * @return the pathRootToFile
   */
  public String getPathRootToFile() {
    return pathRootToFile;
  }

  /**
   * Gets the port.
   * 
   * @return the port
   */
  public int getPort() {
    return port;
  }

  /**
   * @return the size
   */
  public long getSize() {
    return size;
  }

  /**
   * Gets the user name.
   * 
   * @return the userName
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Sets the all path modified.
   * 
   * @param strPathRoot
   *          the str path root
   * @param rootToFile
   *          the root to file
   * @param modifiedDate
   *          the modified
   */
  public void setAllPathModified(final String strPathRoot, final String rootToFile,
      final Timestamp modifiedDate) {
    lastModified = modifiedDate != null ? modifiedDate.getTime() : System.currentTimeMillis();
    pathRoot = strPathRoot.replaceAll("\\\\", "/");
    pathRootToFile = rootToFile.replaceAll("\\\\", "/");

    pathFileName = strPathRoot + rootToFile;
  }

  /**
   * Sets the file type.
   * 
   * @param fileType
   *          the fileType to set
   */
  public void setFileType(final FileTypeEnum fileType) {
    this.fileType = fileType;
  }

  /**
   * Sets the host.
   * 
   * @param host
   *          the host to set
   */
  public void setHost(final String host) {
    this.host = host;
  }

  /**
   * Sets the last modified.
   * 
   * @param lastModified
   *          the new last modified
   */
  public void setLastModified(final long lastModified) {
    this.lastModified = lastModified;
  }

  /**
   * Sets the pass word.
   * 
   * @param passWord
   *          the passWord to set
   */
  public void setPassWord(final String passWord) {
    this.passWord = passWord;
  }

  /**
   * Sets the path file name.
   * 
   * @param pathFileName
   *          the pathFileName to set
   */
  public void setPathFileName(final String pathFileName) {
    this.pathFileName = pathFileName;
  }

  /**
   * Sets the path root.
   * 
   * @param pathRoot
   *          the pathRoot to set
   */
  public void setPathRoot(final String pathRoot) {
    this.pathRoot = pathRoot;
  }

  /**
   * Sets the path root to file.
   * 
   * @param pathRootToFile
   *          the pathRootToFile to set
   */
  public void setPathRootToFile(final String pathRootToFile) {
    this.pathRootToFile = pathRootToFile;
  }

  /**
   * Sets the port.
   * 
   * @param port
   *          the port to set
   */
  public void setPort(final int port) {
    this.port = port;
  }

  /**
   * Sets the size.
   * 
   * @param size
   *          the size to set
   */
  public void setSize(final long size) {
    this.size = size;
  }

  /**
   * Sets the user name.
   * 
   * @param userName
   *          the userName to set
   */
  public void setUserName(final String userName) {
    this.userName = userName;
  }

  /**
   * {@inheritDoc}
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder(512);
    sb.append("FileInfo [pathFileName=").append(pathFileName);
    sb.append(", lastModified=").append(lastModified);
    sb.append(", pathRoot=").append(pathRoot);
    sb.append(", pathRootToFile=").append(pathRootToFile);
    sb.append(", host=").append(host);
    sb.append(", userName=").append(userName);
    sb.append(", passWord=").append(passWord);
    sb.append(", port=").append(port);
    sb.append(", fileType=").append(fileType);
    sb.append(", size=").append(size).append("]");
    return sb.toString();
  }
}
