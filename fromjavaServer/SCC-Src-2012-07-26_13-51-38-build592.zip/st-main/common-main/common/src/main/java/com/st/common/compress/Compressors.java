/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 10, 2012 2:27:02 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.compress;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.st.scc.common.utils.FileUtils;

/**
 * The Class Compressors.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public final class Compressors {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(Compressor.class);

  /**
   * Compress buffIn output buffOutt.
   * 
   * @param buffIn
   *          is buffer input stream.
   * @param buffOut
   *          is buffer output stream.
   * @return true|false.
   */
  private static boolean compressZ(final BufferedInputStream buffIn,
      final BufferedOutputStream buffOut) {
    boolean result = false;
    Compressor com;
    try {
      com = new Compressor(buffIn, buffOut);
      com.compress();
      result = true;
    } catch (final IOException e) {
      LOG.error("IO error " + e.getMessage());
    } catch (final Throwable e) {
      LOG.error("Out of memory " + e.getMessage(), e);
    }
    return result;
  }

  /**
   * Compress fileIn output fileOut.
   * 
   * @param fileIn
   *          is file in.
   * @param fileOut
   *          is file out.
   * @return true|false.
   */
  public static boolean compressZ(final File fileIn, final File fileOut) {
    return compressZ(fileIn, fileOut, false);
  }

  /**
   * Compress fileIn output fileOut.
   * 
   * @param fileIn
   *          is file in.
   * @param fileOut
   *          is file out.
   * @param deleteOldFile
   *          if true is delete old file.
   * @return true|false.
   */
  public static boolean compressZ(final File fileIn, final File fileOut,
      final boolean deleteOldFile) {
    boolean result = false;
    InputStream fInStream = null;
    OutputStream foutStream = null;
    BufferedInputStream buffIn = null;
    BufferedOutputStream buffOut = null;
    if (fileIn == null || fileOut == null) {
      LOG.warn("File is null");
      return false;
    }
    if (!fileIn.exists()) {
      LOG.warn("File input doesn't exist pathFile=" + fileIn.getAbsolutePath());
    } else {
      if (fileOut.getParentFile() != null && !fileOut.getParentFile().exists()) {
        fileOut.getParentFile().mkdirs();
      }
      try {
        fInStream = new FileInputStream(fileIn);
        foutStream = new FileOutputStream(fileOut);
        buffIn = new BufferedInputStream(fInStream);
        buffOut = new BufferedOutputStream(foutStream);
        final long startCompressTime = System.currentTimeMillis();
        result = compressZ(buffIn, buffOut);
        LOG.info("Compress file {} to file {} in "
            + (System.currentTimeMillis() - startCompressTime) + " ms",
            fileIn.getAbsoluteFile(), fileOut.getAbsoluteFile());
      } catch (final Exception e) {
        LOG.error(e.getMessage(), e);
      } finally {
        FileUtils.close(buffOut);
        FileUtils.close(buffIn);
        FileUtils.close(fInStream);
        FileUtils.close(foutStream);
      }
      if (result && deleteOldFile) {
        fileIn.delete();
      }
    }
    return result;
  }

  /**
   * compress file fileInf for creating file .Z fileIn is path of file source.
   * file output = fileInf + ".Z";
   * 
   * @param fileIn
   *          the file in
   * @return true, if successful
   */
  public static boolean compressZ(final String fileIn) {
    final String fileOut = fileIn + ".Z";
    boolean result = false;
    try {
      result = compressZ(fileIn, fileOut);
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    } catch (final Throwable e) {
      LOG.error("Out of memory " + e.getMessage(), e);
    }
    return result;
  }

  /**
   * compress file fileInf for creating file .Z fileIn is path of file source.
   * fileOut is path of file.Z
   * 
   * @param fileIn
   *          file in
   * @param deleteOldFile
   *          if true is delete old file.
   * @return true|false.
   */
  public static boolean compressZ(final String fileIn, final boolean deleteOldFile) {
    final String fileOut = fileIn + ".Z";
    boolean result = false;
    try {
      result = compressZ(fileIn, fileOut, deleteOldFile);
    } catch (final Exception e) {
      LOG.error(e.getMessage(), e);
    } catch (final Throwable e) {
      LOG.error("Out of memory " + e.getMessage(), e);
    }

    return result;
  }

  /**
   * compress file fileInf for creating file .Z fileIn is path of file source.
   * fileOut is path of file.Z
   * 
   * @param fileIn
   *          the file in
   * @param fileOut
   *          the file out
   * @return true, if successful
   */
  public static boolean compressZ(final String fileIn, final String fileOut) {
    final File in = new File(fileIn);
    final File out = new File(fileOut);
    return compressZ(in, out);
  }

  /**
   * compress file fileInf for creating file .Z fileIn is path of file source.
   * fileOut is path of file.Z
   * 
   * @param fileIn
   *          file in
   * @param fileOut
   *          file out
   * @param deleteOutFile
   *          if true is delete old file.
   * @return true|false.
   */
  public static boolean compressZ(final String fileIn, final String fileOut,
      final boolean deleteOutFile) {
    final File in = new File(fileIn);
    final File out = new File(fileOut);
    return compressZ(in, out, deleteOutFile);
  }

  /**
   * Gets the name file stdf.
   * 
   * @param path
   *          the path
   * @return the name file stdf
   */
  public static String getNameFileSTDF(final String path) {
    final File file = new File(path);
    final String nameFile = file.getName();
    String nameSTDF = nameFile;
    final int idx = nameFile.lastIndexOf(".");
    if (idx > -1) {
      nameSTDF = nameFile.substring(0, idx);
    }
    return nameSTDF;
  }

  /**
   * Gets the path file name stdf.
   * 
   * @param fullPathFile
   *          the full path file
   * @return the path file name stdf
   */
  private static String getPathFileNameSTDF(final String fullPathFile) {
    final int length = fullPathFile.length();
    final String result = fullPathFile.substring(0, length - 2);
    return result;
  }

  /**
   * Uncompress.
   * 
   * @param inFile
   *          the in file
   * @param outFile
   *          the out file
   * @param deleteOldFile
   *          the delete old file
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static void uncompress(final File inFile, final File outFile,
      final boolean deleteOldFile) throws IOException {
    if (!outFile.exists()) {
      outFile.getParentFile().mkdirs();
    }
    final InputStream inZ = new FileInputStream(inFile);
    final OutputStream outSTDF = new FileOutputStream(outFile);
    final InputStream in = new UncompressInputStream(inZ);
    final byte[] buf = new byte[8192];
    int len = 0;
    try {
      while ((len = in.read(buf)) > 0) {
        outSTDF.write(buf, 0, len);
      }
    } finally {
      //Don't catch exception, but we must close stream.
      in.close();
      inZ.close();
      outSTDF.close();

      if (deleteOldFile) {
        inFile.delete();
      }
    }
  }

  /**
   * Uncompress.
   * 
   * @param input
   *          the input
   * @param deleteOldFile
   *          the delete old file
   * @return the string
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static String uncompress(final String input, final boolean deleteOldFile)
      throws IOException {
    final String output = getPathFileNameSTDF(input);
    uncompress(input, output, deleteOldFile);
    return output;
  }

  /**
   * Uncompress.
   * 
   * @param input
   *          the input
   * @param output
   *          the output
   * @param deleteOldFile
   *          the delete old file
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static void uncompress(final String input, final String output,
      final boolean deleteOldFile) throws IOException {
    final File inFile = new File(input);
    final File outFile = new File(output);
    uncompress(inFile, outFile, deleteOldFile);
  }

  /**
   * Uncompress.
   * 
   * @param input
   *          the input
   * @param outPathDirector
   *          the out path director
   * @param deleteOldFile
   *          the delete old file
   * @param isDeteleIFFileExist
   *          the is detele if file exist
   * @return the string
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static String uncompress(final String input, final String outPathDirector,
      final boolean deleteOldFile, final boolean isDeteleIFFileExist) throws IOException {
    final StringBuilder str = new StringBuilder();
    str.append(outPathDirector);
    if (!outPathDirector.endsWith("/")) {
      str.append("/");
    }
    str.append(getNameFileSTDF(input));
    final String output = str.toString();
    final File in = new File(input);
    final File out = new File(output);
    if (!isDeteleIFFileExist && out.exists()) {
      return output;
    }
    uncompress(in, out, deleteOldFile);
    return output;
  }

  /**
   * Instantiates a new compressor utility.
   */
  private Compressors() {

  }
}
