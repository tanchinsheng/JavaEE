/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 25, 2012 11:02:54 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.mail;

import static com.st.scc.common.utils.DataValidation.checkGoodMail;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public final class MailUtil {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(MailUtil.class);

  /** The Constant DEFAULT_SMTP_PORT. */
  private static final int DEFAULT_SMTP_PORT = 25;

  /**
   * Gets the e-mails from input string.
   * 
   * @param input
   *          the email string
   * @return the e-mail list
   */
  public static String[] getEmails(final String input) {
    String email = input;
    if (email == null) {
      email = "";
    }
    email = email.trim(); // very important
    email = email.replace(',', ';'); // replace all occurrence of ',' to ';'
    final StringTokenizer t = new StringTokenizer(email, ";");
    final String[] ret = new String[t.countTokens()];
    int index = 0;
    while (t.hasMoreTokens()) {
      final String mail = t.nextToken().trim();
      if (checkGoodMail(mail)) {
        ret[index++] = mail;
      }
    }
    return ret;
  }

  /**
   * Gets the Internet address e-mails.
   * 
   * @param email
   *          the email
   * @return the Internet address e-mails
   * @throws AddressException
   *           the address exception
   */
  private static InternetAddress[] getInternetAddressEmails(final String email)
      throws AddressException {
    final String[] mails = getEmails(email);
    if (mails.length == 0) {
      return null; // must return null, not empty array
    }

    // log.debug("to = " + mails);
    final InternetAddress[] address = new InternetAddress[mails.length];
    for (int i = 0; i < mails.length; i++) {
      address[i] = new InternetAddress(mails[i]);
      // log.debug("to each element = " + mails[i]);
    }
    return address;
  }

  /**
   * Send mail.
   * 
   * @param mailList
   *          the mail list
   * @param serverInfo
   *          the server info
   * @throws MessagingException
   *           the messaging exception
   */
  public static void sendMail(final Collection<MailItem> mailList,
      final SMTPServerInfo serverInfo) throws MessagingException {

    Session session = null;
    Transport transport = null;
    String server = serverInfo.getHost();
    String userName = serverInfo.getUserName();
    String password = serverInfo.getPassword();
    int port = serverInfo.getPort() > 0 ? serverInfo.getPort() : DEFAULT_SMTP_PORT;

    String smtp = "smtp";
    if (serverInfo.isSecure()) {
      smtp = "smtps";
    }

    try {
      for (final MailItem mailItem : mailList) {
        if (transport == null || session == null) {
          final Properties props = new Properties();

          // Local host name used in the SMTP HELO or EHLO command
          try {
            if (InetAddress.getLocalHost().getHostName() == null) {
              props.put("mail." + smtp + ".localhost", server);
            }
          } catch (final UnknownHostException e) {
            props.put("mail." + smtp + ".localhost", server);
          }
          props.put("mail." + smtp + ".host", server);
          props.put("mail." + smtp + ".port", String.valueOf(port));
          if (userName != null && userName.length() > 0) {
            props.put("mail." + smtp + ".auth", "true");
          }
          if (LOG.isDebugEnabled()) {
            props.put("mail.debug", true);
          }
          session = Session.getInstance(props, null);
          transport = session.getTransport(smtp);

          if (userName != null && userName.length() > 0) {
            transport.connect(server, userName, password);
          } else {
            transport.connect();
          }
        }

        final String from = mailItem.getFrom();
        final String fromDisplayName = mailItem.getFromDisplayName();
        final String to = mailItem.getTo();
        final String cc = mailItem.getCc();
        final String bcc = mailItem.getBcc();
        final String subject = mailItem.getSubject();
        final String message = mailItem.getMessage();

        try {
          // this will also check for email error
          InternetAddress fromAddress = null;
          if (checkGoodMail(from)) {
            if (fromDisplayName == null) {
              fromAddress = new InternetAddress(from);
            } else {
              try {
                fromAddress = new InternetAddress(from, fromDisplayName);
              } catch (final UnsupportedEncodingException e) {
                if (LOG.isDebugEnabled()) {
                  LOG.debug(e.getMessage(), e);
                }
              }
            }
          }
          final InternetAddress[] toAddress = getInternetAddressEmails(to);
          final InternetAddress[] ccAddress = getInternetAddressEmails(cc);
          final InternetAddress[] bccAddress = getInternetAddressEmails(bcc);
          if (toAddress == null && ccAddress == null && bccAddress == null) {
            throw new IllegalArgumentException(
                "Cannot send mail because all To, Cc, Bcc addresses are empty.");
          }

          // create a message
          final MimeMessage msg = new MimeMessage(session);
          msg.setSentDate(new Date());
          msg.setFrom(fromAddress);

          if (toAddress != null) {
            msg.setRecipients(Message.RecipientType.TO, toAddress);
          }
          if (ccAddress != null) {
            msg.setRecipients(Message.RecipientType.CC, ccAddress);
          }
          if (bccAddress != null) {
            msg.setRecipients(Message.RecipientType.BCC, bccAddress);
          }

          if (!mailItem.isSendAsHtml()) {
            msg.setSubject(subject, "UTF-8");
            msg.setText(message, "UTF-8");
          } else {
            // Below code is use for unicode
            final MimeBodyPart messageBodyPart = new MimeBodyPart();
            msg.setSubject(subject, "UTF-8");
            messageBodyPart.setText(message, "UTF-8", "html");
            messageBodyPart.setHeader("Content-Type", "text/html;charset=UTF-8");
            messageBodyPart.setHeader("Content-Transfer-Encoding", "quoted-printable");
            final MimeMultipart multipart = new MimeMultipart("alternative");
            multipart.addBodyPart(messageBodyPart);
            msg.setContent(multipart);
          }
          msg.saveChanges();

          transport.sendMessage(msg, msg.getAllRecipients());

        } catch (final SendFailedException ex) {
          LOG.error("SendFailedException has occured.", ex);
          LOG.warn("SendFailedException has occured. Detail info:");
          LOG.warn("from = " + from);
          LOG.warn("to = " + to);
          LOG.warn("cc = " + cc);
          LOG.warn("bcc = " + bcc);
          LOG.warn("subject = " + subject);
          LOG.info("message = " + message);
        } catch (final MessagingException mex) {
          throw mex;
        }
      } // for
    } finally {
      try {
        if (transport != null) {
          transport.close();
        }
      } catch (final MessagingException ex) {
        LOG.error(ex.getMessage(), ex);
      }
    }
  }

  /**
   * Send mail.
   * 
   * @param mailItem
   *          the mail item
   * @param serverInfo
   *          the server info
   * @throws MessagingException
   *           the messaging exception
   */
  public static void sendMail(final MailItem mailItem, final SMTPServerInfo serverInfo)
      throws MessagingException {

    final List<MailItem> mailList = new ArrayList<MailItem>(1);
    mailList.add(mailItem);
    sendMail(mailList, serverInfo);
  }

  /**
   * Instantiates a new mail utility.
   */
  private MailUtil() {

  }
}
