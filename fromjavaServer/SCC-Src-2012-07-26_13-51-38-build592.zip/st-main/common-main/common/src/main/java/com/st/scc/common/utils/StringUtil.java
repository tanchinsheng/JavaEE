package com.st.scc.common.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Collection;
import java.util.StringTokenizer;

/**
 * The Class StringUtil.
 */
public final class StringUtil {

  /**
   * Byte to binary string.
   * 
   * @param value
   *          the value
   * @return the string
   */
  public static String byteToBinaryString(final short value) {
    int a = value & 0xff;
    final char[] digits = new char[]{'0', '1' };
    final char[] buf = new char[8];
    int charPos = 8;
    do {
      buf[--charPos] = digits[a & 1];
      a >>>= 1;
    } while (a != 0);
    for (int i = charPos - 1; i >= 0; i--) {
      buf[i] = '0';
    }
    return new String(buf);
  }

  /**
   * Gets the empty if null.
   * 
   * @param obj
   *          the object
   * @return the empty if null
   */
  public static String getEmptyIfNull(final Object obj) {
    return obj != null ? obj.toString() : "";
  }

  /**
   * Gets the empty string if null.
   * 
   * @param s
   *          the s
   * @return the empty if null
   */
  public static String getEmptyIfNull(final String s) {
    return s != null ? s : "";
  }

  /**
   * Gets the valid string with given length.
   * 
   * @param string
   *          the string
   * @param length
   *          the length
   * @return the valid string
   */
  public static String getValidString(final String string, final int length) {
    String s = "";
    if (string != null) {
      s = string.trim();
      if (s.length() > length) {
        s = s.substring(0, length);
      }
    }
    return s;
  }

  /**
   * Checks if is null or empty.
   * 
   * @param str
   *          the string
   * @return true, if is null or empty
   */
  public static boolean isNullOrEmpty(final String str) {
    return str == null || str.length() == 0;
  }

  /**
   * Split string to array of strings.
   * 
   * @param input
   *          the input
   * @param delim
   *          the delim
   * @return the string[]
   */
  public static String[] split(final String input, final String delim) {
    String str = input;
    if (str == null) {
      str = "";
    }
    str = str.trim();
    final StringTokenizer t = new StringTokenizer(str, delim);
    final String[] ret = new String[t.countTokens()];
    int index = 0;
    while (t.hasMoreTokens()) {
      final String token = t.nextToken().trim();
      ret[index++] = token;
    }
    return ret;
  }

  /**
   * Test string is number or not ?.
   * 
   * @param str
   *          the string
   * @return true, if successful
   */
  public static boolean stringIsNumber(final String str) {
    String temp = "";
    if (str == null || str.length() == 0) {
      return false;
    }
    if (str.charAt(0) == '-') {
      temp = str.substring(1);
    } else {
      temp = str;
    }
    for (int i = 0; i < temp.length(); i++) {
      final char a = temp.charAt(i);
      if (a > '9' || a < '0') {
        return false;
      }
    }
    return true;
  }

  /**
   * To trimmed string.
   * 
   * @param collection
   *          the collection
   * @param separator
   *          the separator
   * @return the string
   */
  @SuppressWarnings("rawtypes")
  public static String toTrimmedString(final Collection collection, final String separator) {
    final StringBuilder sb = new StringBuilder();
    for (final Object obj : collection) {
      if (obj != null) {
        if (sb.length() != 0) {
          sb.append(separator).append(obj.toString().trim());
        } else {
          sb.append(obj.toString().trim());
        }
      }
    }
    return sb.toString();
  }

  /**
   * To string.
   * 
   * @param aThrowable
   *          the a throwable
   * @return the string
   */
  public static String toString(final Throwable aThrowable) {
    final Writer result = new StringWriter();
    final PrintWriter printWriter = new PrintWriter(result);
    aThrowable.printStackTrace(printWriter);
    return result.toString();
  }

  /**
   * Instantiates a new string utility.
   */
  private StringUtil() {

  }
}
