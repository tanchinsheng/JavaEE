/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Aug 11, 2011 10:30:10 AM - nghiatn - Initialize version
/********************************************************************************/
package com.st.common.compress.base;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public class CodeTable {
  /** For dynamic table sizing. */
  private short[] tab;

  /**
   * create array tab. Constructor.
   */
  public CodeTable() {
    tab = new short[Constant.HSIZE];
  }

  /**
   * convert short to non-negative integer . 
   * int result = tab[i]; if (tab[i] < 0) { result = (1<<16)+tab[i]; } return result.
   * 
   * @param i
   *          is element in tab.
   * @return value tab[i].
   */
  public int get(final int i) {
    int j = tab[i];
    return (j << Constant.TWO_BYTE >>> Constant.TWO_BYTE);
  }

  /**
   * set tab[i] = v.
   * 
   * @param i is element of tab.
   * @param v assign tab[i] = v.
   */
  public void set(final int i, final int v) {
    tab[i] = (short) v;
  }

  /**
   * clear tab from 0->size.
   * 
   * @param size
   *          is size.
   */
  public void clear(final int size) {
    int code;
    for (code = 0; code < size; code++) {
      tab[code] = 0;
    }
  }
}
