/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 24, 2011 4:23:34 PM - nghiatn - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.st.common.beans.FileInfo;

/**
 * The Class SFTPUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class SFTPUtils {

  /** The Constant LOG. */
  private static final Logger LOG = LoggerFactory.getLogger(SFTPUtils.class);

  /** The Constant CONNECT_TIMEOUT. */
  public static final int CONNECT_TIMEOUT = 30000;

  /** The Constant DATA_TIMEOUT. */
  private static final int DATA_TIMEOUT = 5000;

  /** The Constant DEFAULT_SFTP_PORT. */
  private static final int DEFAULT_SFTP_PORT = 22;

  /**
   * Check available.
   * 
   * @param fileInfo
   *          the file info
   * @param channel
   *          the channel
   * @return true, if successful
   */
  @SuppressWarnings("unchecked")
  public static boolean checkAvailable(final FileInfo fileInfo, final ChannelSftp channel) {
    boolean result = false;
    try {
      if (channel != null && fileInfo != null) {
        final String pathFile = fileInfo.getPathFileName();
        String parent = "";
        String fileName = "";
        if (pathFile != null && pathFile.length() > 0) {
          final int slashIndex = pathFile.lastIndexOf("/");
          if (slashIndex > -1) {
            parent = pathFile.substring(0, slashIndex);
            fileName = pathFile.substring(slashIndex + 1);
          }
        }
        if (parent.length() > 0 && fileName.length() > 0) {
          final List<LsEntry> ls = listFiles(channel, parent); //channel.ls(parent);
          if (ls != null) {
            for (final LsEntry lsEntry : ls) {
              final SftpATTRS attrs = lsEntry.getAttrs();
              if (fileName.equals(lsEntry.getFilename()) && !attrs.isDir()
                  && attrs.getSize() > 0 && attrs.getSize() == fileInfo.getSize()) {
                result = true;
                break;
              }
            }
          }
        }
      }
    } catch (final SftpException e) {
      // No such file path
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    }
    return result;
  }

  /**
   * Creates the folder.
   * 
   * @param channel
   *          the channel
   * @param filePath
   *          the file path
   * @return true, if successful
   */
  public static boolean createFolder(final ChannelSftp channel, final String filePath) {
    boolean retVal = false;
    if (filePath == null || filePath.length() == 0) {
      LOG.warn("Create path {} on SFTP failed", filePath);
      return retVal;
    }
    final int index = filePath.lastIndexOf("/");
    String parentPath = "";
    if (index > -1) {
      parentPath = filePath.substring(0, index);
    } else {
      LOG.error("Path {} doesn't exist on SFTP", filePath);
      return retVal;
    }
    boolean exist = false;
    try {
      channel.cd(parentPath);
      exist = true;
    } catch (final SftpException e) {
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    }
    if (!exist) {
      final boolean parentExist = createFolder(channel, parentPath);
      if (parentExist) {
        try {
          channel.mkdir(parentPath);
          if (LOG.isDebugEnabled()) {
            LOG.debug("Create sucessfully directory=" + parentPath);
          }
          retVal = true;
        } catch (final SftpException e) {
          LOG.error("Create path {} on SFTP failed", parentPath);
        }
      } else {
        retVal = false;
      }
    } else {
      retVal = true;
    }
    return retVal;
  }

  /**
   * Creates the path.
   * 
   * @param channel
   *          the channel
   * @param pathFolder
   *          the path folder
   * @param directory
   *          the directory
   * @return true, if successful
   */
  public static boolean createPath(final ChannelSftp channel, final String pathFolder,
      final boolean directory) {
    final Pattern pa = Pattern.compile("/");
    final String[] tokens = pa.split(pathFolder);
    boolean retVal = true;
    int size = 0;
    if (directory) {
      size = tokens.length;
    } else {
      size = tokens.length - 1;
    }
    final StringBuilder sb = new StringBuilder(pathFolder.length());
    for (int i = 0; i < size; i++) {
      if (tokens[i] != null && tokens[i].length() > 0) {
        final String folder = sb.append("/").append(tokens[i]).toString();
        boolean change = true;
        try {
          if (change) {
            channel.cd(folder);
            retVal = true;
          }
        } catch (final SftpException e) {
          change = false;
        }
        if (!change) {
          try {
            channel.mkdir(folder);
            channel.cd(folder);
            retVal = true;
          } catch (final SftpException e) {
            retVal = false;
            LOG.error(e.getMessage(), e);
          }
        }
      }
      if (!retVal) {
        return retVal;
      }
    }
    return retVal;
  }

  /**
   * Creates the SSH session with default port 22.
   * 
   * @param host
   *          the host
   * @param userName
   *          the user name
   * @param password
   *          the password
   * @return the session
   */
  public static Session createSession(final String host, final String userName,
      final String password) {
    return createSession(host, userName, password, DEFAULT_SFTP_PORT);
  }

  /**
   * Creates the SSH session.
   * 
   * @param host
   *          the host
   * @param userName
   *          the user name
   * @param password
   *          the password
   * @param port
   *          the port
   * @return SftpCliento
   */
  public static Session createSession(final String host, final String userName,
      final String password, final int port) {
    Session session = null;
    final JSch jsch = new JSch();
    try {
      session = jsch.getSession(userName, host, port);
      session.setConfig("StrictHostKeyChecking", "no");
      session.setPassword(password);
      // session.connect(CONNECT_TIMEOUT);
      session.connect();
      session.setTimeout(DATA_TIMEOUT);
      LOG.info("Create SFTP session successfully, host={}, user={}", host, userName);
    } catch (final JSchException e) {
      LOG.error("Could not create session for SFTP", e);
    }
    return session;
  }

  /**
   * Delete file.
   * 
   * @param channel
   *          the channel
   * @param remoteFile
   *          the remote file
   * @return true, if successful
   */
  public static boolean deleteFile(final ChannelSftp channel, final String remoteFile) {
    boolean retVal = false;
    if (channel != null && channel.isConnected()) {
      try {
        channel.rm(remoteFile);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Delete file {} successfully", remoteFile);
        }
        retVal = true;
      } catch (final SftpException e) {
        LOG.error("Error occurred while deleting file, remote file=" + remoteFile, e);
      }
    }
    return retVal;
  }

  /**
   * Delete file.
   * 
   * @param channel
   *          the channel
   * @param remoteFile
   *          the remote file
   * @param writeLog
   *          the write log
   * @return true, if successful
   * @throws SftpException
   *           the SFTP exception
   */
  public static boolean deleteFile(final ChannelSftp channel, final String remoteFile,
      final boolean writeLog) throws SftpException {
    boolean retVal = false;
    if (writeLog) {
      retVal = deleteFile(channel, remoteFile);
    } else {
      if (channel != null && channel.isConnected()) {
        channel.rm(remoteFile);
        retVal = true;
      }
    }
    return retVal;
  }

  /**
   * Delete non-empty folder.
   * 
   * @param channel
   *          the channel
   * @param remotePath
   *          the remote path
   */
  @SuppressWarnings("unchecked")
  public static void deleteFolder(final ChannelSftp channel, final String remotePath) {
    try {
      final List<LsEntry> vector = listFiles(channel, remotePath); // channel.ls(remotePath);
      if (vector == null) {
        LOG.error("Can't get list path " + remotePath);
        return;
      }
      for (final LsEntry entry : vector) {
        //in SFTP, if folder is empty, it has always 2 value: '.' and '..' 
        final String fileName = entry.getFilename();
        if (".".equals(fileName) || "..".equals(fileName)) {
          continue;
        }
        final StringBuilder sb = new StringBuilder();
        if (remotePath.endsWith("/")) {
          sb.append(remotePath).append(fileName);
        } else {
          sb.append(remotePath).append("/").append(fileName);
        }
        final String pathFileName = sb.toString();
        final SftpATTRS attrs = entry.getAttrs();
        if (attrs.isDir()) {
          deleteFolder(channel, pathFileName);
        } else {
          channel.rm(pathFileName);
        }
      }
      //remove this folder.
      channel.rmdir(remotePath);
      if (LOG.isDebugEnabled()) {
        LOG.debug("Delete folder=" + remotePath + " successfully");
      }
    } catch (final SftpException e) {
      LOG.error("Error occured while deleting folder, remote path=" + remotePath, e);
    }
  }

  /**
   * Disconnect.
   * 
   * @param session
   *          the session
   */
  public static void disconnect(final Session session) {
    if (session != null) {
      session.disconnect();
      LOG.info("Disconnect SFTP successfully.");
    }
  }

  /**
   * download from SFTP to local.
   * 
   * @param channel
   *          the channel
   * @param src
   *          the src
   * @param dest
   *          the dest
   * @return true, if successful
   */
  public static boolean download(final ChannelSftp channel, final String src, final String dest) {
    boolean retVal = false;
    if (channel != null && channel.isConnected()) {
      try {
        channel.get(src, dest);
        retVal = true;
      } catch (final SftpException e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return retVal;
  }

  /**
   * Check the given path exists or not.
   * 
   * @param pathFile
   *          the path file
   * @param channel
   *          the channel
   * @return true, if successful
   */
  @SuppressWarnings("unchecked")
  public static boolean exists(final String pathFile, final ChannelSftp channel) {
    boolean result = false;
    try {
      if (channel != null && pathFile != null) {
        String parent = "";
        String fileName = "";
        if (pathFile.length() > 0) {
          final int slashIndex = pathFile.lastIndexOf("/");
          if (slashIndex > -1) {
            parent = pathFile.substring(0, slashIndex);
            fileName = pathFile.substring(slashIndex + 1);
          }
        }
        if (parent.length() > 0 && fileName.length() > 0) {
          final List<LsEntry> ls = SFTPUtils.listFiles(channel, parent); // channel.ls(parent);
          if (ls != null) {
            for (final LsEntry lsEntry : ls) {
              if (fileName.equals(lsEntry.getFilename()) && !lsEntry.getAttrs().isDir()) {
                result = true;
                break;
              }
            }
          }
        }
      }
    } catch (final SftpException e) {
      // No such file path
      if (LOG.isDebugEnabled()) {
        LOG.debug(e.getMessage(), e);
      }
    }
    return result;
  }

  /**
   * Check the given path exists or not.
   * 
   * @param pathFile
   *          the path file
   * @param session
   *          the session
   * @return true, if successful
   */
  public static boolean exists(final String pathFile, final Session session) {
    boolean result = false;
    if (session != null) {
      final ChannelSftp channel = openChannel(session);
      if (channel != null) {
        result = exists(pathFile, channel);
        channel.disconnect();
      }
    }
    return result;
  }

  /**
   * Move file on SFTP.
   * 
   * @param channel
   *          the channel
   * @param sourceFile
   *          the source file
   * @param destFile
   *          the dest file
   * @return true, if successful
   */
  public static boolean moveFileOnSFTP(final ChannelSftp channel, final String sourceFile,
      final String destFile) {
    int i = 0;
    int posOfPath = 0;
    // Get the same position of 2 file path.
    for (i = 0; i < sourceFile.length() && i < destFile.length(); i++) {
      if (sourceFile.charAt(i) != destFile.charAt(i)) {
        break;
      } else {
        if (sourceFile.charAt(i) == '/') {
          posOfPath = i;
        }
      }

    }
    final String newSourcePath = sourceFile.substring(posOfPath + 1);
    // Count number parent directory
    int numberParent = 0;
    for (i = 0; i < newSourcePath.length(); i++) {
      if (newSourcePath.charAt(i) == '/') {
        numberParent++;
      }
    }
    final String newDestPath = destFile.substring(posOfPath + 1);
    final StringBuilder newPath = new StringBuilder();
    for (i = 0; i < numberParent; i++) {
      newPath.append("../");
    }
    newPath.append(newDestPath);
    final int lastPath = sourceFile.lastIndexOf("/");
    final String currentPath = sourceFile.substring(0, lastPath);
    try {
      channel.cd(currentPath);
      channel.rename(sourceFile.substring(lastPath + 1), newPath.toString());
      return true;
    } catch (final SftpException e) {
      LOG.error(e.getMessage(), e);
    }
    return false;
  }

  /**
   * Open channel.
   * 
   * @param session
   *          the session
   * @return the channel sftp
   */
  public static ChannelSftp openChannel(final Session session) {
    ChannelSftp channel = null;
    if (session != null && session.isConnected()) {
      try {
        channel = (ChannelSftp) session.openChannel("sftp");
        channel.connect();
      } catch (final JSchException e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return channel;
  }

  /**
   * Rename a file on the remote computer.
   * 
   * @param channel
   *          the channel
   * @param oldpath
   *          the old path
   * @param newpath
   *          the new path
   * @return true, if successful
   */
  public static boolean rename(final ChannelSftp channel, final String oldpath,
      final String newpath) {
    boolean retVal = false;
    if (channel != null && channel.isConnected()) {
      final String parent = FileUtils.getParent(newpath);
      try {
        channel.mkdir(parent);
        channel.rename(oldpath, newpath);
        retVal = true;
      } catch (final SftpException e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return retVal;
  }

  /**
   * upload from local to sftp.
   * 
   * @param channel
   *          the channel
   * @param src
   *          the local source file
   * @param dest
   *          file destination, location on SFTP you want to upload.
   * @return true, if successful
   */
  public static boolean upload(final ChannelSftp channel, final String src, final String dest) {
    boolean retVal = false;
    if (channel != null && channel.isConnected()) {
      try {
        createFolder(channel, dest);
        channel.put(src, dest);
        retVal = true;
        if (LOG.isDebugEnabled()) {
          LOG.debug("Upload file {} to SFTP {} successfully", src, dest);
        }
      } catch (final SftpException e) {
        LOG.error(e.getMessage(), e);
      }
    }
    return retVal;
  }

  /**
   * List all files or folder in path.
   * @param channel
   * @param path
   * @return
   * @throws SftpException
   */
  public static List<LsEntry> listFiles(final ChannelSftp channel, final String path)
      throws SftpException {
    if (channel != null) {
      Vector<LsEntry> vector = channel.ls(path);
      if (vector != null) {
        List<LsEntry> list = new ArrayList<LsEntry>();
        for (LsEntry lsEntry : vector) {
          if (!checkIgnoreFile(lsEntry.getFilename())) {
            list.add(lsEntry);
          }
        }
        vector = null;
        return list;
      }
    }
    return null;
  }
  
  /**
   * Check this file whether is ignored. Folder has name is '.' or '..', must
   * ignore it.
   * 
   * @param fileName
   * @return
   */
  public static boolean checkIgnoreFile(String fileName) {
    // SFTP, when list folder, have '.' and '..', must skip them
    if (".".equals(fileName) || "..".equals(fileName)) {
      return true;
    }
    return false;
  }
  
  /**
   * Instantiates a new SFTP utility.
   */
  private SFTPUtils() {
  }
}
