/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 25, 2012 11:01:12 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.mail;

/**
 * The Class MailItem.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class MailItem {

  /** The from. */
  private String from;

  /** The from display name. */
  private String fromDisplayName;

  /** The to. */
  private String to;

  /** The cc. */
  private String cc;

  /** The bcc. */
  private String bcc;

  /** The subject. */
  private String subject;

  /** The message. */
  private String message;

  /** The send as html. */
  private boolean sendAsHtml = false;

  /**
   * Instantiates a new mail item.
   */
  public MailItem() {
  }

  /**
   * Gets the bcc.
   * 
   * @return the bcc
   */
  public String getBcc() {
    return bcc;
  }

  /**
   * Gets the cc.
   * 
   * @return the cc
   */
  public String getCc() {
    return cc;
  }

  /**
   * Gets the from.
   * 
   * @return the from
   */
  public String getFrom() {
    return from;
  }

  /**
   * Gets the from display name.
   * 
   * @return the from display name
   */
  public String getFromDisplayName() {
    return fromDisplayName;
  }

  /**
   * Gets the message.
   * 
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * Gets the subject.
   * 
   * @return the subject
   */
  public String getSubject() {
    return subject;
  }

  /**
   * Gets the to.
   * 
   * @return the to
   */
  public String getTo() {
    return to;
  }

  /**
   * Checks if is send as html.
   * 
   * @return true, if is send as html
   */
  public boolean isSendAsHtml() {
    return sendAsHtml;
  }

  /**
   * Sets the bcc.
   * 
   * @param bcc
   *          the new bcc
   */
  public void setBcc(final String bcc) {
    this.bcc = bcc;
  }

  /**
   * Sets the cc.
   * 
   * @param cc
   *          the new cc
   */
  public void setCc(final String cc) {
    this.cc = cc;
  }

  /**
   * Sets the from.
   * 
   * @param from
   *          the new from
   */
  public void setFrom(final String from) {
    this.from = from;
  }

  /**
   * Sets the from display name.
   * 
   * @param fromDisplayName
   *          the new from display name
   */
  public void setFromDisplayName(final String fromDisplayName) {
    this.fromDisplayName = fromDisplayName;
  }

  /**
   * Sets the message.
   * 
   * @param message
   *          the new message
   */
  public void setMessage(final String message) {
    this.message = message;
  }

  /**
   * Sets the send as html.
   * 
   * @param sendAsHtml
   *          the new send as html
   */
  public void setSendAsHtml(final boolean sendAsHtml) {
    this.sendAsHtml = sendAsHtml;
  }

  /**
   * Sets the subject.
   * 
   * @param subject
   *          the new subject
   */
  public void setSubject(final String subject) {
    this.subject = subject;
  }

  /**
   * Sets the to.
   * 
   * @param to
   *          the new to
   */
  public void setTo(final String to) {
    this.to = to;
  }

}
