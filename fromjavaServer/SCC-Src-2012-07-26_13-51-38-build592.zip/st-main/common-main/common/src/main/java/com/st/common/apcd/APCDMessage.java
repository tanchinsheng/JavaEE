/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jan 18, 2012 1:30:04 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.apcd;

import static com.st.scc.common.utils.StringUtil.getValidString;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * The Class APCDMessage.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class APCDMessage {

  /** The Constant TIME_PATTERN. */
  private static final String TIME_PATTERN = "MM/dd/yy HH:mm:ss";

  /** The cmd. */
  private String cmd;

  /** The mid. */
  private String mid;

  /** The mty. */
  private String mty;

  /** The ecd. */
  private int ecd;

  /** The etx. */
  private String etx;

  /** The alarm id. */
  private int alarmId;

  /** The alarm state. */
  private int alarmState;

  /** The alarm text. */
  private String alarmText;

  /** The event text. */
  private String eventText;

  /** The event id. */
  private String eventId;

  /** The lot. */
  private String lot;

  /** The current wadfer id. */
  private String currentWaferId;

  /** The operations. */
  private String operations;

  /** The flow id. */
  private String flowId;

  /** The prober name. */
  private String proberName;

  /** The job name. */
  private String jobName;

  /** The pp exec name. */
  private String ppExecName;

  /** The jig id. */
  private String jigId;

  /** The curr probe card name. */
  private String currProbeCardName;

  /** The wafer flat angle. */
  private int waferFlatAngle;

  /** The wafer chuck temp. */
  private int waferChuckTemp;

  /** The pass die count. */
  private int passDieCount;

  /** The fail die count. */
  private int failDieCount;

  /** The ugly die count. */
  private int uglyDieCount;

  /** The probe card cont cnt. */
  private int probeCardContCnt;

  /** The port. */
  private int port;

  /** The facility. */
  private String facility;

  /** The user. */
  private String user;

  /** The product. */
  private String product;

  /** The route. */
  private String route;

  /** The tester name. */
  private String testerName;

  /** The test prog name. */
  private String testProgName;

  /** The test prog ver. */
  private String testProgVer;

  /** The map server. */
  private String mapServer;

  /** The map dir. */
  private String mapDir;

  /** The map id. */
  private String mapId;

  /** The new map id. */
  private String newMapId;

  /** The date time. */
  private String dateTime;

  /** The lots. */
  private String lots;

  /** The secs recipe name. */
  private String secsRecipeName;

  /** The CARD_ID list. */
  private final List<String> cardIdList;

  /** The wafer id list. */
  private final List<String> waferIdList;

  /**
   * Instantiates a new aPCD message.
   */
  public APCDMessage() {
    cmd = "";
    mid = "";
    mty = "";
    etx = "";
    alarmText = "";
    eventId = "";
    eventText = "";
    lot = "";
    currentWaferId = "";
    operations = "";
    flowId = "";
    proberName = "";
    jobName = "";
    ppExecName = "";
    jigId = "";
    currProbeCardName = "";
    facility = "";
    user = "";
    product = "";
    route = "";
    testerName = "";
    testProgName = "";
    testProgVer = "";
    mapServer = "";
    mapDir = "";
    mapId = "";
    newMapId = "";
    dateTime = "";
    lots = "";
    secsRecipeName = "";

    cardIdList = new ArrayList<String>();
    waferIdList = new ArrayList<String>();
  }

  /**
   * Builds the alarm message.
   * 
   * @return the string
   */
  public String buildAlarmMessage() {
    final StringBuilder sb = new StringBuilder(512);
    sb.append("CMD/A=\"").append(getCmd()).append("\"").append(" ");
    sb.append("MID/A=\"").append(getMid()).append("\"").append(" ");
    sb.append("MTY/A=\"").append(getMty()).append("\"").append(" ");
    sb.append("ECD/U4=").append(getEcd()).append(" ");
    sb.append("ETX/A=\"").append(getEtx()).append("\" ");
    sb.append("ALARM_ID/I4=").append(getAlarmId()).append(" ");
    sb.append("ALARM_STATE/U1=").append(getAlarmState()).append(" ");
    sb.append("ALARM_TEXT/A=\"").append(getAlarmText()).append("\" ");
    sb.append("EVENT_ID/A=\"").append(getEventId()).append("\"").append(" ");
    sb.append("LOT/A=\"").append(getLot()).append("\" ");
    sb.append("CURRENT_WAFER_ID/A=\"").append(getCurrentWaferId()).append("\" ");
    sb.append("OPERATIONS/A=\"").append(getOperations()).append("\" ");
    sb.append("FLOW_ID/A=\"").append(getFlowId()).append("\" ");
    sb.append("PROBER_NAME/A=\"").append(getProberName()).append("\" ");
    sb.append("JOB_NAME/A=\"").append(getJobName()).append("\" ");
    sb.append("PPEXECNAME/A=\"").append(getPpExecName()).append("\" ");
    sb.append("JIG_ID/A=\"").append(getJigId()).append("\" ");
    sb.append("CURR_PROBE_CARD_NAME/A=\"").append(getCurrProbeCardName()).append("\" ");
    sb.append("WAFER_FLAT_ANGLE/U4=").append(getWaferFlatAngle()).append(" ");
    sb.append("WAFER_CHUCK_TEMP/U4=").append(getWaferChuckTemp()).append(" ");
    sb.append("PASS_DIE_COUNT/U4=").append(getPassDieCount()).append(" ");
    sb.append("FAIL_DIE_COUNT/U4=").append(getFailDieCount()).append(" ");
    sb.append("UGLY_DIE_COUNT/U4=").append(getUglyDieCount()).append(" ");
    sb.append("PROBE_CARD_CONT_CNT/U4=").append(getProbeCardContCnt()).append(" ");
    sb.append("PORT/U1=").append(getPort()).append(" ");
    sb.append("FACILITY/A=\"").append(getFacility()).append("\" ");
    sb.append("USER/A=\"").append(getUser()).append("\" ");
    sb.append("PRODUCT/A=\"").append(getProduct()).append("\" ");
    sb.append("ROUTE/A=\"").append(getRoute()).append("\" ");
    sb.append("TESTER_NAME/A=\"").append(getTesterName()).append("\" ");
    sb.append("TEST_PROG_NAME/A=\"").append(getTestProgName()).append("\" ");
    sb.append("TEST_PROG_VER/A=\"").append(getTestProgVer()).append("\" ");
    sb.append("MAP_SERVER/A=\"").append(getMapServer()).append("\" ");
    sb.append("MAP_DIR/A=\"").append(getMapDir()).append("\" ");
    sb.append("MAP_ID/A=\"").append(getMapId()).append("\" ");
    sb.append("NEW_MAP_ID/A=\"").append(getNewMapId()).append("\" ");
    sb.append("DATE_TIME/A=\"").append(getDateTime()).append("\" ");
    sb.append("LOTS/A[1]=[\"").append(getLots()).append("\"] ");
    sb.append("SECS_RECIPE_NAME/A[1]=[\"").append(getSecsRecipeName()).append("\"]");
    return sb.toString();
  }

  /**
   * Builds the event message.
   * 
   * @return the string
   */
  public String buildEventMessage() {
    final StringBuilder sb = new StringBuilder(512);
    sb.append("CMD/A=\"").append(getCmd()).append("\"").append(" ");
    sb.append("MID/A=\"").append(getMid()).append("\"").append(" ");
    sb.append("MTY/A=\"").append(getMty()).append("\"").append(" ");
    sb.append("ECD/U4=").append(getEcd()).append(" ");
    sb.append("ETX/A=\"").append(getEtx()).append("\" ");
    sb.append("EVENT_ID/A=\"").append(getEventId()).append("\" ");
    sb.append("EVENT_TEXT/A=\"").append(getEventText()).append("\" ");
    sb.append("LOT/A=\"").append(getLot()).append("\" ");
    sb.append("CURRENT_WAFER_ID/A=\"").append(getCurrentWaferId()).append("\" ");
    sb.append("OPERATIONS/A=\"").append(getOperations()).append("\" ");
    sb.append("FLOW_ID/A=\"").append(getFlowId()).append("\" ");
    sb.append("PROBER_NAME/A=\"").append(getProberName()).append("\" ");
    sb.append("JOB_NAME/A=\"").append(getJobName()).append("\" ");
    sb.append("PPEXECNAME/A=\"").append(getPpExecName()).append("\" ");
    sb.append("JIG_ID/A=\"").append(getJigId()).append("\" ");
    sb.append("CURR_PROBE_CARD_NAME/A=\"").append(getCurrProbeCardName()).append("\" ");
    sb.append("WAFER_FLAT_ANGLE/U4=").append(getWaferFlatAngle()).append(" ");
    sb.append("WAFER_CHUCK_TEMP/U4=").append(getWaferChuckTemp()).append(" ");
    sb.append("PASS_DIE_COUNT/U4=").append(getPassDieCount()).append(" ");
    sb.append("FAIL_DIE_COUNT/U4=").append(getFailDieCount()).append(" ");
    sb.append("UGLY_DIE_COUNT/U4=").append(getUglyDieCount()).append(" ");
    sb.append("PROBE_CARD_CONT_CNT/U4=").append(getProbeCardContCnt()).append(" ");
    sb.append("PORT/U1=").append(getPort()).append(" ");
    sb.append("FACILITY/A=\"").append(getFacility()).append("\" ");
    sb.append("USER/A=\"").append(getUser()).append("\" ");
    sb.append("PRODUCT/A=\"").append(getProduct()).append("\" ");
    sb.append("ROUTE/A=\"").append(getRoute()).append("\" ");
    sb.append("TESTER_NAME/A=\"").append(getTesterName()).append("\" ");
    sb.append("TEST_PROG_NAME/A=\"").append(getTestProgName()).append("\" ");
    sb.append("TEST_PROG_VER/A=\"").append(getTestProgVer()).append("\" ");
    sb.append("MAP_SERVER/A=\"").append(getMapServer()).append("\" ");
    sb.append("MAP_DIR/A=\"").append(getMapDir()).append("\" ");
    sb.append("MAP_ID/A=\"").append(getMapId()).append("\" ");
    sb.append("NEW_MAP_ID/A=\"").append(getNewMapId()).append("\" ");
    sb.append("DATE_TIME/A=\"").append(getDateTime()).append("\" ");
    sb.append("LOTS/A[1]=[\"").append(getLots()).append("\"] ");
    sb.append("SECS_RECIPE_NAME/A[1]=[\"").append(getSecsRecipeName()).append("\"]");
    return sb.toString();
  }

  /**
   * Gets the alarm id.
   * 
   * @return the alarm id
   */
  public int getAlarmId() {
    return alarmId;
  }

  /**
   * Gets the alarm state.
   * 
   * @return the alarm state
   */
  public int getAlarmState() {
    return alarmState;
  }

  /**
   * Gets the alarm text.
   * 
   * @return the alarm text
   */
  public String getAlarmText() {
    return alarmText;
  }

  /**
   * Gets the CARD_ID list.
   * 
   * @return the CARD_ID list
   */
  public List<String> getCardIdList() {
    return cardIdList;
  }

  /**
   * Gets the cmd.
   * 
   * @return the cmd
   */
  public String getCmd() {
    return cmd;
  }

  /**
   * Gets the current wafer id.
   * 
   * @return the current wafer id
   */
  public String getCurrentWaferId() {
    return currentWaferId;
  }

  /**
   * Gets the curr probe card name.
   * 
   * @return the curr probe card name
   */
  public String getCurrProbeCardName() {
    return currProbeCardName;
  }

  /**
   * Gets the date time.
   * 
   * @return the date time
   */
  public String getDateTime() {
    return dateTime;
  }

  /**
   * Gets the ecd.
   * 
   * @return the ecd
   */
  public int getEcd() {
    return ecd;
  }

  /**
   * Gets the etx.
   * 
   * @return the etx
   */
  public String getEtx() {
    return etx;
  }

  /**
   * Gets the event id.
   * 
   * @return the event id
   */
  public String getEventId() {
    return eventId;
  }

  /**
   * Gets the event text.
   * 
   * @return the event text
   */
  public String getEventText() {
    return eventText;
  }

  /**
   * Gets the facility.
   * 
   * @return the facility
   */
  public String getFacility() {
    return facility;
  }

  /**
   * Gets the fail die count.
   * 
   * @return the fail die count
   */
  public int getFailDieCount() {
    return failDieCount;
  }

  /**
   * Gets the flow id.
   * 
   * @return the flow id
   */
  public String getFlowId() {
    return flowId;
  }

  /**
   * Gets the jig id.
   * 
   * @return the jig id
   */
  public String getJigId() {
    return jigId;
  }

  /**
   * Gets the job name.
   * 
   * @return the job name
   */
  public String getJobName() {
    return jobName;
  }

  /**
   * Gets the lot.
   * 
   * @return the lot
   */
  public String getLot() {
    return lot;
  }

  /**
   * Gets the lots.
   * 
   * @return the lots
   */
  public String getLots() {
    return lots;
  }

  /**
   * Gets the map dir.
   * 
   * @return the map dir
   */
  public String getMapDir() {
    return mapDir;
  }

  /**
   * Gets the map id.
   * 
   * @return the map id
   */
  public String getMapId() {
    return mapId;
  }

  /**
   * Gets the map server.
   * 
   * @return the map server
   */
  public String getMapServer() {
    return mapServer;
  }

  /**
   * Gets the mid.
   * 
   * @return the mid
   */
  public String getMid() {
    return mid;
  }

  /**
   * Gets the mty.
   * 
   * @return the mty
   */
  public String getMty() {
    return mty;
  }

  /**
   * Gets the new map id.
   * 
   * @return the new map id
   */
  public String getNewMapId() {
    return newMapId;
  }

  /**
   * Gets the operations.
   * 
   * @return the operations
   */
  public String getOperations() {
    return operations;
  }

  /**
   * Gets the pass die count.
   * 
   * @return the pass die count
   */
  public int getPassDieCount() {
    return passDieCount;
  }

  /**
   * Gets the port.
   * 
   * @return the port
   */
  public int getPort() {
    return port;
  }

  /**
   * Gets the pp exec name.
   * 
   * @return the pp exec name
   */
  public String getPpExecName() {
    return ppExecName;
  }

  /**
   * Gets the probe card cont cnt.
   * 
   * @return the probe card cont cnt
   */
  public int getProbeCardContCnt() {
    return probeCardContCnt;
  }

  /**
   * Gets the prober name.
   * 
   * @return the prober name
   */
  public String getProberName() {
    return proberName;
  }

  /**
   * Gets the product.
   * 
   * @return the product
   */
  public String getProduct() {
    return product;
  }

  /**
   * Gets the route.
   * 
   * @return the route
   */
  public String getRoute() {
    return route;
  }

  /**
   * Gets the secs recipe name.
   * 
   * @return the secs recipe name
   */
  public String getSecsRecipeName() {
    return secsRecipeName;
  }

  /**
   * Gets the tester name.
   * 
   * @return the tester name
   */
  public String getTesterName() {
    return testerName;
  }

  /**
   * Gets the test prog name.
   * 
   * @return the test prog name
   */
  public String getTestProgName() {
    return testProgName;
  }

  /**
   * Gets the test prog ver.
   * 
   * @return the test prog ver
   */
  public String getTestProgVer() {
    return testProgVer;
  }

  /**
   * Gets the ugly die count.
   * 
   * @return the ugly die count
   */
  public int getUglyDieCount() {
    return uglyDieCount;
  }

  /**
   * Gets the user.
   * 
   * @return the user
   */
  public String getUser() {
    return user;
  }

  /**
   * Gets the wafer chuck temp.
   * 
   * @return the wafer chuck temp
   */
  public int getWaferChuckTemp() {
    return waferChuckTemp;
  }

  /**
   * Gets the wafer flat angle.
   * 
   * @return the wafer flat angle
   */
  public int getWaferFlatAngle() {
    return waferFlatAngle;
  }

  /**
   * Gets the wafer id list.
   * 
   * @return the wafer id list
   */
  public List<String> getWaferIdList() {
    return waferIdList;
  }

  /**
   * Sets the alarm id.
   * 
   * @param alarmId
   *          the new alarm id
   */
  public void setAlarmId(final int alarmId) {
    this.alarmId = alarmId;
  }

  /**
   * Sets the alarm state.
   * 
   * @param alarmState
   *          the new alarm state
   */
  public void setAlarmState(final int alarmState) {
    this.alarmState = alarmState;
  }

  /**
   * Sets the alarm text.
   * 
   * @param alarmText
   *          the new alarm text
   */
  public void setAlarmText(final String alarmText) {
    this.alarmText = getValidString(alarmText, 132);
  }

  /**
   * Sets the cmd.
   * 
   * @param cmd
   *          the new cmd
   */
  public void setCmd(final String cmd) {
    this.cmd = getValidString(cmd, 21);
  }

  /**
   * Sets the current wafer id.
   * 
   * @param currentWaferId
   *          the new current wafer id
   */
  public void setCurrentWaferId(final String currentWaferId) {
    this.currentWaferId = getValidString(currentWaferId, 21);
  }

  /**
   * Sets the curr probe card name.
   * 
   * @param currProbeCardName
   *          the new curr probe card name
   */
  public void setCurrProbeCardName(final String currProbeCardName) {
    this.currProbeCardName = getValidString(currProbeCardName, 21);
  }

  /**
   * Sets the date time.
   * 
   * @param dateTime
   *          the new date time
   */
  public void setDateTime(final Date dateTime) {
    String s = "";
    if (dateTime != null) {
      final SimpleDateFormat dateFormat = new SimpleDateFormat(TIME_PATTERN);
      s = dateFormat.format(dateTime);
    }
    setDateTime(s);
  }

  /**
   * Sets the date time.
   * 
   * @param dateTime
   *          the new date time
   */
  public void setDateTime(final String dateTime) {
    this.dateTime = getValidString(dateTime, 26);
  }

  /**
   * Sets the ecd.
   * 
   * @param ecd
   *          the new ecd
   */
  public void setEcd(final int ecd) {
    this.ecd = ecd;
  }

  /**
   * Sets the etx.
   * 
   * @param etx
   *          the new etx
   */
  public void setEtx(final String etx) {
    this.etx = getValidString(etx, 132);
  }

  /**
   * Sets the event id.
   * 
   * @param eventId
   *          the new event id
   */
  public void setEventId(final String eventId) {
    this.eventId = getValidString(eventId, 33);
  }

  /**
   * Sets the event text.
   * 
   * @param eventText
   *          the new event text
   */
  public void setEventText(final String eventText) {
    this.eventText = getValidString(eventText, 132);
  }

  /**
   * Sets the facility.
   * 
   * @param facility
   *          the new facility
   */
  public void setFacility(final String facility) {
    this.facility = getValidString(facility, 8);
  }

  /**
   * Sets the fail die count.
   * 
   * @param failDieCount
   *          the new fail die count
   */
  public void setFailDieCount(final int failDieCount) {
    this.failDieCount = failDieCount;
  }

  /**
   * Sets the flow id.
   * 
   * @param flowId
   *          the new flow id
   */
  public void setFlowId(final String flowId) {
    this.flowId = getValidString(flowId, 21);
  }

  /**
   * Sets the jig id.
   * 
   * @param jigId
   *          the new jig id
   */
  public void setJigId(final String jigId) {
    this.jigId = getValidString(jigId, 21);
  }

  /**
   * Sets the job name.
   * 
   * @param jobName
   *          the new job name
   */
  public void setJobName(final String jobName) {
    this.jobName = getValidString(jobName, 21);
  }

  /**
   * Sets the lot.
   * 
   * @param lot
   *          the new lot
   */
  public void setLot(final String lot) {
    this.lot = getValidString(lot, 12);
  }

  /**
   * Sets the lots.
   * 
   * @param lots
   *          the new lots
   */
  public void setLots(final String lots) {
    this.lots = getValidString(lots, 12);
  }

  /**
   * Sets the map dir.
   * 
   * @param mapDir
   *          the new map dir
   */
  public void setMapDir(final String mapDir) {
    this.mapDir = mapDir;
  }

  /**
   * Sets the map id.
   * 
   * @param mapId
   *          the new map id
   */
  public void setMapId(final String mapId) {
    this.mapId = getValidString(mapId, 21);
  }

  /**
   * Sets the map server.
   * 
   * @param mapServer
   *          the new map server
   */
  public void setMapServer(final String mapServer) {
    this.mapServer = getValidString(mapServer, 21);
  }

  /**
   * Sets the mid.
   * 
   * @param mid
   *          the new mid
   */
  public void setMid(final String mid) {
    this.mid = getValidString(mid, 21);
  }

  /**
   * Sets the mty.
   * 
   * @param mty
   *          the new mty
   */
  public void setMty(final String mty) {
    this.mty = getValidString(mty, 1);
  }

  /**
   * Sets the new map id.
   * 
   * @param newMapId
   *          the new new map id
   */
  public void setNewMapId(final String newMapId) {
    this.newMapId = getValidString(newMapId, 21);
  }

  /**
   * Sets the operations.
   * 
   * @param operations
   *          the new operations
   */
  public void setOperations(final String operations) {
    this.operations = getValidString(operations, 21);
  }

  /**
   * Sets the pass die count.
   * 
   * @param passDieCount
   *          the new pass die count
   */
  public void setPassDieCount(final int passDieCount) {
    this.passDieCount = passDieCount;
  }

  /**
   * Sets the port.
   * 
   * @param port
   *          the new port
   */
  public void setPort(final int port) {
    this.port = port;
  }

  /**
   * Sets the pp exec name.
   * 
   * @param ppExecName
   *          the new pp exec name
   */
  public void setPpExecName(final String ppExecName) {
    this.ppExecName = getValidString(ppExecName, 33);
  }

  /**
   * Sets the probe card cont cnt.
   * 
   * @param probeCardContCnt
   *          the new probe card cont cnt
   */
  public void setProbeCardContCnt(final int probeCardContCnt) {
    this.probeCardContCnt = probeCardContCnt;
  }

  /**
   * Sets the prober name.
   * 
   * @param proberName
   *          the new prober name
   */
  public void setProberName(final String proberName) {
    this.proberName = getValidString(proberName, 33);
  }

  /**
   * Sets the product.
   * 
   * @param product
   *          the new product
   */
  public void setProduct(final String product) {
    this.product = getValidString(product, 12);
  }

  /**
   * Sets the route.
   * 
   * @param route
   *          the new route
   */
  public void setRoute(final String route) {
    this.route = getValidString(route, 21);
  }

  /**
   * Sets the secs recipe name.
   * 
   * @param secsRecipeName
   *          the new secs recipe name
   */
  public void setSecsRecipeName(final String secsRecipeName) {
    this.secsRecipeName = getValidString(secsRecipeName, 33);
  }

  /**
   * Sets the tester name.
   * 
   * @param testerName
   *          the new tester name
   */
  public void setTesterName(final String testerName) {
    this.testerName = getValidString(testerName, 15);
  }

  /**
   * Sets the test prog name.
   * 
   * @param testProgName
   *          the new test prog name
   */
  public void setTestProgName(final String testProgName) {
    this.testProgName = getValidString(testProgName, 32);
  }

  /**
   * Sets the test prog ver.
   * 
   * @param testProgVer
   *          the new test prog ver
   */
  public void setTestProgVer(final String testProgVer) {
    this.testProgVer = getValidString(testProgVer, 21);
  }

  /**
   * Sets the ugly die count.
   * 
   * @param uglyDieCount
   *          the new ugly die count
   */
  public void setUglyDieCount(final int uglyDieCount) {
    this.uglyDieCount = uglyDieCount;
  }

  /**
   * Sets the user.
   * 
   * @param user
   *          the new user
   */
  public void setUser(final String user) {
    this.user = getValidString(user, 12);
  }

  /**
   * Sets the wafer chuck temp.
   * 
   * @param waferChuckTemp
   *          the new wafer chuck temp
   */
  public void setWaferChuckTemp(final int waferChuckTemp) {
    this.waferChuckTemp = waferChuckTemp;
  }

  /**
   * Sets the wafer flat angle.
   * 
   * @param waferFlatAngle
   *          the new wafer flat angle
   */
  public void setWaferFlatAngle(final int waferFlatAngle) {
    this.waferFlatAngle = waferFlatAngle;
  }

}
