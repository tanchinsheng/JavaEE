/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/* HISTORY */
// - 1.0.0 - Apr 16, 2011 6:24:25 PM - duytv - Initialize version
/********************************************************************************/
package com.st.common;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class EncryptionUtils {

	private static SecretKeySpec sk;
	private static final String ALGORITHM = "AES";

	static {
		try {
			//KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);
			//kgen.init(128); // 192 and 256 bits may not be available
			// Generate the secret key specs.
			//SecretKey skey = kgen.generateKey();
			byte[] raw = new byte[] { 38, 79, -126, 116, 30, 68, 126, 119, 22,
					22, 83, -67, -31, -43, 81, -55 };
			sk = new SecretKeySpec(raw, ALGORITHM);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Private constructor Constructor
	 */
	private EncryptionUtils() {
	}

	/**
	 * Encrypts input into byte array.
	 * 
	 * @param input
	 * @return encrypted message
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws Exception
	 */
	public static byte[] encrypt(byte[] input) throws NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, sk);
		return cipher.doFinal(input);
	}

	/**
	 * Decrypts byte array into String.
	 * 
	 * @param encryptionBytes
	 * @return decrypted message
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws InvalidKeyException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws Exception
	 */
	public static byte[] decrypt(byte[] encryptionBytes)
			throws IllegalBlockSizeException, BadPaddingException,
			InvalidKeyException, NoSuchAlgorithmException,
			NoSuchPaddingException {
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, sk);
		return cipher.doFinal(encryptionBytes);
	}

	/**
	 * Encrypts input into byte array.
	 * @param input
	 * @return encrypted message
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws UnsupportedEncodingException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws Exception
	 */
	public static String encrypt(String input)
			throws UnsupportedEncodingException, IllegalBlockSizeException,
			BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeyException {

		if (input == null) {
			return null;
		}
		// ENCODE input String
		byte[] byteArr = input.getBytes("UTF8");
		Cipher cipher = Cipher.getInstance(ALGORITHM); // cipher is not thread
													   // safe
		cipher.init(Cipher.ENCRYPT_MODE, sk);
		String encrypedPwd = new String(Base64.encodeBase64(cipher
				.doFinal(byteArr)), "UTF-8");
		return encrypedPwd;
	}

	/**
	 * Decrypts byte array into String.
	 * @param encrypted
	 * @return
	 * @throws NoSuchPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws UnsupportedEncodingException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws InvalidKeyException
	 * @throws Exception
	 */
	public static String decrypt(String encrypted)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			UnsupportedEncodingException, IllegalBlockSizeException,
			BadPaddingException, InvalidKeyException {

		if (encrypted == null) {
			return null;
		}
		// DECODE encrypted String
		byte[] encrypedPwdBytes = Base64.decodeBase64(encrypted
				.getBytes("UTF-8"));
		Cipher cipher = Cipher.getInstance(ALGORITHM);// cipher is not thread
													  // safe
		cipher.init(Cipher.DECRYPT_MODE, sk);
		byte[] original = (cipher.doFinal(encrypedPwdBytes));
		return new String(original, "UTF8");
	}
}
