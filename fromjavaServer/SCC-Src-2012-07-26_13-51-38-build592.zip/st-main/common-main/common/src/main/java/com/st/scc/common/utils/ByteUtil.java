/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Nov 16, 2011 1:50:12 PM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ByteUtil {
  /**
   * Convert integer number to byte array.
   * 
   * @param input
   *          the input
   * @return the byte array
   */
  public static byte[] fromInt(final int input) {
    final byte[] output = new byte[4];
    output[0] = (byte) (input >> 24);
    output[1] = (byte) (input >> 16);
    output[2] = (byte) (input >> 8);
    output[3] = (byte) input;
    return output;
  }

  /**
   * To byte array.
   * 
   * @param object
   *          the object
   * @return the byte[]
   */
  public static byte[] toByteArray(final Object object) {
    final ByteArrayOutputStream bos = new ByteArrayOutputStream(512);
    ObjectOutputStream oos = null;
    try {
      oos = new ObjectOutputStream(bos);
      oos.writeObject(object);
      oos.flush();
    } catch (final IOException ex) {
      // do nothing for improving performance
    } finally {
      if (oos != null) {
        try {
          oos.close();
        } catch (final IOException ex) {
          // do nothing for improving performance
        }
      }
    }
    return bos.toByteArray();
  }

  /**
   * Convert byte array to integer.
   * 
   * @param input
   *          the input
   * @return the integer
   */
  public static int toInt(final byte[] input) {
    assert input.length == 4 : "toInt(): Byte array length must be 4.";
    int output = 0;
    output =
        (input[0] & 0xff) << 24 | (input[1] & 0xff) << 16 | (input[2] & 0xff) << 8 | input[3]
            & 0xff;
    return output;
  }

  /**
   * To object.
   * 
   * @param bytes
   *          the bytes
   * @return the object
   */
  public static Object toObject(final byte[] bytes) {
    Object obj = null;
    final ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
    ObjectInputStream ois = null;
    try {
      ois = new ObjectInputStream(bis);
      obj = ois.readObject();
    } catch (final Exception ex) {
      // do nothing for improving performance
    } finally {
      if (ois != null) {
        try {
          ois.close();
        } catch (final IOException e) {
          // do nothing for improving performance
        }
      }
    }
    return obj;
  }

  /**
   * Instantiates a new byte utility.
   */
  private ByteUtil() {

  }
}
