/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Jun 14, 2011 10:48:09 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import com.st.common.beans.FileInfo;
import com.st.common.beans.FileTypeEnum;

/**
 * The Class ComparisonUtils.
 * 
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class ComparisonUtils {

  /**
   * Compare.
   * 
   * @param a
   *          the a
   * @param b
   *          the b
   * @return true, if successful
   */
  public static boolean compare(final String a, final String b) {
    boolean result;
    if (a != null) {
      result = a.equals(b);
    } else {
      result = b == null;
    }
    return result;
  }

  /**
   * compare two hosts.
   * 
   * @param a
   *          the a
   * @param b
   *          the b
   * @return true, if successful
   */
  public static boolean compareSameServer(final FileInfo a, final FileInfo b) {
    boolean result = false;
    if (a != null && b != null) {
      if (a.getFileType() == FileTypeEnum.NFS) {
        result = false;
      } else {
        if (compare(a.getHost(), b.getHost()) && compare(a.getUserName(), b.getUserName())
            && compare(a.getPassWord(), b.getPassWord()) && a.getFileType() == b.getFileType()
            && a.getPort() == b.getPort()) {
          result = true;
        } else {
          result = false;
        }
      }
    }
    return result;
  }

  /**
   * Instantiates a new comparison utility.
   */
  private ComparisonUtils() {

  }
}
