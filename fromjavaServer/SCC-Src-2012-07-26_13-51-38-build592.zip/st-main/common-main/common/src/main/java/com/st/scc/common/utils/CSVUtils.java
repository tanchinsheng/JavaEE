/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/* HISTORY */
// - 1.0.0 - Sep 14, 2011 5:05:02 PM - duytv - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All
 *         rights reserved.
 */
public final class CSVUtils {

	/**
	 * Private constructor.
	 */
	private CSVUtils() {

	}
	/**
	 * Writes data to csv file.
	 * 
	 * @param fileName
	 *            file path
	 * @param data
	 * @throws IOException
	 */
	public static void writeCsv(final String fileName, final String[] header,
			final List<Object[]> data) throws IOException {

		if (fileName == null || data == null || data.size() == 0) {
			return;
		}
		FileWriter writer = new FileWriter(fileName);
		
		if (header != null) {
			for (int j = 0; j < header.length; j++) {
				String value = header[j] != null ? header[j].trim() : "";
				writer.append("\"" + value + "\"");
				if (j < header.length - 1) {
					writer.append(',');
				} else {
					writer.append('\n');
				}
			}
		}
		for (Object[] arr : data) {
			for (int j = 0; j < arr.length; j++) {
				String value = arr[j] != null ? arr[j].toString().trim() : "";
				writer.append("\"" + value + "\"");
				if (j < arr.length - 1) {
					writer.append(',');
				} else {
					writer.append('\n');
				}
			}
		}
		writer.flush();
		writer.close();
	}
}
