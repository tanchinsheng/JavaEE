/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2011.                                                  */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - May 28, 2011 11:24:08 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.scc.common.utils;

import junit.framework.TestCase;

/**
 * The Class HexUtilsTest.
 *
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2011. All rights reserved.
 */
public class HexUtilsTest extends TestCase {
	
	/**
	 * Test convert int to hex.
	 */
	public void testConvertIntToHex() {
		assertEquals("500 to hex", "01F4", HexUtils.convertIntToHex(500, 4));
		assertEquals("18000 to hex", "4650", HexUtils.convertIntToHex(18000, 4));
		assertEquals("18000 to hex", "4650", HexUtils.convertIntToHex(18000, 3));
		assertEquals("18000 to hex", "004650", HexUtils.convertIntToHex(18000, 6));
	}
}
