/********************************************************************************/
/*                              SCC Package                                     */
/* Copyright (c) by ITAC Singapore, STMicroelectronics Ltd. MCC Singapore       */
/* STMicroelectronics Ltd 2012.                                                 */
/*                                                                              */
/* Warning: This computer program is protected by copyright law and             */
/* international treaties. Unauthorized reproduction or distribution            */
/* of this program, or any portion of it, may result in severe civil            */
/* and criminal penalties, and will be prosecuted of the maximum                */
/* extent possible under the law                                                */
/*                                                                              */
/********************************************************************************/
/*                                DESCRIPTION                                   */
/*                                                                              */
/* SCC package consists of 3 modules:                                           */
/* - 1st module is the STDF Manager (SM) which functions as a Extractor/Loader/ */
/*   Repair/Enrich with an Administrative Maintenance features                  */
/* - 2nd module is the STDF Checker which perform STDF file checking base on    */
/*   user given rule and an Administrative Maintenance features                 */
/* - 3rd module is the SCC Web-based application. SCC application is described  */
/*   as a tool to display after the wafer end, a general trend chart for wafer  */
/*   Yield, with some statically limit (average +/- sigma) and display some OCAP*/
/*   in case of OUT of control.                                                 */
/********************************************************************************/
/*                                 HISTORY                                      */
//- 1.0.0 - Feb 25, 2012 11:53:37 AM - trungtb - Initialize version
/********************************************************************************/
package com.st.common.mail;

import javax.mail.MessagingException;

import junit.framework.TestCase;

/**
 * @author Copyright &copy; by MCC Singapore STMicroelectronics Ltd 2012. All
 *         rights reserved.
 */
public class MailUtilManualTest extends TestCase {

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#setUp()
   */
  protected void setUp() throws Exception {
    super.setUp();
  }

  /**
   * {@inheritDoc}
   * 
   * @see junit.framework.TestCase#tearDown()
   */
  protected void tearDown() throws Exception {
    super.tearDown();
  }

  /**
   * Test method for
   * {@link com.st.common.mail.MailUtil#sendMail(MailItem, SMTPServerInfo)}
   * .
   */
  public void testSendMailMailItemSMTPServerInfo() {
    SMTPServerInfo serverInfo = new SMTPServerInfo();
    serverInfo.setHost("prjmail.cybersoft.vn");
    MailItem mailItem = new MailItem();
    mailItem.setFrom("duytv@gvn-vn.com");
    mailItem.setFromDisplayName("Duy Vo Truong");
    mailItem.setSubject("[SC] Chinh Do");
    mailItem.setTo("nhatvn@gcs-vn.com, chinhddt@gcs-vn.com");
    mailItem.setMessage("SC Message");
    try {
      MailUtil.sendMail(mailItem, serverInfo);
    } catch (MessagingException e) {
      e.printStackTrace();
      fail(e.getMessage());
    }
  }

}
