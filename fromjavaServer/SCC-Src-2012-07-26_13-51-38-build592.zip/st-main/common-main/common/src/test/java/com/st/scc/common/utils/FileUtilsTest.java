package com.st.scc.common.utils;

import junit.framework.TestCase;

/**
 * The Class FileUtilsTest.
 */
public class FileUtilsTest extends TestCase {

  /**
   * Test get file name.
   */
  public void testGetFileName() {
    assertEquals("File name 01", "hui.abc", FileUtils.getFileName("/aaa/ffff/hui.abc"));
    assertEquals("File name 02", "hui", FileUtils.getFileName("/aaa/ffff/hui"));
    assertEquals("File name 03", "hui", FileUtils.getFileName("hui"));
    assertEquals("File name 04", "hui", FileUtils.getFileName("/hui"));
    assertEquals("File name 05", "", FileUtils.getFileName("/hui/"));
    assertEquals("File name 06", "hui.abc", FileUtils.getFileName("C:\\aaa\\ffff\\hui.abc"));
  }

  /**
   * Test get parent.
   */
  public void testGetParent() {
    assertEquals("Parent 01", "/aaa/ffff", FileUtils.getParent("/aaa/ffff/hui.abc"));
    assertEquals("Parent 02", "/aaa/ffff", FileUtils.getParent("/aaa/ffff/hui"));
    assertEquals("Parent 03", "", FileUtils.getParent("hui"));
    assertEquals("Parent 04", "", FileUtils.getParent("/hui"));
    assertEquals("Parent 05", "/hui", FileUtils.getParent("/hui/"));
    assertEquals("Parent 01", "/aaa/ffff", FileUtils.getParent("/aaa/ffff/hui.abc"));
    assertEquals("Parent 06", "C:\\aaa\\ffff", FileUtils.getParent("C:\\aaa\\ffff\\hui.abc"));
  }

}
